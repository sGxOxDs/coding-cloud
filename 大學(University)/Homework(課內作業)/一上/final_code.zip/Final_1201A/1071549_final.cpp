#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };


struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

char departureTimes[35][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30"};


// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

int inputAnInteger(int begin, int end) {
	char in[3] = {};
	int num = 0;
	cin >> in;
	if (in[1] == '\0' && (in[0] >= '0' && in[0] <= '9')) {
		num = in[0] - '0';
		if (num <= end && num >= begin)
			return num;
		else return -1;
	}
	else if (in[2] == '\0' && (in[0] >= '0' && in[0] <= '9') && (in[1] >= '0' && in[1] <= '9')) {
		num=(in[0]-'0')*10+(in[1]-'0');
		if (num <= end && num >= begin)
			return num;
		else return -1;
	}
	else return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]) {
	Reservation reservation;

	int departureTime, numSouthboundTrains, numNorthboundTrains;
	inputReservationDetails(reservation, departureTime);
	if (reservation.originStation < reservation.destinationStation) {
		loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
	}
	else {
		loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);
	}
	inputContactInfo(reservation);
	saveReservation(reservation);
	return;
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime) {
	int origin = 0,destination=0,carClass=0, departureTime1 = 0,adult=0,concession=0;
	char departureDate[12] = {};
	bool judge_st;
	string station[13] = { "0","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua"
,"Yunlin","chiayi","Tainan","Zuoying" };
	cout << "\n\nOrigin Stating";        //input origin station
	for (int n = 1; n < 13; n++) {
		cout <<"\n"<< n << ". " << station[n];
	}
	do {
		cout << "\n? ";
		origin = inputAnInteger(1, 12);
	} while (origin == -1);
	cout << "\n\nDestination Station";     //input destination station
	for (int n = 1; n < 13; n++) {
		cout << "\n" << n << ". " << station[n];
	}
	do {
		cout << "\n? ";
		destination = inputAnInteger(1, 12);
		if (destination == origin)
			judge_st = true;
		else if (destination == -1)
			judge_st = true;
		else judge_st = false;
	} while (judge_st);
	cout << "\n\nCar Class";       //input CarClass
	cout << "\n1. Standard Car\n2. Business Car";
	do {
		cout << "\n? ";
		carClass = inputAnInteger(1, 2);
	} while (carClass  == -1);
	cout << "\n\nDeparture Date: ";     //input Departure Date 
	cin >> departureDate;
	cout << "\n\nDeparture Time";     //input Departure Time
	for (int n = 1; n < 34; n++) {
		cout << "\n" << n << ". " << departureTimes[n];
	}
	do {
		cout << "\n? ";
		departureTime1 = inputAnInteger(1, 32);
	} while (departureTime1== -1);
	do {
		do {                      //input adultnum
			cout << "\n\nHow many adult tickets? ";
			cin >> adult;
		} while (adult < 0);
		do {                      //input concessionnum
			cout << "\n\nHow many concession tickets? ";
			cin >> concession;
		} while (concession < 0);
	} while (adult == 0 && concession == 0);
	strcpy_s(reservation.date, departureDate);
	reservation.originStation = origin;
	reservation.destinationStation = destination;
	reservation.carClass = carClass;
	reservation.adultTickets = adult;
	reservation.concessionTickets = concession;
	departureTime = departureTime1;
}

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) {
	ifstream inFile;
	inFile.open("Southbound timetable.txt", ios::in);
	if (!inFile)
		cerr << "\nSouthbound timetable.txt is not load!!!";
	int n = 0;
	while (!inFile.eof()) {
		inFile >> southboundTimetable[n].trainNumber;
		for (int i = 1; i < 13; i++)
			inFile >> southboundTimetable[n].departureTimes[i];
		n++;
	}
	numSouthboundTrains = n;
	inFile.close();
}

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) {
	ifstream inFile;
	inFile.open("Northbound timetable.txt", ios::in);
	if (!inFile)
		cerr << "\nNorthbound timetable.txt is not load!!!";
	int n = 0;
	while (!inFile.eof()) {
		inFile >> northboundTimetable[n].trainNumber;
		for (int i = 1; i < 13; i++)
			inFile >> northboundTimetable[n].departureTimes[i];
		n++;
	}
	numNorthboundTrains = n;
	inFile.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime) {
	char station[13][12] = { "0","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua"
,"Yunlin","chiayi","Tainan","Zuoying" };
	char carClass[12] = {};
	if (reservation.carClass == 1) {
		char carClass1[12] = { "Standard" };
		strcpy_s(carClass, carClass1);
	}
	else {
		char carClass1[12] = { "Business" };
		strcpy_s(carClass, carClass1);
	}
	int choice;
	int n = 0,i = 0;
	bool judge = false, selettrainnum = false;
	cout << "\n\n" << setw(10) << "Train No." << setw(12) << "Departure" << setw(10) << "Arrival";
	while (n < 10) {
		for (int j = 0; j < 5; j++) {
			if (southboundTimetable[i].departureTimes[reservation.originStation][j] >= departureTimes[departureTime][j]
				&&strcmp(southboundTimetable[i].departureTimes[reservation.destinationStation],"-")!=0&&
				strcmp(southboundTimetable[i].departureTimes[reservation.originStation], "-") != 0) {
				cout << "\n" << setw(10) << southboundTimetable[i].trainNumber
					<< setw(12) << southboundTimetable[i].departureTimes[reservation.originStation]
					<< setw(10) << southboundTimetable[i].departureTimes[reservation.destinationStation];
				n++;
			}
		}
		i++;
	}

		cout<<"\n\nEnter Train Number: ";
		cin >> reservation.trainNumber;

	cout << "\n\nTrip Details";
	display(reservation, southboundTimetable, station, carClass);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) {
	char station[13][12] = { "0","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua"
,"Yunlin","chiayi","Tainan","Zuoying" };
	char carClass[12] = {};
	if (reservation.carClass == 1) {
		char carClass1[12] = { "Standard" };
		strcpy_s(carClass, carClass1);
	}
	else {
		char carClass1[12] = { "Business" };
		strcpy_s(carClass, carClass1);
	}
	int choice;
	int n = 0, i = 0;
	bool judge = false, selettrainnum = false;
	cout << "\n\n" << setw(10) << "Train No." << setw(12) << "Departure" << setw(10) << "Arrival";
	while (n < 10) {
		for (int j = 0; j < 5; j++) {
			if (northboundTimetable[i].departureTimes[reservation.originStation][j] >= departureTimes[departureTime][j]
				&& strcmp(northboundTimetable[i].departureTimes[reservation.destinationStation], "-") != 0&&
				strcmp(northboundTimetable[i].departureTimes[reservation.originStation], "-") != 0) {
				judge = true;
				break;
			}
		}
		if (judge) {
			cout << "\n" << setw(10) << northboundTimetable[i].trainNumber
				<< setw(12) << northboundTimetable[i].departureTimes[reservation.originStation]
				<< setw(10) << northboundTimetable[i].departureTimes[reservation.destinationStation];
			n++;
		}
		i++;
	}


		cout<<"\n\nEnter Train Number: ";
		cin >> reservation.trainNumber;


	cout << "\n\nTrip Details";
	display(reservation, northboundTimetable, station, carClass);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation) {
	char num[12] = {};
	for (int n = 0; n < 9; n++)
		num[n] = rand() % 10 + '0';
	cout << "\n\nEnter Contact Person Information";
	cout << "\n\nID Number: ";
	cin >> reservation.idNumber;
	cout << "\n\nPhone: ";
	cin >> reservation.phone;
	cout << "\n\nReservation Number: " << num;
	strcpy_s(reservation.reservationNumber,num);
	cout << "\n\nReservation Completed!";

}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation) {
	ofstream outFile;
	outFile.open("details.dat", ios::in | ios::binary | ios::app);
	outFile.write(reinterpret_cast<char *> (&reservation), sizeof(reservation));
	outFile.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]) {
	fstream ioFile;
	ioFile.open("details.dat", ios::in | ios::out | ios::binary);
	if (!ioFile)
		cerr << "details could not open!!!";
	Reservation reservation;
	if (!existReservation(ioFile, reservation)) {
		cout << "not find data";
		return;
	}
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	cout << "\n\nEnter Your Choice" << "\n1. Cancellation"<<"\n2. Reduce"<<"\n3. End";
	int choice2=0;
	do {
		cout << "\n? ";
	} while (choice2 == -1);
	switch (choice2) {
	case 1: {
		strcpy_s(reservation.reservationNumber, "\0");
		strcpy_s(reservation.trainNumber, "\0");
		strcpy_s(reservation.idNumber, "\0");
		strcpy_s(reservation.phone, "\0");
		strcpy_s(reservation.date, "\0");
		reservation.originStation = 0;
		reservation.destinationStation = 0;
		reservation.carClass = 0;
		reservation.adultTickets = 0;
		reservation.concessionTickets = 0;
		Reservation tmp_reservation;
		ioFile.seekp(0, ios::beg);
		ioFile.seekg(0, ios::beg);
		ioFile.clear();
		while (!ioFile.eof()) {
			ioFile.read(reinterpret_cast<char*>(&tmp_reservation), sizeof(tmp_reservation));
			if (reservation.idNumber == tmp_reservation.idNumber
				&& reservation.reservationNumber == tmp_reservation.reservationNumber) {
				break;
			}
		}
		int x = sizeof(reservation);
		ioFile.seekg(-x, ios::cur);
		ioFile.seekp(ioFile.tellg(), ios::beg);
		ioFile.write(reinterpret_cast<char*>(&reservation), sizeof(reservation));
		cout << "\n\nReservation Cancelled!";
	}
	case 2:
		reduceSeats(ioFile, southboundTimetable, northboundTimetable, reservation);
	case 3:
		return;
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation) {
	char id[12] = {}, num[12] = {};
	cout << "\n\nEnter Id Number: ";
	cin >> id;
	cout << "\n\nEnter Reservation Number: ";
	cin >> num;
	bool judge = false;
	while (!ioFile.eof()) {
		ioFile.read(reinterpret_cast<char*>(&reservation), sizeof(reservation));
		if (reservation.idNumber == id && reservation.reservationNumber == num) {
			judge = true;
			break;
		}
	}
	return judge;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation) {
	
	int numSouthboundTrains ,numNorthboundTrains;
	char station[13][12] = { "0","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua"
,"Yunlin","chiayi","Tainan","Zuoying" };
	char carClass[12] = {};
	if (reservation.carClass == 1) {
		char carClass1[12] = { "Standard" };
		strcpy_s(carClass, carClass1);
	}
	else {
		char carClass1[12] = { "Business" };
		strcpy_s(carClass, carClass1);
	}
	if (reservation.originStation < reservation.destinationStation) {
		loadNorthboundTimetable(southboundTimetable, numSouthboundTrains);
		display(reservation, southboundTimetable, station, carClass);
	}
	else {
		loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
		display(reservation, northboundTimetable, station, carClass);
	}
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]) {
	cout << "\n\n" << setw(10) << "Date" << setw(12) << "Train No." << setw(8) << "Form"
		<< setw(10) << "To" << setw(11) << "Departure" << setw(10) << "Arrival" << setw(8) << "Adult"
		<< setw(12) << "Concession" << setw(6) << "Fare" << setw(10) << "Class";
	cout << "\n" << setw(10) << reservation.date << setw(12) << reservation.trainNumber << setw(8) <<
		stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation];
	for (int n = 0; trainTimetable[n].trainNumber != reservation.trainNumber; n++) {
		if (trainTimetable[n].trainNumber == reservation.trainNumber) {
			cout << setw(11) << trainTimetable[n].departureTimes[reservation.originStation]
				<< setw(10) << trainTimetable[n].departureTimes[reservation.destinationStation];
		}
	}
	int total = 0;
	total = adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets
		+ adultTicketPrice[reservation.destinationStation][reservation.originStation] * 0.5 * reservation.concessionTickets;
	cout << setw(8) << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*"
		<< reservation.adultTickets << setw(12)
		<< adultTicketPrice[reservation.destinationStation][reservation.originStation] * 0.5 << "*"
		<< reservation.concessionTickets << setw(6) << total << setw(10) << carClass;

}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation) {
	char station[13][12] = { "0","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua"
,"Yunlin","chiayi","Tainan","Zuoying" };
	char carClass[12] = {};
	if (reservation.carClass == 1) {
		char carClass1[12] = { "Standard" };
		strcpy_s(carClass, carClass1);
	}
	else {
		char carClass1[12] = { "Business" };
		strcpy_s(carClass, carClass1);
	}

	int adu = 0, con = 0;
	Reservation tmp_reservation;
	cout << "\n";
	do {
		cout << "\nHow many adult tickets to cancel�H";
		adu = inputAnInteger(0, reservation.adultTickets);
	} while (adu  == -1);
	do {
		cout << "\nHow many concession tickets to cancel�H";
		con = inputAnInteger(0, reservation.concessionTickets);
	} while (con  == -1);
	reservation.adultTickets -= adu;
	reservation.concessionTickets -= con;
	ioFile.seekp(0, ios::beg);
	ioFile.seekg(0, ios::beg);
	ioFile.clear();
	while (!ioFile.eof()) {
		ioFile.read(reinterpret_cast<char*>(&tmp_reservation), sizeof(tmp_reservation));
		if (reservation.idNumber == tmp_reservation.idNumber
			&& reservation.reservationNumber == tmp_reservation.reservationNumber) {
			break;
		}
	}
	int x = sizeof(reservation);
	ioFile.seekg(-x, ios::cur);
	ioFile.seekp(ioFile.tellg(),ios::beg);
	ioFile.write(reinterpret_cast<char*>(&reservation), sizeof(reservation));
	if (reservation.originStation < reservation.destinationStation) {
		display(reservation, southboundTimetable, station, carClass);
	}
	else {;
		display(reservation, northboundTimetable, station, carClass);
	}
	cout << "\n\nYou have successfully reduced the number of tickets!";
}
