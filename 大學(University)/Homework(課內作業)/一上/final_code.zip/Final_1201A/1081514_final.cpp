#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[35][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30"};

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains, Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100], char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char input;
	cin >> input;
	if (input - '0'<begin || input - '0'>end) return -1;
	else return (input - '0');
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;
	int departureTime;
	inputReservationDetails(reservation, departureTime);
	if (reservation.originStation - reservation.destinationStation < 0)
		selectSouthboundTrain(southboundTimetable, sizeof(southboundTimetable), reservation, departureTime);
	else if (reservation.originStation - reservation.destinationStation > 0)
		selectNorthboundTrain(northboundTimetable, sizeof(northboundTimetable), reservation, departureTime);
	else inputReservationDetails(reservation, departureTime);
	inputContactInfo(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	do {
		int input_origin;
		cout << "Origin Station" << endl;
		cout << "1. Nangang\n"
			<< "2. Taipei\n"
			<< "3. Banqiao\n"
			<< "4. Taoyuan\n"
			<< "5. Hsinchu\n"
			<< "6. Miaoli\n"
			<< "7. Taichung\n"
			<< "8. Changhua\n"
			<< "9. Yunlin\n"
			<< "10. Chiayi\n"
			<< "11. Tainan\n"
			<< "12. Zuoying\n";
		do {
			cout << "?";
		} while (input_origin = (inputAnInteger(1, 12) == -1));
		reservation.originStation = input_origin;

		int input_destination;
		cout << "Destination" << endl;
		cout << "1. Nangang\n"
			<< "2. Taipei\n"
			<< "3. Banqiao\n"
			<< "4. Taoyuan\n"
			<< "5. Hsinchu\n"
			<< "6. Miaoli\n"
			<< "7. Taichung\n"
			<< "8. Changhua\n"
			<< "9. Yunlin\n"
			<< "10. Chiayi\n"
			<< "11. Tainan\n"
			<< "12. Zuoying\n";
		do {
			cout << "?";
		} while (input_destination = (inputAnInteger(1, 12) == -1));
		reservation.destinationStation = input_destination;
	} while (reservation.destinationStation == reservation.originStation);

	int input_carclass;
	cout << "Car Class" << endl;
	cout << "1. Standard Car\n"
		<< "2. Business Car\n";
	do {
		cout << "?";
	} while (input_carclass = (inputAnInteger(1, 2) == -1));
	reservation.carClass = input_carclass;

	string input_date;
	cout << "Departure Date: ";
	cin >> input_date;
	cout << input_date << endl;

	cout << "Departure Time" << endl;
	for (int i = 1; i < 35; i++)
		cout << i << ". " << departureTimes[i] << endl;
	do {
		cout << "?";
	} while (departureTime = (inputAnInteger(1, 34) == -1));

	do {
		int input_adultticket;
		cout << "Hoe many adult tickets? ";
		cin >> input_adultticket;
		reservation.adultTickets = input_adultticket;

		int input_concessionticket;
		cout << "Hoe many concession tickets? ";
		cin >> input_concessionticket;
		reservation.concessionTickets = input_concessionticket;
	} while ((reservation.adultTickets + reservation.concessionTickets) <= 0);
}

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inFile_south("Southbound timetable.txt");

	char buffer[8];
	while (inFile_south >> buffer) {
		if (numSouthboundTrains % 14 == 1) southboundTimetable[numSouthboundTrains].trainNumber = buffer;
		else
			for (int count = 0; count < 13; count++)
				southboundTimetable[numSouthboundTrains].departureTimes[count] = buffer;
		cout << buffer << endl;
		numSouthboundTrains++;
	}
	inFile_south.close();
}

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inFile_north("Northbound timetable.txt");

	char buffer[8];
	while (inFile_north >> buffer) {
		if (numNorthboundTrains % 14 == 1) northboundTimetable[numNorthboundTrains].trainNumber = buffer;
		else
			for (int count = 0; count < 13; count++)
				northboundTimetable[numNorthboundTrains].departureTimes[count] = buffer;
		cout << buffer << endl;
		numNorthboundTrains++;
	}
	inFile_north.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains, Reservation& reservation, int departureTime)
{
	char station[13][12] = {
	 "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu",
	  "Miaoli","Taichung","Changhua","Yunlin","Chiayi",
	 "Tainan","Zuoying"
	};
	char carClass[12];
	if (reservation.carClass == 1)	carClass = "Standard";
	else carClass = "Business";
	int start = 0;
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	cout << setw(10) << right << "Train No." << "Departure" << "Arrival" << endl;
	for (int j = 0; j < numSouthboundTrains; j++) {
		for (int i = departureTime; i < 13; i++) {
			if (departureTimes[departureTime] < southboundTimetable[j].departureTimes[i] && start <= 10) {
				cout << setw(10) << right << southboundTimetable[j].trainNumber
					<< setw(10) << right << southboundTimetable[j].departureTimes[i]
					<< setw(10) << right << southboundTimetable[j].departureTimes[reservation.destinationStation - reservation.originStation] << endl;
				start++;
				break;
			}
		}
		if (start >= 10) break;
	}
	cout << "Enter Train Number: ";
	cin >> reservation.trainNumber;
	display(reservation, southboundTimetable, station, carClass);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, Reservation& reservation, int departureTime)
{
	char station[13][12] = {
	 "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu",
	  "Miaoli","Taichung","Changhua","Yunlin","Chiayi",
	 "Tainan","Zuoying"
	};
	char carClass[12];
	if (reservation.carClass == 1)	carClass = "Standard";
	else carClass = "Business";
	int start = 0;
	loadSouthboundTimetable(northboundTimetable, numNorthboundTrains);
	cout << setw(10) << right << "Train No." << "Departure" << "Arrival" << endl;
	for (int j = 0; j < numNorthboundTrains; j++) {
		for (int i = departureTime; i < 13; i++) {
			if (departureTimes[departureTime] < northboundTimetable[j].departureTimes[i] && start <= 10) {
				cout << setw(10) << right << northboundTimetable[j].trainNumber
					<< setw(10) << right << northboundTimetable[j].departureTimes[i]
					<< setw(10) << right << northboundTimetable[j].departureTimes[reservation.destinationStation - reservation.originStation] << endl;
				start++;
				break;
			}
		}
		if (start >= 10) break;
	}
	cout << "Enter Train Number: ";
	cin >> reservation.trainNumber;
	display(reservation, southboundTimetable, station, carClass);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "Enter Contact Information" << endl;
	cout << "ID Number: ";
	cin >> reservation.idNumber;

	cout << "Phone: " << endl;
	cin >> reservation.phone;

	cout << "Reservation Number: " << endl;
	cin >> reservation.reservationNumber;

	fstream outFile("details.dat", ios::binary);
	if (!(existReservation(outFile,reservation))) saveReservation(reservation);
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	fstream outFile("details.dat", ios::out | ios::binary);
		if (!outFile) {
			cerr << "File could not be opened." << endl;
				exit(1);
		}
		else outFile.write(reservation, sizeof(reservation));
}

void reservationHistory(Train southboundTimetable[100], Train northboundTimetable[100])
{
	fstream outFile("details.dat");
	char IDNumber[12], reservationNumber[12];
	cout << "Enter ID Number: ";
	cin >> IDNumber;
	cout << "Enter Reservation Number: ";
	cin >> reservationNumber;
	if(existReservation(outFile,reservation))
		displayReservations(southboundTimetable, northboundTimetable, reservation);

	cout << "Enter Your Choice" << endl;
	cout << "1. Cancellation\n"
		<< "2. Reduce\n"
		<< "3. End\n";
	int choice;
	do {
		cout << "?";
	} while (choice=inputAnInteger(1, 3) == -1);
	switch (choice) {
	case 1:
		cout << "Reservation Cancelled!" << endl;
		break;
	case 2: 
		reduceSeats(outFile, southboundTimetable, northboundTimetable, reservation);
		break;
	case 3:
		return;
		break;
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	char buffer[12];
	while (ioFile >> buffer) {
		if (reservation.idNumber == buffer) return true;
		ioFile >> buffer;
		if (reservation.reservationNumber == buffer) return true;
	}
	return false;
}


void displayReservations(Train southboundTimetable[100], Train northboundTimetable[100], Reservation reservation)
{
	char station[13][12] = {
	 "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu",
	  "Miaoli","Taichung","Changhua","Yunlin","Chiayi",
	 "Tainan","Zuoying"
	};
	char carClass[12];
	cout << "Reservation Details" << endl;
	if (reservation.carClass == 1)	carClass = "Standard";
	else carClass = "Business";
	if (reservation.originStation > reservation.destinationStation) display(reservation, northboundTimetable, station, carClass);
	else  display(reservation, southboundTimetable, station, carClass);
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100], char stations[13][12], char carClass[12])
{
	int trainNumber = 0;
	for (int i = 0; i < 100; i++) if (trainTimetable[i].trainNumber == reservation.trainNumber) {
		trainNumber = i;
		break;
	}
	int north_station, south_station;
	if (reservation.originStation > reservation.destinationStation) {
		north_station = reservation.destinationStation;
		south_station = reservation.originStation;
	}
	else {
		north_station = reservation.originStation;
		south_station = reservation.destinationStation;
	}
	int adultPrice, concessionPrice;
	if (carClass == "Standard") adultPrice = adultTicketPrice[south_station][north_station] * reservation.adultTickets;
	else adultPrice = adultTicketPrice[north_station][south_station] * reservation.adultTickets;
	concessionPrice = adultPrice / 2;

	cout << setw(10) << right << "Date"
		<< setw(10) << right << "Train No."
		<< setw(10) << right << "From"
		<< setw(10) << right << "To"
		<< setw(10) << right << "Departure"
		<< setw(10) << right << "Arrival"
		<< setw(10) << right << "Adult"
		<< setw(10) << right << "Concession"
		<< setw(10) << right << "Fare"
		<< setw(10) << right << "Class" << endl;

	cout << setw(10) << right << reservation.date
		<< setw(10) << right << reservation.trainNumber
		<< setw(10) << right << reservation.originStation
		<< setw(10) << right << reservation.destinationStation
		<< setw(10) << right << trainTimetable[trainNumber].departureTimes[reservation.originStation]
		<< setw(10) << right << trainTimetable[trainNumber].departureTimes[reservation.destinationStation]
		<< setw(10) << right << adultPrice
		<< setw(10) << right << concessionPrice
		<< setw(10) << right << adultPrice+concessionPrice
		<< setw(10) << right << carClass << endl;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation)
{
	int adultCancel,concessionCancel;
	cout << "How many adult tickets to cancel?";
	cin >> adultCancel;
	cout << "How many concession tickets to cancel?";
	cin >> concessionCancel;

	reservation.adultTickets -= adultCancel;
	reservation.concessionTickets -= concessionCancel;

	char buffer[100];
	ioFile >> buffer;

	displayReservations(southboundTimetable, northboundTimetable, reservation);
}