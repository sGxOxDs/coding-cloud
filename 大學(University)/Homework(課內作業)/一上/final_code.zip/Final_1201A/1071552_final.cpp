#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30" };

char station[13][12] = { "","Nangang","Taipei","Banqiao",
	"Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin",
	"Chiayi","Tainan","Zuoying" };

char carClass[4][10] = { "" , "Standard","Business" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end) {
	string a;
	cin >> a;
	int num = 0;
	for (int i = 0; i < (int)a.length(); i++) {
		num *= 10;
		num += a[i] - '0';
	}
	for (int i = 0; i < a.length(); i++) 
		if ((a[i] - '0') < 0 || (a[i] - '0') > 9)return -1;

	if (num >= begin && num <= end)return num;
	else return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]) {
	Reservation reservation;
	int departureTime, numSouthboundTrains=0 , numNorthboundTrains=0;
	inputReservationDetails(reservation,departureTime);

	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);

	if (reservation.originStation < reservation.destinationStation)
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
	else
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);

	inputContactInfo( reservation);
	saveReservation(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime) {
	int choice;
	do {
		cout << "\nOrigin Station" << endl;
		cout << "1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n?";
	}while ((choice = inputAnInteger(1, 12)) == -1);
	reservation.originStation = choice;

	do {
		cout << "\n\nDestination Station" << endl;
		cout << "1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n?";
	} while ((choice = inputAnInteger(1, 12)) == -1 || choice == reservation.originStation);
	reservation.destinationStation = choice;

	do cout << "\n\nCar Class\n1. Standard Car\n2. Business Car\n?";
	while ((choice = inputAnInteger(1, 2)) == -1);
	reservation.carClass = choice;

	cout << "\n\nDeparture Date: ";
	cin >> reservation.date;

	do {
		cout << "\n\nDeparture Time\n";
		for (int i = 1; i <= 34; i++) {
			cout << std::right << setw(2) << i << ". " << departureTimes[i] << endl;
		}cout << "?";
	} while ((choice = inputAnInteger(1, 34)) == -1);
	departureTime = choice;

	do {
		do cout << "\n\nHow many adult tickets? ";
		while ((choice = inputAnInteger(0, 10000)) == -1);
		reservation.adultTickets = choice;

		do cout << "\n\nHow many concession tickets? ";
		while ((choice = inputAnInteger(0, 10000)) == -1);
		reservation.concessionTickets = choice;
	}while(reservation.concessionTickets == 0 && reservation.adultTickets == 0);
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) {
	ifstream inFile("Southbound timetable.txt", ios::in);
	if (!inFile) {
		cout << "File could not be opened." << endl;
		exit(1);
	}
	
	for (int i = 1; !inFile.eof() ; i++) {
		inFile >> southboundTimetable[i].trainNumber;
		numSouthboundTrains++;
		for (int j = 1; j <= 12; j++) {
			inFile >> southboundTimetable[i].departureTimes[j];
		}
	}
	inFile.close();
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) {
	ifstream inFile("Northbound timetable.txt", ios::in);
	if (!inFile) {
		cout << "File could not be opened." << endl;
		exit(1);
	}
	for (int i = 1; !inFile.eof(); i++) {
		inFile >> northboundTimetable[i].trainNumber;
		numNorthboundTrains++;
		for (int j = 1; j <= 12; j++) {
			inFile >> northboundTimetable[i].departureTimes[j];
		}
	}
	inFile.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime) {
	int tmp;
	cout << endl <<std::right << setw(9) <<"Train No."<< std::right << setw(11) << "Departure"<< std::right << setw(9) << "Arrival"<<endl;
	for (int i = 1; i <= numSouthboundTrains; i++) {
		if ((departureTimes[departureTime][0] - '0') * 1000 + (departureTimes[departureTime][1] - '0') * 100 +
			(departureTimes[departureTime][3] - '0') * 10 + (departureTimes[departureTime][4] - '0') <=
			((southboundTimetable[i].departureTimes[reservation.originStation][0] - '0') * 1000 +
			(southboundTimetable[i].departureTimes[reservation.originStation][1] - '0') * 100 +
				(southboundTimetable[i].departureTimes[reservation.originStation][3] - '0') * 10 +
				(southboundTimetable[i].departureTimes[reservation.originStation][4] - '0'))) {
			for (int j = i; j < i + 10; j++) {
				cout << std::right << setw(9) << southboundTimetable[j].trainNumber
					<< std::right << setw(11) << southboundTimetable[j].departureTimes[reservation.originStation]
					<< std::right << setw(9) << southboundTimetable[j].departureTimes[reservation.destinationStation] << endl;
			}
			cout << "\n\nEnter Train Number: ";
			cin >> reservation.trainNumber;
			for (int j = i; j < i + 10; j++) {
				if (strcmp(reservation.trainNumber, southboundTimetable[j].trainNumber) == 0)
					tmp = j;
			}
			break;
		}
	}
	cout << "\n\nTrip Details\n\n";
	display(reservation, southboundTimetable);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) {
	int tmp;
	cout << endl << std::right << setw(9) << "Train No." << std::right << setw(11) << "Departure" << std::right << setw(9) << "Arrival" << endl;
	for (int i = 1; i <= numNorthboundTrains; i++) {
		if ((departureTimes[departureTime][0] - '0') * 1000 + (departureTimes[departureTime][1] - '0') * 100 +
			(departureTimes[departureTime][3] - '0') * 10 + (departureTimes[departureTime][4] - '0') <=
			((northboundTimetable[i].departureTimes[reservation.originStation][0] - '0') * 1000 +
			(northboundTimetable[i].departureTimes[reservation.originStation][1] - '0') * 100 +
				(northboundTimetable[i].departureTimes[reservation.originStation][3] - '0') * 10 +
				(northboundTimetable[i].departureTimes[reservation.originStation][4] - '0'))) {
			for (int j = i; j < i + 10; j++) {
				cout << std::right << setw(9) << northboundTimetable[j].trainNumber
					<< std::right << setw(11) << northboundTimetable[j].departureTimes[reservation.originStation]
					<< std::right << setw(9) << northboundTimetable[j].departureTimes[reservation.destinationStation] << endl;
			}
			cout << "\n\nEnter Train Number: ";
			cin >> reservation.trainNumber;
			for (int j = i; j < i + 10; j++) {
				if (strcmp(reservation.trainNumber, northboundTimetable[j].trainNumber) == 0)
					tmp = j;
			}
			break;
		}
	}

	cout << "\n\nTrip Details\n\n";
	display(reservation, northboundTimetable);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation) {
	cout << "\n\nEnter Contact Person Information ";
	cout << "\n\nID Number: ";
	cin >> reservation.idNumber;
	cout << "\nPhone: ";
	cin >> reservation.phone;
	cout << "\nReservation Number: ";

	srand(time(0));
	int x1 = rand();
	int x2 = rand();
	int x3 = rand();
	int x4 = rand();
	int x5 = rand();
	int x6 = rand();
	int x7 = rand();
	int x8 = rand();
	
	char a[10] = { '0','1','2','3','4','5','6','7','8','9' };
	reservation.reservationNumber[0] = a[x1 % 10];
	reservation.reservationNumber[1] = a[x2 % 10];
	reservation.reservationNumber[2] = a[x3 % 10];
	reservation.reservationNumber[3] = a[x4 % 10];
	reservation.reservationNumber[4] = a[x5 % 10];
	reservation.reservationNumber[5] = a[x6 % 10];
	reservation.reservationNumber[6] = a[x7 % 10];
	reservation.reservationNumber[7] = a[x8 % 10];

	for (int i = 0; i < 8; i++) {
		cout << reservation.reservationNumber[i];
	}
	
	reservation.reservationNumber[8] = '\0';
	cout << "\n\nReservation Completed!\n\n\n";
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation) {
	fstream ioFile("details.dat", ios::in | ios::out | ios::binary | ios::app);
	if (!ioFile) {
		ofstream outFile("details.dat", ios::out | ios::binary);
	}
	ioFile.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
	ioFile.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]) {
	fstream ioFile("details.dat", ios::in | ios::out | ios::binary);
	Reservation tmp;

	if(existReservation(ioFile, tmp)){
		displayReservations(southboundTimetable, northboundTimetable, tmp);
	}
	else
		cout << "\nReservation record not found." << endl;
	
	int choice;
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			tmp.adultTickets = 0;
			tmp.concessionTickets = 0;
			saveReservation(tmp);
			cout << "Reservation Cancelled!  \n\n\n";
			//displayReservations(southboundTimetable, northboundTimetable, tmp);
			return;
		case 2:
			reduceSeats(ioFile, southboundTimetable, northboundTimetable, tmp);
			saveReservation(tmp);
			return;
		case 3:
			return;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation) {
	
	Reservation tmp;
	cout << "\nEnter ID Number: ";
	cin >> reservation.idNumber;
	cout << "\nEnter Reservation Number: ";
	cin >> reservation.reservationNumber;
	while (1) {
		ioFile.read(reinterpret_cast<char*>(&tmp), sizeof(Reservation));
		if (ioFile.eof() == 1) break;
		if (strcmp(reservation.idNumber, tmp.idNumber) == 0 && strcmp(reservation.reservationNumber, tmp.reservationNumber) == 0) {
			reservation = tmp;
			return true;
		}
	}
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation) {
	cout << "\n\nReservation Details \n\n";
	int  numSouthboundTrains = 0, numNorthboundTrains = 0;
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);

	if (reservation.originStation < reservation.destinationStation)
		display(reservation, southboundTimetable);
	else
		display(reservation, northboundTimetable);
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100]) {

	if (reservation.adultTickets == 0 && reservation.concessionTickets == 0)return;
	cout << std::right << setw(10) << "Date" << std::right << setw(10) << "Train No." << std::right << setw(8) << "From"
		<< std::right << setw(10) << "To" << std::right << setw(10) << "Departure" << std::right << setw(9) << "Arrival"
		<< std::right << setw(8) << "Adult" << std::right << setw(12) << "Concession" << std::right << setw(6) << "Fare"
		<< std::right << setw(10) << " Class\n";
	int sign;
	for (int i = 1; i < 100; i++) {
		if (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) == 0) {
			sign = i;
			break;
		}
	}
	if (reservation.originStation > reservation.destinationStation) {
		cout << std::right << setw(10) << reservation.date << std::right << setw(10) << reservation.trainNumber << std::right << setw(8) << station[reservation.originStation]
			<< std::right << setw(10) << station[reservation.destinationStation] 
			<< std::right << setw(10) << trainTimetable[sign].departureTimes[reservation.originStation] 
			<< std::right << setw(9) << trainTimetable[sign].departureTimes[reservation.destinationStation]
			<< std::right << setw(16) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets
			<< std::right << setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << "*" << reservation.concessionTickets
			<< std::right << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets +
			(adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) * reservation.concessionTickets
			<< std::right << setw(10) << carClass[reservation.carClass];
    }
	else {
		cout << std::right << setw(10) << reservation.date << std::right << setw(10) << reservation.trainNumber << std::right << setw(8) << station[reservation.originStation]
			<< std::right << setw(10) << station[reservation.destinationStation]
			<< std::right << setw(10) <<  trainTimetable[sign].departureTimes[reservation.originStation]
			<< std::right << setw(9) << trainTimetable[sign].departureTimes[reservation.destinationStation]
			<< std::right << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets
			<< std::right << setw(10) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << "*" << reservation.concessionTickets
			<< std::right << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets +
			(adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2) * reservation.concessionTickets
			<< std::right << setw(10) << carClass[reservation.carClass];
	}
	cout << endl;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation) {
	int choice;
	do cout << "\nHow many adult tickets to cancel�H";
	while ((choice = inputAnInteger(0, reservation.adultTickets)) == -1);
	reservation.adultTickets -= choice;

	do cout << "\nHow many concession tickets to cancel�H";
	while ((choice = inputAnInteger(0, reservation.concessionTickets)) == -1);
	reservation.concessionTickets -= choice;

	displayReservations( southboundTimetable,northboundTimetable,reservation);

	cout << "\nYou have successfully reduced the number of tickets!\n\n";
}