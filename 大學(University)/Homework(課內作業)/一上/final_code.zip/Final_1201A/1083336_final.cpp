#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include <vector>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 35 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30"};

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char word[10000];
	int digit = 0;
	cin >> word;
	for (unsigned int i = 0; word[i] != '\0'; i++)
	{
		if (word[i] >= '0' && word[i] <= '9')
		{
			digit *= 10;
			digit += word[i] - '0';
		}
		else
			return -1;
	}
	if (digit >= begin && digit <= end)
		return digit;
	else
		return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	int numSouthboundTrains;
	int numNorthboundTrains;
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);

	Reservation reservation;
	int departureTime;
	inputReservationDetails(reservation, departureTime);

	if (reservation.originStation < reservation.destinationStation)
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
	else
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);

	inputContactInfo(reservation);
	saveReservation(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	char station[13][12] = { "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
							"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	cout << "\nOrigin Station\n";

	for (int i = 0; i < sizeof(station) / sizeof(station[0]) - 1; i++)
		cout << i + 1 << ". " << station[i] << endl;
	do {
		cout << '?';
		reservation.originStation = inputAnInteger(0, sizeof(station) / sizeof(station[0]) - 1);
		cout << endl;
	} while (reservation.originStation == -1);

	cout << "Destination Station\n";
	for (int i = 0; i < sizeof(station) / sizeof(station[0]) - 1; i++)
		cout << i + 1 << ". " << station[i] << endl;
	do {
		cout << '?';
		reservation.destinationStation = inputAnInteger(0, sizeof(station) / sizeof(station[0]) - 1);
		cout << endl;
	} while (reservation.destinationStation == -1 || reservation.originStation == reservation.destinationStation);

	cout << "Car Class\n";
	cout << "1. Standard Car\n";
	cout << "2. Business Car\n";
	do {
		cout << '?';
	} while (reservation.carClass = (inputAnInteger(1, 2)) == -1);

	cout << "\nDeparture Date: ";
	cin >> reservation.date;
	cout << "\nDeparture Time\n";
	for (int i = 1; i < sizeof(departureTimes) / sizeof(departureTimes[0]); i++)
		cout << setw(2) << i << ". " << departureTimes[i] << endl;
	do {
		cout << '?';
		departureTime = inputAnInteger(0, sizeof(departureTimes) / sizeof(departureTimes[0]) - 1);
		cout << endl;
	} while (departureTime == -1);

	do {
		cout << "How many adult tickets? ";
		cin >> reservation.adultTickets;
		cout << "\nHow many concession tickets? ";
		cin >> reservation.concessionTickets;
	} while (reservation.adultTickets < 0 || reservation.concessionTickets < 0 || reservation.adultTickets + reservation.concessionTickets == 0);
}

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	numSouthboundTrains = 0;
	ifstream infile("Southbound timetable.txt");
	while (infile >> southboundTimetable[numSouthboundTrains].trainNumber)
	{
		for (int i = 1; i < sizeof(southboundTimetable[0].departureTimes) / sizeof(southboundTimetable[0].departureTimes[0]); i++)
			infile >> southboundTimetable[numSouthboundTrains].departureTimes[i];
		numSouthboundTrains++;
	}
}

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	numNorthboundTrains = 0;
	ifstream infile("Northbound timetable.txt");
	while (infile >> northboundTimetable[numNorthboundTrains].trainNumber)
	{
		for (int i = 1; i < sizeof(northboundTimetable[0].departureTimes) / sizeof(northboundTimetable[0].departureTimes[0]); i++)
			infile >> northboundTimetable[numNorthboundTrains].departureTimes[i];
		numNorthboundTrains++;
	}
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	int i = 0;
	while (strcmp(southboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) < 0 || adultTicketPrice[reservation.destinationStation][reservation.originStation] == 0)
		i++;

	vector <Train> train;
	train.resize(0);
	for (i; i < numSouthboundTrains && train.size() < 10; i++)
		if(strcmp(southboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) >= 0)
			if (southboundTimetable[i].departureTimes[reservation.originStation][0] != '-' && southboundTimetable[i].departureTimes[reservation.destinationStation][0] != '-')
				train.push_back(southboundTimetable[i]);

	cout << setw(10) << "Train No." << setw(10) << "Departure" << setw(10) << "Arrival\n";
	for (unsigned int i = 0; i < train.size(); i++)
		cout << setw(10) << train[i].trainNumber << setw(10) << train[i].departureTimes[reservation.originStation] << setw(10) << train[i].departureTimes[reservation.destinationStation] << endl;
	unsigned int j;
	do {
		cout << "\nEnter Train Number: ";
		cin >> reservation.trainNumber;
		for (j = 0; j < train.size(); j++)
			if (strcmp(reservation.trainNumber, train[j].trainNumber) == 0)
				break;
	} while (j == train.size());

	cout << "\nTrip Details\n\n";
	char station[13][12] = { "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
							"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carClass[2][12] = {"Standard","Business"};
	display(reservation, southboundTimetable, station, carClass[reservation.carClass]);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	int i = 0;
	while (strcmp(northboundTimetable[i].departureTimes[12 - reservation.originStation], departureTimes[departureTime]) < 0 || adultTicketPrice[12 - reservation.originStation][12 - reservation.destinationStation] == 0)
		i++;

	vector <Train> train;
	train.resize(0);
	for (i; i < numNorthboundTrains && train.size() < 10; i++)
		if(strcmp(northboundTimetable[i].departureTimes[12 - reservation.originStation], departureTimes[12 - departureTime]) >= 0)
			if (northboundTimetable[i].departureTimes[12 - reservation.originStation][0] != '-' && northboundTimetable[i].departureTimes[12 - reservation.destinationStation][0] != '-')
				train.push_back(northboundTimetable[i]);

	cout << setw(10) << "Train No." << setw(10) << "Departure" << setw(10) << "Arrival\n";
	for (unsigned int i = 0; i < train.size(); i++)
		cout << setw(10) << train[i].trainNumber << setw(10) << train[i].departureTimes[12 - reservation.originStation] << setw(10) << train[i].departureTimes[12 - reservation.destinationStation] << endl;
	unsigned int j;
	do {
		cout << "\nEnter Train Number: ";
		cin >> reservation.trainNumber;
		for (j = 0; j < train.size(); j++)
			if (strcmp(reservation.trainNumber, train[j].trainNumber) == 0)
				break;
	} while (j == train.size());

	cout << "\nTrip Details\n\n";
	char station[13][12] = { "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
							"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carClass[2][12] = { "Standard","Business" };
	display(reservation, northboundTimetable, station, carClass[reservation.carClass]);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	srand(time(0));
	for (int i = 0; i < 8; i++)
		reservation.reservationNumber[i] = rand() % 10 + '0';
	reservation.reservationNumber[8] = '\0';
	cout << "Enter Contact Person Information\n";
	cout << "\nID Number: ";
	cin >> reservation.idNumber;
	cout << "\nPhone: ";
	cin >> reservation.phone;
	cout << "\nReservation Number: " << reservation.reservationNumber << endl;
	cout << "\nReservation Completed!\n";
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream outfile("details.txt");
	outfile << reservation.reservationNumber << ' ' << reservation.trainNumber << ' ' << reservation.idNumber << ' ' << reservation.phone << ' ' << reservation.date << ' ';
	outfile << reservation.originStation << ' ' << reservation.destinationStation << ' ' << reservation.carClass << ' ' << reservation.adultTickets << ' ' << reservation.concessionTickets << endl;
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	char station[13][12] = { "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
					"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carClass[2][12] = { "Standard","Business" };
	Reservation reservation;
	fstream iofile("details.txt");

	if (existReservation(iofile, reservation))
			displayReservations(southboundTimetable, northboundTimetable, reservation);
	else
	{
		cout << "Invalid idNumber or reservationNumber\n";
		return;
	}

	cout << "\nEnter Your Choice\n";
	cout << "1. Cancellation\n";
	cout << "2. Reduce\n";
	cout << "3. End\n";
	int choice;
	do {
		cout << '?';
		choice = inputAnInteger(1, 3);
		cout << endl;
	}while (choice == -1);

	iofile.ignore();
	iofile.seekp(0);
	if (choice == 1)
	{
		reservation = { "","","","","",0,0,0,0,0 };
		iofile << reservation.reservationNumber << ' ' << reservation.trainNumber << ' ' << reservation.idNumber << ' ' << reservation.phone << ' ' << reservation.date << ' ';
		iofile << reservation.originStation << ' ' << reservation.destinationStation << ' ' << reservation.carClass << ' ' << reservation.adultTickets << ' ' << reservation.concessionTickets << endl;
		cout << "Reservation Cancelled!\n";
	}
	else if (choice == 2)
		reduceSeats(iofile, southboundTimetable, northboundTimetable, reservation);
	else
		return;
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	cout << "\nEnter ID Number: ";
	cin >> reservation.idNumber;
	cout << "\nEnter Reservation Number: ";
	cin >> reservation.reservationNumber;

	vector <Reservation> reservations;
	reservations.resize(0);
	while (!ioFile.eof())
	{
		reservations.resize(reservations.size() + 1);
		ioFile >> reservations[reservations.size() - 1].reservationNumber >> reservations[reservations.size() - 1].trainNumber >> reservations[reservations.size() - 1].idNumber >> reservations[reservations.size() - 1].phone >> reservations[reservations.size() - 1].date;
		ioFile >> reservations[reservations.size() - 1].originStation >> reservations[reservations.size() - 1].destinationStation >> reservations[reservations.size() - 1].carClass >> reservations[reservations.size() - 1].adultTickets >> reservations[reservations.size() - 1].concessionTickets;

		if (strcmp(reservation.idNumber, reservations[reservations.size() - 1].idNumber) == 0)
			if (strcmp(reservation.reservationNumber, reservations[reservations.size() - 1].reservationNumber) == 0)
			{
				reservation = reservations[reservations.size() - 1];
				return true;
			}
	}
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	cout << "\nReservation Details\n\n";
	char station[13][12] = { "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
						"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carClass[2][12] = { "Standard","Business" };
	int numSouthboundTimetable,numNorthboundTimetable;
	loadSouthboundTimetable(southboundTimetable, numSouthboundTimetable);
	loadNorthboundTimetable(northboundTimetable, numNorthboundTimetable);
	if (reservation.originStation < reservation.destinationStation)
		display(reservation, southboundTimetable, station, carClass[reservation.carClass]);
	else
		display(reservation, northboundTimetable, station, carClass[reservation.carClass]);
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	int i = 0;
	while (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) != 0)
		i++;

	int d = reservation.destinationStation, o = reservation.originStation;
	if (o > d)
	{
		o = 12 - o;
		d = 12 - d;
	}

	cout << setw(12) << "Date" << setw(12) << "Train No." << setw(12) << "From" << setw(12) << "To" << setw(12) << "Departure" << setw(12) << "Arrival" << setw(8) << "Adult" << setw(12) << "Concession" << setw(12) << "Fare" << setw(12) << "Class" << endl;
	cout << setw(12) << reservation.date << setw(12) << reservation.trainNumber << setw(12) << stations[o - 1] << setw(12) << stations[d - 1]  << setw(12) << trainTimetable[i].departureTimes[o] << setw(12) <<trainTimetable[i].departureTimes[d];

	if (reservation.carClass == 0)
		cout << setw(6) << adultTicketPrice[d][o] << '*' << reservation.adultTickets << setw(10) << adultTicketPrice[d][o] / 2 << '*' << reservation.concessionTickets << setw(12) << adultTicketPrice[d][o]* reservation.adultTickets + adultTicketPrice[d][o] / 2 * reservation.concessionTickets;
	else
		cout << setw(6) << adultTicketPrice[o][d] << '*' << reservation.adultTickets << setw(10) << adultTicketPrice[o][d] / 2 << '*' << reservation.concessionTickets << setw(12) << adultTicketPrice[o][d] * reservation.adultTickets + adultTicketPrice[o][d] / 2 * reservation.concessionTickets;

	cout << setw(12) << carClass << endl << endl;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int reduceAdult, reduceConcession;
	do {
		cout << "How many adult tickets to cancel�H";
		cin >> reduceAdult;
		cout << "How many concession tickets to cancel�H";
		cin >> reduceConcession;
	} while (reduceAdult < 0 || reduceConcession < 0 || reduceAdult + reduceConcession <= 0);
	reservation.adultTickets -= reduceAdult;
	reservation.concessionTickets -= reduceConcession;
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	cout << "You have successfully reduced the number of tickets!\n";
}