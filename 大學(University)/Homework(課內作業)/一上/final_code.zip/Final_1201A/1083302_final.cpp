#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main


int inputAnInteger(int begin, int end)
{
	char input[100] = {};
	cin >> input;
	for (int i = 0; i < strlen(input); i++)
	{
		if (input[i]<'0' || input[i]>'9')
			return -1;			
	}
	int num = atoi(input);
	if (num >= begin && num <= end)
		return num;

	return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation making;
	int departureTime = 0, numSouthboundTrains = 0, numNorthboundTrains = 0;
	inputReservationDetails(making, departureTime);

	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);

	if (making.originStation < making.destinationStation)
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, making, departureTime);
	if (making.originStation > making.destinationStation)
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, making, departureTime);

	inputContactInfo(making);
	saveReservation(making);
}

void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	int choice;
	cout << "\nOrigin Station";
	cout << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n" << "4. Taoyuan\n" << "5. Hsinchu\n" << "6. Miaoli\n" << "7. Taichung\n" << "8. Changhua\n";
	cout << "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" << "12. Zuoying";
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	cout << endl;
	reservation.originStation = choice;
	int orchoice = choice;

	cout << "\nDestination Station";
	cout << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n" << "4. Taoyuan\n" << "5. Hsinchu\n" << "6. Miaoli\n" << "7. Taichung\n" << "8. Changhua\n";
	cout << "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" << "12. Zuoying";
	choice = inputAnInteger(1, 12);
	do cout << "\n? ";
	while (choice == -1 || choice == orchoice);
	cout <<"Incorrect choice or your destination station and origin station are same. Please try again! "<< endl;
	reservation.destinationStation = choice;

	cout << "Car Class\n" << "1. Standard Car\n" << "2. Business Car";
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 2)) == -1);
	cout << endl;
	reservation.carClass = choice;
		
	cout << "Departure Date: ";
	cin >> reservation.date;
	cout << "\nDeparture Time";
	for (int i = 1; i < 35; i++)
	{
		cout << setw(2) << i << ". " << departureTimes[i] << endl;
	}
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 34)) == -1);
	cout << endl;
	departureTime = choice;
	
	cout << "How many adult tickets ?";
	cin >> reservation.adultTickets;
	cout << "\nHow many concession tickets?";	
	cin >> reservation.adultTickets;

	while ((reservation.adultTickets + reservation.adultTickets) == 0)
	{
		cout << "your tickets can not be 0. Please try again" << endl;
		cout << "How many adult tickets ?";
		cin >> reservation.adultTickets;
		cout << "\nHow many concession tickets?";
		cin >> reservation.adultTickets;
	}
	cout << endl;
}

//??
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	
	ifstream infile("Southbound timetable.txt" , ios::binary);
	if (!infile)
	{
		cout << "file can not be open.";
		exit(1);
	}
	int i = 0;

	while (infile.read((char*)& southboundTimetable[i], sizeof(Train)))
		i++;
	infile.close();
	

}

//??
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream infile("Northbound timetable.txt", ios::binary);
	if (!infile)
	{
		cout << "file can not be open.";
		exit(1);
	}
	int i = 0;

	while (infile.read((char*)& northboundTimetable[i], sizeof(Train)))
		i++;
	infile.close();
}

//??
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains, Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival\n";

	for (int i = 0; i < 9; i++)
	{
		cout << right << setw(9) << southboundTimetable[numSouthboundTrains+i].trainNumber << setw(11) << southboundTimetable[numSouthboundTrains + i].departureTimes[reservation.originStation];
		cout << right << setw(9) << southboundTimetable[numSouthboundTrains+i].departureTimes[reservation.destinationStation];
	}
	cout << "\nEnter Train Number: ";
	cin >> reservation.trainNumber;
	cout << "\nTrip Details\n";
	char station[13][12] = { " ","1. Nangang","2. Taipei","3. Banqiao","4. Taoyuan","5. Hsinchu","6. Miaoli"
		,"7. Taichung","8. Changhua","9. Yunlin","10. Chiayi","11. Tainan","12. Zuoying"};
	char carclass[12] = {};
	if (reservation.carClass == 2)
	{
		carclass[0] = 'B'; 
		carclass[1] = 'u';
		carclass[2] = 's';
		carclass[3] = 'i';
		carclass[4] = 'n';
		carclass[5] = 'e';
		carclass[6] = 's';
		carclass[7] = 's';			
	}
	if (reservation.carClass == 1)
	{
		carclass[0] = 'S';
		carclass[1] = 't';
		carclass[2] = 'a';
		carclass[3] = 'n';
		carclass[4] = 'd';
		carclass[5] = 'a';
		carclass[6] = 'r';
		carclass[7] = 'd';
	}

	display(reservation, southboundTimetable, station, carclass);
}

//??
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival\n";
	for (int i = 0; i < 9; i++)
	{
		cout << right << setw(9) << northboundTimetable[numNorthboundTrains + i].trainNumber << setw(11) << northboundTimetable[numNorthboundTrains + i].departureTimes[reservation.originStation];
		cout << right << setw(9) << northboundTimetable[numNorthboundTrains + i].departureTimes[reservation.destinationStation];
	}
	cout << "\nEnter Train Number: ";
	cin >> reservation.trainNumber;
	cout << "\nTrip Details\n";
	char station[13][12] = { " ","1. Nangang","2. Taipei","3. Banqiao","4. Taoyuan","5. Hsinchu","6. Miaoli"
		,"7. Taichung","8. Changhua","9. Yunlin","10. Chiayi","11. Tainan","12. Zuoying" };
	char carclass[12] = {};
	if (reservation.carClass == 1)
	{
		carclass[0] = 'B';
		carclass[1] = 'u';
		carclass[2] = 's';
		carclass[3] = 'i';
		carclass[4] = 'n';
		carclass[5] = 'e';
		carclass[6] = 's';
		carclass[7] = 's';
	}
	if (reservation.carClass == 2)
	{
		carclass[0] = 'S';
		carclass[1] = 't';
		carclass[2] = 'a';
		carclass[3] = 'n';
		carclass[4] = 'd';
		carclass[5] = 'a';
		carclass[6] = 'r';
		carclass[7] = 'd';
	}

	display(reservation, northboundTimetable, station, carclass);
}

void inputContactInfo(Reservation& reservation)
{
	cout << "\nEnter Contact Person Information\n";
	cout << "ID Number: ";
	cin	>> reservation.idNumber ;
	cout << "\nPhone: "  ;
	cin >> reservation.phone;
	cout << "\nReservation Number: ";
	cin >> reservation.reservationNumber;
	cout << "\nReservation Completed!\n\n";
}

void saveReservation(Reservation reservation)
{
	ofstream outfile("Reservation details.dat", ios::binary);
	if (!outfile)
	{
		cout << "file can not be open.";
		exit(1);
	}

	outfile.write((char*)& reservation, sizeof(Reservation));
	outfile.close();
}

void reservationHistory(Train southboundTimetable[100], Train northboundTimetable[100])
{
	int choice = 0;
	Reservation history;
	cout << "Enter ID Number :";
	cin >> history.idNumber;
	cout << "\nEnter Reservation Number :\n";
	cin >> history.reservationNumber;

	

	if (existReservation)
	{
		displayReservations(southboundTimetable, northboundTimetable, history);
		while (true)
		{
			cout << "\n Enter Your Choice\n";
			cout << "1. Cancellation\n";
			cout << "2. Reduce\n";
			cout << "3. End";

			do cout << "\n? ";
			while ((choice = inputAnInteger(1, 3)) == -1);
			cout << endl;

			switch (choice)
			{
			case 1:
				cout << "Reservation Cancelled!\n\n";
				break;
			case 2:
				reduceSeats(,southboundTimetable, northboundTimetable, history);
				break;
			case 3:
				return;
			default: 
				cerr << "Incorrect Choice!\n";
				break;
			}
		}

	}

}

bool existReservation(fstream& ioFile, Reservation& reservation)
{
	Reservation exit;
	ifstream infile("Reservation details.dat", ios::binary);
	infile.read((char*)& exit, sizeof(Reservation));
	if(!strcmp(exit.idNumber,reservation.idNumber)&&!strcmp(exit.reservationNumber,reservation.reservationNumber)
		return true;

	return false;
}

void displayReservations(Train southboundTimetable[100], Train northboundTimetable[100], Reservation reservation)
{
	cout << "Reservation Details\n";
	int numSouthboundTrains, numNorthboundTrains;
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);

	char station[13][12] = { " ","1. Nangang","2. Taipei","3. Banqiao","4. Taoyuan","5. Hsinchu","6. Miaoli"
		,"7. Taichung","8. Changhua","9. Yunlin","10. Chiayi","11. Tainan","12. Zuoying" };
	char carclass[12] = {};
	if (reservation.carClass == 2)
	{
		carclass[0] = 'B';
		carclass[1] = 'u';
		carclass[2] = 's';
		carclass[3] = 'i';
		carclass[4] = 'n';
		carclass[5] = 'e';
		carclass[6] = 's';
		carclass[7] = 's';
	}
	if (reservation.carClass == 1)
	{
		carclass[0] = 'S';
		carclass[1] = 't';
		carclass[2] = 'a';
		carclass[3] = 'n';
		carclass[4] = 'd';
		carclass[5] = 'a';
		carclass[6] = 'r';
		carclass[7] = 'd';
	}

	display(reservation, southboundTimetable, station, carclass);
}

void display(Reservation reservation, Train trainTimetable[100], char stations[13][12], char carClass[12])
{
	int total = 0, price = 0;
	if (reservation.carClass == 1)
	{
		price = adultTicketPrice[reservation.destinationStation][reservation.originStation];
		total += (price * reservation.adultTickets) + (price / 2 * reservation.concessionTickets);
	}
	if (reservation.carClass == 2)
	{
		price = adultTicketPrice[reservation.originStation][reservation.destinationStation];
		total += (price * reservation.adultTickets) + (price / 2 * reservation.concessionTickets);
	}
	cout << "      Date  Train No.From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
	cout << right << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation] << setw(11) << trainTimetable;
	cout << right << setw(9) << trainTimetable << setw(8) << price << '*' << reservation.adultTickets << setw(12) << price/2 << '*' << reservation.concessionTickets << setw(6) << total << setw(10);
	for (int i = 0; i < strlen(carClass); i++)
		cout << carClass[i];
}

void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation)
{
}
