#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

char stations[13][12] = { "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
char standard[2][13] = { "Standard Car","Business Car" };
struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
	std::cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
	   std::cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do std::cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
	  std::cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
		 std::cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main
// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end) {
	string a;
	cin >> a;
	if (a.size() == 1 && (a[0] - '0' >= begin && a[0] - '0' <= end)) {
		return a[0] - '0';
	}
	else if (a.size() == 2 && ((a[0] - '0') * 10 + a[1] - '0' >= begin && (a[0] - '0') * 10 + a[1] - '0' <= end)) {
		return (a[0] - '0') * 10 + a[1] - '0';
	}
	return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]) {
	Reservation reservation = { "","","","","",0,0,0,0,0 };
	int departureTime;
	int num = 0;
	for (int i = 0; i < 100; i++) {
		southboundTimetable[i] = { "","" };
		northboundTimetable[i] = { "","" };
	}
	inputReservationDetails(reservation, departureTime);
	if (reservation.originStation < reservation.destinationStation) {//�_�W
		loadSouthboundTimetable(southboundTimetable,num);
		selectSouthboundTrain(southboundTimetable, num,reservation,departureTime);
	}
 	else if (reservation.originStation > reservation.destinationStation) {//�n�U
		loadNorthboundTimetable(northboundTimetable,num);
		selectNorthboundTrain(northboundTimetable, num, reservation, departureTime);
	}
	inputContactInfo(reservation);
	saveReservation(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime) {
	unsigned choice1,choice2,choice3,choice4,choice5,choice6;
	string date;
	do {
		std::cout << "Origin Station" << endl << "1. Nangang" << endl << "2. Taipei" << endl << "3. Banqiao" << endl
			<< "4. Taoyuan" << endl << "5. Hsinchu" << endl << "6. Miaoli" << endl << "7. Taichung" << endl << "8. Changhua" << endl << "9. Yunlin" << endl << "10. Chiayi"
			<< endl << "11. Tainan" << endl << "12. Zuoying" << endl << "?";
	} while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
	do {
		std::cout << "Destination Station" << endl << "1. Nangang" << endl << "2. Taipei" << endl << "3. Banqiao" << endl
			<< "4. Taoyuan" << endl << "5. Hsinchu" << endl << "6. Miaoli" << endl << "7. Taichung" << endl << "8. Changhua" << endl << "9. Yunlin" << endl << "10. Chiayi"
			<< endl << "11. Tainan" << endl << "12. Zuoying" << endl << "?";
	} while ((reservation.destinationStation = inputAnInteger(1, 12))==-1 || reservation.destinationStation == reservation.originStation);
	do {
		std::cout << "Car class" << endl << "1. Standard Car" << endl << "2. Business Car" << endl << "?";
	} while ((reservation.carClass = inputAnInteger(1, 2))==-1);
	std::cout << "Departure Date: ";
	std::cin >> reservation.date;//ldks
	std::cout << endl;
	do {
		std::cout << "Departure Time " << endl;
		for (int i = 1; i <= 34; i++) {
			if (i >= 10) {
				std::cout << i << ".  " << departureTimes[i] << endl;
			}
			else {
				std::cout << i << ".   " << departureTimes[i] << endl;
			}
		}
		std::cout << "?" ;
	} while ((departureTime = inputAnInteger(1, 34))==-1);
	do {
		do {
			std::cout << "How many adult tickets? ";
			cin >> reservation.adultTickets;
		} while (reservation.adultTickets < 0);
		do {
			std::cout << "How many concession tickets? ";
			cin >> reservation.concessionTickets;
		} while (reservation.concessionTickets < 0);
	} while (reservation.adultTickets + reservation.concessionTickets <= 0);
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) {
	ifstream inFile("Southbound timetable.txt", ios::in);
	if (!inFile) {
		cerr << "Could not open the file!" << endl;
		exit(1);
	}
	while (inFile >> southboundTimetable[numSouthboundTrains].trainNumber) {
		for (int i = 0 ; i < 12 ; i++) {
			inFile >> southboundTimetable[numSouthboundTrains].departureTimes[i];
		}
		numSouthboundTrains++;
	}
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) {
	ifstream inFile("Northbound timetable.txt", ios::in);
	if (!inFile) {
		cerr << "Could not open the file!" << endl;
		exit(1);
	}
	while (inFile >> northboundTimetable[numNorthboundTrains].trainNumber) {
		for (int i = 0; i < 12; i++) {
			inFile >> northboundTimetable[numNorthboundTrains].departureTimes[i];
		}
		numNorthboundTrains++;
	}
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime) {
	bool tf = true;
	char trainnumber[10][5] = {};
	std::cout << "Train No.  Departure  Arrival" << endl;
	int k = 0;
	for (int i = 0; i < numSouthboundTrains; i++) {
		if (strcmp(southboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) != -1) {
			strcpy_s(trainnumber[k], southboundTimetable[i].trainNumber);
			k++;
			std::cout << southboundTimetable[i].trainNumber << "   ";
			std::cout << southboundTimetable[i].departureTimes[reservation.originStation] << "   ";//Departure
			std::cout << southboundTimetable[i].departureTimes[reservation.destinationStation] << endl;//Arrival
			if (k == 10) {
				break;
			}
		}
	}
	while (tf) {
		std::cout << "Enter Train Number: ";
		std::cin >> reservation.trainNumber;
		for (int i = 0; i < 10; i++) {
			if (!strcmp(reservation.trainNumber, trainnumber[i])) {
				tf = false;
				break;
			}
		}
	}
	display(reservation, southboundTimetable);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) {
	bool tf = true;
	char trainnumber[10][5] = {};
	//char station[13][12] = {};
	std::cout << "Train No.  Departure  Arrival" << endl;
	int k = 0;
	for (int i = 0; i < numNorthboundTrains; i++) {
		if (strcmp(northboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) != -1) {
			strcpy_s(trainnumber[k], northboundTimetable[i].trainNumber);
			k++;
			std::cout << northboundTimetable[i].trainNumber << "   ";
			std::cout << northboundTimetable[i].departureTimes[reservation.originStation] << "   ";//Departure
			std::cout << northboundTimetable[i].departureTimes[reservation.destinationStation] << endl;//Arrival
			if (k == 10) {
				break;
			}
		}
	}
	while (tf) {
		std::cout << "Enter Train Number: ";
		std::cin >> reservation.trainNumber;
		for (int i = 0; i < 10; i++) {
			if (!strcmp(reservation.trainNumber, trainnumber[i])) {
				tf = false;
				break;
			}
		}
	}

	display(reservation, northboundTimetable);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation) {
	string id;
	string phone;
	for (int i = 0; i < 8; i++) {
		reservation.reservationNumber[i] = static_cast<char>(rand() % 10 + 48);
	}
	std::cout << "Enter Contact Person Information" << endl;
	std::cout << "ID Number: ";
	std::cin >> reservation.idNumber;
	std::cout << "Phone: ";
	cin >> reservation.phone;
	std::cout << "Reservation Number: "<<reservation.reservationNumber<<endl;

	std::cout << "Reservation Completed!" << endl;
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation) {
	Reservation data = {"","","","","",0,0,0,0,0 };
	Reservation empty = { "","","","","",0,0,0,0,0 };
	int position = 0;
	ifstream inFile("Reservation details.dat", ios::binary);
	ofstream ioFile("Reservation details.dat", ios::binary | ios::out | ios::ate);
	if (inFile) {
		while (inFile.read(reinterpret_cast<char*>(&data), sizeof(data))) {
			if (strcmp(reservation.idNumber, data.idNumber) == 0 && strcmp(reservation.reservationNumber, data.reservationNumber) == 0) {
				position = inFile.tellg();
				ioFile.seekp(position - sizeof(Reservation));
			}
		}
	}
	if (!ioFile) {
		cerr << "Could not put data to the file!" << endl;
		exit(1);
	}
	if (reservation.adultTickets + reservation.concessionTickets == 0) {
		ioFile.write(reinterpret_cast<char*>(&empty), sizeof(Reservation));
	}
	else {
		ioFile.write(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
	}
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]) {
	Reservation reservation;
	int choice;
	Reservation empty = { "","","","","",0,0,0,0,0 };
	fstream inFile("Reservation details.dat", ios::binary | ios::in );
	if (existReservation(inFile, reservation)) {
		while (true) {
			displayReservations(southboundTimetable, northboundTimetable, reservation);
			do {
				std::cout << "Enter Your Choice \n1. Cancellation \n2. Reduce \n3. End\n?";
			} while ((choice = inputAnInteger(1, 2)) == -1);
			switch (choice)
			{
			case 1:
				reservation.adultTickets = 0;
				reservation.concessionTickets = 0;
				saveReservation(reservation);
				std::cout << "Reservation Cancelled! " << endl;
				return;
			case 2:
				reduceSeats(inFile, southboundTimetable, northboundTimetable, reservation);
				break;
			case 3:
				return;
			default: // display error if user does not select valid choice
				cerr << "Incorrect Choice!\n";
				break;
			}
		}

	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation) {
	Reservation input;
	bool tf = false;
	if (!ioFile) {
		cerr << "wrong!" << endl;
		exit(1);
	}
	std::cout << "Enter ID Number: ";
	std::cin >> input.idNumber;
	std::cout << "Enter Reservation Number: ";
	std::cin >> input.reservationNumber;
	while (ioFile.read(reinterpret_cast<char*>(&reservation), sizeof(reservation))) {
		if (strcmp(reservation.idNumber,input.idNumber) == 0 && strcmp(reservation.reservationNumber,input.reservationNumber) == 0){
			//tf = true;
			return true;
		}
	}
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation) {
	int num = 0;
	//char station[13][12] = {};
	std::cout << "Reservation Details" << endl;

	if (reservation.originStation < reservation.destinationStation) {//�_�W
		loadSouthboundTimetable(southboundTimetable, num);
		display(reservation, southboundTimetable);
	}
	else if (reservation.originStation > reservation.destinationStation) {//�n�U
		loadNorthboundTimetable(northboundTimetable, num);
		display(reservation, northboundTimetable);
	}
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100]) {
	int train;
	for (int i = 0; i < 100; i++) {
		if (!strcmp(trainTimetable[i].trainNumber, reservation.trainNumber)) {
			train = i;
			break;
		}
	}
	int x = reservation.originStation;
	int y = reservation.destinationStation;
	int adult = 0;
	int concession = 0;
	unsigned fare = 0;
	if (reservation.carClass == 1) {
		if (x > y) {
			adult = adultTicketPrice[x][y];
			fare = adultTicketPrice[x][y] * reservation.adultTickets + (adultTicketPrice[x][y] / 2) * reservation.concessionTickets;
		}
		else{
			adult = adultTicketPrice[y][x];
			fare = adultTicketPrice[y][x] * reservation.adultTickets + (adultTicketPrice[y][x] / 2) * reservation.concessionTickets;
		}
	}
	else if (reservation.carClass == 2) {
		if (x > y) {
			adult = adultTicketPrice[y][x];
			fare = adultTicketPrice[y][x] * reservation.adultTickets + (adultTicketPrice[y][x] / 2) * reservation.concessionTickets;
		}
		else {
			adult = adultTicketPrice[x][y];
			fare = adultTicketPrice[x][y] * reservation.adultTickets + (adultTicketPrice[y][x] / 2) * reservation.concessionTickets;
		}
	}
	concession = adult/2;
	std::cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class"<<endl;
	std::cout <<"      "<< reservation.date << "  " << reservation.trainNumber << "    " << stations[reservation.originStation] << "        " << stations[reservation.destinationStation] << "  "
		<< trainTimetable[train].departureTimes[reservation.originStation]<<"  "<< trainTimetable[train].departureTimes[reservation.destinationStation] << "   " << adult <<"*"
		<< reservation.adultTickets << "      " <<concession<< "*" << reservation.concessionTickets <<"  "<< fare <<"   "<< standard[reservation.carClass-1] << endl;
}
// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation) {
	unsigned adult, concession;
	int sum = 0;
	Reservation empty = { "","","","","",0,0,0,0,0 };
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	do {
		do {
			std::cout << "How many adult tickets to cancel�H";
			std::cin >> adult;
			reservation.adultTickets -= adult;
		} while (reservation.adultTickets < 0);
		do {
			std::cout << "How many concession tickets to cancel�H";
			std::cin >> concession;
			reservation.concessionTickets -= concession;
		} while (reservation.concessionTickets < 0);
		sum = reservation.adultTickets + reservation.concessionTickets;
	} while (sum < 0);
	saveReservation(reservation);
}