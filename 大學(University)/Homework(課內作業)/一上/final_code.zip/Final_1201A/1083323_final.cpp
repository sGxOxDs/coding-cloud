#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>


using namespace std;
char stations[13][12] = { "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 35 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

int inputAnInteger(int begin, int end) {
	char word[25];
	cin >> word;
	if (word[0]<'0' || word[0]>'9') {
		return -1;
	}
	int digit = 0; int i = 0;
	while (word[i] != '\0') {
		i++;
	}
	for (int j = 0; j < i; j++) {
		digit += static_cast<int>(word[j] - '0') * pow(10, i - j - 1);
	}
	if (digit> begin || digit<end) {
		return digit;
	}
	else {
		return -1;
	}

}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]) {
	int departureTime;
	Reservation buffer;
	inputReservationDetails(buffer, departureTime);
	int numNorthboundTrains = 0;
	int numSouthboundTrains = 0;
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);

	if (buffer.originStation < buffer.destinationStation) {
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains,buffer, departureTime);
	}
	else  if(buffer.originStation > buffer.destinationStation) {
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains,buffer, departureTime);
	}

		display();
		inputContactInfo();
		saveReservation();
		return;
		
}


void inputReservationDetails(Reservation& reservation, int& departureTime) {
	
	cout << "Origin Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" << endl;
	int choice;
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	cout << endl;
	reservation.originStation = choice;
	cout << "Destination Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" << endl;
	int choice2;
	do cout << "\n? ";
	while ((choice2 = inputAnInteger(1, 12)) == -1 && choice == choice2);
	reservation.destinationStation = choice2;
	cout << endl;
	
	cout << "Car Class" << endl;
	cout << "1. Standard Car" << endl;
	cout << "2. Business Car" << endl;
	int choice3;
	do cout << "\n? ";
	while ((choice3 = inputAnInteger(1, 2)) == -1);
	cout << endl;
	reservation.carClass == choice3;
	cout << "Departure Date:";
	cin >> reservation.date;
	cout << endl;
	for (int i = 1; i < 35; i++) {
		cout << "i. " << departureTimes[i] << endl;
	}
	int choice4;
	do cout << "\n? ";
	while ((choice4 = inputAnInteger(1, 34)) == -1);
	cout << endl;
	departureTime = choice4;
	cout << "How many adult tickets?";
	cin >> reservation.adultTickets;
	cout << endl;
	cout << "How many concession tickets?";
	cin >> reservation.concessionTickets;
	cout << endl;

}
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) {
	ifstream infile("Southbound timetable.txt");
	for (int i = 0; i < 100; i++) {
		infile.read(reinterpret_cast<char*>(&southboundTimetable[i]), sizeof(Train));
	}
}

void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) {
	ifstream infile("Northbound timetable.txt");
	for (int i = 0; i < 100; i++) {
		infile.read(reinterpret_cast<char*>(&northboundTimetable[i]), sizeof(Train));
	}
}
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains, //
	Reservation& reservation, int departureTime) {
	cout << "Train No.  Departure  Arrival " << endl;
	int j = 0;
	int k[10];
	for (int i = 0; i < 100; i++) {
		
		if (southboundTimetable[i].departureTimes[reservation.originStation][1] > departureTimes[departureTime][1]) {
			numSouthboundTrains++;
			if (numSouthboundTrains < 10) {
				cout << setw(9) << right << southboundTimetable[i].trainNumber << setw(11) << right << southboundTimetable[i].departureTimes << setw(9) << right << southboundTimetable[i].departureTimes[reservation.destinationStation];
				k[j] = i;
				j++;
			}
		}
		else if (southboundTimetable[i].departureTimes[reservation.originStation][1] == departureTimes[departureTime][1] && southboundTimetable[i].departureTimes[reservation.originStation][3] >= departureTimes[departureTime][3]) {
			numSouthboundTrains++;
			if (numSouthboundTrains < 10) {
				cout << setw(9) << right << southboundTimetable[i].trainNumber << setw(11) << right << southboundTimetable[i].departureTimes << setw(9) << right << southboundTimetable[i].departureTimes[reservation.destinationStation];
				k[j] = i;
				j++;
			}
		}
	}
	cout << "Enter Train Number : ";
	cin >> reservation.trainNumber;
	cout << endl;
	cout << "Trip Details";
	Train timetable;
	

}


void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, //
	Reservation& reservation, int departureTime) {
	cout << "Train No.  Departure  Arrival" << endl;
	for (int i = 0; i < 100; i++) {
		if (northboundTimetable[i].departureTimes[reservation.originStation][1] > departureTimes[departureTime][1]) {
			numNorthboundTrains++;
			if (numNorthboundTrains < 10) {
				cout << setw(9) << right << northboundTimetable[i].trainNumber << setw(11) << right << northboundTimetable[i].departureTimes << setw(9) << right << northboundTimetable[i].departureTimes[reservation.destinationStation];
			}
		}
		else if (northboundTimetable[i].departureTimes[reservation.originStation][1] == departureTimes[departureTime][1] && northboundTimetable[i].departureTimes[reservation.originStation][3] >= departureTimes[departureTime][3]) {
			numNorthboundTrains++;
			if (numNorthboundTrains < 10) {

				cout << setw(9) << right << northboundTimetable[i].trainNumber << setw(11) << right << northboundTimetable[i].departureTimes << setw(9) << right << northboundTimetable[i].departureTimes[reservation.destinationStation];
			}
		}
	}
	cout << "Enter Train Number : ";
	cin >> reservation.trainNumber;
	cout << endl;
	cout << "Trip Details";

}

void display(Reservation reservation, Train trainTimetable[100], //
	char stations[13][12], char carClass[12]) {
	int price = 0;
	int price2 = 0;
	int fare1 = 0;
	int fare2 = 0;
	if (reservation.carClass == 1) {
		price = adultTicketPrice[reservation.destinationStation][reservation.originStation];
		fare1 = price * reservation.adultTickets + (price / 2) * reservation.concessionTickets;
	}
	else {
		price2 = adultTicketPrice[reservation.originStation][reservation.destinationStation];
		fare2= price2 * reservation.adultTickets + (price2 / 2) * reservation.concessionTickets;
	}
	cout << "Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
	if (reservation.carClass == 1) {
		cout << reservation.date << reservation.trainNumber << reservation.originStation << reservation.destinationStation << trainTimetable->departureTimes << trainTimetable << price << "*" << reservation.adultTickets << price / 2 << "*" << reservation.concessionTickets;
	}
	else {
		cout << reservation.date << reservation.trainNumber << reservation.originStation << reservation.destinationStation << trainTimetable->departureTimes << trainTimetable << price2 << "*" << reservation.adultTickets << price2 / 2 << "*" << reservation.concessionTickets;
	}
}

void inputContactInfo(Reservation& reservation) {
	cout << "Enter Contact Person Information" << endl;
	char id[100];
	cin >> reservation.idNumber;
	cout << "ID Number: " << reservation.idNumber << endl;
	char ph[100];
	cin >> reservation.phone;
	cout << "Phone: " << reservation.phone << endl;
	srand(time(0));
	for (int i = 0; i < 7; i++) {
		reservation.reservationNumber[i] = rand() % 10;
		reservation.reservationNumber[8] = '\0';
	}
	cout << "Reservation Number: " << reservation.reservationNumber << endl;
	cout << "Reservation Completed!" << endl;
	

}
void saveReservation(Reservation reservation) {
	ofstream outfile("Reservation details.dat", ios::binary|ios::app);
	outfile.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));

}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]) {
	Reservation buffer;
	fstream in("Reservation details.dat", ios::binary | ios::in);
	in.seekg(0, ios::end);
	int numline = in.tellg / sizeof(Reservation);
	in.seekg(0, ios::beg);
	for (int i = 0; i < numline; i++) {
		in.read(reinterpret_cast<char*>(&buffer), sizeof(Reservation));
		if(existReservation(buffer,))
	}
	


}

bool existReservation(fstream& ioFile, Reservation& reservation) {
	

}

void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation) {

}