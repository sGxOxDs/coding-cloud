#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>

using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char num[80];

	cin.getline(num, 80, '\n');
	if (!strlen(num))
		cin.getline(num, 80, '\n');
	for (unsigned int i = 0; i < strlen(num); i++)
		if (num[i] < '0' || num[i]>'9')
			return -1;

	int n = atoi(num);
	if (n >= begin && n <= end)
		return n;
	else
		return -1;
}


// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	Reservation re;

	do {
		cout << "Origin Station" << endl;
		cout << "1. Nangang " << endl << "2. Taipei " << endl << "3. Banqiao" << endl << "4. Taoyuan" << endl << "5. Hsinchu " << endl << "6. Miaoli " << endl
			<< "7. Taichung " << endl << "8. Changhua" << endl << "9. Yunlin " << endl << "10. Chiayi " << endl << "11. Tainan " << endl << "12. Zuoying" << "\n? ";
	} while (re.originStation = (inputAnInteger(0, 12)) == -1);

	do {
		cout << "Destination Station" << endl;
		cout << "1. Nangang " << endl << "2. Taipei " << endl << "3. Banqiao" << endl << "4. Taoyuan" << endl << "5. Hsinchu " << endl << "6. Miaoli " << endl
			<< "7. Taichung " << endl << "8. Changhua" << endl << "9. Yunlin " << endl << "10. Chiayi " << endl << "11. Tainan " << endl << "12. Zuoying" << "\n? ";
	} while (re.destinationStation = (inputAnInteger(0, 12)) == -1);


	do {
		cout << "Car Class" << endl;
		cout << "1. Standard Car " << endl << "2. Business Car" << "\n? ";
	} while (re.carClass = (inputAnInteger(0, 2)) == -1);

	int  Date;
	do {
		cout << "Departure Date" << endl;
	} while (Date = (inputAnInteger(0, 2)) == -1);

	int  deptime;
	do {
		cout << "Departure Time" << endl;
		for (int i = 0; i < 37; i++)
			cout << i << ". " << departureTimes[i];
		cout << "\n? ";
	} while (deptime = (inputAnInteger(0, 34)) == -1);

choose:
	cout << "How many adult tickets";
	cin >> re.adultTickets;
	cout << endl;

	cout << "How many concession tickets";
	cin >> re.concessionTickets;
	cout << endl;

	if (re.adultTickets == 0 && re.concessionTickets == 0)
		goto choose;

}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inFile("Southbound timetable.txt", ios::in);


	Train train;
	inFile >> train.trainNumber >> train.departureTimes;

	char buf[9];
	inFile.get(buf, sizeof(buf), '\n');
	inFile.getline(buf, sizeof(buf), '\n');

	char ch;
	inFile.get(ch);

}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inFile("Southbound timetable.txt", ios::in);


	Train train;
	inFile >> train.trainNumber >> train.departureTimes;

	char buf[9];
	inFile.get(buf, sizeof(buf), '\n');
	inFile.getline(buf, sizeof(buf), '\n');

	char ch;
	inFile.get(ch);
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	Reservation re;
	cout << "Train No.  Departure  Arrival  " << endl;

	for (int i = 0; i < 10; i++)
	{
		cout << numSouthboundTrains << southboundTimetable[i] << departureTime;
	}
	int departuretime, arrivaltime;

	cout << "Enter Train Number:" << endl;
	cin >> re.trainNumber;

	cout << "Trip Details" << endl;
	display(reservation, trainTimetable, stations, carClass);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	Reservation re;
	cout << "Train No.  Departure  Arrival  " << endl;

	for (int i = 0; i < 10; i++)
	{
		cout << numNorthboundTrains << northboundTimetable[i] << departureTime;
	}

	int departuretime, arrivaltime;

	cout << "Enter Train Number:" << endl;
	cin >> re.trainNumber;
	
	cout << "Trip Details" << endl;
	display(reservation, trainTimetable, stations, carClass);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	Reservation re;
	cout << "Enter Contact Person Information" << endl;

	cout << "ID Number :";
	cin >> re.idNumber;
	cout << endl << endl << "Phone :";
	cin >> re.phone;
	cout << endl << endl << "Reservation Number :";
	for (int i = 0; i < 8; i++) {
		cout << rand() % 10;
	}
	cout << endl << endl << "Reservation Completed!";
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream outFile;

	outFile.open("Reservation details.dat", ios::app | ios::binary);

	outFile.write(reinterpret_cast<const char*>(&trainNumber), sizeof(trainNumber));
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation re;
	inputReservationDetails(reservation, departureTime);
	int num1, num2;
	num1 = re.originStation;
	num2 = re.destinationStation;
	if (num1 < num2)
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
	else
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);

	display(reservation, trainTimetable, stations, carClass);


	inputContactInfo(reservation);

	saveReservation(reservation);
	return;
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	existReservation(ioFile, reservation);
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	cout << endl << "Reservation Cancelled! " << endl << endl;
	return;
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	int idNumber, renum;
	cout << "Enter ID Number :";
	cin >> idNumber;
	cout << "Enter Reservation Number :";
	cin >> renum;
	for (unsigned int i = 0; i < reservation.size(); i++)
		if (!strcmp((char*)idNumber, reservation[i].idNumber) && !strcmp((char*)renum, reservation[i].reservationNumber))
			return true;

	return false;
}

void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	loadSouthboundTimetable(southboundTimetable[100], numSouthboundTrains);
	loadNorthboundTimetable(northboundTimetable[100], numNorthboundTrains);
	cout << "Reservation Details  " << endl;
	display(reservation, trainTimetable, stations, carClass);

	while (true)
	{
		int choice;
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reduceSeats(ioFile, southboundTimetable, northboundTimetable, reservation);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	Reservation re;
	int total, departuretime, arrivaltime;
	total = (700 * re.adultTickets) + (350 * re.concessionTickets);
	Reservation re;
	cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class";
	cout << setw(10) << right << re.date << setw(11) << re.trainNumber << setw(8) << re.originStation << setw(10) << re.destinationStation
		<< setw(11) << departuretime << setw(9) << arrivaltime << setw(7) << "700 *" << re.adultTickets << setw(11) << "350 *" << re.concessionTickets
		<< setw(6) << total << setw(10) << re.carClass;

}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int adnum, connum;
	cout << "How many adult tickets to cancel�H";
	cin >> adnum;
	cout << "How many concession tickets to cancel�H";
	cin >> connum;
	displayReservations(southboundTimetable, northboundTimetable, reservation);

	cout << "You have successfully reduced the number of tickets!";
}