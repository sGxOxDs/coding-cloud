#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include <sstream>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char num[3] = {" "};
	cin >> num;
	int number = 0;
	for (int i = 0; num[i] != 0; i++)
	{
		if (!isdigit(num[i]))
			return -1;
		else
		{
			number = num[i] - '0';
			if (i == 1)
				number = (num[0] -'0')* 10 + num[1]- '0';
			if (i == 2)
				return -1;
			
		}
	}
	if (number >= begin && number <= end)
		return number;
	else
		return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation buf = { " "," "," "," "," ",0,0,0,0,0 };
	int departureTime = 0;
	int alltrain = 0;
	inputReservationDetails(buf, departureTime);

	char station[13][12] = { " ","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carclass[12] = " ";
	char a[3][12] = {"", "Standard","Business" };

	if (buf.originStation < buf.destinationStation)
	{
		loadSouthboundTimetable(southboundTimetable, alltrain);
		selectSouthboundTrain(southboundTimetable, alltrain, buf, departureTime);
		if (buf.carClass == 1)
		{
			for (int i = 0; i < 12; i++)
			{
				carclass[i] = a[1][i];
			}
		}
		else
		{
			for (int i = 0; i < 12; i++)
			{
				carclass[i] = a[2][i];
			}
		}
		display(buf, southboundTimetable, station,  carclass);
	}
	else
	{
		loadSouthboundTimetable(northboundTimetable, alltrain);
		selectNorthboundTrain(northboundTimetable, alltrain, buf, departureTime);
		if (buf.carClass == 1)
		{
			for (int i = 0; i < 12; i++)
			{
				carclass[i] = a[1][i];
			}
		}
		else
		{
			for (int i = 0; i < 12; i++)
			{
				carclass[i] = a[2][i];
			}
		}
		display(buf, northboundTimetable,  station, carclass);
	}
	inputContactInfo(buf);
	saveReservation(buf);
	return;
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	cout << "Origin Station" << endl;
	string station[13] = { "0","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	for (int i = 1; i < 13; i++)
	{
		cout << i << "." << station[i] << endl;
	}
	cout << "?";
	int choice = 0;
	choice = inputAnInteger(1, 12);
	while (choice == -1)
	{
		cout << "?";
		choice = inputAnInteger(1, 12);
	}
	reservation.originStation = choice;

	cout << endl << "Destination Station" << endl;
	for (int i = 1; i < 13; i++)
	{
		cout << i << "." << station[i] << endl;
	}
	cout << "?";
	choice = inputAnInteger(1, 12);
	while (choice == -1 || choice == reservation.originStation)
	{
		cout << "?";
		choice = inputAnInteger(1, 12);
	}
	reservation.destinationStation = choice;

	cout << endl << "Car Class" << endl;
	cout << "1. Standard Car" << endl;
	cout << "2. Business Car" << endl;
	cout << "?";
	choice = inputAnInteger(1, 2);
	while (choice == -1)
	{
		cout << "?";
		choice = inputAnInteger(1, 2);
	}
	reservation.carClass = choice;

	cout << " Departure Date :";
	cin >> reservation.date; //??

	cout << endl << "Departure Time" << endl;
	for (int i = 1; i < 35; i++)
	{
		cout << i << "." << departureTimes[i] << endl;
	}
	cout << "?";
	choice = inputAnInteger(1, 34);
	while (choice == -1)
	{
		cout << "?";
		choice = inputAnInteger(1, 34);
	}
	departureTime = choice;

	cout << "How many adult tickets ?";
	cin >> reservation.adultTickets;
	cout << endl << "How many concession tickets?";
	cin >> reservation.concessionTickets;
	while(reservation.adultTickets + reservation.concessionTickets <= 0 || reservation.adultTickets<0 || reservation.concessionTickets<0)
	{
		cout << "How many adult tickets ?";
		cin >> reservation.adultTickets;
		cout << endl << "How many concession tickets?";
		cin >> reservation.concessionTickets;
	}

	return;
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	fstream document("Southbound timetable.txt", ios::in );
	
	numSouthboundTrains = 0;
	while(!document.eof() && numSouthboundTrains<100)
	{
		document >> southboundTimetable[numSouthboundTrains].trainNumber >> southboundTimetable[numSouthboundTrains].departureTimes[1] >> southboundTimetable[numSouthboundTrains].departureTimes[2] >> southboundTimetable[numSouthboundTrains].departureTimes[3] >> southboundTimetable[numSouthboundTrains].departureTimes[4] >> southboundTimetable[numSouthboundTrains].departureTimes[5] >> southboundTimetable[numSouthboundTrains].departureTimes[6] >> southboundTimetable[numSouthboundTrains].departureTimes[7] >> southboundTimetable[numSouthboundTrains].departureTimes[8] >> southboundTimetable[numSouthboundTrains].departureTimes[9] >> southboundTimetable[numSouthboundTrains].departureTimes[10] >> southboundTimetable[numSouthboundTrains].departureTimes[11] >> southboundTimetable[numSouthboundTrains].departureTimes[12];
		numSouthboundTrains++;
		//cout<< southboundTimetable[numSouthboundTrains].trainNumber << southboundTimetable[numSouthboundTrains].departureTimes[1] << southboundTimetable[numSouthboundTrains].departureTimes[2] << southboundTimetable[numSouthboundTrains].departureTimes[3] << southboundTimetable[numSouthboundTrains].departureTimes[4] << southboundTimetable[numSouthboundTrains].departureTimes[5] << southboundTimetable[numSouthboundTrains].departureTimes[6] << southboundTimetable[numSouthboundTrains].departureTimes[7] << southboundTimetable[numSouthboundTrains].departureTimes[8] << southboundTimetable[numSouthboundTrains].departureTimes[9] << southboundTimetable[numSouthboundTrains].departureTimes[7] << southboundTimetable[numSouthboundTrains].departureTimes[8] << southboundTimetable[numSouthboundTrains].departureTimes[9] << southboundTimetable[numSouthboundTrains].departureTimes[10] << southboundTimetable[numSouthboundTrains].departureTimes[11] << southboundTimetable[numSouthboundTrains].departureTimes[12]<<endl;
	}
	numSouthboundTrains--;
	
	//document.close();

	return;
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	fstream document("Northbound timetable.txt", ios::in );
	
	numNorthboundTrains = 0;
	while (!document.eof() && numNorthboundTrains<100)
	{
		document >> northboundTimetable[numNorthboundTrains].trainNumber >> northboundTimetable[numNorthboundTrains].departureTimes[1] >> northboundTimetable[numNorthboundTrains].departureTimes[2] >> northboundTimetable[numNorthboundTrains].departureTimes[3] >> northboundTimetable[numNorthboundTrains].departureTimes[4] >> northboundTimetable[numNorthboundTrains].departureTimes[5] >> northboundTimetable[numNorthboundTrains].departureTimes[6] >> northboundTimetable[numNorthboundTrains].departureTimes[7] >> northboundTimetable[numNorthboundTrains].departureTimes[8] >> northboundTimetable[numNorthboundTrains].departureTimes[9] >> northboundTimetable[numNorthboundTrains].departureTimes[10] >> northboundTimetable[numNorthboundTrains].departureTimes[11] >> northboundTimetable[numNorthboundTrains].departureTimes[12];
		numNorthboundTrains++;
	}
	numNorthboundTrains--;
	
	//document.close();
	return;
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << setw(10) << "Train No." << setw(11) << "Departure" << setw(8) << "Arrival" << endl;
	int time=0;
	for (int i = 0; i < numSouthboundTrains && time<10; i++)
	{
		if (strcmp(departureTimes[departureTime], southboundTimetable[i].departureTimes[reservation.originStation]) <= 0 && southboundTimetable[i].departureTimes[reservation.destinationStation][1]!='\0')
		{
			cout << setw(10) << southboundTimetable[i].trainNumber << setw(11) << southboundTimetable[i].departureTimes[reservation.originStation] << setw(8) << southboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
			time++;
		}
	}

	cout << endl << "Enter Train Number:";
	cin >> reservation.trainNumber;
	cout << endl << "Trip Details" << endl;
	return;
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << setw(10) << "Train No." << setw(11) << "Departure" << setw(8) << "Arrival" << endl;
	int time=0;
	for (int i = 0; i < numNorthboundTrains && time<10; i++)
	{
		if (strcmp(departureTimes[departureTime], northboundTimetable[i].departureTimes[reservation.originStation]) <= 0 && northboundTimetable[i].departureTimes[reservation.destinationStation][1] != '\0')
		{
			cout << setw(10) << northboundTimetable[i].trainNumber << setw(11) << northboundTimetable[i].departureTimes[reservation.originStation] << setw(8) << northboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
			
			time++;
		}
	}
	cout << endl << "Enter Train Number:";
	cin >> reservation.trainNumber;

	cout << endl << "Trip Details" << endl;
	return;
}
// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "Enter Contact Person Information" << endl;
	cout << endl << "ID Number:";
	cin >> reservation.idNumber;
	cout << endl <<endl<< "Phone:";
	cin >> reservation.phone;
	for (int i = 0; i < 8; i++)
	{
		reservation.reservationNumber[i] = (rand() % 10)+'0';
	}
	//reservation.reservationNumber[8] = '\0';
	cout << endl <<endl<< "Reservation Number:"<< reservation.reservationNumber<<endl;
	cout << endl << "Reservation Completed!" << endl;
	return;
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	fstream document("Reservation details.dat", ios::out | ios::binary| ios::app);
	document.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
	//document.close();
	return;
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	fstream document("Reservation details.dat", ios::in | ios::binary);
	Reservation buf;
	existReservation(document,buf);
	displayReservations(southboundTimetable, northboundTimetable, buf);

	int choice,point;

	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			reduceSeats(document, southboundTimetable, northboundTimetable, buf);
			break;
			return;
		case 2:
			reduceSeats(document, southboundTimetable, northboundTimetable, buf);
			/*cout << "Enter Your Choice" << endl;
			cout << "1. Cancellation" << endl;
			cout << "2. Reduce" << endl;
			cout << "3. End" << endl;
			cout << "?";
			point = inputAnInteger(1, 3);
			while (point == -1)
			{
				cout << "?";
				point = inputAnInteger(1, 3);
			}
			if (point == 1)
				cout << endl << "Reservation Cancelled!";*/
			break;
			return;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return ;
		}
		return;
	}
	return;
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	cout << "Enter ID Number: ";
	cin >> reservation.idNumber;
	cout << endl << "Enter Reservation Number:";
	cin >> reservation.reservationNumber;
	Reservation compare ;

	while (ioFile.read(reinterpret_cast<char*>(&compare), sizeof(Reservation)))
	{
		if (strcmp(compare.idNumber, reservation.idNumber) == 0 && strcmp(compare.reservationNumber, reservation.reservationNumber) == 0)
		{
			reservation = compare;
			return true;
		}
	}
	return false;
	ioFile.close();
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	cout << "Reservation Details " << endl;
	char station[13][12] = { " ","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carclass[12] = " ";
	char a[3][12] = { "", "Standard","Business" };
	if (reservation.carClass == 1)
	{
		for (int i = 0; i < 12; i++)
		{
			carclass[i] = a[1][i];
		}
	}
	else
	{
		for (int i = 0; i < 12; i++)
		{
			carclass[i] = a[2][i];
		}
	}
	if (reservation.originStation < reservation.destinationStation)
		display(reservation, southboundTimetable, station, carclass);
	else
		display(reservation, northboundTimetable, station, carclass);
	return;
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	cout << setw(10) << "Date" << setw(10) << "Train No." << setw(12) << "From" << setw(12) << "To" << setw(10) << "Departure" << setw(9) << "Arrival" << setw(8) << "Adult" << setw(11) << "Concession" << setw(6) << "Fare" << setw(12) << "Class" << endl;
	int train = 0;
	for (int i = 0; i < 100; i++)
	{
		if (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) == 0)
		{
			train=i;
		}
	}
	int fare = 0;
	fare = adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets + (adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2) * reservation.concessionTickets;
	if (fare != 0) 
	{
		cout<< setw(10) << reservation.date << setw(10) << reservation.trainNumber << setw(12) << stations[reservation.originStation]<< setw(12) << stations[reservation.destinationStation]<< setw(10)  << trainTimetable[train].departureTimes[reservation.originStation] << setw(9)<< trainTimetable[train].departureTimes[reservation.destinationStation] << setw(5) << adultTicketPrice[reservation.destinationStation][reservation.originStation]<<"*"<<setw(2)<<reservation.adultTickets << setw(8) << adultTicketPrice[reservation.destinationStation][reservation.originStation] /2<<"*"<<setw(2)<< reservation.concessionTickets<<setw(6) << fare << setw(12) << carClass << endl;
	}
		return;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int ac,cc;
	cout << "How many adult tickets to cancel�H";
	ac = inputAnInteger(0, reservation.adultTickets);
	while (ac == -1)
	{
		cout << "How many adult tickets to cancel�H";
		ac = inputAnInteger(0, reservation.adultTickets);
	}
	reservation.adultTickets -= ac;
	cout << "How many concession tickets to cancel�H";
	cc= inputAnInteger(0, reservation.concessionTickets);
	while (cc == -1)
	{
		cout << "How many concession tickets to cancel�H";
		cc = inputAnInteger(0, reservation.concessionTickets);
	}
	reservation.concessionTickets -= cc;
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	cout << "You have successfully reduced the number of tickets! " << endl;
	return;
}