#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 35 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30"};

char station[13][10] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
char carclass[3][15] = { "","Standard Car","Business Car" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );



int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int num = 0, num1 = 0;
   loadSouthboundTimetable(southboundTimetable, num);
   loadNorthboundTimetable(northboundTimetable, num1);

   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char input[100];
	cin >> input;
	for (int i = 0; i < strlen(input); i++)
	{
		if (!isdigit(input[i]))
		{
			return -1;
		}
	}
	int inputint = atoi(input);
	if (inputint >= begin && inputint <= end)
	{
		return inputint;
	}
	else
		return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;
	int departureTime;
	inputReservationDetails(reservation, departureTime);
	if (reservation.originStation < reservation.destinationStation)
	{
		selectSouthboundTrain(southboundTimetable, 87, reservation, departureTime);
	}
	else
	{
		selectNorthboundTrain(northboundTimetable, 92, reservation, departureTime);
	}
	inputContactInfo(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{	
	do
	{
		cout << "Origin Station\n";
		for (int i = 1; i < 13; i++)
			cout << i << ". " << station[i] << endl;
		int res;
		do cout << "\n? ";
		while ((res = inputAnInteger(1, 13)) == -1);
		cout << endl;
		reservation.originStation = res;

		cout << "Destination Station\n";
		for (int i = 1; i < 13; i++)
		{
			cout << i << ". " << station[i] << endl;
		}
		int des;
		do cout << "\n? ";
		while ((des = inputAnInteger(1, 13)) == -1);
		cout << endl;
		reservation.destinationStation = des;
	} while (reservation.originStation == reservation.destinationStation);

	cout << "Car Class\n";
	for (int i = 1; i < 3; i++)
		cout << i << ". " << carclass[i] << endl;
	int carc;
	do cout << "\n? ";
	while ((carc = inputAnInteger(1, 2)) == -1);
	cout << endl;
	reservation.carClass = carc;
	
	cout << "Departure Date: ";
	cin >> reservation.date;

	cout << "Departure Time\n";
	for (int i = 1; i < 35; i++)
	{
		cout << i << ". " << departureTimes[i] << endl;
	}
	int deptime;
	do cout << "\n? ";
	while ((deptime = inputAnInteger(1, 34)) == -1);
	departureTime = deptime;

	cout << "\nHow many adult tickets? ";
	cin >> reservation.adultTickets;
	while (reservation.adultTickets <= 0)
	{
		cout << "\nHow many adult tickets? ";
		cin >> reservation.adultTickets;
	}	
	cout << "\nHow many concession tickets? ";
	cin >> reservation.concessionTickets;
	while (reservation.concessionTickets <= 0)
	{
		cout << "\nHow many concession tickets? ";
		cin >> reservation.concessionTickets;
	}

}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inputsouth("Southbound timetable.txt", ios::in);
	
	int i = 0;
	while (!inputsouth.eof())
	{	
		inputsouth >> southboundTimetable[i].trainNumber;//�C�@�����Ĥ@��
		for (int j = 0; j < 12; j++)
		{	
			inputsouth >> southboundTimetable[i].departureTimes[j];
		}
		i++;
	}
	numSouthboundTrains = i - 1;
	inputsouth.close();
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inputnorth("Northbound timetable.txt", ios::in);
	int i = 0;
	while (!inputnorth.eof())
	{
		inputnorth >> northboundTimetable[i].trainNumber;//�C�@�����Ĥ@��
		for (int j = 0; j < 12; j++)
		{
			inputnorth >> northboundTimetable[i].departureTimes[j];	
		}
		i++;
	}
	numNorthboundTrains = i - 1;
	inputnorth.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains, Reservation& reservation, int departureTime)//�L�h�ɶ�
{
	cout << setw(10) << "\nTrain No." << setw(11) << "Departure" << setw(11) << "Arrival\n";
	char time[8];//12:00
	strcpy_s(time, departureTimes[departureTime]);//�ƻs�ɶ���time
	int minute = (time[3] - '0') * 10 + (time[4] - '0');
	int hour = (time[0] - '0') * 10 + (time[1] - '0');
	int i = 0;
	for (; i < numSouthboundTrains; i++)//��12:00���᪺�Q�ӿﶵ
	{
		char buffer[8];
		strcpy_s(buffer, southboundTimetable[i].departureTimes[reservation.originStation - 1]);//��ҿﯸ���ɶ���Jbuffer
		int minuter1 = (buffer[3] - '0') * 10 + (buffer[4] - '0');
		int hour1 = (buffer[0] - '0') * 10 + (buffer[1] - '0');
		if (hour1 == hour && minuter1 > minute)
		{
			break;
		}
	}
	int j = 0;
	while (j < 10)
	{
		if (strcmp(southboundTimetable[i].departureTimes[reservation.originStation - 1], "-") == 0||
			strcmp(southboundTimetable[i].departureTimes[reservation.destinationStation - 1], "-") == 0)
		{
			i++;
		}
		else
		{
			cout << setw(9) << southboundTimetable[i].trainNumber << setw(11) << southboundTimetable[i].departureTimes[reservation.originStation - 1] <<
				setw(11) << southboundTimetable[i].departureTimes[reservation.destinationStation - 1] << endl;
			i++;
			j++;
		}
		if (i >= numSouthboundTrains)
			break;
	}
	cout << "\nEnter Train Number: ";
	cin >> reservation.trainNumber;

	display(reservation, southboundTimetable);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, Reservation& reservation, int departureTime)
{
	cout << setw(10) << "\nTrain No." << setw(11) << "Departure" << setw(11) << "Arrival\n";
	char time[8];//12:00
	strcpy_s(time, departureTimes[departureTime]);//�ƻs�ɶ���time
	int minute = (time[3] - '0') * 10 + (time[4] - '0');
	int hour = (time[0] - '0') * 10 + (time[1] - '0');
	int i = 0;
	for (; i < numNorthboundTrains; i++)//��12:00���᪺�Q�ӿﶵ
	{
		char buffer[8];
		strcpy_s(buffer, northboundTimetable[i].departureTimes[reservation.originStation - 1]);//��ҿﯸ���ɶ���Jbuffer
		int minuter1 = (buffer[3] - '0') * 10 + (buffer[4] - '0');
		int hour1 = (buffer[0] - '0') * 10 + (buffer[1] - '0');
		if (hour1 == hour && minuter1 > minute)
		{
			break;
		}
	}
	int j = 0;
	while (j < 10)
	{
		if (strcmp(northboundTimetable[i].departureTimes[reservation.originStation - 1], "-") == 0 ||
			strcmp(northboundTimetable[i].departureTimes[reservation.destinationStation - 1], "-") == 0)
		{
			i++;
		}
		else
		{
			cout << setw(10) << northboundTimetable[i].trainNumber << setw(11) << northboundTimetable[i].departureTimes[reservation.originStation - 1] <<
				setw(10) << northboundTimetable[i].departureTimes[reservation.destinationStation - 1] << endl;
			i++;
			j++;
		}
		if (i >= numNorthboundTrains)
			break;
	}
	cout << "\nEnter Train Number: ";
	cin >> reservation.trainNumber;

	display(reservation, northboundTimetable);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "\n\nID Number: ";
	cin >> reservation.idNumber;
	cout << "Phone: ";
	cin >> reservation.phone;
	cout << "Reservation Number: ";
	char reservernum[8];
	for (int i = 0; i < 8; i++)
	{
		reservation.reservationNumber[i] = rand() % 10 + '0';
	}
	reservation.reservationNumber[8] = '\0';
	//strcpy_s(reservation.reservationNumber, reservernum);
	cout << reservation.reservationNumber;
	cout << "\n\nReservation Completed!\n";
	saveReservation(reservation);
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream output("details.dat", ios::app | ios::binary);
	output.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
	
}

void reservationHistory(Train southboundTimetable[100], Train northboundTimetable[100])
{	
	Reservation check;
	cout << "\nEnter ID Number: ";
	cin >> check.idNumber;
	cout << "\nEnter Reservation Number: ";
	cin >> check.reservationNumber;
	fstream input("details.dat", ios::in | ios::binary);
	if (existReservation(input, check))
	{
		displayReservations(southboundTimetable, northboundTimetable, check);
	}
	
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{	
	Reservation buffer;
	while (ioFile.read(reinterpret_cast<char*>(&buffer), sizeof(Reservation)))
	{
		if (strcmp(buffer.idNumber, reservation.idNumber) == 0 && strcmp(buffer.reservationNumber, reservation.reservationNumber) == 0)
		{
			reservation = buffer;//�^�ǵ�check
			return true;
		}
	}
	return false;
}

void displayReservations(Train southboundTimetable[100], Train northboundTimetable[100], Reservation reservation)
{
	if (reservation.originStation < reservation.destinationStation)
	{
		display(reservation, southboundTimetable);
	}
	else
	{
		display(reservation, northboundTimetable);
	}
	int choice;
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;
		fstream input("details.dat", ios::in | ios::out| ios::binary);
		int count = 0;
		switch (choice)
		{
		case 1:
			
			cout << "\nReservation Cancelled!";
			break;
		case 2:
			reduceSeats(input, southboundTimetable, northboundTimetable, reservation);
			break;
		case 3:
			return;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100])//��table��
{
	int i = 0;
	for (; i < 92; i++)
	{		
		if (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) == 0)
		{
			break;//���L�btable����
		}		
	}

	cout << setw(10) << "Date" << setw(13) << "Train No." << setw(10) << "From" << setw(10) << "to" << setw(13) << "Departure" <<
		setw(13) << "Arrival" << setw(13) << "Adult" << setw(13) << "Concession" << setw(8) << "Fare" << setw(13) << "Class" << endl;
	cout << setw(10) << reservation.date << setw(13) << reservation.trainNumber << setw(10) << station[reservation.originStation] << setw(10) <<
		station[reservation.destinationStation] << setw(13) << trainTimetable[i].departureTimes[reservation.originStation - 1]
		<< setw(13) << trainTimetable[i].departureTimes[reservation.destinationStation - 1];
	int oristation = reservation.originStation, destation = reservation.destinationStation;
	int adult = 0, concess = 0;
	if (reservation.carClass == 1)
	{
		adult = adultTicketPrice[destation][oristation];
		concess = adult / 2;
	}
	else
	{
		adult = adultTicketPrice[oristation][destation];
		concess = adult / 2;
	}
	cout << setw(11) << adult << "*" << reservation.adultTickets << setw(11) << concess << "*" << reservation.concessionTickets << setw(8) <<
		adult * reservation.adultTickets + concess * reservation.concessionTickets << setw(13) << carclass[reservation.carClass];
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation)
{
	int cancelad, cancelcos;
	cout << "\nHow many adult tickets to cancel�H";
	cin >> cancelad;
	cout << "How many concession tickets to cancel�H";
	cin >> cancelcos;

	reservation.adultTickets -= cancelad;
	reservation.concessionTickets -= cancelcos;
	int count = 0;
	Reservation check;
	while (ioFile.read(reinterpret_cast<char*>(&check), sizeof(Reservation)))//�p��L�b�ɮת���m
	{
		if (strcmp(check.idNumber, reservation.idNumber) == 0)
		{
			break;
		}
		count++;
	}
	ioFile.seekg(count * sizeof(Reservation),ios::beg);
	ioFile.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
	if (reservation.originStation < reservation.destinationStation)
	{
		display(reservation, southboundTimetable);
	}
	else
	{
		display(reservation, northboundTimetable);
	}

	cout << "\n\nYou have successfully reduced the number of tickets! ";
}