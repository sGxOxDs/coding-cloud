#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <string.h>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30"};
char stations[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
char carClass[3][15] = { "","Standard Car","Business Car" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used
	
// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end) {
	int in;
	while(cin >> in)
		if (in >= begin && in <= end)return in;
}


void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);
// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main
void inputContactInfo(Reservation& reservation) {
	string id,ph,rn;
	srand(time(NULL));
	int r =rand() % 9999998 + 20000000;
	r -= 10000000;
	stringstream ss;
	bool nu = 0;
	char A = 'A', Z = 'Z',z = '0',n = '9';
	cout << "Enter Contact Person Information" << endl << endl;
	do{
		cout << "ID Number: ";
		cin >> id;
		nu = 0;
		for (int i = 1; i < id.length(); i++) {
			if ((id[i] - 0 < z - 0) || (id[i] - 0 > n - 0))break;
			if (i == id.length() - 1)nu = 1;
		}
	} while (!(((A - 0 <= id[0] - 0) && ((Z - 0) >= id[0] - 0)) && (id[1] == '2' || id[1] == '1') && id.length() == 10 && nu));
	for (int i = 0; i < 12; i++)reservation.idNumber[i] = ' ';
	for (int i = 0; i < id.length(); i++)reservation.idNumber[i] = id[i];
	cout << endl << endl;
	do {
		cout << "Phone: ";
		cin >> ph;
		nu = 0;
		for (int i = 0; i < ph.length(); i++) {
			if ((ph[i] - 0 < z - 0) || (ph[i] - 0 > n - 0))break;
			if (i == ph.length() - 1)nu = 1;
		}
	}while (!(ph[0] = '0' && ph[1] == '9' && nu && ph.length() == 10));
	for (int i = 0; i < 12; i++)reservation.phone[i] = ' ';
	for (int i = 0; i < ph.length(); i++)reservation.phone[i] = ph[i];
	cout << endl << endl;
	ss.clear();
	ss.str("");
	ss << r;
	ss >> rn;
	for (int i = 0; i < 12; i++)reservation.reservationNumber[i] = ' ';
	for (int i = 0; i < rn.length(); i++)reservation.reservationNumber[i] = rn[i];
	cout << "Reservation Number: " << rn << endl << endl << "Reservation Completed!" << endl << endl;
	saveReservation(reservation);
}
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) {
	ifstream fin("Southbound timetable.txt");
	string str,s;
	stringstream ss;
	vector<vector<string>> tab;
	while (getline(fin,str)) {
		ss.clear();
		ss.str(str);
		vector<string>lin;
		while (ss >> s)lin.push_back(s);
		tab.push_back(lin);
	}
	numSouthboundTrains = tab.size();
	Train* tr = new Train;
	for (int i = 0; i < tab.size(); i++) {
		tr = new Train;
		for (int n = 0; n < 8; n++)tr->trainNumber[n] = '\0';
		for (int k = 0; k < tab[i][0].size(); k++)tr->trainNumber[k] = tab[i][0][k];
		for (int j = 1; j < tab[i].size(); j++) {
			for (int o = 0; o < 8; o++)tr->departureTimes[j][o] = '\0';
			for (int m = 0; m < tab[i][j].size(); m++)tr->departureTimes[j][m] = tab[i][j][m];
		}
		southboundTimetable[i] = *tr;
	}
}
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) {
	ifstream fin("Northbound timetable.txt");
	string str, s;
	stringstream ss;
	vector<vector<string>> tab;
	while (getline(fin,str)) {
		ss.clear();
		ss.str(str);
		vector<string>lin;
		while (ss >> s)lin.push_back(s);
		reverse(lin.begin() + 1, lin.end());
		tab.push_back(lin);
	}
	numNorthboundTrains = tab.size();
	Train* tr = new Train;
	for (int i = 0; i < tab.size(); i++) {
		tr = new Train;
		for (int n = 0; n < 8; n++)tr->trainNumber[n] = '\0';
		for (int k = 0; k < tab[i][0].size(); k++)tr->trainNumber[k] = tab[i][0][k];
		for (int j = 1; j < tab[i].size(); j++) {
			for (int o = 0; o < 8; o++)tr->departureTimes[j][o] = '\0';
			for (int m = 0; m < tab[i][j].size(); m++)tr->departureTimes[j][m] = tab[i][j][m];
		}
		northboundTimetable[i] = *tr;
	}
}
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,	Reservation& reservation, int departureTime) {
	vector<int>trs;
	string s;
	bool st = 0;
	cout << "Train No.\tDeparture\tArrival\n";
	for (int i = 0; i < numSouthboundTrains; i++) {
		if (southboundTimetable[i].departureTimes[reservation.originStation][0] != '-' && southboundTimetable[i].departureTimes[reservation.originStation][3] != '-' &&
			southboundTimetable[i].departureTimes[reservation.originStation][0] == departureTimes[departureTime][0] &&
			southboundTimetable[i].departureTimes[reservation.originStation][1] == departureTimes[departureTime][1]) {
			st = 1;
		}
		if (st) {
			if (southboundTimetable[i].departureTimes[reservation.originStation][0] != '-' && southboundTimetable[i].departureTimes[reservation.originStation][3] != '-' &&
				southboundTimetable[i].departureTimes[reservation.originStation][3] - 0 >= departureTimes[departureTime][3] - 0 &&
				southboundTimetable[i].departureTimes[reservation.originStation][4] - 0 >= departureTimes[departureTime][4] - 0) {
				trs.push_back(i);
				for (int j = 0; j < 8; j++)cout << southboundTimetable[i].trainNumber[j];
				cout << '\t';
				for (int k = 0; k < 8; k++)cout << southboundTimetable[i].departureTimes[reservation.originStation][k];
				cout << '\t';
				for (int l = 0; l < 8; l++)cout << southboundTimetable[i].departureTimes[reservation.destinationStation][l];
				cout << '\n';
			}
			if (trs.size() >= 10)break;
		}
	}
	bool cr = 0;
	while (cin >> s) {
		for (int i = 0; i < trs.size(); i++) {
			for (int j = 0; j < s.length(); j++) {
				if (s[j] != southboundTimetable[trs[i]].trainNumber[j])break;
				if (j == s.length() - 1 && southboundTimetable[trs[i]].trainNumber[j + 1] == '\0') {
					for (int m = 0; m < 9;m++)reservation.trainNumber[m] = southboundTimetable[trs[i]].trainNumber[m];
					for (int o = 0; o < 5; o++)reservation.date[o] = southboundTimetable[i].departureTimes[reservation.originStation][o];
					for (int p = 5; p < 10; p++)reservation.date[p] = southboundTimetable[i].departureTimes[reservation.destinationStation][p-5];
					cr = 1;
					break;
				}
			}
			if (cr == 1)break;
		}
		if (cr == 1)break;
	}
}
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, Reservation& reservation, int departureTime){
	vector<int>trs;
	string s;
	bool st = 0;
	cout << "Train\tNo.Departure\tArrival\n";
	for (int i = 0; i < numNorthboundTrains; i++) {
		if (northboundTimetable[i].departureTimes[reservation.originStation][0] != '-' && northboundTimetable[i].departureTimes[reservation.originStation][3] != '-'&&
			northboundTimetable[i].departureTimes[reservation.originStation][0] == departureTimes[departureTime][0] &&
			northboundTimetable[i].departureTimes[reservation.originStation][1] == departureTimes[departureTime][1]) {
			st = 1;
		}
		if (st) {
			if (trs.size() > 10)break;
			if (northboundTimetable[i].departureTimes[reservation.originStation][0] != '-' && northboundTimetable[i].departureTimes[reservation.originStation][3] != '-' &&
				northboundTimetable[i].departureTimes[reservation.originStation][3] - 0 >= departureTimes[departureTime][3] - 0 &&
				northboundTimetable[i].departureTimes[reservation.originStation][4] - 0 >= departureTimes[departureTime][4] - 0) {
				trs.push_back(i);
				for (int j = 0; j < 8; j++)cout << northboundTimetable[i].trainNumber[j];
				cout << '\t';
				for (int k = 0; k < 8; k++)cout << northboundTimetable[i].departureTimes[reservation.originStation][k];
				cout << '\t';
				for (int l = 0; l < 8; l++)cout << northboundTimetable[i].departureTimes[reservation.destinationStation][l];
			}
			cout << '\n';
		}
	}
	bool cr = 0;
	while (cin >> s) {
		for (int i = 0; i < trs.size(); i++) {
			for (int j = 0; j < s.length(); j++) {
				if (s[j] != northboundTimetable[trs[i]].trainNumber[j])break;
				if (j == s.length() - 1 && northboundTimetable[trs[i]].trainNumber[j + 1] == '\0') {
					for (int m = 0; m < 9;m++)reservation.trainNumber[m] = northboundTimetable[trs[i]].trainNumber[m];
					for (int o = 0; o < 5; o++)reservation.date[o] = northboundTimetable[i].departureTimes[reservation.originStation][o];
					for (int p = 5; p < 10; p++)reservation.date[p] = northboundTimetable[i].departureTimes[reservation.destinationStation][p-5];
					cr = 1;
					break;
				}
			}
			if (cr == 1)break;
		}
		if (cr == 1)break;
	}
}
void inputReservationDetails(Reservation& reservation, int& departureTime) {
	string a,b,c,d,e;
	int ai, bi,ci,ei,at,ct;
	stringstream ss;
	char z = '1',n = '9';
	cout << "Origin Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying" << endl << endl;
	do{
		cout << "? ";
		cin >> a;
		ss.clear();
		ss.str(a);
		ss >> ai;
	}while (!((a.length() == 1 || a.length() == 2) && (a[0] - 0 <= n - 0 && a[0] - 0 >= z - 0) && (a[a.length() - 1] - 0 <= n - 0 && a[a.length() - 1] - 0 >= z - 0) && ai < 13));
	reservation.originStation = ai;
	cout << "Destination Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying" << endl << endl;
	do {
		cout << "? ";
		cin >> b;
		ss.clear();
		ss.str(b);
		ss >> bi;
	} while (!((b.length() == 1 || b.length() == 2) && (b[0] - 0 <= n - 0 && b[0] - 0 >= z - 0) && (b[b.length() - 1] - 0 <= n - 0 && b[b.length() - 1] - 0 >= z - 0) && bi < 13 && bi != ai));
	reservation.destinationStation = bi;
	cout << "Car Class\n1. Standard Car\n2. Business Car\n";
	do {
		cout << "? ";
		cin >> c;
		ss.clear();
		ss.str(c);
		ss >> ci;
	} while (!((c.length() == 1) && (c[0] - 0 <= n - 0 && c[0] - 0 >= z - 0) && ci < 3));
	reservation.carClass = ci;
	cout << "Departure Date : " << d;
	cout << "Departure Time\n";
	for (int i = 1; i < 35; i++) {
		cout << i << ". ";
		for (int j = 0; j < 8; j++)cout << departureTimes[i][j];
		cout << endl;
	}
	do {
		cout << "? ";
		cin >> e;
		ss.clear();
		ss.str(e);
		ss >> ei;
	} while (!((e.length() == 1 || e.length() == 2) && (e[0] - 0 <= n - 0 && e[0] - 0 >= z - 0) && (e[e.length() - 1] - 0 <= n - 0 && e[e.length() - 1] - 0 >= z - 0) && ei < 35));
	departureTime = ei;
	cout << "How many adult tickets ? ";
	cin >> at;
	reservation.adultTickets = at;	
	cout << "How many concession tickets ? ";
	cin >> ct;
	reservation.concessionTickets = ct;
}
void display(Reservation reservation, Train trainTimetable[100]) {
	cout << "Date\tTrain No.\tFrom\t    To\t\tDeparture\tArrival\tAdult\tConcession\tFare\tClass\n";
	cout << "NEVER\t";
	for (int i = 0; i < 8; i++)cout << reservation.trainNumber[i];
	cout << "\t";
	for (int i = 0; i < 12; i++)cout << stations[reservation.originStation][i];
	//cout << "\t";
	for (int i = 0; i < 12; i++)cout << stations[reservation.destinationStation][i];
	cout << "\t";
	for (int i = 0; i < 5; i++)cout << reservation.date[i];
	cout << "\t";
	for (int i = 5; i < 10; i++)cout << reservation.date[i];
	cout << "\t";
	int fare = 0;
	if (reservation.carClass == 2) {
		cout << adultTicketPrice[reservation.originStation][reservation.destinationStation] << '*' << reservation.adultTickets;
		fare += adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets;
		cout << "\t";
		cout << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << '*' << reservation.concessionTickets;
		fare += adultTicketPrice[reservation.originStation][reservation.destinationStation]/2 * reservation.concessionTickets;
	}
	else {
		cout << adultTicketPrice[reservation.destinationStation][reservation.originStation] << '*' << reservation.adultTickets;
		fare += adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets;
		cout << "\t";
		cout << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << '*' << reservation.concessionTickets;
		fare += adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 * reservation.concessionTickets;
	}
	cout << "\t\t" << fare;
	cout << "\t" <<	carClass[reservation.carClass] << endl << endl;
}
void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]) {
	Reservation res;
	int det, nt;
	inputReservationDetails(res, det);
	if (res.destinationStation < res.originStation) {
		loadNorthboundTimetable(northboundTimetable, nt);
		selectNorthboundTrain(northboundTimetable, nt, res, det);
		display(res, northboundTimetable);
	}
	else {
		loadSouthboundTimetable(southboundTimetable, nt);
		selectSouthboundTrain(southboundTimetable, nt, res, det);
		display(res, northboundTimetable);
	}
	inputContactInfo(res);
}
void saveReservation(Reservation reservation) {
	ofstream fout("reservation.dat");
	fout << reservation.idNumber << "\t" << reservation.reservationNumber << "\t" << reservation.phone << "\t";
	fout << reservation.trainNumber;
	fout << "\t";
	fout << reservation.originStation;
	fout << "\t";
	fout << reservation.destinationStation;
	fout << "\t";
	fout << reservation.date;
	fout << "\t";
		fout << reservation.adultTickets;
		fout << "\t";
		fout << reservation.concessionTickets;
	fout << "\t" << reservation.carClass << endl << endl;
}

bool existReservation(fstream& ioFile, Reservation& reservation) { 
	ifstream fin("reservation.dat");
	string str, s;
	stringstream ss;
	bool y = 0;
	vector<vector<string>> tab;
	while (getline(fin, str)) {
		ss.clear();
		ss.str(str);
		vector<string>lin;
		while (ss >> s)lin.push_back(s);
		tab.push_back(lin);
	}
	
	cout << "Enter ID Number: ";
	cin >> s;
	cout << "Enter Reservation Number :";
	cin >> str;
	for (int i = 0; i < tab.size(); i++){
		for (int k = 0; k < tab[i][0].length(); k++)reservation.idNumber[k] = tab[i][0][k];
		for (int k = 0; k < tab[i][1].length(); k++)reservation.reservationNumber[k] = tab[i][1][k];
		for (int k = 0; k < tab[i][2].length(); k++)reservation.phone[k] = tab[i][2][k];
		for (int n = 0; n < 8; n++)reservation.trainNumber[n] = '\0';
		for (int k = 0; k < tab[i][3].length(); k++)reservation.trainNumber[k] = tab[i][3][k];
		reservation.originStation = atoi(tab[i][4].c_str());
		reservation.destinationStation = atoi(tab[i][5].c_str());
		for (int n = 0; n < 12; n++)reservation.date[n] = '\0';
		for (int k = 0; k < tab[i][6].length(); k++)reservation.date[k] = tab[i][6][k];
		reservation.adultTickets = atoi(tab[i][7].c_str());
		reservation.concessionTickets = atoi(tab[i][8].c_str());
		reservation.carClass = atoi(tab[i][9].c_str());
	}
	for (int i = 0; i < tab.size(); i++) {
		if (tab[i][0] == s && tab[i][1] == str)y = 1;
	}
	return y; }
void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]) {
	Reservation res;
	fstream fin("reservation.dat");
	existReservation(fin, res);
	displayReservations(southboundTimetable, northboundTimetable, res);
}
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation) {}
void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation) {
	cout << "Date\tTrain No.\tFrom\t    To\t\tDeparture\tArrival\tAdult\tConcession\tFare\tClass\n";
	cout << "NEVER\t";
	for (int i = 0; i < 8; i++)cout << reservation.trainNumber[i];
	cout << "\t";
	for (int i = 0; i < 12; i++)cout << stations[reservation.originStation][i];
	//cout << "\t";
	for (int i = 0; i < 12; i++)cout << stations[reservation.destinationStation][i];
	cout << "\t";
	for (int i = 0; i < 5; i++)cout << reservation.date[i];
	cout << "\t";
	for (int i = 5; i < 10; i++)cout << reservation.date[i];
	cout << "\t";
	int fare = 0;
	if (reservation.carClass == 2) {
		cout << adultTicketPrice[reservation.originStation][reservation.destinationStation] << '*' << reservation.adultTickets;
		fare += adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets;
		cout << "\t";
		cout << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << '*' << reservation.concessionTickets;
		fare += adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 * reservation.concessionTickets;
	}
	else {
		cout << adultTicketPrice[reservation.destinationStation][reservation.originStation] << '*' << reservation.adultTickets;
		fare += adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets;
		cout << "\t";
		cout << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << '*' << reservation.concessionTickets;
		fare += adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 * reservation.concessionTickets;
	}
	cout << "\t\t" << fare;
	cout << "\t" << carClass[reservation.carClass] << endl << endl;
}