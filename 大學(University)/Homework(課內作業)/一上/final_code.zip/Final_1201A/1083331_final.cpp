#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[35][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	string temp = {};

	int number = 0;

	cin >> temp;

	if (temp.size() > 2)
	{
		return -1;
	}
	else if (temp.size() == 2)
	{
		for (int i = 0; i < 2; i++)
		{
			if (temp[i] > '9' || temp[i] < '0')
			{
				return -1;
			}
		}

		number = (temp[0] - '0') * 10 + (temp[1] - '0');

		if (number >= begin && number <= end)
		{
			return number;
		}
		else
		{
			return -1;
		}
	}
	else if (temp.size() == 1)
	{
		if (temp[0] > '9' || temp[0] < '0')
		{
			return -1;
		}

		number = (temp[0] - '0');

		if (number >= begin && number <= end)
		{
			return number;
		}
		else
		{
			return -1;
		}
	}
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation temp;

	int departureTime = 0;
	int numboundTrains;

	inputReservationDetails(temp, departureTime);

	if (temp.destinationStation > temp.originStation)
	{
		loadSouthboundTimetable(southboundTimetable, numboundTrains);
		selectSouthboundTrain(southboundTimetable, numboundTrains, temp, departureTime);
	}
	else
	{
		loadNorthboundTimetable(northboundTimetable, numboundTrains);
		selectNorthboundTrain(northboundTimetable, numboundTrains, temp, departureTime);
	}

	inputContactInfo(temp);

	saveReservation(temp);

}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	int choice = 0;

	char train[13][12] = { "",
   "Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli", "Taichung", "Changhua",
   "Yunlin", "Chiayi", "Tainan", "Zuoying" };

	char carClass1[12] = { "Standard" };
	char carClass2[12] = { "Business" };

	cout << "Origin Station" << endl;

	for (int i = 1; i < 13; i++)
	{
		cout << i << ". " << train[i] << endl;
	}

	do cout << "? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	cout << endl;

	reservation.originStation = choice;

	cout << "Destination Station" << endl;

	for (int i = 1; i < 13; i++)
	{
		cout << i << ". " << train[i] << endl;
	}

	do cout << "? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	cout << endl;

	reservation.destinationStation = choice;

	while (reservation.destinationStation == reservation.originStation)
	{
		do cout << "Your Origin Station and Destination Station are same. Please try entering Destination Station again !" << endl << "\n? ";
		while ((choice = inputAnInteger(1, 12)) == -1);
		cout << endl;

		reservation.destinationStation = choice;
	}

	cout << "Car Class" << endl;
	cout << "1. Standard Car" << endl;
	cout << "2. Business Car" << endl;

	do cout << "? ";
	while ((choice = inputAnInteger(1, 2)) == -1);
	cout << endl;

	reservation.carClass = choice;

	cout << "Departure Date: ";
	cin >> reservation.date;
	cout << endl;

	cout << "Departure Time" << endl;

	for (int i = 1; i < 35; i++)
	{
		cout << setw(2) << i << ". " << departureTimes[i] << endl;
	}

	do cout << "? ";
	while ((choice = inputAnInteger(1, 35)) == -1);
	cout << endl;

	departureTime = choice;

	Train boundTimetable[100];
	int numboundTrains;

	do {
		do cout << "How many adult tickets ? ";
		while ((choice = inputAnInteger(0, 100)) == -1);
		cout << endl;

		reservation.adultTickets = choice;

		do cout << "How many concession tickets ? ";
		while ((choice = inputAnInteger(0, 100)) == -1);
		cout << endl;

		reservation.concessionTickets = choice;
	} while (reservation.adultTickets == 0 && reservation.concessionTickets == 0);
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	fstream load1("Southbound timetable.txt", ios::in);

	string str;
	string alldata;

	numSouthboundTrains = 1;

	load1 >> alldata;

	while (!load1.eof())
	{
		load1 >> southboundTimetable[numSouthboundTrains].trainNumber;

		for (int j = 13; j >= 0; j++)
		{
			 load1 >> southboundTimetable[numSouthboundTrains].departureTimes[j];
		}

		numSouthboundTrains++;

		/*for (int i = 0; i < numSouthboundTrains; i++)
		{
			for (int j = 13; j >= 0; j++)
			{
				load1 >> southboundTimetable[i].trainNumber >> southboundTimetable[i].departureTimes[j];
			}
		}*/
	}
	/*while (!load1.eof())
	{
		for (int i = 0; i < numSouthboundTrains; i++)
		{
			getline(southboundTimetable[i], sizeof(Train));
		}
	}*/


	/*load1.seekg(0, ios::end);

	numSouthboundTrains = load1.tellg() / sizeof(Train);

	load1.seekg(0, ios::beg);

	for (int i = 0; i < numSouthboundTrains; i++)
	{
		load1.read(reinterpret_cast<char*>(&southboundTimetable[i]), sizeof(Train));
	}

	load1.close();*/

	
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	fstream load2("Northbound timetable.txt", ios::in);

	string alldata;

	load2 >> alldata;

	while (!load2.eof())
	{
		load2 >> northboundTimetable[numNorthboundTrains].trainNumber;

		for (int j = 13; j >= 0; j++)
		{
			load2 >> northboundTimetable[numNorthboundTrains].departureTimes[j];
		}

		numNorthboundTrains++;
	}

	/*load2.seekg(0, ios::end);

	numNorthboundTrains = load2.tellg() / sizeof(Train);

	load2.seekg(0, ios::beg);

	for (int i = 0; i < numNorthboundTrains; i++)
	{
		load2.read(reinterpret_cast<char*>(&northboundTimetable[i]), sizeof(Train));
	}

	load2.close();*/
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	int no;
	char time[8];
	int station1, station2;

	//departureTime -= 13;

	char train[13][12] = { "",
   "Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli", "Taichung", "Changhua",
   "Yunlin", "Chiayi", "Tainan", "Zuoying" };

	char carClass1[12] = { "Standard" };
	char carClass2[12] = { "Business" };

	station1 = reservation.originStation;
	station2 = reservation.destinationStation;

	for (int i = 0; i < 8; i++)
	{
		time[i] = departureTimes[departureTime][i];
	}

	//cout << time << endl;

	int j;

	for (int i = 0; i < 100; i++)
	{
		for (j = 0; j < 8; j++)
		{
			if (time[i] > southboundTimetable[i].departureTimes[station1][j])
			{
				break;
			}
			if (time[i] < southboundTimetable[i].departureTimes[station1][j])
			{
				no = j;
				break;
			}
		}

		if (j == 8)
		{
			no = i;
		}
	}

	cout << "Train No.  Departure  Arrival" << endl;

	for (int i = 0; i < 10; i++)
	{
		cout << setw(9) << southboundTimetable[no + i].trainNumber << setw(11)
			<< southboundTimetable[no + i].departureTimes[station1] << setw(9) << southboundTimetable[no + i].departureTimes[station2] << endl;
	}

	cout << "Enter train Number: ";
	cin >> reservation.trainNumber;

	cout << "Trip Details" << endl;

	if (reservation.carClass == 1)
	{
		display(reservation, southboundTimetable, train, carClass1);
	}
	else
	{
		display(reservation, southboundTimetable, train, carClass2);
	}


}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	int no;
	char time[8];
	int station1, station2;

	char train[13][12] = { "",
   "Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli", "Taichung", "Changhua",
   "Yunlin", "Chiayi", "Tainan", "Zuoying" };

	char carClass1[12] = { "Standard" };
	char carClass2[12] = { "Business" };

	station1 = reservation.originStation;
	station2 = reservation.destinationStation;

	for (int i = 0; i < 8; i++)
	{
		time[i] = departureTimes[departureTime][i];
	}

	int j;

	for (int i = 0; i < 100; i++)
	{
		for (j = 0; j < 8; j++)
		{
			if (time[i] > northboundTimetable[i].departureTimes[station1][j])
			{
				break;
			}
		}

		if (j == 8)
		{
			no = i;
		}
	}

	cout << "Train No.  Departure  Arrival" << endl;

	for (int i = 0; i < 10; i++)
	{
		cout << setw(9) << northboundTimetable[no + i].trainNumber << setw(11)
			<< northboundTimetable[no + i].departureTimes[station1] << setw(9) << northboundTimetable[no + i].departureTimes[station2] << endl;
	}

	cout << "Enter train Number: ";
	cin >> reservation.trainNumber;

	cout << "\nTrip Details" << endl;

	if (reservation.carClass == 1)
	{
		display(reservation, northboundTimetable, train, carClass1);
	}
	else
	{
		display(reservation, northboundTimetable, train, carClass2);
	}

}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "\nEnter Contact Person Information" << endl;
	cout << endl;

	cout << "ID Number: ";
	cin >> reservation.idNumber;
	cout << endl;

	cout << "Phone: ";
	cin >> reservation.phone;
	cout << endl;

	cout << "Reservation Number : ";

	int num = time(0);

	for (int i = 0; i < 13; i++)
	{
		reservation.reservationNumber[i] = '\0';
	}

	for (int i = 0; i < 8; i++)
	{
		reservation.reservationNumber[i] = rand() % 10 + '0';
	}

	cout << reservation.reservationNumber << endl;
	cout << endl;

	cout << "Reservation Completed ! " << endl;

}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	fstream save1("Reservation details.dat", ios::in | ios::out | ios::binary);

	if (!save1)
	{
		ofstream save2("Reservation details.dat", ios::out | ios::binary);

		/*save2.seekg(0, ios::end);

		int numReservations = save2.tellg() / sizeof(Train);

		save2.seekg((sizeof(reservation) * numReservations), ios::beg);*/

		save2.write(reinterpret_cast<char*>(&reservation), sizeof(reservation));
	}
	else
	{
		save1.seekg(0, ios::end);

		int numReservations = save1.tellg() / sizeof(Train);

		save1.seekg((sizeof(reservation) * numReservations), ios::beg);

		save1.write(reinterpret_cast<char*>(&reservation), sizeof(reservation));
	}
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	Reservation temp;

	fstream open;

	if (existReservation(open, temp) == 1)
	{
		int choice;

		while (true)
		{
			cout << "\nEnter Your Choice\n"
				<< "1. Cancellation\n"
				<< "2. Reduce\n"
				<< "3. End";

			do cout << "\n? ";
			while ((choice = inputAnInteger(1, 3)) == -1);
			cout << endl;

			switch (choice)
			{
			case 1:
				temp.reservationNumber[8] = {};
				temp.trainNumber[12] = {};
				temp.idNumber[12] = {};
				temp.phone[12] = {};
				temp.date[12] = {};
				temp.originStation = 0;
				temp.destinationStation = 0;
				temp.carClass = 0;
				temp.adultTickets = 0;
				temp.concessionTickets = 0;
				cout << "Reservation Cancelled!" << endl;
				break;
			case 2:
				reduceSeats(open, southboundTimetable, northboundTimetable, temp);
				displayReservations(southboundTimetable, northboundTimetable, temp);
				break;
			case 3:
				return;
			default: // display error if user does not select valid choice
				cerr << "Incorrect Choice!\n";
				break;
			}

		}
	}
	else
	{
		cout << "Invalid ID number or reservation number. Please try again !" << endl;
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	char id[12] = {};
	char reservationnum[12] = {};

	// ioFile.open("Reservation Details.dat");

	//ioFile.seekg(0, ios::end);

	//int numData = ioFile.tellg() / sizeof(reservation);

	//ioFile.seekg(0, ios::beg);

	for (int i = 0; i < 100; i++)
	{
		if ((strcmp(id, reservation[i].idNumber)) == 0 && (strcmp(reservationnum, reservation[i].reservationNumber)) == 0)
		{
			return true;
		}
	}

	return  false;

}

void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	char train[13][12] = { "",
   "Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli", "Taichung", "Changhua",
   "Yunlin", "Chiayi", "Tainan", "Zuoying" };
	char carClass1[12] = { "Standard" };
	char carClass2[12] = { "Business" };

	int numnorthboundTrain;
	int numSouthboundTrain;

	loadNorthboundTimetable(northboundTimetable, numnorthboundTrain);
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrain);

	cout << "Reservation Details" << endl;

	if (reservation.destinationStation > reservation.originStation)
	{
		if (reservation.carClass == 1)
		{
			display(reservation, southboundTimetable, train, carClass1);
		}
		else
		{
			display(reservation, southboundTimetable, train, carClass2);
		}
	}
	else
	{
		if (reservation.carClass == 1)
		{
			display(reservation, northboundTimetable, train, carClass1);
		}
		else
		{
			display(reservation, northboundTimetable, train, carClass2);
		}
	}

}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	char departTime[8];
	char arrivalTime[8];
	int no = 0;

	for (int i = 0; i < 100; i++)
	{
		if ((strcmp(reservation.trainNumber, trainTimetable[i].trainNumber)) == 0)
		{
			no = i;
			break;
		}
	}

	for (int i = 0; i < 8; i++)
	{
		departTime[i] = trainTimetable[no].departureTimes[reservation.originStation][i];
	}
	for (int i = 0; i < 8; i++)
	{
		arrivalTime[i] = trainTimetable[no].departureTimes[reservation.destinationStation][i];
	}


	cout << "      Date  Train No.      From        To  Departure    Arrival   Adult  Concession  Fare     Class" << endl;

	cout << setw(10) << right << reservation.date << setw(11) << reservation.trainNumber << setw(10)
		<< stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation]
		<< setw(11) << departTime << setw(11) << arrivalTime;

	int total;

	cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets;
	cout << setw(10) << "350" << "*" << reservation.concessionTickets;
	total = adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets + 350 * reservation.concessionTickets;
	cout << setw(6) << total << setw(10) << carClass;

	/*if (reservation.carClass == 1)
	{
		cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets;
		cout << setw(10) << "350" << "*" << reservation.concessionTickets;
		total = adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets + 350 * reservation.concessionTickets;
		cout << setw(6) << total;
		cout << setw(10) << "Standard" << endl;
	}
	else
	{
		cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets;
		cout << setw(10) << "350" << "*" << reservation.concessionTickets;
		total = adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets + 350 * reservation.concessionTickets;
		cout << setw(6) << total;
		cout << setw(10) << "Business" << endl;
	}*/

}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int num1;
	int num2;

	cout << "How many adult tickets to cancel�H";
	cin >> num1;

	cout << "How many concession tickets to cancel�H";
	cin >> num2;

	while (num1 > reservation.adultTickets && num2 > reservation.concessionTickets)
	{
		cout << "Error. Please try again !" << endl;
		cout << "How many adult tickets to cancel�H";
		cin >> num1;

		cout << "How many concession tickets to cancel�H";
		cin >> num2;
	}

	if (num1 <= reservation.adultTickets && num2 <= reservation.concessionTickets)
	{
		reservation.adultTickets -= num1;
		reservation.concessionTickets -= num2;
	}

	if (reservation.adultTickets == 0 && reservation.concessionTickets == 0)
	{
		reservation.reservationNumber[8] = {};
		reservation.trainNumber[12] = {};
		reservation.idNumber[12] = {};
		reservation.phone[12] = {};
		reservation.date[12] = {};
		reservation.originStation = 0;
		reservation.destinationStation = 0;
		reservation.carClass = 0;
		reservation.adultTickets = 0;
		reservation.concessionTickets = 0;
	}

	displayReservations(southboundTimetable, northboundTimetable, reservation);
}