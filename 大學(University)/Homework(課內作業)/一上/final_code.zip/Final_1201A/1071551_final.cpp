#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets 20 + 56
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

int inputAnInteger(int begin, int end)
{
	char choice[100]{};
	cin.getline(choice, 100);
	cin.clear();
	cin.sync();
	if (strlen(choice) > 2)return -1;
	int sum = 0;
	for (int i = 0; i < strlen(choice); i++) {
		sum = sum * 10 + (choice[i] - '0');
	}
	if (sum >= begin && sum <= end)
		return sum;
	else
		return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation user;
	int departuretime = 0;
	inputReservationDetails(user, departuretime);

	//select north or south 
	int numtrain;
	if (user.destinationStation > user.originStation) {//head south
		loadSouthboundTimetable(southboundTimetable, numtrain);
		selectSouthboundTrain(southboundTimetable, numtrain, user, departuretime);
	}
	else {//head south
		loadNorthboundTimetable(northboundTimetable, numtrain);
		selectNorthboundTrain(northboundTimetable, numtrain, user, departuretime);
	}

	inputContactInfo(user);
}

void inputContactInfo(Reservation& reservation)
{
	cout << "\nEnter Contact Person Information" << endl;
	cout << "\nID Number: ";
	cin.getline(reservation.idNumber, 12);
	cin.clear();
	cin.sync();
	cout << "\nPhone: ";
	cin.getline(reservation.phone, 12);
	cin.clear();
	cin.sync();
	cout << "\nReservation Number: ";
	for (int i = 0; i < 8; i++) {
		reservation.reservationNumber[i] = rand() % 10 + '0';
		cout << reservation.reservationNumber[i];
	}
	for (int i = 8; i < 12; i++)
		reservation.reservationNumber[i] = '\0';
	cout << endl;
	saveReservation(reservation);
	cout << "\nReservation Completed!\n" << endl;
}

void saveReservation(Reservation reservation)
{
	ofstream outfile("Reservation details.dat", ios::app | ios::binary);
	outfile.write(reinterpret_cast<char*> (&reservation), sizeof(Reservation));
}

void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream infile("Southbound timetable.txt", ios::in);
	if (!infile) {
		cout << "file could not be opend" << endl;
		exit(1);
	}

	int i = 0;
	while (!infile.eof()) {
		infile >> southboundTimetable[i].trainNumber;
		for (int j = 1; j < 13; j++) {
			infile >> southboundTimetable[i].departureTimes[j];
		}
		i++;
	}
}

void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream infile("Northbound timetable.txt", ios::in);
	if (!infile) {
		cout << "file could not be opend" << endl;
		exit(1);
	}

	int i = 0;
	while (!infile.eof()) {
		infile >> northboundTimetable[i].trainNumber;
		for (int j = 1; j < 13; j++) {
			infile >> northboundTimetable[i].departureTimes[j];
		}
		i++;
	}
}

void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains, Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival" << endl;

	int starthour, startmin;
	starthour = (departureTime - 1) / 2 + 6;
	if (departureTime % 2 == 1)startmin = 0;
	else startmin = 30;

	char train[10][5]{};
	int k = 0;
	//display 10 train
	for (int i = 0, print = 0; i < 100; i++) {
		if (print == 10)break;
		int hour = 0, min = 0;
		for (int j = 0; j < 2; j++)//0 1
			hour = hour * 10 + (southboundTimetable[i].departureTimes[reservation.originStation][j] - '0');
		for (int j = 3; j < 5; j++)
			min = min * 10 + (southboundTimetable[i].departureTimes[reservation.originStation][j] - '0');
		if (hour >= starthour && min >= startmin && southboundTimetable[i].departureTimes[reservation.destinationStation][0] != '-') {
			print++;
			strcpy_s(train[k++], 5, southboundTimetable[i].trainNumber);
			cout << setw(9) << southboundTimetable[i].trainNumber << setw(11) << southboundTimetable[i].departureTimes[reservation.originStation]
				<< setw(9) << southboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
		}
	}
	char wtf[10]{};
	cin.sync();
	cin.clear();
	cin.getline(wtf, 10);
	//display select train
	int jud = 0;
	do {
		cout << "\nEnter Train Number: ";
		char tmp[10]{};
		cin.getline(tmp, 10);
		cin.clear();
		cin.sync();
		for (int i = 0; i < 10; i++) {
			if (strcmp(tmp, train[i]) == 0) {
				jud = 1;
				strcpy_s(reservation.trainNumber, 8, tmp);
				break;
			}
		}
	} while (jud == 0);
	cout << "\nTrip Details" << endl;

	//go to display
	char stations[13][12]{ "",
						"Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli",
						"Taichung", "Changhua", "Yunlin", "Chiayi", "Tainan", "Zuoying" };
	if (reservation.carClass == 1) {
		char carClass[12]{ "Standard" };
		display(reservation, southboundTimetable, stations, carClass);
	}
	else {
		char carClass[12]{ "Business" };
		display(reservation, southboundTimetable, stations, carClass);
	}
}

void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival" << endl;

	int starthour, startmin;
	starthour = (departureTime - 1) / 2 + 6;
	if (departureTime % 2 == 1)startmin = 0;
	else startmin = 30;

	char train[10][5]{};
	int k = 0;
	//display 10 train
	for (int i = 0, print = 0; i < 100; i++) {
		if (print == 10)break;
		int hour = 0, min = 0;
		for (int j = 0; j < 2; j++)//0 1
			hour = hour * 10 + (northboundTimetable[i].departureTimes[13 - reservation.originStation][j] - '0');//e04
		for (int j = 3; j < 5; j++)
			min = min * 10 + (northboundTimetable[i].departureTimes[13 - reservation.originStation][j] - '0');
		if (hour >= starthour && min >= startmin && northboundTimetable[i].departureTimes[13 - reservation.originStation][0] != '-') {
			print++;
			strcpy_s(train[k++], 5, northboundTimetable[i].trainNumber);
			cout << setw(9) << northboundTimetable[i].trainNumber << setw(11) << northboundTimetable[i].departureTimes[13 - reservation.originStation]
				<< setw(9) << northboundTimetable[i].departureTimes[13 - reservation.destinationStation] << endl;
		}
	}
	//display select train
	char wtf[10]{};
	cin.sync();
	cin.clear();
	cin.getline(wtf, 10);
	int jud = 0;
	do {
		cout << "\nEnter Train Number: ";
		char tmp[10]{};
		cin.getline(tmp, 10);
		cin.clear();
		cin.sync();
		for (int i = 0; i < 10; i++) {
			if (strcmp(tmp, train[i]) == 0) {
				jud = 1;
				strcpy_s(reservation.trainNumber, 8, tmp);
				break;
			}
		}
	} while (jud == 0);
	cout << "\nTrip Details" << endl;

	//go to display
	char stations[13][12]{ "",
						"Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli",
						"Taichung", "Changhua", "Yunlin", "Chiayi", "Tainan", "Zuoying" };
	if (reservation.carClass == 1) {
		char carClass[12]{ "Standard" };
		display(reservation, northboundTimetable, stations, carClass);
	}
	else {
		char carClass[12]{ "Business" };
		display(reservation, northboundTimetable, stations, carClass);
	}
}

void display(Reservation reservation, Train trainTimetable[100], char stations[13][12], char carClass[12])
{
	cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
	cout << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation]
		<< setw(10) << stations[reservation.destinationStation];
	for (int i = 0; i < 100; i++) {
		if (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) == 0) {
			cout << setw(11) << trainTimetable[i].departureTimes[reservation.originStation]
				<< setw(9) << trainTimetable[i].departureTimes[reservation.destinationStation];
		}
	}
	//display Ticket
	if (reservation.carClass == 1)
		cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation];
	else
		cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation];
	cout << "*";
	cout << reservation.adultTickets;

	if (reservation.carClass == 1)
		cout << setw(10) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2;
	else
		cout << setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2;
	cout << "*";
	cout << reservation.concessionTickets;

	//display fare
	if (reservation.carClass == 1)
		cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets + adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 * reservation.concessionTickets;
	else
		cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets + adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 * reservation.concessionTickets;
	cout << setw(10) << carClass << endl;
}

void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	//display origin
	cout << "Origin Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" ;

	int choice;
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	reservation.originStation = choice;

	//display destination
	cout << "\nDestination Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" ;
	do {
		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 12)) == -1);
		reservation.destinationStation = choice;
	} while (reservation.destinationStation == reservation.originStation);

	//display car class
	cout << "\nCar Class" << endl;
	cout << "1. Standard Car" << endl;
	cout << "2. Business Car";
	while (1) {
		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 2)) == -1);
		if (choice == 2) {
			if (reservation.originStation == 1 && (reservation.destinationStation == 2 || reservation.destinationStation == 3))
				continue;
			else if (reservation.originStation == 2 && reservation.destinationStation == 3)
				continue;
			else
				break;
		}
		else break;
	}
	reservation.carClass = choice;

	//select depart date any char 
	cout << "\nDeparture Date: ";
	cin.getline(reservation.date, 12);
	cin.clear();
	cin.sync();

	//dispaly departure time
	cout << "\nDeparture Time" << endl;
	for (int i = 1, j = 6, c = 0; i <= 34; i++, c++) {
		cout << setw(2) << i;
		if (j < 10) {
			cout << ". 0" << j << ":";
			if (i % 2 == 1)
				cout << "00" ;
			else
				cout << "30" ;
		}
		else {
			cout << ". " << j << ":";
			if (i % 2 == 1)
				cout << "00" ;
			else
				cout << "30" ;
		}
		if (c == 1) {
			c = -1;
			j++;
		}
		if (i != 34)cout << endl;
	}
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 34)) == -1);
	departureTime = choice;

	//display adult and concession ticket
	do {
		do {
			cout << "\nHow many adult tickets? ";
			cin >> reservation.adultTickets;
			cin.clear();
			cin.sync();
			cout << endl;
		} while (reservation.adultTickets < 0);

		do {
			cout << "How many concession tickets? ";
			cin >> reservation.concessionTickets;
			cin.clear();
			cin.sync();
			cout << endl;
		} while (reservation.concessionTickets < 0);
	} while (reservation.adultTickets + reservation.concessionTickets <= 0);

}

void reservationHistory(Train southboundTimetable[100], Train northboundTimetable[100])
{
	fstream iofile("Reservation details.dat", ios::in | ios::out | ios::binary);
	if (!iofile) {
		cout << "There were no reservation yet." << endl;
		return;
	}
	Reservation user;
	while (1) {
		if (existReservation(iofile, user) == true) {
			displayReservations(southboundTimetable, northboundTimetable, user);
			break;
		}
		else
			cout << "\nReservation record not found.\n" << endl;
	}

	cout << "\nEnter Your Choice\n"
		<< "1. Cancellation\n"
		<< "2. Reduce\n"
		<< "3. End";
	int choice;
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 3)) == -1);
	cout << endl;
	if (choice == 1) {
		iofile.seekg(0, ios::beg);
		Reservation tmp;
		int i = 0;
		iofile.seekg(0, ios::beg);
		iofile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation));
		while (!iofile.eof()) {
			i++;
			char none[1]{};
			//iofile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation));
			if (strcmp(user.idNumber, tmp.idNumber) == 0 && strcmp(user.reservationNumber, tmp.reservationNumber) == 0) {
				strcpy_s(user.reservationNumber, 12, none);
				strcpy_s(user.idNumber, 12, none);
				strcpy_s(user.phone, 12, none);
				strcpy_s(user.date, 12, none);
				strcpy_s(user.trainNumber, 8, none);
				user.originStation = 0;
				user.destinationStation = 0;
				user.carClass = 0;
				user.adultTickets = 0;
				user.concessionTickets = 0;
				iofile.seekp((i - 1) * sizeof(Reservation), ios::beg);
				iofile.write(reinterpret_cast<char*> (&user), sizeof(Reservation));
				break;
			}
			iofile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation));
		}
		cout << "Reservation Cancelled!\n" << endl;
	}
	else if (choice == 2) {
		reduceSeats(iofile, southboundTimetable, northboundTimetable, user);
		cout << "\nYou have successfully reduced the number of tickets!\n" << endl;
	}
	else if (choice == 3) {
		cout << "Thank you! Goodbye!\n\n";
		system("pause");
		return;
	}
	else
		cout << "e04su3su;6ru 19 " << endl;

}

bool existReservation(fstream& ioFile, Reservation& reservation)
{
	Reservation tmp;
	char id[12]{}, Rnum[12]{};
	cout << "Enter ID Number: ";
	cin.getline(id, 12);
	cin.clear();
	cin.sync();
	cout << "\nEnter Reservation Number: ";
	cin.getline(Rnum, 12);
	cin.clear();
	cin.sync();
	ioFile.seekg(0, ios::beg);
	ioFile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation));
	while (!ioFile.eof()) {
		//ioFile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation));
		if (strcmp(tmp.idNumber, id) == 0 && strcmp(tmp.reservationNumber, Rnum) == 0){
			strcpy_s(reservation.reservationNumber, 12, tmp.reservationNumber);
			strcpy_s(reservation.idNumber, 12, tmp.idNumber);
			strcpy_s(reservation.phone, 12, tmp.phone);
			strcpy_s(reservation.date, 12, tmp.date);
			strcpy_s(reservation.trainNumber, 8, tmp.trainNumber);
			reservation.originStation = tmp.originStation;
			reservation.destinationStation = tmp.destinationStation;
			reservation.carClass = tmp.carClass;
			reservation.adultTickets = tmp.adultTickets;
			reservation.concessionTickets = tmp.concessionTickets;
			return true;
		}
		ioFile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation));
	}
	return false;
	//ioFile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation));
}

void displayReservations(Train southboundTimetable[100], Train northboundTimetable[100], Reservation reservation)
{
	cout << "\nReservation Details\n" << endl;
	if (reservation.destinationStation > reservation.originStation) {//head south
		int num = 0;
		loadSouthboundTimetable(southboundTimetable, num);
		// go to display
		char stations[13][12]{ "",
							"Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli",
							"Taichung", "Changhua", "Yunlin", "Chiayi", "Tainan", "Zuoying" };
		if (reservation.carClass == 1) {
			char carClass[12]{ "Standard" };
			display(reservation, southboundTimetable, stations, carClass);
		}
		else {
			char carClass[12]{ "Business" };
			display(reservation, southboundTimetable, stations, carClass);
		}
	}
	else {//head north
		int num = 0;
		loadNorthboundTimetable(northboundTimetable, num);
		// go to display
		char stations[13][12]{ "",
							"Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli",
							"Taichung", "Changhua", "Yunlin", "Chiayi", "Tainan", "Zuoying" };
		if (reservation.carClass == 1) {
			char carClass[12]{ "Standard" };
			display(reservation, northboundTimetable, stations, carClass);
		}
		else {
			char carClass[12]{ "Business" };
			display(reservation, northboundTimetable, stations, carClass);
		}
	}
}

void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation)
{
	int atck, ctck;
	do {
		cout << "How many adult tickets to cancel�H";
		cin >> atck;
		cin.clear();
		cin.sync();
	} while (atck < 0 && atck >= reservation.adultTickets);
	do {
		cout << "How many concession tickets to cancel�H";
		cin >> ctck;
		cin.clear();
		cin.sync();
	} while (ctck < 0 && ctck >= reservation.concessionTickets);
	reservation.adultTickets = atck;
	reservation.concessionTickets = ctck;
	Reservation tmp;
	int i = 0;
	ioFile.seekg(0, ios::beg);
	ioFile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation));
	while (!ioFile.eof()) {
		i++;
		if (strcmp(reservation.idNumber, tmp.idNumber) == 0 && strcmp(reservation.reservationNumber, tmp.reservationNumber) == 0) {
			ioFile.seekp((i - 1) * sizeof(Reservation), ios::beg);
			ioFile.write(reinterpret_cast<char*> (&reservation), sizeof(Reservation));
			break;
		}
		ioFile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation));
	}
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	char wtf[10]{};
	cin.getline(wtf, 10);
	cin.clear();
	cin.sync();
}