#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30",  };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

int inputAnInteger(int begin, int end)
 {
	char a[100];
	cin >> a;
	if (a[0] <= end + 48 && a[0] >= begin+48 && a[1] == 0)
	{
		return  a[0]-48;
	}
	if ( ( a[0] - 48 ) * 10 + ( a[1] - 48 )<=end && (a[0]-48)*10+(a[1]-48)>=begin&&a[2]==0)
	{
		return (a[0] - 48) * 10 + (a[1] - 48);
	}
	else
	{
		return -1;
	}
 }

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation temp;
	int departuretime = 0;
	inputReservationDetails(temp,departuretime);

	//select north or south
	int northtrain,southtrain;
	if (temp.destinationStation > temp.originStation)
	  {
		loadSouthboundTimetable(southboundTimetable, northtrain);
		selectSouthboundTrain(southboundTimetable,northtrain,temp,departuretime);
	  }
	else
	{
		loadNorthboundTimetable(northboundTimetable, southtrain);
		selectNorthboundTrain(northboundTimetable,southtrain,temp,departuretime);
	}
	inputReservationDetails(temp,departuretime);
	saveReservation(temp);

}

void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inFile("Southbound timetable.txt", ios::in);
	if (!inFile)
	{
		cout << "File could not be open" << endl;
		exit(1);
	}
	inFile.close();

}

void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inFile("Northbound timetable.txt", ios::in);
	if (!inFile)
	{
		cout << "File could not be open" << endl;
		exit(1);
	}
	inFile.close();
}


void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival ";
	int starthour(0),startmin(0), starttrain(0),start(0);
	starthour = (departureTime - 1) / 2 + 6;
	if (departureTime % 2 == 1)
		starttrain = 0;
	else
		starttrain = 30;
	char train[10][5];
	//display 10 trains
	for (int i(0), print(0); i < 100; i++)
	{
		int hour(0), min(0);

		for (int k(0); k < 2; k++)
			hour = hour * 10 + (southboundTimetable[k].departureTimes[reservation.destinationStation][k]);
		for (int k(0); k < 2; k++)
			hour = hour * 10 + (southboundTimetable[k].departureTimes[reservation.originStation][k]);
			if (hour >= starthour && min >= startmin)
			{
				print++;
			


		    }

	}
	int choice(0);
	cout << "Enter Train Number:";
	cin >>  choice;
	cout <<  endl;
	reservation.trainNumber[8] = choice;


	cout << "Trip Details" << endl;
	

}
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival ";
	int starthour(0), startmin(0), starttrain(0), start(0);
	starthour = (departureTime - 1) / 2 + 6;
	if (departureTime % 2 == 1)
		starttrain = 0;
	else
		starttrain = 30;
	char train[10][5];
	//display 10 trains
	for (int i(0), print(0); i < 100; i++)
	{
		int hour(0), min(0);

		for (int k(0); k < 2; k++)
			hour = hour * 10 + (northboundTimetable[k].departureTimes[reservation.destinationStation][k]);
		for (int k(0); k < 2; k++)
			hour = hour * 10 + (northboundTimetable[k].departureTimes[reservation.originStation][k]);
		if (hour >= starthour && min >= startmin)
		{
			print++;



		}

	}
	int choice(0);
	cout << "Enter Train Number:";
	cin >> choice;
	cout << endl;
	reservation.trainNumber[8] = choice;


	cout << "Trip Details" << endl;

}

void inputContactInfo(Reservation& reservation)
{
	int idnumber(0),phone(0),reservationnumber(0);
	srand(static_cast<unsigned int>(time(0)));
	cout << "\nEnter Contact Person Information " << endl;
	cout << "ID Number:";
	cin >> idnumber;
	cout << "phone";
	cin >> phone;
	cout << "Reservation Number: ";
	for (int i = (0);i<10;i++)
	{
		reservation.reservationNumber[i] = srand % 10;
	}


	cout << endl;
	cout << "Reservation Completed!" << endl;

}
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	//Origin Station   
	int choice(0);
	cout << "Origin Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" << endl;

	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	cout << endl;
	reservation.originStation = choice;

	//Destination Station
	cout << "Destination Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" << endl;
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	reservation.destinationStation = choice;

	//car class
	cout << "Car Class" << endl;
	cout << "1. Standard Car" << endl;
	cout << "2. Business Car" << endl;
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 2)) == -1);
	reservation.carClass = choice;

	//Departure Date: 2019-12-28
	cout << "Departure Date: 2019-12-28" << endl;

	//Departure Time
	for (int i = 1; i < 34; i++)
	{
	   cout << setw(2) << i <<". ";
	   if ( i % 2 != 0 )
	    {
		   for (int k(6); k <= 22; k++)
		   { 
			   cout << k << ":00" << endl;
		   }
		}
	   else
	   {
		   for (int j(6); j <= 22; j++)
		   {
			   cout << j << ":30" << endl;
		   }
	   }
    }
		do cout << "\n? ";
	while ((choice = inputAnInteger(1, 34)) == -1);
	departureTime = choice;

	//How many adult tickets
	cout << "How many adult tickets";
	do cout << "\n? ";
	while ((choice = inputAnInteger(0, 999)) == -1);
	reservation.adultTickets = choice;

	//How many concession tickets?
	cout << "How many concession tickets";
	do cout << "\n? ";
	while ((choice = inputAnInteger(0, 999)) == -1);
	reservation.concessionTickets = choice;

}

void display(Reservation reservation, Train trainTimetable[100], char stations[13][12], char carClass[12])
{
	cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
	cout << "2019-12-28" << reservation.trainNumber[8] << stations[reservation.originStation] << stations[reservation.destinationStation];
	for (int i(0); i < 100; i++)
	{
		if (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) == 0)
		{
			cout << setw(11) << trainTimetable[i].departureTimes[reservation.originStation]
				<< trainTimetable[i].departureTimes[reservation.destinationStation];
		}
	}
	if (reservation.carClass == 1)
		cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2;
	else
		cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2;
	cout << "*";
	cout << reservation.concessionTickets;

	//fare
	if (reservation.carClass == 1)
		cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation];
	else
		cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation];

	cout << reservation.carClass << endl;

}
void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation)
{
	int choice,n1,n2;
	cout << "How many adult tickets to cancel";
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 999)) == -1);
	cout << endl;
	cin >> n1;
	reservation.adultTickets -= n1;
	cout << "How many concession tickets to cancel";
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 999)) == -1);
	cout << endl;
	cin >> n2;
	reservation.concessionTickets -= n2;
	Reservation tmp;
	int i = 0;
	ioFile.read(reinterpret_cast<char*>(&tmp), sizeof Reservation);
    

}
void reservationHistory(Train southboundTimetable[100], Train northboundTimetable[100])
{
	fstream iofile("Reservation details.dat", ios::in | ios::out | ios::binary);
	if (!iofile.eof())
	{
		cout << "There are no registration yet" << endl;
		return;
	}
	Reservation temp;
	while (1)
	{
		if (existReservation(iofile, temp) == true)
		{
			displayReservations(southboundTimetable, northboundTimetable, temp);
			break;
		}
		else
		{
			cout << "Registration have not found" << endl;
		}
	}
	cout << "Enter Your Choice" <<endl;
	cout << "1. Cancellation" <<endl;
	cout << "2. Reduce" << endl;
	cout << "3. End" << endl;
	int choice;
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 3)) == -1);
	cout << endl;
	switch (choice)
	{
	case 1:
		iofile.seekg(0, ios::beg);



	case 2:
		reduceSeats(iofile);
		break;
	case 3:
		cout << "Thank you! Goodbye!\n\n";
		system("pause");
	default: 
		cerr << "Incorrect Choice!\n";
		break;

	}

}
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	Reservation temp;
	char id[12]{}, name[22]{};
	while (!ioFile)
	{
		cout << "Reservation already exist";
		return 0;
	}
	return 1;
}
void displayReservations(Train southboundTimetable[100], Train northboundTimetable[100], Reservation reservation)
{
	cout << "Reservation Details" << endl;

	char stations[13][12] = { "Nangang"," Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua"
						,"Yunlin","Chiayi","Tainan","Zuoying" };
	if (reservation.carClass == 1)
	{
		cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
		cout << "2019-12-28" << reservation.trainNumber[8] << stations[reservation.originStation] << stations[reservation.destinationStation];
		for (int i(0); i < 100; i++)
		{
			if (strcmp(reservation.trainNumber, northboundTimetable[i].trainNumber) == 0)
			{
				cout << setw(11) << northboundTimetable[i].departureTimes[reservation.originStation]
					<< northboundTimetable[i].departureTimes[reservation.destinationStation];
			}
		}
		if (reservation.carClass == 1)
			cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2;
		else
			cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2;
		cout << "*";
		cout << reservation.concessionTickets;

		//fare
		if (reservation.carClass == 1)
			cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation];
		else
			cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation];

		cout << "standard"<< endl;

	}
	else
	{
		cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
		cout << "2019-12-28" << reservation.trainNumber[8] << stations[reservation.originStation] << stations[reservation.destinationStation];
		for (int i(0); i < 100; i++)
		{
			if (strcmp(reservation.trainNumber, southboundTimetable[i].trainNumber) == 0)
			{
				cout << setw(11) << southboundTimetable[i].departureTimes[reservation.originStation]
					<< southboundTimetable[i].departureTimes[reservation.destinationStation];
			}
		}
		if (reservation.carClass == 1)
			cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2;
		else
			cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2;
		cout << "*";
		cout << reservation.concessionTickets;

		//fare
		if (reservation.carClass == 1)
			cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation];
		else
			cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation];

		cout << "business" << endl;
	}

}










