#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

char station[13][12] = { "","Nangang","Taipei", "Banqiao" , "Taoyuan" , "Hsinchu" , "Miaoli" , "Taichung" , "Changhua" , "Yunlin" , "Chiayi" , "Tainan", "Zuoying" };
int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[35][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30"};

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

int inputAnInteger(int begin, int end)
{
	string a;
	cin >> a;
	int num = 0;
	for (int i = 0; i < (int)a.length(); i++)
	{
		num *= 10;
		num += (a[i] - '0');
	}
	for (int i = 0; i < (int)a.length(); i++)
		if ((a[i] - '0' < 0) || (a[i] - '0' > 9))
			return -1;

	if ((num >= begin) && (num <= end))
		return num;
	else
		return -1;
}//all right

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;
	int departureTime, numSouthboundTrains,numNorthboundTrains;
	inputReservationDetails(reservation, departureTime);
	if (reservation.originStation > reservation.destinationStation)
	{
		loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
		display(reservation, southboundTimetable);
		inputContactInfo(reservation);
	}
	else
	{
		loadSouthboundTimetable(northboundTimetable, numNorthboundTrains);
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);
		display(reservation, northboundTimetable);
		inputContactInfo(reservation);
	}
	saveReservation(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	cout << "\nOrigion Station" << endl;
	for (int i = 1; i < 13; i++)
	{
		cout << i << ". " << station[i] << endl;
	}
	int choice1;
	do cout<<"?"; 
	while ((choice1 = inputAnInteger(1, 12)) == -1);
	cout << endl;
	reservation.originStation = choice1;
	cout << "\nDestination Station\n";
	for (int i = 1; i < 13; i++)
	{
		cout << i << ". " << station[i] << endl;
	}
	int choice2;
	do cout<<"?";
	while ((choice2 = inputAnInteger(1, 12)) == -1);
	cout << endl;
	reservation.destinationStation = choice2;
	if (choice1 == choice2)
	{
		cout << "You have the same station!\n";
		return;
	}
	cout << "\nCar Class\n" << "1.Standard Car\n" << "2.Business Car\n";
	int choice3;
	do cout<<"?";
	while ((choice3 = inputAnInteger(1, 2)) == -1);
	reservation.carClass = choice3;
	cout << "\nDeparture Date: ";
	cin >> reservation.date;
	cout << endl << "\nDeparture Time\n";
	for (int i = 1; i < 35; i++)
		cout << i << ". " << departureTimes[i] << endl;
	int choice4;
	do cout << "?"; 
	while ((choice4=inputAnInteger(1,34))==-1);
	departureTime = choice4;
	do {
		do cout << endl << "How many adult tickets?";
		while ((reservation.adultTickets = inputAnInteger(0, 100000)) == -1);
		do cout << endl << "How many concession tickets?";
		while ((reservation.concessionTickets = inputAnInteger(0, 100000)) == -1);
	} while (((reservation.adultTickets == 0) && (reservation.concessionTickets == 0)));
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	fstream inFile("Southbound timetable.txt",ios::in );
	if (!inFile){
		cout << "The file can not be opened." << endl;
		exit(1);
	}
	int j = 0;
	for (int i = 0; i < 100; i++){
		j++;
		inFile.read(reinterpret_cast<char*>(&southboundTimetable), sizeof(Train));
	}
	numSouthboundTrains = j;
}
// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	fstream inFile("Nortbound timetable.txt", ios::in);
	if (!inFile) {
		cout << "The file can not be opened." << endl;
		exit(1);
	}
	int j = 0;
	for (int i = 0; i < 100; i++) {
		j++;
		inFile.read(reinterpret_cast<char*>(&northboundTimetable), sizeof(Train));
	}
	numNorthboundTrains = j;
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << "Train No."
		<< std::right << setw(12) << "Departure"
		<< std::right << setw(12) << "Arrival"<< endl;
	departureTimes[departureTime];
	
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << "Train No." 
		<< std::right << setw(12) << "Departure" 
		<< std::right << setw(12) << "Arrival" <<endl;
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "Enter Contact Person Information" << endl;
	cout << "ID Number: ";
	cin >> reservation.idNumber;
	cout << "\nPhone: ";
	cin >> reservation.phone;
	srand(8);
	int x = rand();
	cout << "Reservation Number: " << x;
	cout << endl << "Reservation Completed!" << endl;
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream outFile("Reservation details.dat", ios::out|ios::binary );
	if (!outFile)
	{
		cout << "The file can not be opened." << endl;
		exit(1);
	}
	outFile.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
	outFile.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	Reservation reservation;
	fstream ioFile("Reservation details.dat", ios::in | ios::out | ios::binary);
	existReservation(ioFile, reservation);
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	if (reservation.originStation > reservation.destinationStation)
		display(reservation, southboundTimetable);
	else
		display(reservation, northboundTimetable);
	int choice;
	while (true){
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellion\n"
			<< "2. Reduce\n"
			<< "3. End ";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			existReservation(ioFile, reservation);
			break;
		case 2:
			reduceSeats(ioFile,southboundTimetable, northboundTimetable,reservation);
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return;
		default: 
			cerr << "Incorrect Choice!\n";
			break;
		}
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	ioFile.read(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
	if (!ioFile)
		return false;
	else
	{
		cout << endl << "Enter ID Number: " << reservation.idNumber << endl << endl;
		cout << "Enter Reservation Number: " << reservation.reservationNumber << endl;
		return true;
	}
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{

}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100])
{
	int fare;
	fare = reservation.adultTickets;
	cout << std::right << setw(12) << "Data"
		<< std::right << setw(10) << "Train No."
		<< std::right << setw(15) << "From"
		<< std::right << setw(10) << "To"
		<< std::right << setw(15) << "Departure"
		<< std::right << setw(8) << "Arrival"
		<< std::right << setw(6) << "Adult"
		<< std::right << setw(15) << "Concession"
		<< std::right << setw(9) << "fare"
		<< std::right << setw(10) << "Class" << endl;

	cout << std::right << setw(12) << reservation.date
		<< std::right << setw(10) << reservation.trainNumber
		<< std::right << setw(15) << reservation.originStation
		<< std::right << setw(10) << reservation.destinationStation
		<< std::right << setw(15) << ""
		<< std::right << setw(8) << ""
		<< std::right << setw(6) << ""
		<< std::right << setw(15) << ""
		<< std::right << setw(9) << fare
		<< std::right << setw(10) << reservation.carClass << endl;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int a,b;
	cout << "How many adult tickets to cancel?";
	cin >> a;
	cout <<endl<< "How many concession tickets to cancel?";
	cin >> b;
	reservation.adultTickets -= a;
	reservation.concessionTickets -= b;
	if ((reservation.adultTickets < 0 || reservation.concessionTickets < 0))
		return;
	else if ((reservation.adultTickets == 0) && (reservation.concessionTickets == 0))
		existReservation(ioFile,reservation);
	
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	cout << endl << "You have successfully reduced the number of tickets!" ;
	return;
}




