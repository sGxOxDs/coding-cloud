#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

char station[13][12] = { "",
	"Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli",
	"Taichung", "Changhua", "Yunlin", "Chiayi", "Tainan", "Zuoying"
};

char carClass[3][12] = { "",
	"Standard", "Business"
};

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	if (end < 10)
	{
		int choice;
		char num[20];
		cin >> num;
		if (num[1] != '\0' || num[0] < '0' || num[0] > '9')
			return -1;
		else if ((num[0] - '0') < begin || (num[0] - '0') > end)
			return -1;
		else
		{
			choice = num[0] - '0';
			return choice;
		}
	}

	else if (end < 100)
	{
		int result = -1;
		char num[20];
		cin >> num;
		for (int i = 0; num[i] != '\0'; i++)
		{
			if (num[i] < '0' || num[i] > '9')
				return -1;
		}
		if (num[1] != '\0')
			result = (num[0] - '0') * 10 + (num[1] - '0');
		else
			result = num[0] - '0';
		if (result < begin || result > end)
			return -1;
		return result;
	}
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;
	int departureTime, numSouthboundTrains = 10, numNorthboundTrains = 10;
	inputReservationDetails(reservation, departureTime);
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);

	if (reservation.originStation < reservation.destinationStation)//�_�����X�p����I���A�n�U
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
	else //���M�O�_�W
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);
	
	inputContactInfo(reservation);

	saveReservation(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	int station = -1, destination = -1, carClass = -1, adultTickets = 0, concessionTickets = 0; //�ŧi�n�Ψ쪺�ܼ�
	do
		cout << "Origin Station\n" << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n" << "4. Taoyuan\n" << "5. Hsinchu\n" << "6. Miaoli\n" << "7. Taichung\n" << "8. Changhua\n" << "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" << "12. Zuoying\n" << "?";
	while ((station = inputAnInteger(1, 12)) == -1);//��ܰ_�l���[�W���b
	reservation.originStation = station;
	cout << endl;

	while (true)//��ܥت��a���A���i�M�_�l���ۦP
	{
		cout << "\nDestination Station\n" << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n" << "4. Taoyuan\n" << "5. Hsinchu\n"  << "6. Miaoli\n" << "7. Taichung\n" << "8. Changhua\n" << "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" << "12. Zuoying\n" << "?";
		if ((destination = inputAnInteger(1, 12)) == -1);
		else if (destination == station)
			cout << "Wrong choice! Plz try again";
		else
			break;
	}
	reservation.destinationStation = destination;//�s�Jreservation
	cout << endl << endl;

	do
		cout << "Car Class\n" << "1. Standard Car\n" << "2. Business Car\n" << "?";//��ܨ���
	while ((carClass = inputAnInteger(1, 2)) == -1);
	reservation.carClass = carClass;

	cout << "\nDeparture Date: ";	//�L�X�X�o���
	cin >> reservation.date;
	cout << endl;

	for (int i = 1; i < 35; i++)
		cout << i << ". " << departureTimes[i] << endl;//�L�X�X�o���ѥi��ɬq

	do
		cout << "\n?";
	while ((departureTime = inputAnInteger(1, 34) == -1));//������J��departureTime

	while (true)//��ܲ��ةM�ƶq�A�����j�󵥩�0�i
	{
		cout << "\nHow many adult tickets?";
		cin >> adultTickets;
		cout << "\nHow many concession tickets?";
		cin >> concessionTickets;
		if (adultTickets >= 0 && concessionTickets >= 0 && (adultTickets + concessionTickets) > 0)//���b
			break;
		else;
	}
	reservation.adultTickets = adultTickets;
	reservation.concessionTickets = concessionTickets;
}

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream south("Southbound timetable.txt", ios::in);
	int i = 0;
	while (south >> southboundTimetable[i].trainNumber)
	{
		for (int j = 1; j <= 12; j++)
			south >> southboundTimetable[i].departureTimes[j];

		i++;
	}
	south.close();
}

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream north("Northbound timetable.txt", ios::in);
	int i = 0;
	while (north >> northboundTimetable[i].trainNumber)
	{
		for (int j = 1; j <= 12; j++)
			north >> northboundTimetable[i].departureTimes[j];

		i++;
	}
	north.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival\n";
	struct valid
	{
		int num;
		int hour;
		int minute;
	};
	int counter = 0;
	valid buf[100];

	int departureTime1 = (departureTimes[departureTime][0] - '0') * 10 + (departureTimes[departureTime][1] - '0');
	int departureTime2 = (departureTimes[departureTime][3] - '0') * 10 + (departureTimes[departureTime][4] - '0');
	for (int i = 0; southboundTimetable[i].trainNumber[0] != '\0'; i++)
	{
		if ((southboundTimetable[i].departureTimes[reservation.originStation][0] - '0') < 0 || (southboundTimetable[i].departureTimes[reservation.originStation][0] - '0' > 9) ||
			(southboundTimetable[i].departureTimes[reservation.destinationStation][0] - '0') < 0 || (southboundTimetable[i].departureTimes[reservation.destinationStation][0] - '0' > 9))
			i++;//�S���Z��
		else if (((southboundTimetable[i].departureTimes[reservation.originStation][0] - '0') * 10 + (southboundTimetable[i].departureTimes[reservation.originStation][1] - '0')) > departureTime1 && 
			((southboundTimetable[i].departureTimes[reservation.originStation][3] - '0') * 10 + (southboundTimetable[i].departureTimes[reservation.originStation][4] - '0') > departureTime2))
		{
			//�ɶ��ŦX��
			buf[counter].hour = southboundTimetable[i].departureTimes[reservation.originStation][0] - '0' * 10 + (southboundTimetable[i].departureTimes[reservation.originStation][1] - '0');
			buf[counter].minute = southboundTimetable[i].departureTimes[reservation.originStation][3] - '0' * 10 + (southboundTimetable[i].departureTimes[reservation.originStation][4] - '0');
			buf[counter].num = i;
			counter++;
		}
	}

	for (int i = 0; buf[i].hour >= 0; i++)
	{
		if (buf[i].hour > buf[i + 1].hour)
		{
			int k = buf[i].num;
			buf[i].num = buf[i + 1].num;
			buf[i + 1].num = k;
		}
		else if (buf[i].hour == buf[i + 1].hour)
			if (buf[i].minute > buf[i + 1].minute)
			{
				int k = buf[i].num;
				buf[i].num = buf[i + 1].num;
				buf[i + 1].num = k;
			}
			else;

		else;
	}
	for (int i = 0; i < 10; i++)
	{
		if (buf[i].num >= 0)
			cout << right << setw(9) << southboundTimetable[buf[i].num].trainNumber << right << setw(11) << southboundTimetable[buf[i].num].departureTimes[reservation.originStation] << right << setw(9) << southboundTimetable[buf[i].num].departureTimes[reservation.destinationStation] << endl;
		else
			i++;
	}
TRAIN:	
	{
		cout << "\nEnter Train Number : ";
		cin >> reservation.trainNumber;

		int index = 0;
		for (int i = 0; i < 10; i++)
			if (strcmp(reservation.trainNumber, southboundTimetable[buf[i].num].trainNumber) == 0)
			{
				numSouthboundTrains = i;
				index++;
				break;
			}
		if (index != 1)
			goto TRAIN;
		else
			cout << "\nTrip Details\n";

		display(reservation, southboundTimetable);
	}
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival\n";
	struct valid
	{
		int num;
		int hour;
		int minute;
	};
	int counter = 0;
	valid buf[100];

	int departureTime1 = (departureTimes[departureTime][0] - '0') * 10 + (departureTimes[departureTime][1] - '0');
	int departureTime2 = (departureTimes[departureTime][3] - '0') * 10 + (departureTimes[departureTime][4] - '0');
	for (int i = 0; northboundTimetable[i].trainNumber[0] != '\0'; i++)
	{
		if ((northboundTimetable[i].departureTimes[reservation.originStation][0] - '0') < 0 || (northboundTimetable[i].departureTimes[reservation.originStation][0] - '0') > 9
			|| (northboundTimetable[i].departureTimes[reservation.destinationStation][0] - '0') < 0 || (northboundTimetable[i].departureTimes[reservation.destinationStation][0] - '0') > 9)
			i++;//�S���Z��
		else if (((northboundTimetable[i].departureTimes[reservation.originStation][0] - '0') * 10 + (northboundTimetable[i].departureTimes[reservation.originStation][1] - '0') > departureTime1) && 
			((northboundTimetable[i].departureTimes[reservation.originStation][3] - '0') * 10 + (northboundTimetable[i].departureTimes[reservation.originStation][4] - '0') > departureTime2))

		{
			//�ɶ��ŦX��
			buf[counter].hour = (northboundTimetable[i].departureTimes[reservation.originStation][0] - '0') * 10 + (northboundTimetable[i].departureTimes[reservation.originStation][1] - '0');
			buf[counter].minute = (northboundTimetable[i].departureTimes[reservation.originStation][3] - '0') * 10 + (northboundTimetable[i].departureTimes[reservation.originStation][4] - '0');
			buf[counter].num = i;
			counter++;
		}
	}

	for (int i = 0; buf[i].hour >= 0; i++)
	{
		if (buf[i].hour > buf[i + 1].hour)
		{
			int k = buf[i].num;
			buf[i].num = buf[i + 1].num;
			buf[i + 1].num = k;
		}
		else if (buf[i].hour == buf[i + 1].hour)
			if (buf[i].minute > buf[i + 1].minute)
			{
				int k = buf[i].num;
				buf[i].num = buf[i + 1].num;
				buf[i + 1].num = k;
			}
			else;
		else;
	}
	for (int i = 0; i < 10; i++)
	{
		if (buf[i].num >= 0)
			cout << right << setw(9) << northboundTimetable[buf[i].num].trainNumber << right << setw(11) << northboundTimetable[buf[i].num].departureTimes[reservation.originStation] << right << setw(9) << northboundTimetable[buf[i].num].departureTimes[reservation.destinationStation] << endl;
		else
			i++;
	}
TRAIN:
	{
		cout << "\nEnter Train Number : ";
		cin >> reservation.trainNumber;

		int index = 0;
		for (int i = 0; i < 10; i++)
			if (strcmp(reservation.trainNumber, northboundTimetable[buf[i].num].trainNumber) == 0)
			{
				numNorthboundTrains = i;
				index++;
				break;
			}
		if (index != 1)
			goto TRAIN;
		else
			cout << "\nTrip Details\n";

		display(reservation, northboundTimetable);
	}
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "\nEnter Contact Person Information: \n";

	cout << "ID Number :";
	cin >> reservation.idNumber;
	cout << "\nPhone : ";
	cin >> reservation.phone;
	cout << "\nReservation Number : ";
	srand(time(0));
	for (int i = 0; i < 8; i++)
	{ 
		reservation.reservationNumber[i] = rand() % 10 + '0';
		cout << reservation.reservationNumber[i];       //�H������
	}
	cout << "\n\nReservation Completed!\n";
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream file("Reservation details.dat", ios::out | ios::app | ios::binary);
	for (int i = 0; i < 100; i++)
		file.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));//�v�@�g�J
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	fstream ioFile("Reservation details.dat", ios::in | ios::binary |ios::out);
	Reservation reservation, buf;
	for (int i = 0; i < 100; i++)
		ioFile.read(reinterpret_cast<char*>(&buf), sizeof(Reservation));
	while (true)
	{
		if (existReservation(ioFile, reservation))//���ŦX�A���X
			break;
		else
			break;
	}

	int choice;
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
		{
			int k;
			for (int i = 0; i < 100; i++)
				if (strcmp(reservation.idNumber, buf.idNumber) == 0)
					k = i;
			ioFile.seekg(sizeof(Reservation) * k, ios::beg);
			ioFile.tellg();
			buf.adultTickets = 0;
			buf.carClass = 0;
			buf.concessionTickets = 0;
			for (int j = 0; j < 12; j++)
			{ 
				buf.date[j] = '\0';
				buf.idNumber[j] = '\0';
				buf.phone[j] = '\0';
			}
			buf.destinationStation = 0;
			buf.originStation = 0;
			for (int j = 0; j < 8; j++)
			{
				buf.reservationNumber[j] = '\0';
				buf.trainNumber[j] = '\0';
			}
			ioFile.write(reinterpret_cast<const char*>(&buf), sizeof(Reservation));
		}
			break;
		case 2:
			reduceSeats(ioFile, southboundTimetable, northboundTimetable, reservation);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	cout << "\nEnter ID Number: ";
	cin >> reservation.idNumber;
	cout << "\nEnter Reservation Number: ";
	cin >> reservation.reservationNumber;
	Reservation buf[100];
	for (int i = 0; !ioFile.eof(); i++)
	{
		ioFile.read(reinterpret_cast<char*>(&buf[i]), sizeof(Reservation));
	}
	for (int i = 0; i < 100; i++)
		if (strcmp(buf[i].idNumber, reservation.idNumber) == 0 && strcmp(buf[i].reservationNumber, reservation.reservationNumber) == 0)
			return true;
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	cout << "\nReservation Details\n";
	int numSouthboundTrains, numNorthboundTrains;
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
	display(reservation, southboundTimetable);
	display(reservation, northboundTimetable);
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100])
{
	int k;
	for (int i = 0; i < 100; i++)
		if (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) == 0)
			k = i;
	cout << "      Date  Train No.      From        To  Departure  Arrival   Adult  Concession  Fare      Class\n";
	cout << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(10) << station[reservation.originStation] << setw(10) << station[reservation.destinationStation] << setw(11)
		<< setw(11) << trainTimetable[k].departureTimes[reservation.originStation] << setw(9) << trainTimetable[k].departureTimes[reservation.destinationStation]
		<< setw(7) << "700*" << reservation.adultTickets << setw(11) << "350*" << reservation.concessionTickets << setw(6) << 700 * reservation.adultTickets + 350 * reservation.concessionTickets
		<< setw(11) << carClass[reservation.carClass] << endl;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	Reservation buf;
	int k;
	for (int i = 0; i < 100; i++)
		if (strcmp(reservation.idNumber, buf.idNumber) == 0)
			k = i;
	ioFile.seekg(sizeof(Reservation) * k, ios::beg);
	ioFile.tellg();
	cout << "\nHow many adult tickets to cancel�H\n";
	int num;
	cin >> num;
	buf.adultTickets -= num;
	cout << "\nHow many concession tickets to cancel�H\n";
	cin >> num;
	buf.concessionTickets -= num;
	ioFile.write(reinterpret_cast<const char*>(&buf), sizeof(Reservation));
}
