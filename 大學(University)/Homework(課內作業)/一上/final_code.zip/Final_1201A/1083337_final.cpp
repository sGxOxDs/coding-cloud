#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

char stastion[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
							"Taichung","Changhua","Yunlin"," Chiayi","Tainan","Zuoying" };

char carClass[2][12] = {"Standard","Business"};

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation �q��N��
	char trainNumber[8];  // used to identify a train �������X
	char idNumber[12];    // the id number of the contact person�����H�������Ҧr��
	char phone[12];       // the (local or mobile) phone number of the contact person�����H���p���q��
	char date[12];        // outbound date �f�����
	int originStation;      // the origin station code�_�{���N�X
	int destinationStation; // the destination station code��F���N�X
	int carClass;           // the car class code; 1:standard car, 2:business car���[����; 1:�зǨ��[, 2:�ӰȨ��[
	int adultTickets;       // the number of adult tickets�����i��
	int concessionTickets;  // the number of concession tickets�u�ݲ��i��
};

struct Train
{
	char trainNumber[8];          // used to identify a train �������X
	char departureTimes[13][8]; // the departure time of a train for each station, �����b�U���������ɶ�(�f���ɶ�)
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main
// input an integer in the range [ begin, end ](�T�{�d��)
int inputAnInteger(int begin, int end) {
	char select[3] = {""};
	cin >> select;
	int number = 0;

	for (int i = 0; select[i] != 0; i++) {
		if (!isdigit(select[i])) {
			return -1;
		}
		else {
			number = select[i] - '0';
			if (i == 1) {
				number = (select[0] - '0') * 10 + select[1] - '0';
			}
			if (i == 2) {
				return -1;
			}

		}

	}
	if (number >= begin && number <= end) {
		return number;
	}
	else{
		return -1;
	}
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]) {
	
	Reservation re = { "","","","","",0,0,0,0,0 };

	int departureTime = 0 ;
	int numTrains = 0;
	inputReservationDetails( re, departureTime);
	
	if (re.originStation < re.destinationStation) {		//�_�I���p����I��(�_�W)

		loadNorthboundTimetable(northboundTimetable, numTrains);
		selectNorthboundTrain(northboundTimetable, numTrains, re, departureTime);
		display(re, northboundTimetable);
	}
	if (re.originStation < re.destinationStation) {		//�_�I���j����I��(�n�U)

		loadSouthboundTimetable(southboundTimetable, departureTime);
		selectSouthboundTrain;
		selectSouthboundTrain(southboundTimetable, numTrains, re, departureTime);
		display(re , southboundTimetable);
	}
}

// inputs originStation, destinationStation, carClass,
// date, departureTime(�f���ɶ�), adultTickets(����) and concessionTickets(�u�ݲ�)
void inputReservationDetails(Reservation& reservation, int& departureTime){
	int choice1 = 0;
	int choice2 = 0;
	cout << "originStation" << endl;				//��_�I��
	for (int i = 1; i < 13; i++) {
		cout << i << ".  " << stastion[i] << endl;
	}
	do cout << "Choose originStation : ";
	while ((choice1 = inputAnInteger(1, 12)) == -1);
	reservation.originStation = choice1;
	cout << endl;

	cout << "Destination Station" << endl;			//����I��
	for (int i = 1; i < 13; i++) {
		cout << i << ".  " << stastion[i] << endl;
	}
	do cout << "Choose Destination : ";
	while ((choice2 = inputAnInteger(1, 12)) == -1);
	cout << endl;

	if (choice1 == choice2) {						//��ܬۦP����(����)
		cout << "Can't choose same number " << endl;
		inputReservationDetails(reservation, departureTime);
	}
	else
	reservation.destinationStation = choice2;

	cout << "Car Class" << endl;				//�郞�l
	cout << "1.  " << "Standard Car" << endl;
	cout << "2.  " << "Business Car" << endl;
	int car=0;
	do cout << "Choose Car :" ;
	while ((car = inputAnInteger(1, 2)) == -1);
	reservation.carClass = car;

	char date[10]={""};						//��g�f�����
	cout << "Departure Date:";
	cin >> date ;
	strcpy_s(reservation.date, date);

	cout << endl << "Departure Time" << endl;
	for (int i = 1; i < 35; i++) {
		cout << i << ".  " << departureTimes[i] << endl;
	}
	do cout << "Choose departureTime :";					//��ܷf���ɶ�
	while ((departureTime = inputAnInteger(1,34)) == -1);


	int adult = 0;
	int concession = 0;
	do {
		cout << "How many adult tickets? :";
		cin >> adult;
		cout << "How many concession tickets? :";
		cin >> concession;
	} while (adult < 0|| concession<0 || adult==0&&concession==0); //�p�G���p��0�Ψ�̵���0(����@��)

	reservation.adultTickets = adult;
	reservation.concessionTickets = concession;
}

// loads the southbound timetable from the file "Southbound timetable.dat"(���J�n�U�ɶ���)
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) {

	fstream Sfile("Southbound timetable.txt");
		
	while (Sfile.getline(reinterpret_cast<char*>(&southboundTimetable), sizeof(Train))) {
		numSouthboundTrains++;
	}
	Sfile.close();
}

// loads the northbound timetable from the file "Northbound timetable.dat"(���J�_�W�ɶ���)
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) {

	fstream Nfile("Northbound timetable.txt");

	while (Nfile.getline(reinterpret_cast<char*>(&northboundTimetable), sizeof(Train))) {
		numNorthboundTrains++;
	}
	Nfile.close();
}

// displays timetables for 10 coming southbound trains, then let user select one(��ܫn�U����)
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime) {

	char Tnumtemp[50][5]={""};

	cout << setw(10) << "Train No." << setw(10) << "Departure" << setw(10) << " Arrival" << endl;
	for (int n = 0; n < numSouthboundTrains; n++) {
		if (departureTimes[departureTime] < southboundTimetable[n].departureTimes[13-reservation.originStation]) {
			cout << setw(10)<<southboundTimetable[n].trainNumber<<setw(10)<< southboundTimetable[n].departureTimes[13-reservation.originStation]<< setw(10)<< southboundTimetable[n].departureTimes[13-reservation.destinationStation];
			cout << endl;
		}
	}
	cout << "Enter Train Number:";
	cin >> reservation.trainNumber;

}

// displays timetables for 10 coming northbound trains, then let user select one(��ܥ_�W����)
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) {

	char Tnumtemp[50][5] = { "" };
	Train table = { "","" };
	cout << setw(10) << "Train No." << setw(10) << "Departure" << setw(10) << " Arrival" << endl;
	for (int n = 0; n < numNorthboundTrains; n++) {
		if (departureTimes[departureTime] < northboundTimetable[n].departureTimes[reservation.originStation]) {
			cout << setw(10) << northboundTimetable[n].trainNumber << setw(10) << northboundTimetable[n].departureTimes[reservation.originStation] << setw(10) << northboundTimetable[n].departureTimes[reservation.destinationStation];
			cout << endl;
		}
	}
	cout << "Enter Train Number:";
	cin >> reservation.trainNumber;
}

// inputs idNumber and phone, and randomly generate reservationNumber(��J�p�����)
void inputContactInfo(Reservation& reservation) {

	cout<< "ID Number:" << endl;
	cin >> reservation.idNumber;
	cout << "Phone" << endl;
	cin >> reservation.phone;

	char temp[8] = {};
	for (int i = 0; i < 8; i++) {
		temp[i] = rand() % 10 + '0';
	}
	cout << "Reservation Number: ";
	for (int i = 0; i < 8; i++) {
		cout << temp[i];
		reservation.reservationNumber[i] = temp[i];
	}
	cout << endl << "Reservation Completed!" << endl;
	saveReservation(reservation);
	return;
}

// save reservation to the end of the file Reservation details.dat (�x�s�q��)
void saveReservation(Reservation reservation) {

	fstream outFile("details.dat", ios::binary);

	if (!outFile) {
		fstream File("details.dat", ios::binary);
	}
	while (outFile.write(reinterpret_cast<char*>(&reservation), sizeof(Reservation)));
	outFile.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]) {

	Reservation member = { "","","","","",0,0,0,0,0 };
	cout << "Enter ID Number:";
	cin >> member.idNumber;
	cout << "Enter Reservation Number:";
	cin >> member.reservationNumber;

	fstream file("details.dat", ios::binary);
	

	existReservation(file, member);
	displayReservations(southboundTimetable, northboundTimetable, member);//��ܭq��
	
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists  (�O�_�s�b)
bool existReservation(fstream& ioFile, Reservation& reservation) {
	
	Reservation fileline = {"","","","","",0,0,0,0,0};
	ioFile.write(reinterpret_cast<char*>(&fileline), sizeof(Reservation));

	for (int i = 0; i < 100; i++) {
		if (strcmp(fileline.idNumber, reservation.idNumber) == 0) {
			strcpy_s(reservation.date, fileline.date);
			strcpy_s(reservation.trainNumber, fileline.trainNumber);
			reservation.originStation = fileline.originStation;
			reservation.destinationStation = fileline.destinationStation;
			reservation.adultTickets = fileline.adultTickets;
			reservation.concessionTickets = fileline.concessionTickets;
			reservation.carClass = fileline.carClass;
			return true;
		}
	}
	return false;
}


void displayReservations(Train southboundTimetable[100],			//��ܭq��
	Train northboundTimetable[100], Reservation reservation) {

	int n = 0;

	cout << endl << setw(10) << " Date" << setw(10) << "Train No." << setw(10) << "From" << setw(10) << "To" << setw(15)
		<< "Departure " << setw(15) << "Arrival" << setw(15) << "Adult" << setw(20) << "Concession" << setw(10)
		<< "Fare" << setw(20) << "Class" << endl;


	cout << setw(10) << reservation.date << setw(10) << reservation.trainNumber << setw(10) << stastion[reservation.originStation]
		<< setw(10) << stastion[reservation.destinationStation];


	while (reservation.trainNumber != southboundTimetable[n].trainNumber) {
		n++;
	}

	cout << setw(15) << southboundTimetable[n].departureTimes[reservation.originStation] << setw(15) << southboundTimetable[n].departureTimes[reservation.destinationStation]
		<< adultTicketPrice[reservation.originStation][reservation.destinationStation] << '*' << reservation.adultTickets
		<< setw(20) << adultTicketPrice[reservation.destinationStation][reservation.originStation] <<'*'<< reservation.concessionTickets
		<< setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets + adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.concessionTickets
		<< setw(20) << carClass[reservation.carClass] << endl;

}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100]) {

	int n = 0;
	cout << endl << "Trip Details" << endl;

	cout << endl << setw(10) << " Date" << setw(10) << "Train No." << setw(10) << "From" <<setw(10)<<"To" <<setw(15)
		<< "Departure " << setw(15) << "Arrival" << setw(15) << "Adult" << setw(20) << "Concession" << setw(10)
		<< "Fare" << setw(20) << "Class"<<endl;

	cout << setw(10) << reservation.date << setw(10) << reservation.trainNumber << setw(10) << stastion[reservation.originStation]
		<< setw(10) << stastion[reservation.destinationStation] ;

	while (reservation.trainNumber != trainTimetable[n].trainNumber) {
		n++;
	}

	cout<< setw(15) << trainTimetable[n].departureTimes[reservation.originStation] << setw(15) << trainTimetable[n].departureTimes[reservation.destinationStation]
		<< adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets
		<< setw(20) << adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.concessionTickets
		<< setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets + adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.concessionTickets
		<< setw(20) << carClass[reservation.carClass] << endl;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation) {


}