#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };
char stations[13][12] = {"",
	"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying"
};
char classtrain[3][9] = {
	"","Standard","Business"
};
struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);
//����
int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main
//����
int inputAnInteger(int begin, int end)
{
	char (*choice) = new char [100];
	cin >> choice;
	int size = strlen(choice);
	int x = size;
	int total = 0;
	//cout << strlen(choice);
	if (size < 1)
		return -1;
	for (int i = 0; i < size; i++)
		if (choice[i]<'0' || choice[i] > '9')
			return -1;
	for (int i = 0; i < size; i++)
	{
		total += (choice[i] - '0') * pow(10, (x-1));
		x -= 1;
	}
	if (total > end || total < begin)
		return -1;
	return(total);
}
//����
void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Train southtable[100];
	int southnum = 0;
	loadSouthboundTimetable(southtable, southnum);

	Train northtable[100];
	int northnum = 0;
	loadNorthboundTimetable(northtable, northnum);

	Reservation New;
	int timechoice=-1;
	inputReservationDetails(New, timechoice);

	if (New.originStation < New.destinationStation)
		selectSouthboundTrain(southtable, southnum, New, timechoice);
	else
		selectNorthboundTrain(northtable, northnum, New, timechoice);
}
//����
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	int Originchoice = -1;
	cout << "\nOrigin Station\n" << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n" << "4. Taoyuan\n" << "5. Hsinchu\n" << "6. Miaoli\n" << "7. Taichung\n" << "8. Changhua\n" << "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" << "12. Zuoying";
	do cout << "\n? ";
	while ((Originchoice = inputAnInteger(1, 12)) == -1);
	cout << endl;
	int Destinationchoice = -1;
	cout << "\nDestination Station\n" << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n" << "4. Taoyuan\n" << "5. Hsinchu\n" << "6. Miaoli\n" << "7. Taichung\n" << "8. Changhua\n" << "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" << "12. Zuoying";
	do cout << "\n? ";
	while ((Destinationchoice = inputAnInteger(1, 12)) == -1);
	cout << endl;
	if (Destinationchoice == Originchoice)
	{
		cout << "�_���P���I������ۦP" << endl << endl;
		return inputReservationDetails(reservation,departureTime);
	}
	int trainchoice = -1;
	cout << "\nCar Class\n"
		<< "1. Standard Car\n"
		<< "2. Business Car";
	do cout << "\n? ";
	while ((trainchoice = inputAnInteger(1, 2)) == -1);
	cout << endl;
	char* DepartureDate =new char [100];
	cout << "Departure Date: ";
	cin >> DepartureDate;
	cout << "\nDeparture Time\n";
	for (int i = 1; i < 34; i++)
		cout << setw(2) << i << ". " << departureTimes[i] << endl;
	cout << "34. 22:30";
	do cout << "\n? ";
	while ((departureTime = inputAnInteger(1, 34)) == -1);
	cout << endl;
	int adultnum = -1;
	do cout << "How many concession tickets? " << endl;
	while ((adultnum = inputAnInteger(0, 10000000)) == -1);
	int concessionnum = -1;
	do cout << "How many adult tickets? " << endl;
	while ((concessionnum = inputAnInteger(0, 10000000)) == -1);
	if (concessionnum == 0 && adultnum == 0)
	{

		cout << "���H���P�u�f������Ҭ�0" << endl << endl;
		return inputReservationDetails(reservation, departureTime);
	}
	int ran;
	srand(time(NULL));
	for (int i = 0; i < 12; i++)
	{
		ran = rand();
		ran /= 1001;
		while ((ran + '0') < '0' || (ran + '0') > '9')
			ran = rand();
		reservation.reservationNumber[i] = char(ran + '0');
	}

	strcpy_s(reservation.date,12, DepartureDate);
	reservation.originStation = Originchoice;
	reservation.destinationStation = Destinationchoice;
	reservation.carClass = trainchoice;
	reservation.adultTickets = adultnum;
	reservation.concessionTickets = concessionnum;
	return;
}
//����
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	int x = 0;
	fstream inFile("Southbound timetable.txt", ios::in);
	while (inFile >> (southboundTimetable[x].trainNumber))
	{
		//cout << setw(8) << southboundTimetable[x].trainNumber;
		for (int i = 1; i < 13; i++)
		{
			inFile >> (southboundTimetable[x].departureTimes[i]);
			//cout <<setw(8)<< southboundTimetable[x].departureTimes[i];
		}
		//cout << endl;
		x += 1;
	}
	inFile.close();
}

void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	int x = 0;
	fstream inFile("Northbound timetable.txt", ios::in);
	while (inFile >> (northboundTimetable[x].trainNumber))
	{
		/*cout << setw(8) << northboundTimetable[x].trainNumber;*/
		for (int i = 1; i < 13; i++)
		{
			inFile >> (northboundTimetable[x].departureTimes[i]);
			/*cout << setw(8) << northboundTimetable[x].departureTimes[i];*/
		}
		/*cout << endl;*/
		x += 1;
	}
	inFile.close();
}
//����
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains, Reservation& reservation, int departureTime)
{
	int x = 1;
	char *time = departureTimes[departureTime];
	char val[11][100];
	cout << setw(9) << "Train No." << setw(11) << "Departure" << setw(9) << "Arrival" << endl;
	for (int i = 0; i < 100; i++)
	{
		if (x > 10)
			break;
		if (strcmp(southboundTimetable[i].departureTimes[reservation.originStation], time) > 0&& strcmp(southboundTimetable[i].departureTimes[reservation.destinationStation],time)>0)
		{
			cout << setw(9) << southboundTimetable[i].trainNumber << setw(11) << southboundTimetable[i].departureTimes[reservation.originStation] << setw(9) << southboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
			for (int j = 0; j < strlen(southboundTimetable[i].trainNumber); j++)
			{
				val[x][j] = southboundTimetable[i].trainNumber[j];
			}
			x += 1;
		}
	}
	char *Trainnum = new char[100];
	cout << "Enter Train Number: ";
	cin >> Trainnum;
	int total;
	int valsize;
	for (int i = 1; i < 11; i++)
	{
		valsize = 0;
		for (int j = 0; j < 100; j++)
		{
			if (val[i][j] < '0')
				break;
			else
				valsize += 1;
		}
		if (valsize == strlen(Trainnum))
		{
			total = 0;
			for (int z = 0; z < valsize; z++)
			{
				if (Trainnum[z] - '0' == val[i][z] - '0')
					total += 1;
			}
			if (total >= valsize)
			{
				strcpy_s(reservation.trainNumber, Trainnum);
				cout << endl << "Trip Details" << endl;
				return display(reservation,southboundTimetable);
			}
		}
		if (i == 10)
		{
			cout << "wrong Train number" << endl;
			return selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
		}
	}
}
//����
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, Reservation& reservation, int departureTime)
{
	int x = 1;
	char* time = departureTimes[departureTime];
	char val[11][100];
	cout << setw(9) << "Train No." << setw(11) << "Departure" << setw(9) << "Arrival" << endl;
	for (int i = 0; i < 100; i++)
	{
		if (x > 10)
			break;
		if (strcmp(northboundTimetable[i].departureTimes[reservation.originStation], time) > 0 && strcmp(northboundTimetable[i].departureTimes[reservation.destinationStation], time) > 0)
		{
			cout << setw(9) << northboundTimetable[i].trainNumber << setw(11) << northboundTimetable[i].departureTimes[reservation.originStation] << setw(9) << northboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
			for (int j = 0; j < strlen(northboundTimetable[i].trainNumber); j++)
			{
				val[x][j] = northboundTimetable[i].trainNumber[j];
			}
			x += 1;
		}
	}
	char* Trainnum = new char[100];
	cout << "Enter Train Number: ";
	cin >> Trainnum;
	int total;
	int valsize;
	for (int i = 1; i < 11; i++)
	{
		valsize = 0;
		for (int j = 0; j < 100; j++)
		{
			if (val[i][j] < '0')
				break;
			else
				valsize += 1;
		}
		if (valsize == strlen(Trainnum))
		{
			total = 0;
			for (int z = 0; z < valsize; z++)
			{
				if (Trainnum[z] - '0' == val[i][z] - '0')
					total += 1;
			}
			if (total >= valsize)
			{
				strcpy_s(reservation.trainNumber, Trainnum);
				cout << endl << "Trip Details" << endl;
				return display(reservation, northboundTimetable);
			}
		}
		if (i == 10)
		{
			cout << "wrong Train number" << endl;
			return selectSouthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);
		}
	}
}
//����
void inputContactInfo(Reservation& reservation)
{
	cout << endl << endl << "Enter Contact Person Information " << endl << endl;
	char ID[12];
	cout << "ID Number : ";
	cin >> ID;
	cout << endl;
	char phone[12];
	cout << "Phone: ";
	cin >> phone;
	cout << endl ;
	cout << "Reservation Number: " << reservation.reservationNumber << endl << endl;

	strcpy_s(reservation.idNumber, 12, ID);
	strcpy_s(reservation.phone, 12, phone);
	cout << "Reservation Completed!" << endl << endl;

	saveReservation(reservation);
}
//����
void saveReservation(Reservation reservation)
{
	cout << reservation.reservationNumber << "  ";
	cout << reservation.trainNumber << "  ";
	cout << reservation.idNumber << "  ";
	cout << reservation.phone << "  ";
	cout << reservation.date << "  ";
	cout << reservation.originStation << "  ";
	cout << reservation.destinationStation << "  ";
	cout << reservation.carClass << "  ";
	cout << reservation.adultTickets << "  ";
	cout << reservation.concessionTickets << "  ";

	fstream outFile("Reservation details.dat", ios::app | ios::binary);
		outFile.write(reinterpret_cast<char*>(&reservation),76);
		outFile.close();
}

void reservationHistory(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation New;
	cout << endl << "Enter ID Number: ";
	cin >> New.idNumber;
	cout << endl << "Enter Reservation Number : ";
	cin >> New.reservationNumber;

	fstream In("Reservation details.dat", ios::in | ios::binary);
	if (!existReservation(In, New))
	{
		cout << "Reservation record not found." << endl << endl;
		return;
	}
}

bool existReservation(fstream& ioFile, Reservation& reservation)
{
	Reservation check;
	ioFile.read(reinterpret_cast<char*>(&check.reservationNumber), 12);
	ioFile.read(reinterpret_cast<char*>(&check.trainNumber), 8);
	ioFile.read(reinterpret_cast<char*>(&check.idNumber), 12);
	ioFile.read(reinterpret_cast<char*>(&check.phone), 12);
	ioFile.read(reinterpret_cast<char*>(&check.date), 12);
	ioFile.read(reinterpret_cast<char*>(&check.originStation), 4);
	ioFile.read(reinterpret_cast<char*>(&check.destinationStation), 4);
	ioFile.read(reinterpret_cast<char*>(&check.carClass), 4);
	ioFile.read(reinterpret_cast<char*>(&check.adultTickets), 4);
	ioFile.read(reinterpret_cast<char*>(&check.concessionTickets), 4);

	if (strlen(check.idNumber) == strlen(reservation.idNumber))
		if (strncmp(reservation.idNumber, check.idNumber, strlen(check.idNumber)) == 0)
			if (strlen(check.reservationNumber) == strlen(reservation.reservationNumber))
				if (strncmp(reservation.reservationNumber, check.reservationNumber, strlen(check.reservationNumber)) == 0)
				{
					for (int i = 0; i < 12; i++)
						reservation.reservationNumber[i] = check.reservationNumber[i];
					for (int i = 0; i < 8; i++)
						reservation.trainNumber[i] = check.trainNumber[i];
					for (int i = 0; i < 12; i++)
						reservation.phone[i] = check.phone[i];
					for (int i = 0; i < 12; i++)
						reservation.idNumber[i] = check.idNumber[i];
					for (int i = 0; i < 12; i++)
						reservation.date[i] = check.date[i];

					reservation.originStation = check.originStation;
					reservation.destinationStation = check.destinationStation;
					reservation.carClass = check.carClass;
					reservation.adultTickets = check.adultTickets;
					reservation.concessionTickets = check.concessionTickets;
					return true;
				}

	/*cout << reservation.reservationNumber << "  ";
	cout << check.trainNumber<<"  ";
	cout << check.idNumber << "  ";
	cout << check.phone << "  ";
	cout << check.date << "  ";
	cout << check.originStation << "  ";
	cout << check.destinationStation << "  ";
	cout << check.carClass << "  ";
	cout << check.adultTickets << "  ";
	cout << check.concessionTickets << "  ";*/

	return false;
}

void displayReservations(Train southboundTimetable[100], Train northboundTimetable[100], Reservation reservation)
{

}
//����
void display(Reservation reservation, Train trainTimetable[100])
{
	int a = 0;
	for (int i = 0; i < 100; i++)
		if (strncmp(reservation.trainNumber,trainTimetable[i].trainNumber,strlen(reservation.trainNumber))==0)
		{
			a = i;
			break;
		}
	cout << endl;
	int x = 0;

	if (reservation.carClass == 1)
		x = adultTicketPrice[reservation.destinationStation][reservation.originStation];
	else if (reservation.carClass == 2)
		x = adultTicketPrice[reservation.originStation][reservation.destinationStation];

	if (x == 0)
	{
		cout << "���Z���S��Business Car,�w�N�z�令Standard Car";
		reservation.carClass = 1;
		return display(reservation, trainTimetable);
	}
	cout <<setw(12)<< "Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
	cout << reservation.date << setw(14) << reservation.trainNumber << setw(8) << stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation] << setw(10) << trainTimetable[a].departureTimes[reservation.originStation] << setw(9) << trainTimetable[a].departureTimes[reservation.destinationStation] << setw(6) << x << "*" << reservation.adultTickets << setw(10) << x / 2 << "*" << reservation.adultTickets << setw(6) << x * reservation.adultTickets + (x / 2) * reservation.concessionTickets << setw(10) << classtrain[reservation.carClass] << endl;
	inputContactInfo(reservation);
}

void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation)
{
}
