#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

char stations[13][12] = {"Nangang","Taipei","banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying"};

char carClass[12] = {};
// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];

   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end) {
	int number = 0;
	string temp = {};

	cin >> temp;

	if (temp.size() > 2)	return -1;
	else if (temp.size() == 2) {
		number = (temp[0] - '0') * 10 + (temp[1] - '0');
		if (number >= begin && number <= end)
			return number;
		else
			return -1;
	}
	else if (temp.size() == 1) {
		number = temp[0] - '0';
		if (number >= begin && number <= end)
			return number;
		else
			return -1;
	}
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]) {
	Reservation temp;
	int departureTime;
	int numSouthboundTrains, numNorthboundTrains;
	int choice;

	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);	
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);

	inputReservationDetails(temp, departureTime);
	//�n�U
	if (temp.destinationStation > temp.originStation) {
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, temp, departureTime);
		inputContactInfo(temp);
		saveReservation(temp);
	}
	//�_�W
	else if (temp.destinationStation < temp.originStation) {
		selectNorthboundTrain(southboundTimetable, numSouthboundTrains, temp, departureTime);
		inputContactInfo(temp);
		saveReservation(temp);
	}
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime) {
	cout << "Origin Station"  << endl
		 << "1. Nangang"	  << endl
		 << "2. Taipei"		  << endl
		 << "3. Banqiao"	  << endl
	 	 << "4. Taoyuan"	  << endl
		 << "5. Hsinchu"	  << endl
		 << "6. Miaoli"		  << endl
		 << "7. Taichung"	  << endl
		 << "8. Changhua"	  << endl
		 << "9. Yunlin"		  << endl
		 << "10. Chiayi"	  << endl
		 << "11. Tainan"	  << endl
		 << "12. Zuoying";

	do cout << "\n? ";
	while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
	cout << endl;

	cout << "Destination Station" << endl
		<< "1. Nangang"			  << endl
		<< "2. Taipei"			  << endl
		<< "3. Banqiao"			  << endl
		<< "4. Taoyuan"			  << endl
		<< "5. Hsinchu"			  << endl
		<< "6. Miaoli"			  << endl
		<< "7. Taichung"		  << endl
		<< "8. Changhua"		  << endl
		<< "9. Yunlin"			  << endl
		<< "10. Chiayi"			  << endl
		<< "11. Tainan"			  << endl
		<< "12. Zuoying";

	do {
		if (reservation.destinationStation == reservation.originStation)
			cout << "Your destinationStation and originStation are same.Please enter again." << endl;
		cout << "\n? "; 
	}while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1 || 
			reservation.destinationStation==reservation.originStation);
	cout << endl;

	cout << "Car Class" << endl << "1. Standard Car" << endl << "2. Business Car";
	do cout << "\n? ";
	while ((reservation.carClass = inputAnInteger(1,2)) == -1);
	cout << endl;

	cout << "Departure Date:";
	cin >> reservation.date;

	for (int i = 1; i < 35; i++)
		cout << i << "." << departureTimes[i] << endl;
	do cout << "\n? ";
	while ((departureTime = inputAnInteger(1, 34)) == -1);
	cout << endl;

	do {
		cout << "How many adult tickets?" << endl;
		cin >> reservation.adultTickets;
		cout << "How many concession tickets?" << endl;
		cin >> reservation.concessionTickets;
	} while ((reservation.adultTickets + reservation.concessionTickets) <= 0 ||
			 reservation.adultTickets < 0|| reservation.concessionTickets < 0);
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) {
	fstream insouth("Southbound timetable.txt", ios::in );
	string word;
	Train train;
	int count = 0;
	int times = 0;
	while (insouth>> word) {
		for (int i = 0; i < word.size(); i++) {
			if (times == 0) {
				southboundTimetable[0].trainNumber[i] = word[i];
			}
			else
				;
		}

		//cout << southboundTimetable[0].departureTimes << southboundTimetable[0].trainNumber << endl;


		southboundTimetable = word.c_str;
		times++;
		if (count % 14 == 0)
			numSouthboundTrains++;
	}
	insouth.close();

}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) {
	fstream innorth("Southbound timetable.txt", ios::in );
	
	string word;
	Train train;
	int j = 0;
	int times = 0;
	while (innorth >> word) {
		for (int i = 0; i < word.size(); i++) {
			if (times == 0) {
				northboundTimetable[j].trainNumber[i] = word[i];
			}
			//else
				//southboundTimetable[j].departureTimes[i] = word[i];
		}
		times++;
		//cout << southboundTimetable[0].departureTimes << southboundTimetable[0].trainNumber << endl;
		j++;
	}

	innorth.close();

}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime) {
	int count = 0;
	cout << "Train No." << setw(11) << right << "Departure" << setw(9) << right << "Arrival" << endl;
	

	for (int i = 0; i < numSouthboundTrains; i++) {
		if (strcmp(reinterpret_cast<char*>(&southboundTimetable[i].departureTimes), departureTimes[departureTime]) > 0) {
			cout << setw(9) << right << southboundTimetable[i].trainNumber
				<< setw(11) << right << southboundTimetable[i].departureTimes <<setw(9)<< endl;;
			  /*<<arrival time<<endl;*/
			count++;
		}
		if (count == 10)
			break;
	}


	/*do {*/
		cout << "Enter Train Number:" << endl;
		cin >> reservation.trainNumber;
	/*} while (reservation.trainNumber);*/

	cout << "Trip Details" << endl;

	display(reservation, southboundTimetable, stations,carClass);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) {
	int count = 0;
	cout << "Train No." << setw(11) << right << "Departure" << setw(9) << right << "Arrival" << endl;
	for (int i = 0; i < numNorthboundTrains; i++) {

		/*if (strcmp(reinterpret_cast<char*>(&numNorthboundTrains[i].departureTimes), departureTimes[departureTime]) > 0) {
			cout << northboundTimetable[i].trainNumber << northboundTimetable->trainNumber;

			count++;
		}
		if (count == 10)*/
			break;
	}
	do {
		cout << "Enter Train Number:" << endl;
		cin >> reservation.trainNumber;
	} while (reservation.trainNumber);

	cout << "Trip Details" << endl;

	display(reservation, northboundTimetable, stations,carClass);

}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation) {
	cout << "Enter Contact Person Information" << endl;
	cout << "ID Number:" ;
	cin >> reservation.idNumber;
	cout << "Phone:" ;
	cin >> reservation.phone;
	cout << "Reservation Number:";
	for (int i = 0; i < 8; i++) {
		reservation.reservationNumber[i] = rand() % 10 + '0';
		cout << reservation.reservationNumber[i];
	}
	cout << endl;
	cout << "Reservation Completed!" << endl;

}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation) {
	fstream outfile("details.dat", ios::out | ios::binary);
	outfile.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));

	outfile.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]) {
	Reservation temp = {};
	int choice;

	//��������q�������ƬҬ�0 ���P����
	if (temp.adultTickets == 0 &&temp.concessionTickets ==0 ) {
		cout << "Reservation Cancelled! " << endl;
		return;
	}
	
	fstream infile("Reservation details.dat", ios::in | ios::binary);
	existReservation(infile,temp);
	displayReservations(southboundTimetable, northboundTimetable,temp);
	
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reduceSeats(infile, southboundTimetable, northboundTimetable,temp);
			break;
		case 3:
			return ;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation) {
	Reservation tmp;

	cout << "Enter ID Number:" << endl;
	cin >> reservation.idNumber;
	cout << "Enter Reservation Number:" << endl;
	cin >> reservation.reservationNumber;
	
	while (ioFile.read(reinterpret_cast<char*>(&tmp), sizeof(Reservation))) {
		if (strcmp(reservation.idNumber,tmp.idNumber) == 0) {
			if (strcmp(reservation.reservationNumber,tmp.reservationNumber ) == 0)
				return true;
		}
	}
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation) {
	int numsouth,numnorth;
	loadSouthboundTimetable(southboundTimetable,numsouth);
	loadNorthboundTimetable(northboundTimetable,numnorth);
		
	cout << "Reservation Details" << endl;
	display(reservation, southboundTimetable, stations,carClass);
	display(reservation, northboundTimetable, stations, carClass);
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]) {
	int total=0;
	if (reservation.adultTickets != 0 || reservation.concessionTickets != 0) {
		//fare
		total += adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets 
			+ adultTicketPrice[reservation.originStation][reservation.destinationStation] * 0.5* reservation.concessionTickets;
		
		cout << setw(17) << right << "Date  Train" << setw(4) << left << "No." << setw(8) << right << "From"
			<< setw(10) << right << "To" << setw(11) << right << "To  Departure" << setw(9) << right << "Arrival"
			<< setw(8) << right << "Adult" << setw(12) << right << "Concession" << setw(6) << right << "Fare"
			<< setw(10) << right << "Class" << endl;


		cout << setw(17) << right << reservation.date << setw(4) << left << reservation.trainNumber
			<< setw(8) << right << stations[reservation.originStation]
			<< setw(10) << right << stations[reservation.destinationStation]
			<< setw(11) << right << trainTimetable->departureTimes << setw(9) << right << trainTimetable->departureTimes
			<< setw(8) << right << adultTicketPrice[reservation.originStation][reservation.destinationStation] 
			<< "*" << reservation.adultTickets
			<< setw(12) << right << adultTicketPrice[reservation.originStation][reservation.destinationStation] * 0.5 
			<< "*" << reservation.concessionTickets
			<< setw(6) << right << total << setw(10) << right << carClass[reservation.carClass] << endl;
		
	}
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation) {
	Reservation tmp;
	Reservation input;

	displayReservations(southboundTimetable, northboundTimetable, reservation);

	do {
		cout << "How many adult tickets to cancel�H" << endl;
		cin >> input.adultTickets;
	} while (input.adultTickets > reservation.adultTickets);

	do {
		cout << "How many concession tickets to cancel�H" << endl;
		cin >> input.concessionTickets;
	} while (input.concessionTickets > reservation.concessionTickets);

	while (ioFile.read(reinterpret_cast<char*>(&tmp), sizeof(Reservation))) {
		if (strcmp(reinterpret_cast<const char*>(&tmp), reinterpret_cast<const char*>(&reservation)) == 0) {
			tmp.adultTickets = input.adultTickets;
			reservation.adultTickets = input.adultTickets;
			tmp.concessionTickets = input.concessionTickets;
			reservation.concessionTickets = input.concessionTickets;
		}
	}

	/*while (ioFile.read(reinterpret_cast<char*>(&tmp), sizeof(Reservation))) {
		int adulttickets, concessiontickets;
		do {
			cout << "How many adult tickets to cancel�H" << endl;
			cin >> adulttickets;
		} while (adulttickets > reservation.adultTickets);
		reservation.adultTickets = adulttickets;

		do {
			cout << "How many concession tickets to cancel�H" << endl;
			cin >> concessiontickets;
		} while (concessiontickets > reservation.concessionTickets);
		reservation.concessionTickets = concessiontickets;

		displayReservations(southboundTimetable, northboundTimetable, reservation);

		cout << "You have successfully reduced the number of tickets!" << endl;
	}*/

}