#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

char stations[13][12] = { "", "Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu",
		"Miaoli", "Taichung", "Changhua", "Yunlin", "Chiayi", "Tainan", "Zuoying" };
char carClass[13];
char carclass1[2][13] = { "standard car", "business car" };

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	int input = 0;
	if (end < 10)
	{
		char num[100];
		int j = -1;
		cin >> num;
		for (int i = 0; num[i] != '\0'; i++)
			j++;
		if (j > 0)
			return -1;
		else
		{
			if (num[0] < '0' || num[0] > '9')
				return -1;
			input = num[0] - '0';
			if (input >= begin && input <= end)
				return input;
		}
	}
	else
	{
		char num[100];
		cin >> num;
		int j = -1;
		for (int i = 0; num[i] != '\0'; i++)
			j++;
		if (j > 1)
			return -1;
		else
		{
			for (int i = 0; i < j + 1; i++)
				if (num[i] < '0' || num[i] > '9')
					return -1;
			if (j == 0)
				input = num[0] - '0';
			else if(j == 1)
				 input += (num[0] - '0') * 10 + (num[1] - '0');
			if (input >= begin && input <= end)
				return input;
		}
	}
	return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;
	int departureTime, trains = 0 , north, south;
	
	loadSouthboundTimetable(southboundTimetable, south);
	loadNorthboundTimetable(northboundTimetable, north);
	
	inputReservationDetails(reservation, departureTime);
	if (reservation.carClass == 1)
	{
		for (int i = 0; i < 13; i++)
			carClass[i] = carclass1[0][i];
	}
	else if (reservation.carClass == 2)
	{
		for (int i = 0; i < 13; i++)
			carClass[i] = carclass1[1][i];
	}
	
	if (reservation.originStation > reservation.destinationStation)
	{
		selectNorthboundTrain(northboundTimetable, trains, reservation, departureTime);
		display(reservation, northboundTimetable, stations, carClass);
	}
	else if (reservation.originStation < reservation.destinationStation)
	{
		selectSouthboundTrain(southboundTimetable, trains, reservation, departureTime);
		display(reservation, southboundTimetable, stations, carClass);
	}

	inputContactInfo(reservation);
}
// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	int time;
	int origin, distination;
	cout << "Origin Station" << endl;
	cout << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n" << "4. Taoyuan\n"
		<< "5. Hsinchu\n" << "6. Miaoli\n" << "7. Taichung\n" << "8. Changhua\n"
		<< "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" << "12. Zuoying\n";
	do {
		cout << "? ";
	} while ((reservation.originStation = inputAnInteger(1, 12)) == -1);

	cout << "\nDestination Station" << endl;
	cout << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n" << "4. Taoyuan\n"
		<< "5. Hsinchu\n" << "6. Miaoli\n" << "7. Taichung\n" << "8. Changhua\n"
		<< "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" << "12. Zuoying\n";
	do {
		do {
			cout << "? ";
		} while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1);
	}while (reservation.originStation == reservation.destinationStation);

	cout << "\nCar Class" << endl;
	cout << "1. Standard Car\n" << "2. Business Car\n";
	do{
		cout << "? ";
	} while ((reservation.carClass = inputAnInteger(1, 2) == -1));

	cout << "Departure Date: ";
	cin >> reservation.date;

	cout << "Departure Time" << endl;
	for (int i = 1; i < 36; i++)
		cout << setw(2) << right << i << ". " << departureTimes[i] << endl;
	do {
		cout << "? ";
	} while ((time = inputAnInteger(1, 36) == -1));

	do {
		cout << "How many adult tickets? ";
	} while ((reservation.adultTickets = inputAnInteger(0, 100) == -1));
	do {
		cout << "How many concession tickets? ";
	} while ((reservation.concessionTickets = inputAnInteger(0, 100) == -1));
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	int num;
	Train tmp;
	char chtmp[13][8];
	fstream inFile("Southbound timetable.txt", ios::in);
	inFile.seekg(0, ios::end);
	num = inFile.tellg() / sizeof(Train);
	inFile.seekg(0, ios::beg);
	for(int i = 0; i < 87; i++)
	{
		inFile >> southboundTimetable[i].trainNumber;
		for (int j = 1; j < 13; j++)
		{
			inFile >> southboundTimetable[i].departureTimes[j];
		}
	}
}
// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	int num;
	fstream inFile("Northbound timetable.txt", ios::in);
	inFile.seekg(0, ios::end);
	num = inFile.tellg() / sizeof(Train);
	inFile.seekg(0, ios::beg);
	for (int i = 0; i < 92; i++)
	{
		inFile >> northboundTimetable[i].trainNumber;
		for (int j = 1; j < 13; j++)
			inFile >> northboundTimetable[i].departureTimes[j];
	}
}
// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	int num = 0;
	char train[10][8];
	int rf = 0;
	int tableTimeHr[87], tableTimeMin[87], departureHr, departureMin;

	for (int i = 0; i < 86; i++)
	{
		tableTimeHr[i] =
			(southboundTimetable[i].departureTimes[reservation.originStation][0] - '0') * 10 +
			(southboundTimetable[i].departureTimes[reservation.originStation][1] - '0');
		tableTimeMin[i] =
			(southboundTimetable[i].departureTimes[reservation.originStation][3] - '0') * 10 +
			(southboundTimetable[i].departureTimes[reservation.originStation][4] - '0');
	}
	departureHr =
		(departureTimes[departureTime][1] - '0') * 10 +
		(departureTimes[departureTime][2] - '0');
	departureMin =
		(departureTimes[departureTime][3] - '0') * 10 +
		(departureTimes[departureTime][1] - '0');
	
	cout << "Train No." << setw(11) << right << "Departure" << setw(9) << right << "Arrival" << endl;
	
	for (int i = 0; i < 87; i++)
	{
		if (tableTimeHr[i] >= departureHr && tableTimeMin[i] >= departureMin)
		{
			cout << setw(9) << southboundTimetable[i].trainNumber;
			cout << setw(11) << southboundTimetable[i].departureTimes[reservation.originStation];
			cout << setw(9) << southboundTimetable[i].departureTimes[reservation.destinationStation];
			for (int j = 0; j < 8; j++)
			    train[num][j] = southboundTimetable[i].trainNumber[j];
			num++;
		}
		if (num == 10)
			break;
	}
	while (rf = 0)
	{
		cout << "Enter Train Number: ";
		cin >> reservation.trainNumber;
		for (int i = 0; i < 10; i++)
			if (strcmp(train[i], reservation.trainNumber) == 0)
			{
				rf = 1;
				break;
			}
	}
	for (int i = 0; i < 87; i++)
		if (strcmp(southboundTimetable[i].trainNumber, reservation.trainNumber))
			numSouthboundTrains = i;
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	int num = 0;
	char train[10][8];
	int rf = 0;
	int tableTimeHr[92], tableTimeMin[92], departureHr, departureMin;

	for (int i = 0; i < 91; i++)
	{
		tableTimeHr[i] =
			(northboundTimetable[i].departureTimes[reservation.originStation][0] - '0') * 10 +
			(northboundTimetable[i].departureTimes[reservation.originStation][1] - '0');
		tableTimeMin[i] =
			(northboundTimetable[i].departureTimes[reservation.originStation][3] - '0') * 10 +
			(northboundTimetable[i].departureTimes[reservation.originStation][4] - '0');
	}
	departureHr =
		(departureTimes[departureTime][0] - '0') * 10 +
		(departureTimes[departureTime][1] - '0');
	departureMin =
		(departureTimes[departureTime][3] - '0') * 10 +
		(departureTimes[departureTime][1] - '0');
	
	cout << "Train No." << setw(11) << right << "Departure" << setw(9) << right << "Arrival" << endl;
	
	for (int i = 0; i < 91; i++)
	{
		if (tableTimeHr[i] >= departureHr && tableTimeMin[i] >= departureMin)
		{
			cout << setw(9) << northboundTimetable[i].trainNumber;
			cout << setw(11) << northboundTimetable[i].departureTimes[reservation.originStation];
			cout << setw(9) << northboundTimetable[i].departureTimes[reservation.destinationStation];
			for (int j = 0; j < 8; j++)
				train[num][j] = northboundTimetable[i].trainNumber[j];
			num++;
		}
		if (num == 10)
			break;
	}
	while (rf = 0)
	{
		cout << "Enter Train Number: ";
		cin >> reservation.trainNumber;
		for (int i = 0; i < 10; i++)
			if (strcmp(train[i], reservation.trainNumber) == 0)
			{
				rf = 1;
				break;
			}
	}
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	srand(time(NULL));
	int tmp;
	cout << "Enter Contact Person Information" << endl;

	cout << "\nID Number: ";
	cin >> reservation.idNumber;

	cout << "\nPhone: ";
	cin >> reservation.phone;

	cout << "\nReservation Number: ";
	for (int i = 0; i < 8; i++)
	{
		tmp = rand() % 10;
		reservation.reservationNumber[i] = tmp + '0';
		cout << reservation.reservationNumber[i];
	}

	cout << "\nReservation Completed!";
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream outFile("Reservation details.dat", ios::app | ios::binary);
	outFile.write(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
}
void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
    Reservation reservation;
	int num;
	
	fstream file("Reservation details.dat", ios::binary | ios::in);
	file.read(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
	
	if (!existReservation(file, reservation))
		return;

	int choice;
	do
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			if (!existReservation(file, reservation))
				break;
			displayReservations(southboundTimetable, northboundTimetable, reservation);
			reservation.adultTickets = 0;
			reservation.concessionTickets = 0;
			reservation.carClass = 0;	
			reservation.destinationStation = 0;
			reservation.originStation = 0;
			for (int i = 0; i < 12; i++)
			{
				reservation.date[i] = '\0';
				reservation.idNumber[i] = '\0';
				reservation.phone[i] = '\0';
				reservation.reservationNumber[i] = '\0';
				reservation.trainNumber[i] = '\0';
			}
			cout << "\nReservation Cancelled!";
			break;
		case 2:
			reduceSeats(file, southboundTimetable, northboundTimetable, reservation);
			choice = 1;
			break;
		case 3:
			return;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	} while (choice != 1);
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	char id[12];
	char num[12];

	cout << "Enter ID Number : ";
	cin >> id;

	cout << "\nEnter Reservation Number: ";
	cin >> num;
	 
	if (strcmp(id, reservation.idNumber) != 0 || strcmp(num, reservation.reservationNumber) != 0)
		return false;
	else
		return true;
}
void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	int north, south;
	cout << "Reservation Details" << endl;
	
	loadNorthboundTimetable(northboundTimetable, north);
	loadSouthboundTimetable(southboundTimetable, south);
	
	if (reservation.originStation < reservation.destinationStation)
		display(reservation, southboundTimetable, stations, carClass);
	else if (reservation.originStation > reservation.destinationStation)
		display(reservation, northboundTimetable, stations, carClass);
}
// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	int num = 0;
	int price;
	for (int i = 0; i < 100; i++)
	{
		if (strcmp(trainTimetable[i].trainNumber, reservation.trainNumber) == 0)
		{
			num = i;
			break;
		}
	}

	price = adultTicketPrice[reservation.originStation][reservation.destinationStation];

		cout << setw(10) << "Date" << setw(11) << "Train No." << setw(8) << "From"
		<< setw(10) << "To" << setw(11) << "Departure" << setw(9) << " Arrival"
		<< setw(8) << "Adult" << setw(12) << "Concession" << setw(6) << "Fare"
		<< setw(10) << "Class" << endl;

	cout << setw(10) << reservation.date << setw(11) << reservation.trainNumber
		<< setw(8) << stations[reservation.originStation] << setw(10)
		<< stations[reservation.destinationStation] << setw(11)
		<< trainTimetable[num].departureTimes[reservation.originStation]
		<< setw(9) << trainTimetable[num].departureTimes[reservation.destinationStation]
		<< setw(6) << price << "*" << reservation.adultTickets
		<< setw(10) << price / 2 << "*" << reservation.concessionTickets
		<< setw(6) << (price * reservation.adultTickets) + (price / 2 * reservation.concessionTickets)
		<< setw(10) << carClass;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	if (!existReservation(ioFile, reservation))
		return;

	displayReservations(southboundTimetable, northboundTimetable, reservation);
	int adultCC;
	int concessionCC;

	do
	{
		cout << "\nHow many adult tickets to cancel�H";
		cin >> adultCC;
	} while (adultCC > reservation.adultTickets);

	do
	{
		cout << "How many concession tickets to cancel�H";
		cin >> concessionCC;
	} while (concessionCC > reservation.concessionTickets);

	reservation.adultTickets -= adultCC;
	reservation.concessionTickets -= concessionCC;

	if (reservation.adultTickets == 0 && reservation.concessionTickets == 0)
	{
		reservation.adultTickets = 0;
		reservation.concessionTickets = 0;
		reservation.carClass = 0;
		reservation.destinationStation = 0;
		reservation.originStation = 0;
	}
	for (int i = 0; i < 12; i++)
	{
		reservation.date[i] = '\0';
		reservation.idNumber[i] = '\0';
		reservation.phone[i] = '\0';
		reservation.reservationNumber[i] = '\0';
		reservation.trainNumber[i] = '\0';
	}
}