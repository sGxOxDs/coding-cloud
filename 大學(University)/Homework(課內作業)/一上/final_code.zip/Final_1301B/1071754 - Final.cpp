#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char input[10];
	int total = 0;
	cin >> input;
	for (int i = 0; i < strlen(input); i++)
		if (!isdigit(input[i]))
			return -1;
	total = atoi(input);
	if (total > end || total < begin)
		return -1;
	return total;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	char carclass[12];
	char station[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung"
		,"Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	int numSouthboundTrains;
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains); // ��ܫn�U�����ɨ��
	int numNorthboundTrains;
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains); // ��ܥ_�W�����ɨ��
	Reservation temp;
	int departureTime;
	inputReservationDetails(temp, departureTime);
	cout << "Train No." << setw(10) << "Departure" << setw(10) << "Arrival" << endl;
	if (temp.destinationStation > temp.originStation)
	{
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, temp, departureTime);
		display(temp, southboundTimetable, station, carclass);
	}
	else
	{
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, temp, departureTime);
	}
	inputContactInfo(temp);
	saveReservation(temp);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation &reservation, int &departureTime)
{
	cout << "Origin Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" << endl;

	do cout << "? ";			//�_�I��
	while ((reservation.originStation = inputAnInteger(1, 12)) == -1);

	cout << "\nOrigin Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" << endl;

	do cout << "? ";		//���I�� (���൥��_�I��)
	while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1 ||reservation.destinationStation==reservation.originStation);

	cout << "\nCar Class\n" << "1. Standard Car\n" << "2. Business Car\n";
	do cout << "? ";
	while ((reservation.carClass = inputAnInteger(1, 2)) == -1);	//����

	cout << "\nDeparture Date: ";
	cin >> reservation.date;	//�o�����

	cout << "\nDeparture Time\n";
	for (int i = 1; i <= 34; i++)
		cout << setw(2) << i << ". " << departureTimes[i] << endl;
	do cout << "? ";
	while ((departureTime = inputAnInteger(1, 34)) == -1);		//��ܪ��ɶ� => �Ψ���ܤ��᪺�Q�ӷf���ɶ�


	do cout << "\nHow many adult tickets? ";		//���H��
	while ((reservation.adultTickets=inputAnInteger(0,99999999))==-1);

	do cout << "\nHow many concession tickets? ";		//�u�ݲ�
	while ((reservation.concessionTickets = inputAnInteger(0, 99999999)) == -1||(reservation.concessionTickets==0 &&reservation.adultTickets==0));
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int &numSouthboundTrains)
{
	ifstream infile("Southbound timetable.txt", ios::in );
	numSouthboundTrains = 0;
	while (infile >> southboundTimetable[numSouthboundTrains].trainNumber)
	{
		for (int i = 1; i <= 12; i++)
			infile >> southboundTimetable[numSouthboundTrains].departureTimes[i];
		numSouthboundTrains++;
	}
	infile.close();
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int &numNorthboundTrains)
{
	ifstream infile("Northbound timetable.txt", ios::in);
	numNorthboundTrains = 0;
	while (infile >> northboundTimetable[numNorthboundTrains].trainNumber)
	{
		for (int i = 1; i <= 12; i++)
			infile >> northboundTimetable[numNorthboundTrains].departureTimes[i];
		numNorthboundTrains++;
	}
	infile.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	int position = 0;
	for (int i = 0; i < numSouthboundTrains; i++)
	{
		for (int j = 0; j <= 4; j++)
		{
			if ((southboundTimetable[i].departureTimes[reservation.originStation][j] - '0') >= (departureTimes[departureTime][j] - '0'))
			{
				if (j == 4)
					position = i;
				continue;
			}
			else
				break;
		}
		if (position != 0)
			break;
	}
	char the10[10][8];
	int count = 0;
	for (int i = position; i < position + 10; i++)
	{
		cout << setw(10) << southboundTimetable[i].trainNumber;
		cout << setw(10) << southboundTimetable[i].departureTimes[reservation.originStation];
		cout << setw(10) << southboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
		for (int j = 0; j < strlen(southboundTimetable[i].trainNumber); j++)
			the10[count][j] = southboundTimetable[i].trainNumber[j];
		the10[count][strlen(southboundTimetable[i].trainNumber)] = '\0';
		count++;
	}
	char mot[5];
	int a = 0;
	while (a == 0)
	{
		cout << "\nEnter Train Number: ";
		cin >> mot;
		for (int i = 0; i < 10; i++)
			if (strcmp(mot, the10[i]) == 0)
			{
				for (int j = 0; j < strlen(mot); j++)
					reservation.trainNumber[j] = mot[j];
				a = 1;
			}
	}
	if (strlen(mot) == 3)
		reservation.trainNumber[3] = '\0';
	else
		reservation.trainNumber[4] = '\0';
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	int position = 0;
	for (int i = 0; i < numNorthboundTrains; i++)
	{
		for (int j = 0; j <= 4; j++)
		{
			if ((northboundTimetable[i].departureTimes[reservation.originStation][j] - '0') >= (departureTimes[departureTime][j] - '0'))
			{
				if (j == 4)
					position = i;
				continue;
			}
			else
				break;
		}
		if (position != 0)
			break;
	}
	char the10[10][8];
	int count = 0;
	for (int i = position; i < position + 10; i++)
	{
		cout << setw(10) << northboundTimetable[i].trainNumber;
		cout << setw(10) << northboundTimetable[i].departureTimes[reservation.originStation];
		cout << setw(10) << northboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
		for (int j = 0; j < strlen(northboundTimetable[i].trainNumber); j++)
			the10[count][j] = northboundTimetable[i].trainNumber[j];
		the10[count][strlen(northboundTimetable[i].trainNumber)] = '\0';
		count++;
	}
	char mot[5];
	int a = 0;
	while (a == 0)
	{
		cout << "\nEnter Train Number: ";
		cin >> mot;
		for (int i = 0; i < 10; i++)
			if (strcmp(mot, the10[i]) == 0)
			{
				for (int j = 0; j < strlen(mot); j++)
					reservation.trainNumber[j] = mot[j];
				a = 1;
			}
	}
	if (strlen(mot) == 3)
		reservation.trainNumber[3] = '\0';
	else
		reservation.trainNumber[4] = '\0';
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "\nEnter Contact Person Information\n";
	cout << "\nID Number: ";
	cin >> reservation.idNumber;
	cout << "\nPhone: ";
	cin >> reservation.phone;
	cout << "\nReservation Number: ";
	for (int i = 0; i <= 7; i++)
	{
		reservation.reservationNumber[i] = rand() % 10 + '0';
		cout << reservation.reservationNumber[i];
	}
	reservation.reservationNumber[8] = '\0';
	cout << "\n\nReservation Completed!\n\n";
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream outfile("Reservation details.dat", ios::app | ios::binary);
	outfile.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
	outfile.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	char station[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung"
		,"Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char mother_fucker[8];
	Reservation temp;
	fstream infile("Reservation details.dat", ios::binary|ios::in|ios::out);
	
	while (!existReservation(infile, temp))
		cout << "\nReservation record not found.\n";

		cout << "\nReservation Details          displayed by displayReservations\n";
		if (temp.destinationStation > temp.originStation)
			display(temp, southboundTimetable, station, mother_fucker);
		else
			display(temp, northboundTimetable, station, mother_fucker);

		int choice;
		do cout << "\nEnter Your Choice" << "\n1. Cancellation" << "\n2. Reduce" << "\n3. End\n";
		while ((choice = inputAnInteger(1, 3)) == -1);
			
		switch (choice)
		{
		case 1:
			
			break;

		case 2:
			reduceSeats(infile, southboundTimetable, northboundTimetable, temp);
			if (temp.destinationStation > temp.originStation)
				display(temp, southboundTimetable, station, mother_fucker);
			else
				display(temp, northboundTimetable, station, mother_fucker);
			cout << "\nYou have successfully reduced the number of tickets! \n";
			break;

		case 3:
			break;
		}		
		infile.close();
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	cout << "\nEnter ID Number: ";
	cin >> reservation.idNumber;
	cout << "\nEnter Reservation Number: ";
	cin >> reservation.reservationNumber;
	Reservation load;
	while (ioFile.read(reinterpret_cast<char*>(&load), sizeof(Reservation)))
		if (strcmp(load.idNumber, reservation.idNumber) == 0)
			if (strcmp(load.reservationNumber, reservation.reservationNumber) == 0)
			{
				reservation = load;
				return true;
			}
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	cout << "\nReservation Details\n";
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class\n";
	cout << setw(10) << reservation.date;
	cout << setw(10)<< reservation.trainNumber;
	cout << setw(3);
	for (int i = 0; i < strlen(stations[reservation.originStation]); i++)
		cout << stations[reservation.originStation][i];
	cout << setw(3);
	for (int i = 0; i < strlen(stations[reservation.destinationStation]); i++)
		cout << stations[reservation.destinationStation][i];
	int position;
	for(int i=0;i<100;i++)
		if (strcmp(reservation.trainNumber,trainTimetable[i].trainNumber)==0)
		{
			position = i;
				break;
		}
	cout << setw(10) << trainTimetable[position].departureTimes[reservation.originStation];
	cout<<setw(10)<< trainTimetable[position].departureTimes[reservation.destinationStation];
	int price;
	if (reservation.carClass == 2)
	{
		price = adultTicketPrice[reservation.originStation][reservation.destinationStation];
		cout << setw(7) << price << '*' << reservation.adultTickets << setw(10) << price / 2 << '*' << reservation.concessionTickets;
		cout<<setw(5) << (reservation.adultTickets * price) + (reservation.concessionTickets * price / 2);
		cout << setw(10) << "Concession";
	}
	else
	{
		price = adultTicketPrice[reservation.destinationStation][reservation.originStation];
		cout << setw(7) << price << '*' << reservation.adultTickets << setw(10) << price / 2 << '*' << reservation.concessionTickets;
		cout << setw(5) << (reservation.adultTickets * price) + (reservation.concessionTickets * price / 2);
		cout << setw(12) << "Standard";
	}
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int adultC, concessC;
	do
	{
		cout << "\nHow many adult tickets to cancel�H ";
		cin >> adultC;
		cout << "How many concession tickets to cancel�H ";
		cin >> concessC;
	} while (adultC <= reservation.adultTickets && concessC <= reservation.concessionTickets || adultC + concessC == reservation.adultTickets + reservation.concessionTickets);
	reservation.adultTickets -= adultC;
	reservation.concessionTickets -= concessC;
	
	ioFile.seekg(0, ios::beg);
	ioFile.seekp(0, ios::beg);

	int count = 0;
	Reservation load;
	while (ioFile.read(reinterpret_cast<char*>(&load), sizeof(Reservation)))
	{
		if (strcmp(load.idNumber, reservation.idNumber) == 0)
			if (strcmp(load.reservationNumber, reservation.reservationNumber) == 0)
			{
				reservation = load;
				break;
			}
		count++;
	}
	ioFile.seekg(count * sizeof(Reservation), ios::beg);
	ioFile.write(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
}