#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include <string>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

char stations[13][12] = { "", "Nangang", "Taipei", "Banqiao", "Taoyuan", "Hsinchu", "Miaoli", "Taichung", "Changhua", "Yunlin", "Chiayi", "Tainan", "Zuoying" };

char carClass[12];

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[100] = {0};
   Train northboundTimetable[100] = {0};
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char a[100];
	cin >> a;
	if (a[0] - 48 >= begin && a[0] - 48 <= end && a[1] == 0) // one digit
	{
		return a[0] - 48;
	}
	else if (((a[0] - 48) * 10 + (a[1] - 48)) >= begin && ((a[0] - 48) * 10 + (a[1] - 48)) <= end && a[2] == 0) // two digit
	{
		return ((a[0] - 48) * 10 + (a[1] - 48));
	}
	else
	{
		return -1;
	}
}


void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;
	int numSouthboundTrains = 0, numNorthboundTrains = 0, departureTime = 0;
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
	inputReservationDetails(reservation, departureTime);
	if (reservation.originStation > reservation.destinationStation)
	{
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains,
			reservation, departureTime);
	}
	else
	{
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains,
			reservation, departureTime);
	}
	inputContactInfo(reservation);
	saveReservation(reservation);
}


// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	inputStation:
	cout << "Origin Station" << endl;
	cout << "1. Nangang" << endl <<
		"2. Taipei" << endl <<
		"3. Banqiao" << endl <<
		"4. Taoyuan" << endl <<
		"5. Hsinchu" << endl <<
		"6. Miaoli" << endl <<
		"7. Taichung" << endl <<
		"8. Changhua" << endl <<
		"9. Yunlin" << endl <<
		"10. Chiayi" << endl <<
		"11. Tainan" << endl <<
		"12. Zuoying" << endl;
	do cout << "?";
	while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
	cout << endl << endl << "Destination Station" << endl;
	cout << "1. Nangang" << endl <<
		"2. Taipei" << endl <<
		"3. Banqiao" << endl <<
		"4. Taoyuan" << endl <<
		"5. Hsinchu" << endl <<
		"6. Miaoli" << endl <<
		"7. Taichung" << endl <<
		"8. Changhua" << endl <<
		"9. Yunlin" << endl <<
		"10. Chiayi" << endl <<
		"11. Tainan" << endl <<
		"12. Zuoying" << endl;
	do cout << "?";
	while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1);
	if (reservation.originStation == reservation.destinationStation)
		goto inputStation;
	cout << endl << endl << "Car Class" << endl;
	cout << "1. Standard Car" << endl <<
		"2. Business Car" << endl;
	do cout << "?";
	while ((reservation.carClass = inputAnInteger(1, 2)) == -1);
	if ((reservation.originStation == 1 && reservation.destinationStation == 2 && reservation.carClass == 2) || (reservation.originStation == 1 && reservation.destinationStation == 3 && reservation.carClass == 2) || (reservation.originStation == 2 && reservation.destinationStation == 3 && reservation.carClass == 2))
	{
		cout << "no Business Car" << endl;
		goto inputStation;
	}
	cout << endl << endl << "Departure Date: ";
	cin >> reservation.date;
	cout << endl << endl << "Departure Time" << endl;
	cout << "1. 06:00" << endl <<
		"2. 06 : 30" << endl <<
		"3. 07 : 00" << endl <<
		"4. 07 : 30" << endl <<
		"5. 08 : 00" << endl <<
		"6. 08 : 30" << endl <<
		"7. 09 : 00" << endl <<
		"8. 09 : 30" << endl <<
		"9. 10 : 00" << endl <<
		"10. 10 : 30" << endl <<
		"11. 11 : 00" << endl <<
		"12. 11 : 30" << endl <<
		"13. 12 : 00" << endl <<
		"14. 12 : 30" << endl <<
		"15. 13 : 00" << endl <<
		"16. 13 : 30" << endl <<
		"17. 14 : 00" << endl <<
		"18. 14 : 30" << endl <<
		"19. 15 : 00" << endl <<
		"20. 15 : 30" << endl <<
		"21. 16 : 00" << endl <<
		"22. 16 : 30" << endl <<
		"23. 17 : 00" << endl <<
		"24. 17 : 30" << endl <<
		"25. 18 : 00" << endl <<
		"26. 18 : 30" << endl <<
		"27. 19 : 00" << endl <<
		"28. 19 : 30" << endl <<
		"29. 20 : 00" << endl <<
		"30. 20 : 30" << endl <<
		"31. 21 : 00" << endl <<
		"32. 21 : 30" << endl <<
		"33. 22 : 00" << endl <<
		"34. 22 : 30" << endl;
	do cout << "?";
	while ((departureTime = inputAnInteger(1, 34)) == -1);
	inputTicket:
	cout << endl << endl << "How many adult tickets? ";
	cin >> reservation.adultTickets;
	cout << endl << endl << "How many concession tickets? ";
	cin >> reservation.concessionTickets;
	if ((reservation.adultTickets == 0 && reservation.concessionTickets == 0) || reservation.adultTickets < 0 || reservation.concessionTickets < 0)
		goto inputTicket;

}


// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inFile("Southbound timetable.txt", ios::in);
	string s;
	int a = 0, b = 0, timeCount = 1, timeChar = 0;
	while (getline(inFile, s))
	{
		timeCount = 0;
		for (int i = 0; i < s.size(); i++)
		{
			if (southboundTimetable[a].trainNumber[0] == 0 && s[i] != 9)
			{
				while (s[b] != 9)
				{
					southboundTimetable[a].trainNumber[b] = s[b];
					b++;
				}
				i = b - 1;
				b = 0;
			}
			else if (s[i] != 9)
			{
				if (s[i] == 45)
				{
					southboundTimetable[a].departureTimes[timeCount][timeChar] = s[i];
					timeCount++;
				}
				else
				{
					while (s[i] != 9)
					{
						southboundTimetable[a].departureTimes[timeCount][timeChar] = s[i];
						i++;
						timeChar++;
					}
					timeCount++;
					timeChar = 0;
					i = i - 1;
				}
			}
		}
		numSouthboundTrains += 1;
		a++;
	}
}


// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inFile("Northbound timetable.txt", ios::in);
	string s;
	int a = 0, b = 0, timeCount = 12, timeChar = 0;
	while (inFile >> s)
	{
		timeCount = 12;
		for (int i = 0; i < s.size(); i++)
		{
			if (northboundTimetable[a].trainNumber[0] == 0 && s[i] != 9)
			{
				while (s[b] != 9)
				{
					northboundTimetable[a].trainNumber[b] = s[b];
					b++;
				}
				i = b - 1;
				b = 0;
			}
			else if (s[i] != 9)
			{
				if (s[i] == 45)
				{
					northboundTimetable[a].departureTimes[timeCount][timeChar] = s[i];
					timeCount--;
				}
				else
				{
					while (s[i] != 9)
					{
						northboundTimetable[a].departureTimes[timeCount][timeChar] = s[i];
						i++;
						timeChar++;
					}
					timeCount--;
					timeChar = 0;
					i = i - 1;
				}
			}
		}
		numNorthboundTrains += 1;
		a++;
	}
}


// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << setw(9) << "Train No." << setw(11) << "Departure" << setw(9) << "Arrival" << endl;
	char departTime[8] = { 0 }, trainNum[8] = {0};
	int startPos = 101;
	bool found = false;
	for (int i = 0; i < strlen(departureTimes[departureTime]) + 1; i++)
	{
		departTime[i] = departureTimes[departureTime][i];
	}
	for (int i = 0; i < numSouthboundTrains; i++)
	{
		if (southboundTimetable[i].departureTimes[reservation.originStation][0] == departTime[0] && southboundTimetable[i].departureTimes[reservation.originStation][1] == departTime[1] && southboundTimetable[i].departureTimes[reservation.originStation][3] == departTime[3] && southboundTimetable[i].departureTimes[reservation.originStation][4] == departTime[4])
		{
			startPos = i;
			break;
		}
	}
	if(startPos == 101)
	for (int i = 0; i < numSouthboundTrains; i++)
	{
		if (southboundTimetable[i].departureTimes[reservation.originStation][0] == departTime[0] && southboundTimetable[i].departureTimes[reservation.originStation][1] == departTime[1] && southboundTimetable[i].departureTimes[reservation.originStation][3] == departTime[3])
		{
			startPos = i;
			break;
		}
	}
	if (startPos == 101)
		for (int i = 0; i < numSouthboundTrains; i++)
		{
			if (southboundTimetable[i].departureTimes[reservation.originStation][0] == departTime[0] && southboundTimetable[i].departureTimes[reservation.originStation][1] == departTime[1] && southboundTimetable[i].departureTimes[reservation.originStation][3] >= departTime[3])
			{
				startPos = i;
				break;
			}
		}
	for (int i = 0; i < 10; i++)
	{
		int x = startPos;
		cout << setw(9) << southboundTimetable[x].trainNumber << setw(11) << southboundTimetable[x].departureTimes[reservation.originStation] << setw(9) << southboundTimetable[x].departureTimes[reservation.destinationStation] << endl;
		x++;
	}
	INPUT:
	cout << endl << "Enter Train Number: ";
	cin >> trainNum;
	for (int i = 0; i < 10; i++)
	{
		if (!strcmp(trainNum, southboundTimetable[startPos].trainNumber))
		{
			strcpy_s(reservation.trainNumber, trainNum);
			found = true;
			break;
		}
		else
		{
			found = false;
		}
	}
	if (found == false)
		goto INPUT;
	cout << endl << endl << "Trip Details" << endl;
	if (reservation.carClass == 1)
	{
		char carClass[12] = "Standard";
		display(reservation, southboundTimetable, stations, carClass);
	}
	else if (reservation.carClass == 2)
	{
		char carClass[12] = "Business";
		display(reservation, southboundTimetable, stations, carClass);
	}
}


// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << setw(9) << "Train No." << setw(11) << "Departure" << setw(9) << "Arrival" << endl;
	char departTime[8] = { 0 }, trainNum[8] = { 0 };
	int startPos = 101;
	bool found = false;
	for (int i = 0; i < strlen(departureTimes[departureTime]) + 1; i++)
	{
		departTime[i] = departureTimes[departureTime][i];
	}
	for (int i = 0; i < numNorthboundTrains; i++)
	{
		if (northboundTimetable[i].departureTimes[reservation.originStation][0] == departTime[0] && northboundTimetable[i].departureTimes[reservation.originStation][1] == departTime[1] && northboundTimetable[i].departureTimes[reservation.originStation][3] == departTime[3] && northboundTimetable[i].departureTimes[reservation.originStation][4] == departTime[4])
		{
			startPos = i;
			break;
		}
	}
	if (startPos == 101)
		for (int i = 0; i < numNorthboundTrains; i++)
		{
			if (northboundTimetable[i].departureTimes[reservation.originStation][0] == departTime[0] && northboundTimetable[i].departureTimes[reservation.originStation][1] == departTime[1] && northboundTimetable[i].departureTimes[reservation.originStation][3] == departTime[3])
			{
				startPos = i;
				break;
			}
		}
	if (startPos == 101)
		for (int i = 0; i < numNorthboundTrains; i++)
		{
			if (northboundTimetable[i].departureTimes[reservation.originStation][0] == departTime[0] && northboundTimetable[i].departureTimes[reservation.originStation][1] == departTime[1] && northboundTimetable[i].departureTimes[reservation.originStation][3] >= departTime[3])
			{
				startPos = i;
				break;
			}
		}
	for (int i = 0; i < 10; i++)
	{
		int x = startPos;
		cout << setw(9) << northboundTimetable[x].trainNumber << setw(11) << northboundTimetable[x].departureTimes[reservation.originStation] << setw(9) << northboundTimetable[x].departureTimes[reservation.destinationStation] << endl;
		x++;
	}
    input:
	cout << endl << "Enter Train Number: ";
	cin >> trainNum;
	for (int i = 0; i < 10; i++)
	{
		if (!strcmp(trainNum, northboundTimetable[startPos].trainNumber))
		{
			strcpy_s(reservation.trainNumber, trainNum);
			found = true;
			break;
		}
		else
		{
			found = false;
		}
	}
	if (found == false)
		goto input;
	cout << endl << endl << "Trip Details" << endl;
	if (reservation.carClass == 1)
	{
		char carClass[12] = "Standard";
		display(reservation, northboundTimetable, stations, carClass);
	}
	else if (reservation.carClass == 2)
	{
		char carClass[12] = "Business";
		display(reservation, northboundTimetable, stations, carClass);
	}
}


// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << endl << "ID Number: ";
	cin >> reservation.idNumber;
	cout << endl << "Phone: ";
	cin >> reservation.phone;
	for (int i = 0; i < 8; i++)
	{
		reservation.reservationNumber[i] = static_cast<unsigned int> (rand() % 10);
	}
	reservation.reservationNumber[8] = 0;
	cout << endl << "Reservation Number: ";
	for (int i = 0; i < 8; i++)
	{
		reservation.reservationNumber[i];
	}
	cout << endl << endl << "Reservation Completed!";
}


// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	fstream ioFile("Reservation details.dat", ios::in | ios::app | ios::binary);
	while (ioFile.write(reinterpret_cast<const char*> (&reservation.reservationNumber), sizeof(reservation.reservationNumber)))
	{
		ioFile.write(reinterpret_cast<const char*> (&reservation.trainNumber), sizeof(reservation.trainNumber));
		ioFile.write(reinterpret_cast<const char*> (&reservation.idNumber), sizeof(reservation.idNumber));
		ioFile.write(reinterpret_cast<const char*> (&reservation.phone), sizeof(reservation.phone));
		ioFile.write(reinterpret_cast<const char*> (&reservation.date), sizeof(reservation.date));
		ioFile.write(reinterpret_cast<const char*> (&reservation.originStation), sizeof(reservation.originStation));
		ioFile.write(reinterpret_cast<const char*> (&reservation.destinationStation), sizeof(reservation.destinationStation));
		ioFile.write(reinterpret_cast<const char*> (&reservation.carClass), sizeof(reservation.carClass));
		ioFile.write(reinterpret_cast<const char*> (&reservation.adultTickets), sizeof(reservation.adultTickets));
		ioFile.write(reinterpret_cast<const char*> (&reservation.concessionTickets), sizeof(reservation.concessionTickets));
	}
	ioFile.close();
}


void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	Reservation reservation;
	fstream ioFile("Reservation details.dat", ios::in | ios::app | ios::binary);
	if (!ioFile)
	{
		ofstream outFile("Reservation details.dat", ios::out, ios::binary);
		outFile.close();
		ioFile.clear();
	}
	existReservation(ioFile, reservation);
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	int choice, zero = 0;
	char null[1] = { 0 };
	cout << "\nEnter Your Choice\n"
	<< "1. Cancellation\n"
	<< "2. Reduce\n"
	<< "3. End";
	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 3)) == -1);
	cout << endl;
	switch (choice)
	{
	case 1:
		ioFile.write(reinterpret_cast<const char*> (&null), sizeof(null));
		ioFile.write(reinterpret_cast<const char*> (&null), sizeof(null));
		ioFile.write(reinterpret_cast<const char*> (&null), sizeof(null));
		ioFile.write(reinterpret_cast<const char*> (&null), sizeof(null));
		ioFile.write(reinterpret_cast<const char*> (&null), sizeof(null));
		ioFile.write(reinterpret_cast<const char*> (&zero), sizeof(zero));
		ioFile.write(reinterpret_cast<const char*> (&zero), sizeof(zero));
		ioFile.write(reinterpret_cast<const char*> (&zero), sizeof(zero));
		ioFile.write(reinterpret_cast<const char*> (&zero), sizeof(zero));
		ioFile.write(reinterpret_cast<const char*> (&zero), sizeof(zero));
		cout << endl << endl << "Reservation Cancelled! ";
		break;
	case 2:
		reduceSeats(ioFile, southboundTimetable, northboundTimetable, reservation);
		break;
	case 3:
		return;
	default: // display error if user does not select valid choice
		cerr << "Incorrect Choice!\n";
		break;
	}
	ioFile.close();
}


// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	bool tf = false;
	char idNumber[12];
	char reservationNumber[12];
	Reservation temp;
	cout << "Enter ID Number: ";
	cin >> idNumber;
	cout << endl << "Enter Reservation Number: ";
	cin >> reservationNumber;
	cout << endl;
	int pos = ioFile.tellg();
	while (ioFile.read(reinterpret_cast<char*> (&temp.reservationNumber), sizeof(temp.reservationNumber)))
	{
		ioFile.read(reinterpret_cast<char*> (&temp.trainNumber), sizeof(temp.trainNumber));
		ioFile.read(reinterpret_cast<char*> (&temp.idNumber), sizeof(temp.idNumber));
		ioFile.read(reinterpret_cast<char*> (&temp.phone), sizeof(temp.phone));
		ioFile.read(reinterpret_cast<char*> (&temp.date), sizeof(temp.date));
		ioFile.read(reinterpret_cast<char*> (&temp.originStation), sizeof(temp.originStation));
		ioFile.read(reinterpret_cast<char*> (&temp.destinationStation), sizeof(temp.destinationStation));
		ioFile.read(reinterpret_cast<char*> (&temp.carClass), sizeof(temp.carClass));
		ioFile.read(reinterpret_cast<char*> (&temp.adultTickets), sizeof(temp.adultTickets));
		ioFile.read(reinterpret_cast<char*> (&temp.concessionTickets), sizeof(temp.concessionTickets));
		if (!strcmp(temp.idNumber, idNumber))
		{
			if (!strcmp(temp.reservationNumber, reservationNumber))
			{
				strcpy_s(reservation.reservationNumber, temp.reservationNumber);
				strcpy_s(reservation.trainNumber, temp.trainNumber);
				strcpy_s(reservation.idNumber, temp.idNumber);
				strcpy_s(reservation.phone, temp.phone);
				strcpy_s(reservation.date, temp.date);
				reservation.originStation = temp.originStation;
				reservation.destinationStation = temp.destinationStation;
				reservation.carClass = temp.carClass;
				reservation.adultTickets = temp.adultTickets;
				reservation.concessionTickets = temp.concessionTickets;
				ioFile.seekp(pos);
				return true;
			}
		}
		pos = ioFile.tellg();
	}
	return tf;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	cout << "Reservation Details" << endl;
	if (reservation.originStation > reservation.destinationStation)
	{
		if (reservation.carClass == 1)
		{
			char carClass[12] = "Standard";
			display(reservation, northboundTimetable, stations, carClass);
		}
		else if (reservation.carClass == 2)
		{
			char carClass[12] = "Business";
			display(reservation, northboundTimetable, stations, carClass);
		}
	}
	else
	{
		if (reservation.carClass == 1)
		{
			char carClass[12] = "Standard";
			display(reservation, southboundTimetable, stations, carClass);
		}
		else if (reservation.carClass == 2)
		{
			char carClass[12] = "Business";
			display(reservation, southboundTimetable, stations, carClass);
		}
	}
}


// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	bool tf = false;
	if (reservation.originStation > reservation.destinationStation)
	{
		int change;
		change = reservation.originStation;
		reservation.originStation = reservation.destinationStation;
		reservation.destinationStation = change;
		tf = true;
	}
	int trainPos = 101, adult = 0, Concession = 0, fare = 0;
	for (int i = 0; i < 100; i++)
	{
		if (!strcmp(reservation.trainNumber, trainTimetable[i].trainNumber))
		{
			trainPos = i;
			break;
		}
	}
	if (reservation.carClass == 1) // standard
	{
		adult = adultTicketPrice[reservation.destinationStation][reservation.originStation];
		Concession = adult / 2;
	}
	else if (reservation.carClass == 2) // Business
	{
		adult = adultTicketPrice[reservation.originStation][reservation.destinationStation];
		Concession = adult / 2;
	}
	fare = adult * reservation.adultTickets + Concession * reservation.concessionTickets;
	cout << setw(10) << "Date" << setw(11) << "Train No." << setw(8) << "From" << setw(10) << "To" << setw(11) << "Departure" << setw(9) << "Arrival" << setw(8) << "Adult" << setw(12) << "Concession" << setw(6) << "Fare" << setw(10) << "Class" << endl;
	cout << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation] << setw(11) << trainTimetable[trainPos].departureTimes[reservation.originStation] << setw(9) << trainTimetable[trainPos].departureTimes[reservation.destinationStation] << setw(8) << adult << "*" << reservation.adultTickets << setw(12) << Concession << "*" << reservation.concessionTickets << setw(6) << fare << setw(10) << carClass << endl;
	if (tf == true)
	{
		int change;
		change = reservation.originStation;
		reservation.originStation = reservation.destinationStation;
		reservation.destinationStation = change;
	}
}


// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int adult, concession;
	do cout << endl << "How many adult tickets to cancel�H";
	while ((adult = inputAnInteger(0, reservation.adultTickets)) == -1);
	do cout << endl << "How many concession tickets to cancel�H";
	while ((concession = inputAnInteger(0, reservation.concessionTickets)) == -1);
	reservation.adultTickets -= adult;
	reservation.concessionTickets -= concession;
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	cout << endl << "You have successfully reduced the number of tickets!" << endl;
}