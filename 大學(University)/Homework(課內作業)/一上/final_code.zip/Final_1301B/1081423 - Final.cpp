#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <cstring>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

char station[13][12] = { "",
	"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu",
	"Miaoli","Taichung","Changhua","Yunlin","Chiayi",
	"Tainan","Zuoying" };

char carClassName[3][12] = { "",
	"Standard","Class" };

struct Reservation
{
	char reservationNumber[12] = {}; // used to identify a reservation
	char trainNumber[8] = {};  // used to identify a train
	char idNumber[12] = {};    // the id number of the contact person
	char phone[12] = {};       // the (local or mobile) phone number of the contact person
	char date[12] = {};        // outbound date
	int originStation = {};      // the origin station code
	int destinationStation = 0; // the destination station code
	int carClass = 0;           // the car class code; 1:standard car, 2:business car
	int adultTickets = 0;       // the number of adult tickets
	int concessionTickets = 0;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8] = {};          // used to identify a train
	char departureTimes[13][8] = {}; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char input[120] = {};
	cin >> input;
	if (strlen(input) < 1 || strlen(input) > 2)
		return -1;
	int number = atoi(input);
	if (number<begin || number>end)
		return -1;
	else return number;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation; //����w����Ʃ�breservation
	int departureTime = 0; //����w���ɶ���btrain
	int snumTrain = 0, nnumTrain = 0;
	//��J�q���ƻP�]�w�X�o�ɶ�(�N���A�D�����ɶ�)
	inputReservationDetails(reservation, departureTime);
	loadSouthboundTimetable(southboundTimetable, snumTrain);
	loadNorthboundTimetable(northboundTimetable, nnumTrain);

	if (reservation.originStation < reservation.destinationStation) { //�n�U
		selectSouthboundTrain(southboundTimetable, snumTrain, reservation, departureTime);//������X�o�I�X�o�ɶ��̪񪺤Q�Z�C��
		//cout << "Trip Details\n\n";
		//display(reservation, southboundTimetable, station, carClassName[reservation.carClass]);
	}
	else if (reservation.originStation > reservation.destinationStation) { //�_�W
		selectNorthboundTrain(northboundTimetable, nnumTrain, reservation, departureTime);
		//cout << "Trip Details\n\n";
		//display(reservation, northboundTimetable, station, carClassName[reservation.carClass]);
	}
	inputContactInfo(reservation);
	saveReservation(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime) //ok
{
	int choice = 0;
	//�_�I
	cout << "\nOrigin Station\n";
	cout << "1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying";
	do {
		cout << "\n?";
	} while ((choice = inputAnInteger(1, 12)) == -1);
	cout << endl;
	reservation.originStation = choice;
	//���I
	cout << "\nDestination Station\n";
	cout << "1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying";
	do {
		cout << "\n?";
	} while ((choice = inputAnInteger(1, 12)) == -1);
	cout << endl;
	reservation.destinationStation = choice;
	//���b:�_�I���I�ۦP
	if (reservation.originStation == reservation.destinationStation) {
		cout << "Please remaking the reservation.\n";
		inputReservationDetails(reservation, departureTime);
	}
	//���[����
	cout << "\n\nCar Class\n";
	cout << "1. Standard Car\n2. Business Car";
	do cout << "\n?";
	while ((choice = inputAnInteger(1, 2)) == -1);
	cout << endl;
	//�����ѰӰȿ����������b�]�������s�^
	if (reservation.originStation == 1 && (reservation.destinationStation == 2 || reservation.destinationStation == 3) && reservation.carClass==2) {
		cout << "We don't have business car in this station.Please reinput your reservatioin.\n";
		inputReservationDetails(reservation, departureTime);
	}
	else if (reservation.originStation == 2 && reservation.destinationStation == 3 && reservation.carClass==2) {
		cout << "We don't have business car in this station.Please reinput your reservatioin.\n";
		inputReservationDetails(reservation, departureTime);
	}
	else {
		//�T�{�L�~��⨮�[��ܩ�J
		reservation.carClass = choice;
		//�H�K��J�Y�i
		cout << "\nDeparture Date: ";
		cin >> reservation.date;
		//�X�o�ɶ�
		cout << "\nDeparture Time\n";
		for (int i = 1; i <= 34; i++) {
			cout << right << setw(2) << i << ". " << departureTimes[i] << endl;
		}
		do cout << "\n?";
		while ((choice = inputAnInteger(1, 34)) == -1);
		cout << endl;
		departureTime = choice;
		//���H���ƻP�u�ݲ���
		cout << "\nHow many adult tickets? ";
		cin >> reservation.adultTickets;
		cout << "\nHow many concession tickets? ";
		cin >> reservation.concessionTickets;
		cout << endl;
	}
}

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) //����
{
	//numSouthboundTrains:�`�@�X�Z�C���A�]���O&-->���V�ק�ƭ�(�ϩI�sloadsou...�̪��ȧ���)
	//87�Z����
	//departureTimes�ݼg
	ifstream inFile1("Southbound timetable.txt", ios::in);
	if (!inFile1) {
		cout << "File(south) could not be opened" << endl;
		exit(1);
	}
	int i = 0;
	Train buffer;
	//�ݧ�
/*	while (inFile1 >> buffer.trainNumber) {
		strcpy_s(southboundTimetable[i].trainNumber, buffer.trainNumber);
		i++;
	}
	numSouthboundTrains = i; //�`�@���X�Z�C��
	*/
	int numstation = 0;
	while (inFile1.getline(southboundTimetable[i].trainNumber, ' ', '\n')) {
		while (inFile1.getline(southboundTimetable[i].departureTimes[numstation], ' ', '\n'))
			numstation++;
		//strcpy_s(southboundTimetable[i].trainNumber, buffer.trainNumber);
		i++;
	}
}

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) //�ݧ�
{
	//numNorthboundTrains:�`�@�X�Z�C��
	//�@92��-->92�Z����
	ifstream inFile2("Northbound timetable.txt", ios::in);
	if (!inFile2) {
		cout << "File(north) could not be opened" << endl;
		exit(1);
	}
	int i = 0;
	Train buffer;
	/*	while (inFile2 >> buffer.trainNumber) {
			strcpy_s(northboundTimetable[i].trainNumber, buffer.trainNumber);
			i++;
		}
		numNorthboundTrains = i;*/
	int numstation = 0;
	while (inFile2.getline(northboundTimetable[i].trainNumber, ' ', '\n')) {
		while (inFile2.getline(northboundTimetable[i].departureTimes[numstation], ' ', '\n'))
			numstation++;
		//strcpy_s(southboundTimetable[i].trainNumber, buffer.trainNumber);
		i++;
	}
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime) //�ݧ�
{
	cout << left << setw(6) << "Train" << right << setw(4) << "No." << right << setw(11) << "Departure" << right
		<< setw(9) << "Arrival\n";

	int j = 0;
	//�C�X�Q�Z�����@//����-->southboundTimetable
	for (int i = 0; i < numSouthboundTrains; i++) {
		for (int a = 0; a < 13; a++) {
			//�Y�ɶ����X�o�ɶ��P��ܪ��X�o�ɶ��ۦP�h��X����Q�Z����
			//�Ģ�Z����
			if (strcmp((char*)southboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) == 0)
				while (j < 10) { //�q��}�l���U�Ƣ�Z�]�@�Q�Z�^����
					cout << right << setw(10) << southboundTimetable[i + j].trainNumber[reservation.originStation] << right << setw(11) << southboundTimetable[i + j].departureTimes[reservation.originStation]
						<< right << setw(9) << southboundTimetable[i + j].departureTimes[reservation.destinationStation] << endl;
					j++;
				}
			if (j != 0)
				break;
		}
		if (j != 0)
			break;
	}
	cout << "Enter Train Number: ";
	cin >> reservation.trainNumber;
	cout << endl;
	cout << "Trip Details\n\n";
	display(reservation, southboundTimetable, station, carClassName[reservation.carClass]);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) //�ݧ�
{
	cout << left << setw(6) << "Train" << right << setw(4) << "No." << right << setw(11) << "Departure" << right
		<< setw(9) << "Arrival\n";

	int j = 0;
	//�C�X�Q�Z�C�� //����-->northboundTimetable
	for (int i = 0; i < numNorthboundTrains; i++) {
		for (int a = 0; a < 13; a++) {
			//�Y�ɶ����X�o�ɶ��P��ܪ��X�o�ɶ��ۦP�h��X����Q�Z����
			//�Ģ�Z����
			//�_�W�_�I�����篸
			if (strcmp((char*)northboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) == 0)
				while (j < 10) { //�q��}�l���U�Ƣ�Z�]�@�Q�Z�^����
					cout << right << setw(10) << northboundTimetable[i + j].trainNumber[reservation.originStation] << right << setw(11) << northboundTimetable[i + j].departureTimes[reservation.originStation]
						<< right << setw(9) << northboundTimetable[i + j].departureTimes[reservation.destinationStation] << endl;
					j++;
				}
			if (j != 0)
				break;
		}
		if (j != 0)
			break;
	}
	cout << "Enter Train Number: ";
	cin >> reservation.trainNumber;
	cout << endl;
	cout << "Trip Details\n\n";
	display(reservation, northboundTimetable, station, carClassName[reservation.carClass]);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "Enter Contact Person Information\nID Number: ";
	cin >> reservation.idNumber;
	cout << "\nPhone: ";
	cin >> reservation.phone;
	cout << "\nReservation Number: ";
	srand(time(NULL));
	int number = rand() % 10;
	for (int i = 0; i < 8; i++) {
		reservation.reservationNumber[i] = '9' - number;
		cout << reservation.reservationNumber[i];
		number = rand() % 10;
	}
	cout << "\n\nReservation Completed!\n\n";
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream outFile("Reservation details.dat", ios::out | ios::binary | ios::app);
	outFile.write((char*)&reservation, sizeof(Reservation));
	outFile.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	fstream ioFile("Reservation details.dat", ios::in | ios::out | ios::app);
	Reservation reservation;
	if (existReservation(ioFile, reservation)) {
		int choice;
		while (true)
		{
			cout << "\nEnter Your Choice\n"
				<< "1. Cancellation\n"
				<< "2. Reduce\n"
				<< "3. End";

			do cout << "\n? ";
			while ((choice = inputAnInteger(1, 3)) == -1);
			cout << endl;

			switch (choice)
			{
			case 1:
				//�R�����(erase)
				reservation.reservationNumber[0] = NULL;
				reservation.trainNumber[0] = NULL;
				reservation.idNumber[0] = NULL;
				reservation.phone[0] = NULL;
				reservation.date[0] = NULL;
				reservation.destinationStation = 0;
				reservation.originStation = 0;
				reservation.adultTickets = 0;
				reservation.concessionTickets = 0;
				reservation.carClass = 0;
				cout << "Reservation Cancelled!\n\n";
				return;
			case 2:
				reduceSeats(ioFile, southboundTimetable, northboundTimetable, reservation);
				break;
			case 3:
				return;
			default: // display error if user does not select valid choice
				cerr << "Incorrect Choice!\n";
				break;
			}
		}
	}
	else return;
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	char idNumber[120] = {};
	cout << "Enter ID Number: ";
	cin >> idNumber;
	cout << endl;
	char reservationNumber[120] = {};
	cout << "Enter Reservation Number: ";
	cin >> reservationNumber;

	Reservation buffer;

	while (ioFile.read((char*)&buffer, sizeof(Reservation))) {
		if (strcmp(idNumber, buffer.idNumber) == 0 && strcmp(reservationNumber, buffer.reservationNumber) == 0) {
			reservation = buffer;
			return true;
		}
	}
	cout << "not exist\n";
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	int snumTrain = 0, nnumTrain = 0;
	loadNorthboundTimetable(northboundTimetable, nnumTrain);
	loadSouthboundTimetable(southboundTimetable, snumTrain);
	cout << "Reservation Details\n\n";
	if (reservation.originStation < reservation.destinationStation) //�n�U
		display(reservation, southboundTimetable, station, carClassName[reservation.carClass]);
	else if (reservation.originStation > reservation.destinationStation) //�_�W
		display(reservation, northboundTimetable, station, carClassName[reservation.carClass]);

	cout << "You have successfully reduced the number of tickets!\n\n";
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	cout << right << setw(10) << "Date" << right << setw(12) << "Train No." << right << setw(9) << "From"
		<< right << setw(10) << "To" << right << setw(11) << "Departure" << right << setw(10) << "Arrival" << right << setw(8)
		<< "Adult" << right << setw(12) << "Concession" << right << setw(8) << "Fare" << right << setw(11) << "Class\n";
	//�ɶ��B���� �ݼg
	//�u�ݲ��������H�����@�b
	//���FŪ�ɡ]�ɶ����^�B�榡�@��L����
	int total = 0; //�`����
	if (reservation.carClass == 2) {//�Ӱȿ�
		total = adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets
			+ adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 * reservation.concessionTickets;
		cout << right << setw(10) << reservation.date << right << setw(12) << reservation.trainNumber << right << setw(9) << stations[reservation.originStation]
			<< right << setw(10) << station[reservation.destinationStation] << right << setw(11) << trainTimetable[reservation.originStation].departureTimes[reservation.originStation] << right << setw(10)
			<< trainTimetable[reservation.destinationStation].departureTimes[reservation.destinationStation] << right << setw(6)
			<< adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets << right << setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << "*" << reservation.concessionTickets << right << setw(8)
			<< total << right << setw(10) << carClass << endl << endl;
	}
	else if (reservation.carClass == 1) {//�g�ٿ�
		total = adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets
			+ adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 * reservation.concessionTickets;

		cout << right << setw(10) << reservation.date << right << setw(12) << reservation.trainNumber << right << setw(9) << stations[reservation.originStation]
			<< right << setw(10) << station[reservation.destinationStation] << right << setw(11) << trainTimetable[reservation.originStation].departureTimes[reservation.originStation] << right << setw(10)
			<< trainTimetable[reservation.destinationStation].departureTimes[reservation.destinationStation] << right << setw(6)
			<< adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets << right << setw(10) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << "*" << reservation.concessionTickets << right << setw(8)
			<< total << right << setw(10) << carClass << endl << endl;

	}
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	//�Y�����Ƥj��q�ʲ��� �h��������
	int num = 0;
	cout << "How many adult tickets to cancel?";
	cin >> num;
	if (reservation.adultTickets < num)
		reduceSeats(ioFile, southboundTimetable, northboundTimetable, reservation);
	else
		reservation.adultTickets = num;

	cout << "How many concession tickets to cancel�H";
	cin >> num;
	if (reservation.concessionTickets < num)
		reduceSeats(ioFile, southboundTimetable, northboundTimetable, reservation);
	else
		reservation.concessionTickets = num;

	if (reservation.adultTickets == 0 && reservation.concessionTickets == 0) {
		//�R�����(erase)
		reservation.reservationNumber[0] = NULL;
		reservation.trainNumber[0] = NULL;
		reservation.idNumber[0] = NULL;
		reservation.phone[0] = NULL;
		reservation.date[0] = NULL;
		reservation.destinationStation = 0;
		reservation.originStation = 0;
		reservation.adultTickets = 0;
		reservation.concessionTickets = 0;
		reservation.carClass = 0;
		cout << "Reservation Cancelled!\n\n";
	}
}
