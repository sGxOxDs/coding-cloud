#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

char stations[13][12] = { "","Nangang" ,"Taipei","Banqiao" ,"Taoyuan" ,
							  "Hsinch","Miaoli" ,"Taichung" ,"Changhua"
							 ,"Yunlin" ,"Chiayi","Tainan" ,"Zuoying" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

int inputAnInteger(int begin, int end)
{
	string input;
	int num;
	cin >> input;
	if (input.size() == 1)
	{
		num=input[0] - '0';

		if (begin <= num && num <= end || num == 0)
			return num;
		else
			return -1;
	}
	else if (input.size() == 2)
	{
		num = (input[0] - '0') * 10 + (input[1] - '0');

		if (num <= end)
			return num;
		else
			return -1;

	}
	else
	{
		return -1;
	}

}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;
	int departureTime;
	inputReservationDetails(reservation, departureTime);

	int numboundTrains;
	if (reservation.originStation < reservation.destinationStation)
	{
		loadSouthboundTimetable(southboundTimetable, numboundTrains);
		selectSouthboundTrain(southboundTimetable, numboundTrains, reservation, departureTime);
	}
	else
	{
		loadNorthboundTimetable(northboundTimetable, numboundTrains);
		selectNorthboundTrain(northboundTimetable, numboundTrains, reservation, departureTime);
	}

	inputContactInfo(reservation);
	saveReservation(reservation);
}

void reservationHistory(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation = {};
	fstream Read;
	do
	{
		cout << "Reservation record not found." << endl << endl;

	} while (!existReservation(Read, reservation));
	

		


}

bool existReservation(fstream& ioFile, Reservation& reservation)
{
	ioFile.open("Reservation details.dat");
	if (!ioFile)
	{
		cout << "The file could not be opened." << endl;
		exit(1);
	}

	ioFile.seekg(0, ios::end);
	int linenum = ioFile.tellg() / sizeof(Reservation);
	ioFile.seekg(0, ios::beg);

	Reservation temp[10] = {};
	for (int i = 0; i < linenum; i++)
	{
		ioFile.read(reinterpret_cast<char*>(&temp[i]), sizeof(Reservation));
	}

	cout << "Enter ID Number : ";
	cin >> reservation.idNumber;
	cout << "Enter Reservation Number : ";
	cin >> reservation.reservationNumber;

	bool pass = true;
	for (int q = 0; q < 10; q++)
	{
		for (int p = 0; p < 12; p++)
		{
			pass = true;
			if (reservation.idNumber[p] != temp[q].idNumber[p])
			{
				pass = false;
				break;
			}

			if (pass)
			{
				for (int k = 0; k < 12; k++)
				{
					if (reservation.reservationNumber[k] != temp[q].idNumber[k])
					{
						pass = false;
						break;
					}
				}
				if (pass)
				{
					reservation = temp[q];
					return true;
				}
				
			}
		}
	}
	return false;
}



void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	while (true)
	{
		cout << "Origin Station" << endl
			<< "1. Nangang" << endl
			<< "2. Taipei" << endl
			<< "3. Banqiao" << endl
			<< "4. Taoyuan" << endl
			<< "5. Hsinchu" << endl
			<< "6. Miaoli" << endl
			<< "7. Taichung" << endl
			<< "8. Changhua" << endl
			<< "9. Yunlin" << endl
			<< "10. Chiayi" << endl
			<< "11. Tainan" << endl
			<< "12. Zuoying" << endl;

		do
			cout << "your choice:";
		while (reservation.originStation = inputAnInteger(1, 12) == -1);
		cout << endl;

		cout << "Destination Station" << endl
			<< "1. Nangang" << endl
			<< "2. Taipei" << endl
			<< "3. Banqiao" << endl
			<< "4. Taoyuan" << endl
			<< "5. Hsinchu" << endl
			<< "6. Miaoli" << endl
			<< "7. Taichung" << endl
			<< "8. Changhua" << endl
			<< "9. Yunlin" << endl
			<< "10. Chiayi" << endl
			<< "11. Tainan" << endl
			<< "12. Zuoying" << endl;
		do
			cout << "your choice:";
		while (reservation.destinationStation = inputAnInteger(1, 12) == -1);
		cout << endl;

		if (reservation.originStation != reservation.destinationStation)
			break;
	}
	

	cout << "Car Class" << endl
		<< "1. Standard Car" << endl
		<< "2. Business Car" << endl;
	while (true)
	{
		do
			cout << "your choice:";
		while (reservation.carClass = inputAnInteger(1, 2) == -1);
		cout << endl;
		if (reservation.carClass == 2)
		{
			int tempO = reservation.originStation;
			int tempD = reservation.destinationStation;

			if (!(tempO == 1 && tempD == 2 || tempO == 1 && tempD == 3 || tempO == 2 && tempD == 1))
				break;
			
		}
		else
		{
			break;
		}
	}
	
	
	cout << "Departure Date: ";
	cin >> reservation.date;
	cout << endl;

	cout << "Departure Time" << endl;
	for(int i=1;i<37;i++)
	{
		cout << i << ". " << departureTimes[i] << endl;
	}
	do
		cout << "your choice:";
	while (departureTime = inputAnInteger(1, 34) == -1);
	cout << endl;

	while (true)
	{
		cout << "How many adult tickets? ";
		cin >> reservation.adultTickets;
		cout << endl;

		cout << "How many concession tickets? ";
		cin >> reservation.concessionTickets;
		cout << endl;

		if (!(reservation.adultTickets == 0 && reservation.concessionTickets == 0))
			break;
	}
}



void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inFile("Southbound timetable.txt");
	if (!inFile)
	{
		cout << "The filecould not be opened." << endl;
		exit(1);
	}

	inFile.seekg(0, ios::end);
	int linenum = inFile.tellg() / sizeof(Train);
	inFile.seekg(0, ios::beg);

	for (numSouthboundTrains = 1; numSouthboundTrains <= linenum; numSouthboundTrains++)
	{
		inFile.read(reinterpret_cast<char*>(&southboundTimetable[numSouthboundTrains]), sizeof(Train));
	}
	numSouthboundTrains--;
	inFile.close();
}

void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains, Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival" << endl;
	Train temp[10];
	bool pass = true;
	int i = 1, p = 0;//�u�O���q���L�N�q�ܼƦӤw
	
	while( i <= numSouthboundTrains)
	{
		pass = true;
		p = 0;
		while(p < 8)
		{
			if (southboundTimetable[i].departureTimes[reservation.originStation][p]-'0' < departureTimes[departureTime][p]-'0')
			{
				pass = false;
				break;
			}
			else if (southboundTimetable[i].departureTimes[reservation.originStation][p] - '0' > departureTimes[departureTime][p] - '0')
			{
				break;
			}
				
			p++;
		}
		if (pass)
			break;
		i++;
		
	}
	for (i; i < i+10; i++)
	{
		
		cout<<setw(9)<<right<<southboundTimetable[i].trainNumber;
		cout << setw(11) << right << southboundTimetable[i].departureTimes[reservation.originStation];
		cout << setw(9) << right << southboundTimetable[i].departureTimes[reservation.destinationStation] << endl << endl;
		
	}
	cout << "Enter Train Number: ";
	cin >> reservation.trainNumber;
	cout << endl;

	cout << "Trip Details:" << endl << endl;

	char CARclass[12] = {};
	if (reservation.carClass == 1)
	{
		string temp = "Standard";
		for (int q = 0; q < temp.size(); q++)
		{
			CARclass[q] = temp[q];
		}
		
	}
	else
	{
		string temp = "Business";
		for (int q = 0; q < temp.size(); q++)
		{
			CARclass[q] = temp[q];
		}
		 
	}
	
	display(reservation, southboundTimetable,stations,CARclass);

}


void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inFile("Southbound timetable.txt");
	if (!inFile)
	{
		cout << "The filecould not be opened." << endl;
		exit(1);
	}

	inFile.seekg(0, ios::end);
	int linenum = inFile.tellg() / sizeof(Train);
	inFile.seekg(0, ios::beg);

	for (numNorthboundTrains = 1; numNorthboundTrains <= linenum; numNorthboundTrains++)
	{
		inFile.read(reinterpret_cast<char*>(&northboundTimetable[numNorthboundTrains]), sizeof(Train));
	}
	numNorthboundTrains--;
	inFile.close();
}

void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival" << endl;
	Train temp[10];
	bool pass = true;
	int i = 1, p = 0;//�u�O���q���L�N�q�ܼƦӤw

	while (i <= numNorthboundTrains)
	{
		pass = true;
		p = 0;
		while (p < 8)
		{
			if (northboundTimetable[i].departureTimes[reservation.originStation][p] - '0' < departureTimes[departureTime][p] - '0')
			{
				pass = false;
				break;
			}
			else if (northboundTimetable[i].departureTimes[reservation.originStation][p] - '0' > departureTimes[departureTime][p] - '0')
			{
				break;
			}

			p++;
		}
		if (pass)
			break;
		i++;

	}
	for (i; i < i + 10; i++)
	{

		cout << setw(9) << right << northboundTimetable[i].trainNumber;
		cout << setw(11) << right << northboundTimetable[i].departureTimes[reservation.originStation];
		cout << setw(9) << right << northboundTimetable[i].departureTimes[reservation.destinationStation] << endl << endl;

	}
	cout << "Enter Train Number: ";
	cin >> reservation.trainNumber;
	cout << endl;

	cout << "Trip Details:" << endl << endl;

	char CARclass[12] = {};
	if (reservation.carClass == 1)
	{
		string temp = "Standard";
		for (int q = 0; q < temp.size(); q++)
		{
			CARclass[q] = temp[q];
		}

	}
	else
	{
		string temp = "Business";
		for (int q = 0; q < temp.size(); q++)
		{
			CARclass[q] = temp[q];
		}

	}
	
	display(reservation, northboundTimetable, stations, CARclass);
}



void display(Reservation reservation, Train trainTimetable[100], char stations[13][12], char carClass[12])
{
	cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
	cout << setw(10) << right << reservation.date
		<< setw(11) << right << reservation.trainNumber
		<< setw(8) << right << stations[reservation.originStation]
		<< setw(10) << right << stations[reservation.destinationStation];

	bool pass=true;
	int count = 0;
	for (int i = 1; i < 100; i++)
	{
		pass = true;
		for (int q = 0; q < 8; q++)
		{
			if (reservation.trainNumber[q] != trainTimetable[i].trainNumber[q])
			{
				pass = false;
				break;
			}
				
		}
		if (pass)
		{
			count = i;
			break;
		}
	}
	cout << setw(11) << right << trainTimetable[count].departureTimes[reservation.originStation]
		<< setw(9) << right << trainTimetable[count].departureTimes[reservation.destinationStation];
	if (reservation.carClass == 1)
	{
		if (reservation.originStation > reservation.destinationStation)
		{
			cout << setw(8) << right << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets;
			cout<<setw(12)<<right<< adultTicketPrice[reservation.originStation][reservation.destinationStation]/2 << "*" << reservation.concessionTickets;

			int fare = adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets
				+ (adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) * reservation.concessionTickets;

			cout << setw(6) << right << fare;
		}
		else
		{
			cout << setw(8) << right << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets;
			cout << setw(12) << right << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << "*" << reservation.concessionTickets;

			int fare = adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets
				+ (adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2) * reservation.concessionTickets;

			cout << setw(6) << right << fare;
		}
		
	}
	else
	{
		if (reservation.originStation > reservation.destinationStation)
		{
			cout << setw(8) << right << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets;
			cout << setw(12) << right << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << "*" << reservation.concessionTickets;

			int fare = adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets
				+ (adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2) * reservation.concessionTickets;

			cout << setw(6) << right << fare;
		}
		else
		{
			cout << setw(8) << right << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets;
			cout << setw(12) << right << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << "*" << reservation.concessionTickets;

			int fare = adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets
				+ (adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) * reservation.concessionTickets;

			cout << setw(6) << right << fare;
		}
	}

	cout << setw(10) << right << carClass << endl << endl;
		
}


void inputContactInfo(Reservation& reservation)
{
	cout << "Enter Contact Person Information " << endl << endl;

	cout << "ID Number: ";
	cin >> reservation.idNumber;
	cout << endl << endl;

	cout << "Phone: ";
	cin >> reservation.phone;
	cout << endl << endl;

	cout << "Reservation Number: ";

	int count=0,mult = 0,temp=0,num= rand()*rand();
	while (count < 8)
	{
		temp = num % 10;
		mult = num / 10;
		reservation.reservationNumber[count] = temp + '0';
	}
	cout << reservation.reservationNumber;
	cout << endl << endl;

	cout << "Reservation Completed!" << endl << endl;

}

void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation)
{

}

void saveReservation(Reservation reservation)
{
	ofstream outFile("Reservation details.dat", ios::out | ios::binary | ios::app);
	if (!outFile)
	{
		cout << "The file could not be opened." << endl;
		exit(1);
	}

	outFile.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
	outFile.close();
}

