#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include<string>
#include<vector>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice
   
   
   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main
// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	string integer;
	cin >> integer;
	if (integer[0] >= begin + 48 && integer[0] <= end + 48 && integer.size() == 1)
	{
		return integer[0] - 48;
	}
	else if (integer.size() == 2 && (integer[0] - 48) * 10 + integer[1]-48>= begin /*+ 48 */&& (integer[0] - 48) * 10 + integer[1]-48 <= end /*+ 48*/)
	{
		return (integer[0] - 48) * 10 + integer[1] - 48;
	}
	else
	{
		return -1;
	}
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;
	int departureTime=0, numSouthboundTrains=0, numNorthboundTrains=0;

	loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
	loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
	
	inputReservationDetails(reservation, departureTime);
	if (reservation.originStation < reservation.destinationStation)
	{
		loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
		cout << southboundTimetable[0].trainNumber;
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
	}
	if (reservation.originStation > reservation.destinationStation)
	{
		loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);
	}
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	int choice1 = 0, choice2 = 0,choice3=0,choice4=0,adult=0, concession=0;
	char date[12] = {};
	cout << "Origin Station" << endl << "1. Nangang" << endl
		<< "2. Taipei" << endl << "3. Banqiao" << endl
		<< "4. Taoyuan" << endl << "5. Hsinchu" << endl << "6. Miaoli"
		<< endl << "7. Taichung" << endl << "8. Changhua" << endl << "9. Yunlin" << endl
		<< "10. Chiayi" << endl << "11. Tainan" << endl << "12. Zuoying" << endl;
	do
	{
		cout << '?';
		choice1 = inputAnInteger(1, 12);
	}while (choice1 == -1);
	
	cout << "Destination Station" << endl << "1. Nangang" << endl
		<< "2. Taipei" << endl << "3. Banqiao" << endl
		<< "4. Taoyuan" << endl << "5. Hsinchu" << endl << "6. Miaoli"
		<< endl << "7. Taichung" << endl << "8. Changhua" << endl << "9. Yunlin" << endl
		<< "10. Chiayi" << endl << "11. Tainan" << endl << "12. Zuoying" << endl;
	do
	{
		cout << '?';
		choice2 = inputAnInteger(1, 12);
	}while (choice2 == -1);
	
	cout << "Car Class" << endl << "1. Standard Car" << endl << "2. Business Car"<<endl;

	do
	{
		cout << '?';
		choice3 = inputAnInteger(1, 2);
	} while (choice3  == -1);
	
		cout << "Departure Date: ";
		cin >> date;
		cout << endl << "Departure Time" << endl;
		for(int i = 1; i < 35; i++)
		{
			if (i < 10)
			{
				cout <<" "<<i << '.' << departureTimes[i] << endl;
			}
			else
			{
				cout << i << '.' << departureTimes[i] << endl;
			}
		   
		}
    do
	{
		cout << '?';
		choice4 = inputAnInteger(1, 34);
	} while ((choice4  == -1));

	//departureTime= choice4

	cout << "How many adult tickets?" ;
	cin >> adult;
	cout << endl << endl << "How many concession tickets?";
	cin >> concession;

	reservation.originStation = choice1;
	reservation.destinationStation = choice2;
	reservation.carClass = choice3;
	reservation.adultTickets = adult;
	reservation.concessionTickets = concession;
	strcpy_s(reservation.date, date);

	
}

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inFile("Southbound timetable.txt", ios::in|ios::binary);
	if (!inFile)
	{
		ofstream outFile("Southbound timetable.txt", ios::out | ios::binary);
		outFile.close();
	}
	else
	{
		inFile.seekg(0, ios::end);
		int end = inFile.tellg();

		inFile.seekg(0, ios::beg);
		int beg = inFile.tellg();

		int times = (end - beg) / sizeof(Train);
		for (int i = 1; i <= times; i++)
		{
			inFile.read(reinterpret_cast<char*>(southboundTimetable[i].trainNumber), sizeof(southboundTimetable[i].trainNumber));
			inFile.read(reinterpret_cast<char*>(southboundTimetable[i].departureTimes), sizeof(southboundTimetable[i].departureTimes));
		}

		inFile.close();
	}
	
}

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inFile("Northbound timetable.txt", ios::in | ios::binary);
	if (!inFile)
	{
		ofstream outFile("Northbound timetable.txt", ios::out | ios::binary);
		outFile.close();
	}
	else
	{
		inFile.seekg(0, ios::end);
		int end = inFile.tellg();

		inFile.seekg(0, ios::beg);
		int beg = inFile.tellg();

		int times = (end - beg) / sizeof(Train);
		for (int i = 1; i <= times; i++)
		{
			inFile.read(reinterpret_cast<char*>(northboundTimetable[i].trainNumber), sizeof(northboundTimetable[i].trainNumber));
			inFile.read(reinterpret_cast<char*>(northboundTimetable[i].departureTimes), sizeof(northboundTimetable[i].departureTimes));
		}

		inFile.close();
	}

}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	char stations[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli"
							  ,"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying"
	};
	char trainNumber = {};
	char carClass[12] = {};
	cout << "Train No.  Departure  Arrival" << endl;
	for (int i = 1; i <= 8; i++)
	{
		cout << right << setw(9) << southboundTimetable[i].trainNumber << right << setw(9) << southboundTimetable[i].departureTimes
			<< right << setw(7) << " ";
	}
	cout << "Enter Train Number: ";
	cin >> trainNumber;
	cout << endl << endl << "Trip Details" << endl;
	display(reservation, southboundTimetable, stations, carClass);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	char stations[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli"
							  ,"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying"
	};

	
	char trainNumber = {};
	char carClass[12] = {};
	cout << "Train No.  Departure  Arrival" << endl;
	for (int i = 1;i<=8;i++)
	{
		cout << right << setw(9) << northboundTimetable[i].trainNumber << right << setw(9) << northboundTimetable[i].departureTimes
		<< right << setw(7) << " ";
	}
	cout << "Enter Train Number: ";
	cin >> trainNumber;
	cout << endl << endl << "Trip Details" << endl;
	display(reservation, northboundTimetable, stations,carClass);
	
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	char idnumber[12] = {};
	char phone[12] = {};
	char reservationNumber[12] = {};
	cout << "Enter Contact Person Information" << endl;
	cout << "ID Number:";
	cin >> idnumber;
	cout << endl << "Phone:" << endl;
	cin >> phone;
	cout << endl << "Reservation Number: " << endl;
	cin >> reservationNumber;
	cout << endl << "Reservation Completed!";

	strcpy_s(reservation.idNumber, idnumber);
	strcpy_s(reservation.phone, phone);
	strcpy_s(reservation.reservationNumber, reservationNumber);

}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream outFile("Reservation details.dat", ios::out | ios::binary);
	
	outFile.write(reinterpret_cast<char*>(reservation.reservationNumber), sizeof(reservation.reservationNumber));
	outFile.write(reinterpret_cast<char*>(reservation.trainNumber), sizeof(reservation.trainNumber));
	outFile.write(reinterpret_cast<char*>(reservation.idNumber), sizeof(reservation.idNumber));
	outFile.write(reinterpret_cast<char*>(reservation.phone), sizeof(reservation.phone));
	outFile.write(reinterpret_cast<char*>(reservation.date), sizeof(reservation.date));
	outFile.write(reinterpret_cast<char*>(reservation.originStation), sizeof(reservation.originStation));
	outFile.write(reinterpret_cast<char*>(reservation.destinationStation), sizeof(reservation.destinationStation));
	outFile.write(reinterpret_cast<char*>(reservation.carClass), sizeof(reservation.carClass));
	outFile.write(reinterpret_cast<char*>(reservation.adultTickets), sizeof(reservation.adultTickets));
	outFile.write(reinterpret_cast<char*>(reservation.concessionTickets), sizeof(reservation.concessionTickets));
	
	outFile.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	fstream file("Reservation details.dat", ios::in | ios::binary);
	Reservation temp;
	existReservation(file,temp);
	displayReservations(southboundTimetable, northboundTimetable, temp);
	int choice = 0;
	cout << "Enter Your Choice" << endl;
	cout << "1. Cancellation" << endl << "2. Reduce" << endl << "3. End"<<endl;
	do
	{
		cout << '?';
		choice = inputAnInteger(1, 3);
	} while (choice == -1);
	switch (choice)
	{
	case 1:
		cout << "Reservation Cancelled!" << endl;

	case 2:
		reduceSeats(file, southboundTimetable, northboundTimetable, temp);

	case 3:
		saveReservation(temp);
	}

}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	char idnumber[12] = {};
	char ReservationNumber[12] = {};
	cout << "Enter ID Number: ";
	cin >> idnumber;
	cout << endl << endl << "Enter Reservation Number: " << endl;
	cin >> ReservationNumber;
	if (strcmp(reservation.idNumber, idnumber) == 0)
	{
		if (strcmp(reservation.reservationNumber, ReservationNumber) == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}


}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	char stations[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli"
							  ,"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying"
	};
	cout << " Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
	cout << right << setw(10) << reservation.date << right << setw(9) << reservation.trainNumber << right << setw(8)
		<< stations[reservation.originStation] << right << setw(10) << stations[reservation.destinationStation] <<
		right << setw(11) << trainTimetable[i].departureTimes<<right<<setw(9)<<<<right<<setw(12)
		<< adultTicketPrice[] <<'*'<< reservation.adultTickets<<right<<setw(12)<< adultTicketPrice <<'*'<<reservation.concessionTickets
	
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	cout << "Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
	cout << right << setw(10) << reservation.date << right << setw(9) << reservation.trainNumber << right << setw(8)
		<< stations[reservation.originStation] << right << setw(10) << stations[reservation.destinationStation] <<
		right << setw(11) << trainTimetable[1].departureTimes<<right<<setw(9)<< " " <<right<<setw(12)
		<< adultTicketPrice[1] <<'*'<< reservation.adultTickets<<right<<setw(12)<< adultTicketPrice <<'*'<<reservation.concessionTickets
	


}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int adult = 0, concession=0;
	cout << "How many adult tickets to cancel�H";
	cin >> adult;
	cout << "How many concession tickets to cancel�H";
	cin >> concession;
	reservation.adultTickets -= adult;
	reservation.concessionTickets-= concession;
	displayReservations(southboundTimetable, northboundTimetable,reservation);
	cout << endl << "You have successfully reduced the number of tickets! ";
}
