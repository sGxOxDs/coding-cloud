#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

int inputAnInteger(int begin, int end)
{
	int a;

	cin >> a;

	if (a <= end && a >= begin)
	{
		return a;
	}

	else
	{
		return -1;
	}
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	int numS, numN, depTime;

	Reservation reservation;

	loadSouthboundTimetable(southboundTimetable, numS);

	loadNorthboundTimetable(northboundTimetable, numN);
	
	inputReservationDetails(reservation, depTime);

	if (reservation.originStation > reservation.destinationStation)
	{
		selectNorthboundTrain(northboundTimetable, numN, reservation, depTime);
	}

	if (reservation.originStation < reservation.destinationStation)
	{
		selectSouthboundTrain(southboundTimetable, numS, reservation, depTime);
	}
	
	inputContactInfo(reservation);

	cout << "Reservation Completed!" << endl;

	saveReservation(reservation);
	
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	int start;
	do
	{
		cout << "Origin Station" << endl;
		cout << "1. Nangang" << endl;
		cout << "2. Taipei" << endl;
		cout << "3. Banqiao" << endl;
		cout << "4. Taoyuan" << endl;
		cout << "5. Hsinchu" << endl;
		cout << "6. Miaoli" << endl;
		cout << "7. Taichung" << endl;
		cout << "8. Changhua" << endl;
		cout << "9. Yunlin" << endl;
		cout << "10. Chiayi" << endl;
		cout << "11. Tainan" << endl;
		cout << "12. Zuoying" << endl;
	} while (start = inputAnInteger(1, 12) == -1);
	
	int end;

	do
	{
		cout << "Origin Station" << endl;
		cout << "1. Nangang" << endl;
		cout << "2. Taipei" << endl;
		cout << "3. Banqiao" << endl;
		cout << "4. Taoyuan" << endl;
		cout << "5. Hsinchu" << endl;
		cout << "6. Miaoli" << endl;
		cout << "7. Taichung" << endl;
		cout << "8. Changhua" << endl;
		cout << "9. Yunlin" << endl;
		cout << "10. Chiayi" << endl;
		cout << "11. Tainan" << endl;
		cout << "12. Zuoying" << endl;
	} while (end = inputAnInteger(1, 12) == -1);

	if (start == end)
	{
		cout << "not choose the same station" << endl;
		do
		{
			cout << "Origin Station" << endl;
			cout << "1. Nangang" << endl;
			cout << "2. Taipei" << endl;
			cout << "3. Banqiao" << endl;
			cout << "4. Taoyuan" << endl;
			cout << "5. Hsinchu" << endl;
			cout << "6. Miaoli" << endl;
			cout << "7. Taichung" << endl;
			cout << "8. Changhua" << endl;
			cout << "9. Yunlin" << endl;
			cout << "10. Chiayi" << endl;
			cout << "11. Tainan" << endl;
			cout << "12. Zuoying" << endl;
		} while (end = inputAnInteger(1, 12) == -1);
	}

	int carClass;

	do
	{
		cout << "Car Class" << endl;
		cout << "1. Standard Car" << endl;
		cout << "2. Business Car" << endl;
	} while (carClass = inputAnInteger(1, 12) == -1);

	char depDate[12];

	cout << "Departure Date:";

	cin >> depDate;

	cout << endl;

	do
	{
		cout << "Departure Time" << endl;
		for (int i = 1; i < 37; i++)
		{
			cout << i << "." << departureTimes[i] << endl;
		}
		
	} while (departureTime = inputAnInteger(1, 34) == -1);

	int adT, coT;
	cout << "How many adult tickets" << endl;
	cin >> adT;
	cout << "How many concession tickets" << endl;
	cin >> coT;

	reservation.originStation = start;
	reservation.destinationStation = end;
	reservation.carClass = carClass;
	for (int i = 0; i < 12; i++)
	{
		reservation.date[i] = depDate[i];
	}
	reservation.adultTickets = adT;
	reservation.concessionTickets = coT;
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inFile("Southbound timetable.txt", ios::in );

	numSouthboundTrains = 0;
		 
	for (int i = 1; i < 88; i++)
	{
		inFile.getline(southboundTimetable[i].trainNumber, ' ');

		for (int j = 1; j < 13; j++)
		{
			inFile.getline(southboundTimetable[i].departureTimes[j], ' ');
		}
		numSouthboundTrains++;
	}

	inFile.close();
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inFile("Northbound timetable.txt", ios::in);

	numNorthboundTrains = 0;

	for (int i = 1; i < 94; i++)
	{
		inFile.getline(northboundTimetable[i].trainNumber, ' ');

		for (int j = 1; j < 13; j++)
		{
			inFile.getline(northboundTimetable[i].departureTimes[j], ' ');
		}
		numNorthboundTrains++;
	}

	inFile.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,Reservation& reservation, int departureTime)
{
	int time = 0;

	cout << "Train No.Departure  Arrival" << endl;
	
	for (int i = 0; i < numSouthboundTrains; i++)
	{
		if (southboundTimetable[i].departureTimes[reservation.originStation] > departureTimes[departureTime])
		{
			time++;

			cout << southboundTimetable[i].trainNumber << southboundTimetable[i].departureTimes[reservation.originStation] <<endl;			
		}

		if (time == 10)
		{
			break;
		}
	}

	cout << "Enter Train Number: ";

	int sele;

	cin >> sele;

	cout << endl;

	char carClass[12];

	if (reservation.carClass == 1)
	{
		carClass[0] = 1;
	}

	else if (reservation.carClass == 2)
	{
		carClass[0] = 2;
	}

	char stations[13][12] = { "",
		"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };

	display(reservation, southboundTimetable, stations, carClass);

}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, Reservation& reservation, int departureTime)
{
	int time = 0;

	cout << "Train No.Departure  Arrival" << endl;

	for (int i = 0; i < numNorthboundTrains; i++)
	{
		if (northboundTimetable[i].departureTimes[reservation.originStation] > departureTimes[departureTime])
		{
			time++;

			cout << northboundTimetable[i].trainNumber << northboundTimetable[i].departureTimes[reservation.originStation] << endl;
		}

		if (time == 10)
		{
			break;
		}
	}

	cout << "Enter Train Number: ";

	int sele;

	cin >> sele;

	cout << endl;

	char carClass[12];

	if (reservation.carClass == 1)
	{
		carClass[0] = 1;
	}

	else if (reservation.carClass == 2)
	{
		carClass[0] = 2;
	}

	char stations[13][12] = { "",
		"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };

	display(reservation, northboundTimetable, stations, carClass);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	char id[12], ph[12];
		
	cout << "idNumber: ";

	cin >> id;

	cout << "\nphone: ";

	cin >> ph;

	strcpy_s(reservation.idNumber, id);
	strcpy_s(reservation.phone, ph);

	for (int i = 0; i < 12; i++)
	{
		reservation.reservationNumber[i] = '\n';
	}

	cout << "Reservation Number: ";

	for (int i = 0; i < 8; i++)
	{
		reservation.reservationNumber[i] = (rand() % 10);

		cout << reservation.reservationNumber[i];
	}

	cout << endl;
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream outFile("Reservation details.dat", ios::app);

	outFile.write(reinterpret_cast<const char*>(&reservation.reservationNumber), sizeof(reservation.reservationNumber));
	outFile.write(reinterpret_cast<const char*>(&reservation.trainNumber), sizeof(reservation.trainNumber));
	outFile.write(reinterpret_cast<const char*>(&reservation.idNumber), sizeof(reservation.idNumber));
	outFile.write(reinterpret_cast<const char*>(&reservation.phone), sizeof(reservation.phone));
	outFile.write(reinterpret_cast<const char*>(&reservation.date), sizeof(reservation.date));
	outFile.write(reinterpret_cast<const char*>(reservation.originStation), sizeof(reservation.originStation));
	outFile.write(reinterpret_cast<const char*>(&reservation.destinationStation), sizeof(reservation.destinationStation));
	outFile.write(reinterpret_cast<const char*>(&reservation.carClass), sizeof(reservation.carClass));
	outFile.write(reinterpret_cast<const char*>(&reservation.adultTickets), sizeof(reservation.adultTickets));
	outFile.write(reinterpret_cast<const char*>(&reservation.concessionTickets), sizeof(reservation.concessionTickets));

	outFile.close();
}

void reservationHistory(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;

	fstream inFile("Reservation details.dat", ios::in | ios::binary);

	if (existReservation(inFile,reservation) == true)
	{
		displayReservations(southboundTimetable, northboundTimetable, reservation);
	}

	int choice;

	while (true)
	{
		do
		{
			cout << "\nEnter Your Choice\n"
				<< "1. Cancellation\n"
				<< "2. Reduce\n"
				<< "3. End";
		} while (choice = inputAnInteger(1, 3) == -1);

		switch (choice)
		{
		case 1:
			reservation.reservationNumber[0]={'\n' };
			reservation.trainNumber[0] = { '\n' };
			reservation.idNumber[0] = { '\n' };
			reservation.phone[0] = { '\n' };
			reservation.date[0] = { '\n' };
			reservation.originStation = '\n';
			reservation.destinationStation = '\n';
			reservation.carClass = '\n';
			reservation.adultTickets = '\n';
			reservation.concessionTickets = '\n';
			cout <<"Reservation Cancelled!" << endl;
			saveReservation(reservation);
			break;
		case 2:
			reduceSeats(inFile, southboundTimetable, northboundTimetable, reservation);
			break;
		case 3:			
			return;
		default: 
			cerr << "Incorrect Choice!\n";
			break;
		}
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{	
	char id[12], res[12];

	while (!ioFile.eof())
	{
		ioFile.read(reinterpret_cast<char*>(&reservation.reservationNumber), sizeof(reservation.reservationNumber));
		ioFile.read(reinterpret_cast<char*>(&reservation.trainNumber), sizeof(reservation.trainNumber));
		ioFile.read(reinterpret_cast<char*>(&reservation.idNumber), sizeof(reservation.idNumber));
		ioFile.read(reinterpret_cast<char*>(&reservation.phone), sizeof(reservation.phone));
		ioFile.read(reinterpret_cast<char*>(&reservation.date), sizeof(reservation.date));
		ioFile.read(reinterpret_cast<char*>(reservation.originStation), sizeof(reservation.originStation));
		ioFile.read(reinterpret_cast<char*>(&reservation.destinationStation), sizeof(reservation.destinationStation));
		ioFile.read(reinterpret_cast<char*>(&reservation.carClass), sizeof(reservation.carClass));
		ioFile.read(reinterpret_cast<char*>(&reservation.adultTickets), sizeof(reservation.adultTickets));
		ioFile.read(reinterpret_cast<char*>(&reservation.concessionTickets), sizeof(reservation.concessionTickets));

		cout << "idNumber: ";

		cin >> id;

		cout << "\nreservationNumber: ";

		cin >> res;

		if (strcmp(res, reservation.reservationNumber) == 0)
		{
			if (strcmp(id, reservation.idNumber) == 0)
			{
				return true;
			}

			else
			{
				return false;
			}
		}
		return false;
	}	
}


void displayReservations(Train southboundTimetable[100], Train northboundTimetable[100], Reservation reservation)
{
	int numS, numN;

	loadNorthboundTimetable(northboundTimetable, numN);

	loadSouthboundTimetable(southboundTimetable, numS);

	char carClass[12];

	if (reservation.carClass == 1)
	{
		carClass[0] = 1;
	}

	else if (reservation.carClass == 2)
	{
		carClass[0] = 2;
	}

	char stations[13][12] = { "",
		"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };

	if (reservation.originStation > reservation.destinationStation)
	{
		display(reservation, northboundTimetable, stations, carClass);
	}

	if (reservation.originStation < reservation.destinationStation)
	{
		display(reservation, southboundTimetable, stations, carClass);
	}

}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100], char stations[13][12], char carClass[12])
{
	cout << "Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;
	if (carClass[0] == 2)
	{
		cout << reservation.date << reservation.trainNumber << stations[reservation.originStation]
			<< stations[reservation.destinationStation] << "departureTime" << "arrival time"
			<< adultTicketPrice[reservation.originStation][reservation.destinationStation] << " * " << reservation.adultTickets
			<< adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << " * " << reservation.concessionTickets
			<< (adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets) + (adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 * reservation.concessionTickets)
			<< "Business" << endl;
	}
	if (carClass[0] == 1)
	{
		cout << reservation.date << reservation.trainNumber << stations[reservation.originStation]
			<< stations[reservation.destinationStation] << "departureTime" << "arrival time"
			<< adultTicketPrice[reservation.destinationStation][reservation.originStation] << " * " << reservation.adultTickets
			<< adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << " * " << reservation.concessionTickets
			<< (adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets) + (adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 * reservation.concessionTickets)
			<< "Standard" << endl;
	}
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation)
{
	cout << "How many adult tickets to cancel�H";
	int ad;
	cin >> ad;
	cout << endl;

	cout << "How many concession tickets to cancel�H";
	int con;
	cin >> con;
	cout << endl;

	reservation.adultTickets -= ad;

	reservation.concessionTickets -= con;

	displayReservations(southboundTimetable, northboundTimetable, reservation);

	cout << "You have successfully reduced the number of tickets!" << endl;

}