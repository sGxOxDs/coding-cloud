#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main
int inputAnInteger(int begin, int end)
{
	string choice;
	cin >> choice;
	if (choice.size() == 2)
	{
		int a = (choice[0] - '0') * 10 + (choice[1] - '0');
		if (a >= begin && a <= end)
			return a;
		else
			return -1;
	}
	else if (choice.size() == 1)
	{
		if (choice[0] + '0' >= begin && choice[0] + '0' <= end)
			return choice[0] - '0';
		else
			return -1;
	}
	return -1;
}
void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	inputContactInfo(reservation);
	selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
	selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);
	loadNorthboundTimetable(northboundTimetable);
	loadSouthboundTimetable(southboundTimetable);


	saveReservation(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	int choice;
	Reservation user;
	Train departureTime;
	string a[13] = { "Nangang","Taipei", "Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	cout << "Origin Station " << endl;
	for (int i = 0; i < 13; i++)
		cout <<i+1<<"."<< a[i]<<endl;
	do cout << "?";
	while ((choice = inputAnInteger(0, 13)) == -1);
	cin >> user.originStation;
	if (choice == 0)
		return;

	cout << "Destination Station" << endl;
	for (int i = 0; i < 13; i++)
		cout << i + 1 << "." << a[i] << endl;
	do cout << "?";
	while ((choice = inputAnInteger(0, 13)) == -1);
	cin >> user.destinationStation;
	if (choice == 0)
		return;

	if (user.originStation = user.destinationStation)
		return;
	cout << "Car Class ";
	cout << "1. Standard Car";
	cout << "2. Business Car";
	 do cout << "?";
	 while ((choice = inputAnInteger(0, 1)) == -1);
	cin >> user.carClass;

	cout << "Departure Date: ";
	cin >> user.date;
	cout << "Departure Time" << endl;
	for (int i = 1; i < 37; i++)
	{
		cout << setw(2) << i << ". " << departureTimes[i] << endl;
		
	}
	do cout << "?";
	while ((choice = inputAnInteger(0, 37)) == -1);
	if (choice == 0)
		return;
	cin >> departureTimes[choice];
	
	do cout << "How many adult tickets? ";
	while (user.adultTickets >= 0);
	cin >> user.adultTickets;
	cout << endl;

	do cout << "How many concession tickets?";
	while (user.concessionTickets >= 0);
	cin >> user.concessionTickets;

		
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	fstream File("Southbound timetable.txt", ios::in | ios::out );
	File.seekg(0, ios::end);
	int numLine = File.tellg() / sizeof(numSouthboundTrains);
	File.seekg(0, ios::beg);
	int  numSouthboundTrains(numLine);
	for (int i = 0; i < numLine; i++)
	{
		File.read(reinterpret_cast<char*>(&numSouthboundTrains), sizeof(numSouthboundTrains));
	}

}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	fstream File("Southbound timetable.txt", ios::in | ios::out );
	File.seekg(0, ios::end);
	int numLine = File.tellg() / sizeof(numNorthboundTrains);
	File.seekg(0, ios::beg);
	//int  numSouthboundTrainssize(numLine);
	for (int i = 0; i < numLine; i++)
	{
		File.read(reinterpret_cast<char*>(&numNorthboundTrains), sizeof(numNorthboundTrains));
	}

}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	Reservation user; int choice;
	cout << "Train No."<<"Departure" << setw(5) << "Arrival";
	for (int i = 0; i < numSouthboundTrains; i++)
	{
		if (strcmp(departureTimes[choice], southboundTimetable[i]) == 0)
			i = choice;
	}
	for (int i = 0; i < 10; i++)
		cout <<southboundTimetable[i];
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	Reservation user; int choice;
	cout << "Train No." << "Departure" << setw(5) << "Arrival";
	for (int i = 0; i < numNorthboundTrains; i++)
	{
		if (strcmp(departureTimes[choice], northboundTimetable[i]) == 0)
			i = choice;
	}
	for (int i = 0; i < 10; i++)
		cout << northboundTimetable[i];




}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	Reservation user;
	cout << "Enter Contact Person Information" << endl;
	cout << "ID Number: ";
	cin >> user.idNumber;
	cout << endl;
	cout << "Phone: ";
	cin >> user.phone;
	cout << endl;
	//srand time(NULL);
	cout << "Reservation Number: ";
	for (int i = 0; i < 12; i++) {
		user.reservationNumber[i] = (rand() % 10) + '0';
		cout<<user.reservationNumber[i];
	}
	cout << endl;
	cout << "Reservation Completed!";
	
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	fstream File("Reservation details.dat", ios::in | ios::app | ios::binary);
	File.seekg(0, ios::end);
	int numLine = File.tellg() / sizeof(reservation);
	File.seekg(0, ios::beg);
	for (int i = 0; i < numLine; i++)
	{
		File.write(reinterpret_cast<char*>(&reservation), sizeof(reservation));
	}
	
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	Reservation user;
	int choice;
	cout << "Enter ID Number:";
	cin >> user.idNumber;
	cout << "Enter Reservation Number:";
	cin >> user.reservationNumber;
	displayReservations(southboundTimetable, northboundTimetable, user);

	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1.Cancellation"
			<< "2. Reduce\n"
			<< "3. End ";
		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			reduceSeats(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reduceSeats(southboundTimetable, northboundTimetable);
			break;
		case 3:
			return;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}

	}


// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	Reservation user;
	cout << "Enter ID Number:";
	cin >> user.idNumber;
	cout << "Enter Reservation Number:";
	cin >> user.reservationNumber;
	for (int i = 0; i < 100; i++)
	{
		if (strcmp(user.idNumber, reservation.idNumber) == 0 && strcmp(user.reservationNumber, reservation.reservationNumber) == 0)
			return true;
	}
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	int numSouthboundtrains;
	loadSouthboundTimetable(southboundTimetable, numSouthboundtrains);
	int numNorthboundtrains;
	loadSouthboundTimetable(northboundTimetable, numNorthboundtrains);
	




}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	int choice; int adultTicketsPrice;
	int total = 0;
	cout << "Reservation Details  " << endl;
	cout << setw(10) << "Date" << setw(5) << "Train No." << setw(10) << "From" << setw(5) << "To" << setw(10) << "Departure" << setw(10) << "Arrival" << setw(10) << "Adult" << setw(10) << "Concession" << setw(5) << "Fare" << setw(5) << "Class" << endl;
	cout << reservation.date << setw(10) << reservation.trainNumber << setw(5) << reservation.originStation << setw(5) << reservation.destinationStation << setw(5) << departureTimes[choice] << adultTicketsPrice[choice] * reservation.adultTickets << setw(5) << adultTicketsPrice[choice] * reservation.concessionTickets << setw(2) << total << setw(5) << reservation.carClass << endl;
	total = departureTimes[choice] << adultTicketsPrice[choice] + adultTicketsPrice[choice] * reservation.concessionTickets;


}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	Reservation temp;
	Reservation user;
	int total;
	do cout << "How many adult tickets to cancel�H";
	while (temp.adultTickets <= user.adultTickets);
	cin >>temp.adultTickets;
	do cout << "How many concession tickets to cancel�H";
	while (temp.concessionTickets <= user.concessionTickets);
	cin >> temp.concessionTickets;

	if (user.adultTickets = user.concessionTickets == 0)
		reservation.erase(ios:beg(),



	cout << "Reservation Details  " << endl;
	cout << setw(10) << "Date" << setw(5) << "Train No." << setw(10) << "From" << setw(5) << "To" << setw(10) << "Departure" << setw(10) << "Arrival" << setw(10) << "Adult" << setw(10) << "Concession" << setw(5) << "Fare" << setw(5) << "Class" << endl;
	cout << reservation.date << setw(10) << reservation.trainNumber << setw(5) << reservation.originStation << setw(5) << reservation.destinationStation << setw(5) << departureTimes[choice] << adultTicketsPrice[choice] * reservation.adultTickets << setw(5) << adultTicketsPrice[choice] * reservation.concessionTickets << setw(2) << total << setw(5) << reservation.carClass << endl;
	total = departureTimes[choice] << adultTicketsPrice[choice] + adultTicketsPrice[choice] * reservation.concessionTickets;

	cout << "You have successfully reduced the number of tickets!  " << endl;






}