#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	string input;
	int temp = 0;
	cin >> input;
	while (1)
	{
		for (int i = 0; i < input.size(); i++)
		{
			if (!(input[i] >= '0' && input[i] <= '9'))
			{
				input.clear();
				break;
			}
		}
		if (input.empty())
			return -1;
		else
		{
			for (int i = 0; i < input.size(); i++)
				temp += (input[i] - '0') * pow(10, (input.size() - i - 1));
			if (temp >= begin && temp <= end)
				return temp;
			else
				return -1;
		}
	}
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	int numSouthboundTrains = 0, numNorthboundTrains = 0, departureTime;
	Reservation temp;

	inputReservationDetails(temp, departureTime);

	if (temp.originStation > temp.destinationStation)
	{
		loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, temp, departureTime);
	}
	else
	{
		loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, temp, departureTime);
	}

	inputContactInfo(temp);

	saveReservation(temp);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	char station[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
							"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };

	int choice;

	cout << "\nOrigin Station" << endl;
	for (int i = 1; i < 13; i++)
		cout << setw(2) << i << ". " << station[i] << endl;
	do cout << "? ";
	while ((choice = inputAnInteger(1, 12)) == -1);

	reservation.originStation = choice;

	cout << "\nDestination Station" << endl;
	for (int i = 1; i < 13; i++)
		cout << setw(2) << i << ". " << station[i] << endl;
	do cout << "? ";
	while ((choice = inputAnInteger(1, 12)) == -1 || reservation.originStation == choice);

	reservation.destinationStation = choice;

	cout << "\nCar Class" << endl;
	if (adultTicketPrice[reservation.originStation][reservation.destinationStation] == 0)
	{
		cout << "1. Standard Car" << endl;
		do cout << "? ";
		while ((choice = inputAnInteger(1, 1)) == -1);
	}
	else
	{
		cout << "1. Standard Car" << endl;
		cout << "2. Business Car" << endl;
		do cout << "? ";
		while ((choice = inputAnInteger(1, 2)) == -1);
	}

	reservation.carClass = choice;

	cout << "\nDeparture Date: ";
	cin >> reservation.date;

	cout << "\nDeparture Time" << endl;
	for (int i = 1; i < 35; i++)
		cout << setw(2) << i << ". " << departureTimes[i] << endl;
	do cout << "? ";
	while ((choice = inputAnInteger(1, 34)) == -1);

	departureTime = choice;

	do
	{
		do
		{
			cout << "\nHow many adult tickets? ";
			cin >> choice;
		} while (choice < 0);

		reservation.adultTickets = choice;

		do
		{
			cout << "\nHow many concession tickets? ";
			cin >> choice;
		} while (choice < 0);

		reservation.concessionTickets = choice;
	} while (reservation.adultTickets == 0 && reservation.concessionTickets == 0);
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inFile("Southbound timetable.txt", ios::in);
	int i = 0, t = 0;
	while (1)
	{
		if (t == 0)
		{
			inFile >> southboundTimetable[i].trainNumber;
			if (southboundTimetable[i].trainNumber[0] == '\0')
			{
				i--;
				break;
			}
			t++;
		}
		else if (t > 0 && t < 12)
		{
			inFile >> southboundTimetable[i].departureTimes[t];
			t++;
		}
		else if (t == 12)
		{
			inFile >> southboundTimetable[i].departureTimes[t];
			i++;
			t = 0;
		}
	}
	numSouthboundTrains = i;
	inFile.close();
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inFile("Northbound timetable.txt", ios::in);
	int i = 0, t = 13;
	while (1)
	{
		if (t == 13)
		{
			inFile >> northboundTimetable[i].trainNumber;
			if (northboundTimetable[i].trainNumber[0] == '\0')
			{
				i--;
				break;
			}
			t--;
		}
		else if (t > 1 && t < 13)
		{
			inFile >> northboundTimetable[i].departureTimes[t];
			t--;
		}
		else if (t == 1)
		{
			inFile >> northboundTimetable[i].departureTimes[t];
			i++;
			t = 13;
		}
	}
	numNorthboundTrains = i;
	inFile.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	char station[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
							"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carClass[3][12] = { "","Standard","Business" };

	cout << "\nTrain No." << setw(11) << "Departure" << setw(9) << "Arrival" << endl;
	int temp = 0, i = 0;
	for (int j = 0; j < 10; i++)
	{
		if (strcmp(southboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) != -1)
		{
			if (i > numSouthboundTrains)
				break;
			if (j == 0)
				temp = i;

			cout << setw(9) << southboundTimetable[i].trainNumber
				<< setw(11) << southboundTimetable[i].departureTimes[reservation.originStation]
				<< setw(9) << southboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
			j++;
		}
	}

	int choice = -1;

	while (choice == -1)
	{
		cout << "\nEnter Train Number:";
		cin >> reservation.trainNumber;
		for (int j = temp; j <= i; j++)
		{
			if (strcmp(reservation.trainNumber, southboundTimetable[j].trainNumber) == 0)
			{
				choice = 1;
				break;
			}
		}
	}

	display(reservation, southboundTimetable, station, carClass[reservation.carClass]);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	char station[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
							"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carClass[3][12] = { "","Standard","Business" };

	cout << "\nTrain No." << setw(11) << "Departure" << setw(9) << "Arrival" << endl;
	int i = 0, temp = 0;
	for (int t = 0; t < 10; i++)
	{
		if (strcmp(northboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) != -1)
		{
			if (i > numNorthboundTrains)
				break;
			if (t == 0)
				temp = i;
			cout << setw(9) << northboundTimetable[i].trainNumber
				<< setw(11) << northboundTimetable[i].departureTimes[reservation.originStation]
				<< setw(9) << northboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
			t++;
		}
	}

	int choice = -1;

	while (choice == -1)
	{
		cout << "\nEnter Train Number:";
		cin >> reservation.trainNumber;
		for (int j = temp; j <= i; j++)
		{
			if (strcmp(reservation.trainNumber, northboundTimetable[j].trainNumber) == 0)
			{
				choice = 1;
				break;
			}
		}
	}

	display(reservation, northboundTimetable, station, carClass[reservation.carClass]);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "\nEnter Contact Person Information";

	cout << "\nID Number: ";
	cin >> reservation.idNumber;

	cout << "\nPhone: ";
	cin >> reservation.phone;

	srand(time(0));
	for (int i = 0; i < 9; i++)
		reservation.reservationNumber[i] = rand() % 10 + '0';
	reservation.reservationNumber[9] = '\0';

	cout << "\nReservation Number: " << reservation.reservationNumber << endl;

	cout << "\nReservation Completed!" << endl;
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	Reservation temp[100], null;
	fstream File("Reservation details.dat", ios::in | ios::out | ios::binary);
	if (!File)
	{
		ofstream outFile("Reservation details.dat", ios::out | ios::binary);
		outFile.write(reinterpret_cast<const char*>(&reservation), sizeof(reservation));
	}
	else
	{
		File.seekg(0, ios::end);
		int num = File.tellg() / sizeof(Reservation);
		File.seekg(0, ios::beg);
		int i = 0;
		for (; i < num; i++)
		{
			File.read(reinterpret_cast<char*>(&temp[i]), sizeof(temp[i]));
		}
		temp[i] = reservation;
		File.seekg(0, ios::beg);
		for (int j = 0; j < num; j++)
		{
			File.write(reinterpret_cast<const char*>(&temp[j]), sizeof(temp[j]));
			if (strcmp(reservation.idNumber, temp[j].idNumber) == 0
				&& strcmp(reservation.reservationNumber, temp[j].reservationNumber) == 0)
				File.write(reinterpret_cast<const char*>(&null), sizeof(null));
		}
		File.write(reinterpret_cast<const char*>(&temp[i]), sizeof(temp[i]));
	}
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	Reservation temp, null;

	fstream inFile("Reservation details.dat", ios::in | ios::out | ios::binary);

	do
	{
		cout << "\nEnter ID Number: ";
		cin >> temp.idNumber;
		cout << "\nEnter Reservation Number: ";
		cin >> temp.reservationNumber;
		if (!existReservation(inFile, temp))
			cout << "\nReservation record not found." << endl;
	} while (!existReservation(inFile, temp));

	displayReservations(southboundTimetable, northboundTimetable, temp);

	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
		{
			Reservation a;

			inFile.seekg(0, ios::end);
			int num = inFile.tellg() / sizeof(Reservation);
			inFile.seekg(0, ios::beg);

			for (int i = 0; i < num; i++)
			{
				inFile.read(reinterpret_cast<char*>(&a), sizeof(a));
				if (strcmp(temp.idNumber, a.idNumber) == 0
					&& strcmp(temp.reservationNumber, a.reservationNumber) == 0)
				{
					inFile.seekg((i * sizeof(Reservation)), ios::beg);
					inFile.write(reinterpret_cast<const char*>(&null), sizeof(null));
				}
			}
			temp.adultTickets = 0;
			temp.concessionTickets = 0;
			inFile.seekg(0, ios::end);
			inFile.write(reinterpret_cast<const char*>(&temp), sizeof(temp));
			return;
		}
		case 2:
			reduceSeats(inFile, southboundTimetable, northboundTimetable, temp);
			return;
		case 3:
			return;
		}
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	ioFile.seekg(0, ios::end);
	int num = ioFile.tellg() / sizeof(Reservation);
	ioFile.seekg(0, ios::beg);
	Reservation temp;
	for (int i = 0; i < num; i++)
	{
		ioFile.read(reinterpret_cast<char*>(&temp), sizeof(temp));
		if (strcmp(reservation.idNumber, temp.idNumber) == 0
			&& strcmp(reservation.reservationNumber, temp.reservationNumber) == 0)
		{
			reservation = temp;
			return true;
		}
	}
	return false;
}

void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	char station[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
							"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carClass[3][12] = { "","Standard","Business" };
	int numSouthboundTrains = 0, numNorthboundTrains = 0;

	cout << "\nReservation Details" << endl;

	if (reservation.originStation > reservation.destinationStation)
	{
		loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
		display(reservation, northboundTimetable, station, carClass[reservation.carClass]);
	}
	else
	{
		loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
		display(reservation, southboundTimetable, station, carClass[reservation.carClass]);
	}
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	if (reservation.adultTickets == 0 && reservation.concessionTickets == 0)
		return;

	cout << setw(10) << "Date" << setw(11) << "Train No." << setw(8) << "From"
		<< setw(10) << "To" << setw(11) << "Departure" << setw(9) << "Arrival"
		<< setw(8) << "Adult" << setw(13) << "Concession" << setw(6) << "Fare" << setw(11) << "Class" << endl;

	cout << setw(10) << reservation.date << setw(11) << reservation.trainNumber
		<< setw(8) << stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation];

	for (int i = 0;; i++)
	{
		if (strcmp(trainTimetable[i].trainNumber, reservation.trainNumber) == 0)
		{
			cout << setw(11) << trainTimetable[i].departureTimes[reservation.originStation]
				<< setw(9) << trainTimetable[i].departureTimes[reservation.destinationStation];
			break;
		}
	}

	int total = 0;

	if (reservation.originStation > reservation.destinationStation)
	{
		if (reservation.carClass == 1)
		{
			cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets
				<< setw(11) << (adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) << "*" << reservation.concessionTickets;
			total = (adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets)
				+ ((adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) * reservation.concessionTickets);
		}
		else
		{
			cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets
				<< setw(11) << (adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) << "*" << reservation.concessionTickets;
			total = (adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets)
				+ ((adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) * reservation.concessionTickets);
		}
	}
	else
	{
		if (reservation.carClass == 1)
		{
			cout << setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets
				<< setw(11) << (adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2) << "*" << reservation.concessionTickets;
			total = (adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets)
				+ ((adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2) * reservation.concessionTickets);
		}
		else
		{
			cout << setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets
				<< setw(11) << (adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) << "*" << reservation.concessionTickets;
			total = (adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets)
				+ ((adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) * reservation.concessionTickets);
		}
	}

	cout << setw(6) << total << setw(11) << carClass << endl;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	if (reservation.adultTickets == 0 && reservation.concessionTickets == 0)
	{
		Reservation temp, null;

		ioFile.seekg(0, ios::end);
		int num = ioFile.tellg() / sizeof(Reservation);
		ioFile.seekg(0, ios::beg);

		for (int i = 0; i < num; i++)
		{
			ioFile.read(reinterpret_cast<char*>(&temp), sizeof(temp));
			if (strcmp(reservation.idNumber, temp.idNumber) == 0
				&& strcmp(reservation.reservationNumber, temp.reservationNumber) == 0)
			{
				ioFile.seekg((i * sizeof(Reservation)), ios::beg);
				ioFile.write(reinterpret_cast<const char*>(&null), sizeof(null));
			}
		}
		ioFile.seekg(0, ios::end);
		ioFile.write(reinterpret_cast<const char*>(&reservation), sizeof(reservation));
		return;
	}
	int choice = 0;
	do
	{
		cout << "\nHow many adult tickets to cancel�H ";
		cin >> choice;
	} while (choice < 0 || choice > reservation.adultTickets);

	reservation.adultTickets = choice;

	do
	{
		cout << "How many concession tickets to cancel�H ";
		cin >> choice;
	} while (choice < 0 || choice > reservation.concessionTickets);

	reservation.concessionTickets = choice;

	if (!(reservation.adultTickets == 0 && reservation.concessionTickets == 0))
	{
		displayReservations(southboundTimetable, northboundTimetable, reservation);
		cout << "\nYou have successfully reduced the number of tickets!" << endl;
	}

	Reservation temp, null;

	ioFile.seekg(0, ios::end);
	int num = ioFile.tellg() / sizeof(Reservation);
	ioFile.seekg(0, ios::beg);

	for (int i = 0; i < num; i++)
	{
		ioFile.read(reinterpret_cast<char*>(&temp), sizeof(temp));
		if (strcmp(reservation.idNumber, temp.idNumber) == 0
			&& strcmp(reservation.reservationNumber, temp.reservationNumber) == 0)
		{
			ioFile.seekg((i * sizeof(Reservation)), ios::beg);
			ioFile.write(reinterpret_cast<const char*>(&null), sizeof(null));
		}
	}
	ioFile.seekg(0, ios::end);
	ioFile.write(reinterpret_cast<const char*>(&reservation), sizeof(reservation));
}