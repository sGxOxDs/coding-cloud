#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main
// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char number[3];
	cin >> number;
	int final;

	if (number[1]=='\0')
	{
		final = number[0] - '0';
	}
	else
	{
		final = (number[0] - '0') * 10 + number[1] - '0';
	}

	if (final>=begin&&final<=end)
	{
		return final;
	}
	else
	{
		return -1;
	}

}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reservation;
	int departureTime;
	int numSouthboundTrains, numNorthboundTrains;
	char stations[13][12] = { "",
	"Nangang",
	"Taipei",
	"Banqiao",
	"Taoyuan",
	"Hsinchu",
	"Miaoli",
	"Taichung",
	"Changhua",
	"Yunlin",
	"Chiayi",
	"Tainan",
	"Zuoying" };
	inputReservationDetails(reservation, departureTime);
	if (reservation.originStation < reservation.destinationStation)
	{
		loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, reservation, departureTime);
		if (reservation.carClass == 1)
		{
			char carClass[12] = "Standard";
			display(reservation, southboundTimetable, stations, carClass);
		}
		else
		{
			char carClass[12] = "Business";
			display(reservation, southboundTimetable, stations, carClass);
		}

	}
	else
	{
		loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);
		if (reservation.carClass == 1)
		{
			char carClass[12] = "Standard";
			display(reservation, southboundTimetable, stations, carClass);
		}
		else
		{
			char carClass[12] = "Business";
			display(reservation, southboundTimetable, stations, carClass);
		}
	}

	inputContactInfo(reservation);
	saveReservation( reservation);

}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	cout << "Origin Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
	do cout << "\n? ";
	while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
	cout << endl;
	cout << "Destination Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
	do cout << "\n? ";
	while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1|| reservation.destinationStation== reservation.originStation);
	cout << endl;
	
	cout << "Car Class\n1. Standard Car\n2. Business Car\n";
	do cout << "\n? ";
	while ((reservation.carClass = inputAnInteger(1, 2)) == -1);
	cout << endl;
	if (reservation.carClass==2)
	{
		if (reservation.originStation > reservation.destinationStation)
		{
			while (adultTicketPrice[reservation.originStation][reservation.destinationStation] == 0)
			{
				cout << "Origin Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
				do cout << "\n? ";
				while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
				cout << endl;
				cout << "Destination Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
				do cout << "\n? ";
				while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1 || reservation.destinationStation == reservation.originStation);
				cout << endl;

				cout << "Car Class\n1. Standard Car\n2. Business Car\n";
				do cout << "\n? ";
				while ((reservation.carClass = inputAnInteger(1, 2)) == -1);
				cout << endl;
			}
		}
		else
		{
			while (adultTicketPrice[reservation.destinationStation][reservation.originStation] == 0)
			{
				cout << "Origin Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
				do cout << "\n? ";
				while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
				cout << endl;
				cout << "Destination Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
				do cout << "\n? ";
				while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1 || reservation.destinationStation == reservation.originStation);
				cout << endl;

				cout << "Car Class\n1. Standard Car\n2. Business Car\n";
				do cout << "\n? ";
				while ((reservation.carClass = inputAnInteger(1, 2)) == -1);
				cout << endl;
			}
		}
	}
	else
	{
		if (reservation.originStation > reservation.destinationStation)
		{
			while (adultTicketPrice[reservation.destinationStation][reservation.originStation] == 0)
			{
				cout << "Origin Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
				do cout << "\n? ";
				while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
				cout << endl;
				cout << "Destination Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
				do cout << "\n? ";
				while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1 || reservation.destinationStation == reservation.originStation);
				cout << endl;

				cout << "Car Class\n1. Standard Car\n2. Business Car\n";
				do cout << "\n? ";
				while ((reservation.carClass = inputAnInteger(1, 2)) == -1);
				cout << endl;
			}
		}
		else
		{
			while (adultTicketPrice[reservation.originStation][reservation.destinationStation] == 0)
			{
				cout << "Origin Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
				do cout << "\n? ";
				while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
				cout << endl;
				cout << "Destination Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying\n";
				do cout << "\n? ";
				while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1 || reservation.destinationStation == reservation.originStation);
				cout << endl;

				cout << "Car Class\n1. Standard Car\n2. Business Car\n";
				do cout << "\n? ";
				while ((reservation.carClass = inputAnInteger(1, 2)) == -1);
				cout << endl;
			}
		}
	}
	cout << "Departure Date :";
	cin >> reservation.date;
	cout << "Departure Time\n";
	for (int i = 1; i < 37; i++)
	{
		cout << i << "." << departureTimes[i] << endl;
	}
	do cout << "\n? ";
	while ((departureTime = inputAnInteger(1, 36)) == -1);
	cout << endl;
	cout << "How many adult tickets? ";
	cin >> reservation.adultTickets;
	cout << "How many concession tickets ? ";
	cin >> reservation.concessionTickets;

}
// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	int i = 0;
	
	ifstream readsouth("Southbound timetable.txt", ios::in);
	while (!readsouth.eof())
	{
		readsouth >> southboundTimetable[i].trainNumber;
		int j = 1;
		while ( j < 13)
		{
			readsouth >> southboundTimetable[i].departureTimes[j];
			j++;
		}
		i++;
	}
	numSouthboundTrains = i;
	readsouth.close();
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	int i = 0;
	
	ifstream readnorth("Northbound timetable.txt", ios::in);
	while (!readnorth.eof())
	{
		readnorth >> northboundTimetable[i].trainNumber;
		int j = 1;
		while (j<13)
		{
			
			readnorth >> northboundTimetable[i].departureTimes[j];
			j++;
		}
		i++;
	}
	numNorthboundTrains = i;
	readnorth.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{	int number = 0;
	int departchange,southchanghe, southchanghe2;
	departchange = ((departureTimes[departureTime][0] - '0') * 10 + (departureTimes[departureTime][1] - '0')) * 60 + (departureTimes[departureTime][3] - '0') + (departureTimes[departureTime][4] - '0');
	cout << "Train No." << setw(5) << "Departure" << setw(5) << "  Arrival\n";
	for (int i = 0; i < 100; i++)
	{
		
		southchanghe = ((southboundTimetable[i].departureTimes[reservation.originStation][0] - '0')*10 + (southboundTimetable[i].departureTimes[reservation.originStation][1] - '0')) * 60 + (southboundTimetable[i].departureTimes[reservation.originStation][3] - '0') + (southboundTimetable[i].departureTimes[reservation.originStation][4] - '0');
		southchanghe2 = ((southboundTimetable[i].departureTimes[reservation.destinationStation][0] - '0')*10 + (southboundTimetable[i].departureTimes[reservation.destinationStation][1] - '0') )* 60 + (southboundTimetable[i].departureTimes[reservation.destinationStation][3] - '0') + (southboundTimetable[i].departureTimes[reservation.destinationStation][4] - '0');
		if (southchanghe>= departchange && southchanghe2> southchanghe)
		{
			number++;
			cout<< southboundTimetable[i].trainNumber << setw(10) << southboundTimetable[i].departureTimes[reservation.originStation] << setw(10) << southboundTimetable[i].departureTimes[reservation.destinationStation]<<endl;
			if (number == 10)
				break;
		}

	}
	cout << "Enter Train Number :";
	cin >> reservation.trainNumber;
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) 
{	int number = 0;
	int departchange, northchanghe, northchanghe2;
	departchange =((departureTimes[departureTime][0] - '0')*10 + (departureTimes[departureTime][1] - '0') )* 60 + (departureTimes[departureTime][3] - '0') + (departureTimes[departureTime][4] - '0');
	cout << "Train No." << setw(10) << "Departure" << setw(10) << "  Arrival\n";
	for (int i = 0; i < 10; i++)
	{
		
		northchanghe = ((northboundTimetable[i].departureTimes[13-reservation.originStation][0] - '0')*10 + (northboundTimetable[i].departureTimes[13-reservation.originStation][1] - '0')) * 60 + (northboundTimetable[i].departureTimes[13-reservation.originStation][3] - '0') + (northboundTimetable[i].departureTimes[13-reservation.originStation][4] - '0');
		northchanghe2 = ((northboundTimetable[i].departureTimes[13-reservation.destinationStation][0] - '0')*10 + (northboundTimetable[i].departureTimes[13-reservation.destinationStation][1] - '0')) * 60 + (northboundTimetable[i].departureTimes[13-reservation.destinationStation][3] - '0') + (northboundTimetable[i].departureTimes[13-reservation.destinationStation][4] - '0');
		if (northchanghe >= departchange && northchanghe2 > northchanghe)
		{
			number++;
			cout << northboundTimetable[i].trainNumber << setw(10) << northboundTimetable[i].departureTimes[13-reservation.originStation] << setw(10) << northboundTimetable[i].departureTimes[13-reservation.destinationStation] << endl;
			if (number == 10)
				break;
		}

	}
	cout << "Enter Train Number :";
	cin >> reservation.trainNumber;
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "Enter Contact Person Information\n";
	cout << "ID Number : ";
	cin >> reservation.idNumber;

	cout << "Phone : ";
	cin >> reservation.phone;
	
	cout << "Reservation Number : ";
	for (int i = 0; i < 8; i++)
	{
		reservation.reservationNumber[i] = rand()% 10+'0';
	}
	reservation.reservationNumber[8] = '\0';
	cout << reservation.reservationNumber<<endl;
	cout << "Reservation Completed!\n";

}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	fstream save("Reservation details.dat", ios::out | ios::binary|ios::app);
	if (!save)
	{
		ofstream save2("Reservation details.dat", ios::out | ios::binary);
		save2.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
		save2.close();
	}

	save.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
	save.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	fstream ioFile("Reservation details.dat", ios::in | ios::binary);

	Reservation reservation;
	
	
	int choice; // store user choice

  // enable user to specify action
	while (existReservation(ioFile, reservation))
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			reservation.reservationNumber[0]='\0'; // used to identify a reservation
			reservation.trainNumber[0] = '\0';  // used to identify a train
			reservation.idNumber[0] = '\0';    // the id number of the contact person
			reservation.phone[0] = '\0';       // the (local or mobile) phone number of the contact person
			reservation.date[0] = '\0';        // outbound date
			reservation.originStation=0;      // the origin station code
			reservation.destinationStation = 0; // the destination station code
			reservation.carClass = 0;           // the car class code; 1:standard car, 2:business car
			reservation.adultTickets = 0;       // the number of adult tickets
			reservation.concessionTickets = 0;  // the number of concession tickets


			return;
		case 2:
			reduceSeats(ioFile, southboundTimetable, northboundTimetable, reservation);
			return;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return;

		}
	}

	system("pause");


}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	char reservationNumber[12];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	cout << "Enter ID Number : ";
	cin >> idNumber;
	cout << "Enter Reservation Number :";
	cin >> reservationNumber;

	while (ioFile.read(reinterpret_cast<char*>(&reservation),sizeof(Reservation)))
	{
		for (int i = 0; i < 12&& idNumber[i] == reservation.idNumber[i]; i++)
		{
			if (idNumber[i]==reservation.idNumber[i]&&i==11)
			{
				for (int j = 0; j < 12&&  reservationNumber[j] == reservation. reservationNumber[j]; j++)
				{
					if (reservationNumber[j]==reservation.reservationNumber[j]&&j==11)
					{
						return true;
					}
				}
			}
		}
	}
	return false;


}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	int numSouthboundTrains, numNorthboundTrains;
	char stations[13][12] = { "",
		"Nangang",
		"Taipei",
		"Banqiao",
		"Taoyuan",
		"Hsinchu",
		"Miaoli",
		"Taichung",
		"Changhua",
		"Yunlin",
		"Chiayi",
		"Tainan",
		"Zuoying" };

	if (reservation.originStation > reservation.destinationStation)
	{
		loadSouthboundTimetable(southboundTimetable, numSouthboundTrains);
		if (reservation.carClass == 1)
		{
			char carClass[12] = "Standard";
			display(reservation, southboundTimetable, stations, carClass);
		}
		else
		{
			char carClass[12] = "Business";
			display(reservation, southboundTimetable, stations, carClass);
		}

	}
	else
	{
		loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
		if (reservation.carClass == 1)
		{
			char carClass[12] = "Standard";
			display(reservation, southboundTimetable, stations, carClass);
		}
		else
		{
			char carClass[12] = "Business";
			display(reservation, southboundTimetable, stations, carClass);
		}
	}

	



}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{

	cout << setw(12) << "Date" << setw(8) << "Train No." << setw(10) << "From" << setw(10) << "To" << setw(10) << "Departure" << setw(10) << "  Arrival" << setw(10) << "Adult" << setw(10) << "Concession" << setw(5) << "Fare" << setw(10) << "Class\n";
	cout << setw(12) << reservation.date
		<< setw(8) << reservation.trainNumber;
	cout << setw(10) << stations[reservation.originStation]
		<< setw(10) << stations[reservation.destinationStation];
	for (int i = 0; i < 100; i++)
	{
		if (trainTimetable[i].trainNumber == reservation.trainNumber)
		{
			cout << setw(10) << trainTimetable[i].departureTimes[reservation.originStation] << setw(10) << trainTimetable[i].departureTimes[reservation.destinationStation];
		}

	}

	if (reservation.carClass == 2)
	{
		if (reservation.originStation > reservation.destinationStation)
		{
			cout << setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets
				<< setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << "*" << reservation.concessionTickets
				<< setw(10) << (adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets) + ((adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) * reservation.concessionTickets);
		}
		else
		{
			cout << setw(10) << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets
				<< setw(10) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << "*" << reservation.concessionTickets
				<< setw(10) << (adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2) * reservation.concessionTickets + (adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets);
		}

	}
	else
	{
		if (reservation.originStation > reservation.destinationStation)
		{
			cout << setw(10) << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets
				<< setw(10) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << "*" << reservation.concessionTickets
				<< setw(10) << (adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2) * reservation.concessionTickets + (adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets);
		}
		else
		{
			cout << setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets
				<< setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << "*" << reservation.concessionTickets
				<< setw(10) << (adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets) + ((adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) * reservation.concessionTickets);
		}

		cout << setw(10) << carClass << endl;
	}
}
// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int number;
	cout << "How many adult tickets to cancel�H";        
	cin >> number;
	reservation.adultTickets -= number;
	cout << "How many concession tickets to cancel�H"; 
	cin >> number;
	reservation.concessionTickets -= number;
	if (reservation.concessionTickets == 0 && reservation.adultTickets == 0)
	{
		reservation.reservationNumber[0] = '\0'; // used to identify a reservation
		reservation.trainNumber[0] = '\0';  // used to identify a train
		reservation.idNumber[0] = '\0';    // the id number of the contact person
		reservation.phone[0] = '\0';       // the (local or mobile) phone number of the contact person
		reservation.date[0] = '\0';        // outbound date
		reservation.originStation = 0;      // the origin station code
		reservation.destinationStation = 0; // the destination station code
		reservation.carClass = 0;           // the car class code; 1:standard car, 2:business car
		reservation.adultTickets = 0;       // the number of adult tickets
		reservation.concessionTickets = 0;  // the number of concession tickets
	}

	displayReservations(southboundTimetable, northboundTimetable, reservation);
	cout << "You have successfully reduced the number of tickets!\n";
}