#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

char carClass[3][10] =
{
	"",
	"Standard","business"
};
char Southboundstations[13][12] =
{
	"",
	"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
	"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying"
};
char Northboundstations[13][12] =
{
	"",
	"Zuoying","Tainan","Chiayi","Yunlin","Changhua","Taichung",
	"Miaoli","Hsinchu","Taoyuan","Banqiao","Taipei","Nangang"
};
int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	char input[5];
	for (int i = 0; i < 4; i++)
	{
		cin.get(input[i]);
		if (input[i] == '\n')
			break;
	}
	input[4] = '\0';

	int n = 0;
	for (int i = 0; input[i] != '\n'; i++)
		n++;
	if (n == 4)
		return -1;
	
	for (int i = 0; i < n; i++)
		if (input[i] > '9' || input[i] < '0')
			return -1;

	int number = 0;
	for (int i = 0; i < n; i++)
		number += (input[i] - '0') * pow(10, n - i - 1);
	if (number >= begin && number <= end)
		return number;
	else
		return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation temp;
	int departureTime;
	int a = 0, b = 0;
	loadSouthboundTimetable(southboundTimetable, a);
	loadNorthboundTimetable(northboundTimetable, b);
	inputReservationDetails(temp, departureTime);
	if (temp.originStation < temp.destinationStation) //�n�U
	{
		int numSouthboundTrains = 0;
		selectSouthboundTrain(southboundTimetable, numSouthboundTrains, temp, departureTime);
		display(temp, southboundTimetable, Southboundstations, carClass[temp.carClass]);
	}
	else//�_�W
	{
		int numNorthboundTrains = 0;
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, temp, departureTime);
		display(temp, northboundTimetable, Northboundstations, carClass[temp.carClass]);
	}
	inputContactInfo(temp);
	saveReservation(temp);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	cout << "Origin Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" << endl;
	int choice;
	do
		cout << "\n? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	cout << endl;
	reservation.originStation = choice;

	cout << "Destination Station" << endl;
	cout << "1. Nangang" << endl;
	cout << "2. Taipei" << endl;
	cout << "3. Banqiao" << endl;
	cout << "4. Taoyuan" << endl;
	cout << "5. Hsinchu" << endl;
	cout << "6. Miaoli" << endl;
	cout << "7. Taichung" << endl;
	cout << "8. Changhua" << endl;
	cout << "9. Yunlin" << endl;
	cout << "10. Chiayi" << endl;
	cout << "11. Tainan" << endl;
	cout << "12. Zuoying" << endl;
	do
		cout << "\n? ";
	while ((choice = inputAnInteger(1, 12)) == -1 || choice == reservation.originStation);
	cout << endl;
	reservation.destinationStation = choice;

	cout << "Car Class" << endl;
	cout << "1. Standard Car" << endl;
	cout << "2. Business Car" << endl;
	do
		cout << "\n? ";
	while ((choice = inputAnInteger(1, 2)) == -1);
	cout << endl;
	reservation.carClass = choice;
	cout << "Departure Date:";
	cin >> reservation.date;
	cout << endl;

	cout << "Departure Time";
	for (int i = 0; i < 35; i++)
		cout << departureTimes[i] << endl;
	do
		cout << "\n? ";
	while ((choice = inputAnInteger(1, 34)) == -1);
	cout << endl;
	departureTime = choice;

	cout << "How many adult tickets?";
	cin >> reservation.adultTickets;
	cout << endl;
	cout << "How many concession tickets? ";
	cin >> reservation.concessionTickets;
	cout << endl;
}

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream load("Southbound timetable.txt", ios::in);
	int i = 0;
	while (!load.eof())
	{
		load >> southboundTimetable[i].trainNumber;
		for (int j = 1; j <= 12; j++)
			load >> southboundTimetable[i].departureTimes[j];
		i++;
	}
	load.close();
}

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream load("Northbound timetable.txt", ios::in);
	int i = 0;
	while (!load.eof())
	{
		load >> northboundTimetable[i].trainNumber;
		for (int j = 1; j <= 12; j++)
			load >> northboundTimetable[i].departureTimes[j];
		i++;
	}
	load.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival " << endl;
	char trainNo[10][8];
	int num = 0;
	for (int i = 0; i < 100; i++)
	{
		if (strcmp(departureTimes[departureTime], southboundTimetable[i].departureTimes[reservation.originStation]) < 0)
		{
			if (strcmp(southboundTimetable[i].departureTimes[reservation.originStation], "-") != 0)
			{
				if (strcmp(southboundTimetable[i].departureTimes[reservation.destinationStation], "-") != 0)
				{
					cout << right << setw(9) << southboundTimetable[i].trainNumber;
					cout << right << setw(9) << southboundTimetable[i].departureTimes[reservation.originStation];
					cout << right << setw(9) << southboundTimetable[i].departureTimes[reservation.destinationStation];
					cout << endl;
					strcpy_s(trainNo[num], southboundTimetable[i].trainNumber);
					num++;
					if (num == 10)
						break;
				}
			}
		}
	}

	int numTrain[10] = {};
	for (int i = 0; i < 10; i++)
	{
		int j = 0;
		for(; trainNo[i][j]!='\0';j++){}

		for (int k = 0; k < j; k++)
			numTrain[i] += (trainNo[i][k] - '0') * pow(10, j - k - 1);
	}

	int boolnum = 0;
	do
	{
		cout << "Enter Train Number :";
		cin >> numSouthboundTrains;
		for (int i = 0; i < 10; i++)
		{
			if (numTrain[i] == numSouthboundTrains)
			{
				boolnum++;
				strcpy_s(reservation.trainNumber, trainNo[i]);
			}
		}
	} while (boolnum);

	cout << endl;
	cout << "\nTrip Details:" << endl << endl;
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << "Train No.  Departure  Arrival " << endl;
	char trainNo[10][8];
	int num = 0;
	for (int i = 0; i < 100; i++)
	{
		if (strcmp(departureTimes[departureTime], northboundTimetable[i].departureTimes[reservation.originStation]) < 0)
		{
			if (strcmp(northboundTimetable[i].departureTimes[reservation.originStation], "-") != 0)
			{
				if (strcmp(northboundTimetable[i].departureTimes[reservation.destinationStation], "-") != 0)
				{
					cout << right << setw(9) << northboundTimetable[i].trainNumber;
					cout << right << setw(9) << northboundTimetable[i].departureTimes[reservation.originStation];
					cout << right << setw(9) << northboundTimetable[i].departureTimes[reservation.destinationStation];
					cout << endl;
					strcpy_s(trainNo[num], northboundTimetable[i].trainNumber);
					num++;
					if (num == 10)
						break;
				}
			}
		}
	}

	int numTrain[10] = {};
	for (int i = 0; i < 10; i++)
	{
		int j = 0;
		for (; trainNo[i][j] != '\0'; j++) {}

		for (int k = 0; k < j; k++)
			numTrain[i] += (trainNo[i][k] - '0') * pow(10, j - k - 1);
	}

	int boolnum = 0;
	do
	{
		cout << "Enter Train Number :";
		cin >> numNorthboundTrains;
		for (int i = 0; i < 10; i++)
		{
			if (numTrain[i] == numNorthboundTrains)
			{
				boolnum++;
				strcpy_s(reservation.trainNumber, trainNo[i]);
			}
		}
	} while (boolnum);

	cout << endl;
	cout << "\nTrip Details:" << endl << endl;
}


// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "\nEnter Contact Person Information" << endl << endl;
	cout << "ID Number : ";
	cin >> reservation.idNumber;
	cout << endl;
	cout << "Phone : ";
	cin >> reservation.phone;
	cout << endl;
	cout << "Reservation Number : ";
	for (int i = 1; i <= 8; i++)
		cout << rand() % 10;
	cout << "\n\nReservation Completed!" << endl << endl;
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream save("Reservation details.dat", ios::app | ios::binary);
	save.write(reinterpret_cast<const char*>(&reservation), sizeof(reservation));
	save.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	fstream data("Reservation details.dat", ios::in | ios::out | ios::binary);
	Reservation temp;
	if (existReservation(data, temp))
	{
		displayReservations(southboundTimetable, northboundTimetable, temp);
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";
		int choice;
		do
			cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		if (choice == 1)
		{
			//�٨S�R��   look at here!
			cout << "\nReservation Cancelled! " << endl << endl;
		}
		else if (choice == 2)
		{
			reduceSeats(data, southboundTimetable, northboundTimetable, temp);
			cout << "\nYou have successfully reduced the number of tickets!" << endl << endl;
		}
		else
			choice = 0;
	}
	else
		cout << "\nReservation record not found." << endl << endl;
	data.close();
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	Reservation usetocompare;
	cout << "Enter ID Number : ";
	cin >> reservation.idNumber;
	cout << "Enter Reservation Number : ";
	cin >> reservation.reservationNumber;
	ioFile.seekg(0, ios::end);
	int count = ioFile.tellg() / sizeof(Reservation);
	int count2 = 1;
	for (int i = 0; i < count; i++)
	{
		ioFile.seekg((count - count2) * sizeof(Reservation), ios::beg);
		ioFile.read(reinterpret_cast<char*>(&usetocompare), sizeof(Reservation));
		count2++;
		if (strcmp(usetocompare.idNumber, reservation.idNumber) == 0 && strcmp(usetocompare.reservationNumber, reservation.reservationNumber) == 0)
		{
			reservation = usetocompare;
			return true;
		}
	}
	return false;
}

void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	int a = 0, b = 0;
	loadSouthboundTimetable(southboundTimetable, a);
	loadNorthboundTimetable(northboundTimetable, b);
	cout << "Reservation Details" << endl << endl;
	if (reservation.originStation < reservation.destinationStation)//�n�U
		display(reservation, southboundTimetable, Southboundstations, carClass[reservation.carClass]);
	else//�_�W
		display(reservation, northboundTimetable, Northboundstations, carClass[reservation.carClass]);
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	cout << right << setw(10) << "Date" << setw(11) << "Train   No." << setw(8) << "From";
	cout << setw(10) << "to" << setw(11) << "Departure" << setw(9) << "Arrival" << setw(9) << "Adult";
	cout << setw(14) << "Concession" << setw(6) << "Fare" << setw(10) << "Class" << endl;

	int sum = 0;
	cout << right << setw(10);
	for (int i = 0; reservation.date[i] != '\0'; i++)
		cout << reservation.date[i];
	cout << setw(11);
	for (int i = 0; reservation.trainNumber[i] != '\0'; i++)
		cout << reservation.trainNumber;
	cout << setw(8) << stations[reservation.originStation];
	cout << setw(10) << stations[reservation.destinationStation];
	for (int i = 0; i < 100; i++)
		if (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) == 0)
		{
			cout << setw(11) << trainTimetable[i].departureTimes[reservation.originStation];
			cout << setw(9) << trainTimetable[i].departureTimes[reservation.destinationStation];
		}
	cout << setw(9) << adultTicketPrice[reservation.originStation][reservation.destinationStation] <<'*'<<reservation.adultTickets;
	cout << setw(14) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << '*' << reservation.concessionTickets;
	sum += (adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2) * (reservation.concessionTickets + reservation.adultTickets * 2);
	cout << setw(6) << sum;//�٨S�Ϥ��O���O�Ӱȿ�
	cout << setw(10);
	for (int i = 0; carClass[i] != '\0'; i++)
		cout << carClass[i];
	cout << endl;
	    //          Date   Train No.    From        To  Departure     Arrival    Adult    Concession  Fare     Class
		//2019 - 12 - 28        825   Taipei  Taichung      12:11    13 : 17   700 * 2       350 * 2  2100  Standard
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int choice = 0;
	do
		cout << "\nHow many adult tickets to cancel�H";
	while (choice > reservation.adultTickets);

	do
		cout << "\nHow many concession tickets to cancel�H";
	while (choice > reservation.concessionTickets);

	//�o�̭n���� look at here!
	displayReservations(southboundTimetable, northboundTimetable, reservation);
}
