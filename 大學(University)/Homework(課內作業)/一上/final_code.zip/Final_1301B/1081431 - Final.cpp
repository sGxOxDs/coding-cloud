#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end) {
	char n[4];
	int a;
	cin >> n;
	
	if (n[1] == '\0') {
		a = n[0] - '0';
	}
	else if (n[2] == '\0') {
		a = n[1] - '0' + (n[0] - '0') * 10;
	}

	if (a<begin || a>end) {
		return -1;
	}
	else {
		return a;
	}
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]) {
	Reservation reservation;
	Train table[100];
	int departureTime;
	int trains=0,i;
	inputReservationDetails(reservation, departureTime);
	
	if (reservation.destinationStation - reservation.originStation > 0) {
		loadSouthboundTimetable(table, trains);
		selectSouthboundTrain(table, trains, reservation, departureTime);
	}
	else {
		loadNorthboundTimetable(table, trains);
		selectNorthboundTrain(table, trains, reservation, departureTime);
	}

	inputContactInfo(reservation);
	saveReservation(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime) {
	int i;

	cout << "Origin Station" << endl;
	cout << "1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying";
	do cout << "\n? ";
	while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
	cout << endl;
	
	cout << endl << "Destination Station" << endl;
	cout << "1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying";
	do cout << "\n? ";
	while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1 || reservation.destinationStation == reservation.originStation);
	cout << endl;

	cout << "Car Class" << endl;
	cout << "1. Standard Car\n2. Business Car";
	do cout << "\n? ";
	while ((reservation.carClass = inputAnInteger(1, 2)) == -1 || ((reservation.destinationStation ==1 || reservation.destinationStation == 2) && (reservation.originStation == 2 && reservation.originStation == 1) && reservation.carClass == 2) || ((reservation.destinationStation == 1 || reservation.destinationStation == 3) && (reservation.originStation == 1 && reservation.originStation == 3) && reservation.carClass == 2) || ((reservation.destinationStation == 3 || reservation.destinationStation == 2) && (reservation.originStation == 2 && reservation.originStation == 3) && reservation.carClass == 2));
	cout << endl;

	cout << "Departure Date: ";
	cin >> reservation.date;

	cout << "\nDeparture Time" << endl;
	for (i = 1; i < 10; i++)
		cout << " " << i << ". " << departureTimes[i] << endl;
	for(i = 10; i < 35; i++)
		cout << i << ". " << departureTimes[i] << endl;
	do cout << "\n? ";
	while ((departureTime = inputAnInteger(1, 36)) == -1);
	cout << endl;

	do {
		cout << "How many adult tickets? ";
		do {
			cin >> reservation.adultTickets;
		} while (reservation.adultTickets < 0);
	
		cout << endl << "How many concession tickets? ";
		do {
			cin >> reservation.concessionTickets;
		} while (reservation.concessionTickets < 0);
	} while (reservation.adultTickets == 0 && reservation.concessionTickets == 0);

}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) {
	int i,j;
	ifstream file("Southbound timetable.txt", ios::in);
	for (i = 0; !file.eof(); i++){
		file >> southboundTimetable[i].trainNumber;
		for (j = 1; j < 13; j++)
			file >> southboundTimetable[i].departureTimes[j];
		numSouthboundTrains++;
		cout << southboundTimetable[i].trainNumber << " " << southboundTimetable[i].departureTimes[12] << endl;
	}
	southboundTimetable[i].trainNumber[0] = '\0';
	file.close();
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) {
	int i, j;
	ifstream file("Northbound timetable.txt", ios::in);
	for (i = 0; !file.eof(); i++) {
		file >> northboundTimetable[i].trainNumber;
		for (j = 1; j < 13; j++)
			file >> northboundTimetable[i].departureTimes[j];
		numNorthboundTrains++;
	}
	file.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime) {

	char carClass[12];
	carClass[8] = '\0';
	if (reservation.carClass == 1) {
		carClass[0] = 'S'; carClass[1] = 't'; carClass[2] = 'a'; carClass[3] = 'n'; carClass[4] = 'd'; carClass[5] = 'a'; carClass[6] = 'r'; carClass[7] = 'd'; 
	}
	else {
		carClass[0] = 'B'; carClass[1] = 'u'; carClass[2] = 's'; carClass[3] = 'i'; carClass[4] = 'n'; carClass[5] = 'e'; carClass[6] = 's'; carClass[7] = 's';
	}
	char stations[13][12] = { "",
		"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying",
	};

	int i,j;
	int a0 = departureTimes[departureTime][0], a1 = departureTimes[departureTime][1], a3 = departureTimes[departureTime][3], a4 = departureTimes[departureTime][4];
	int b0, b1, b3, b4,o;
	cout << endl << setw(9) << "Train No." << setw(11) << "Departure" << setw(9) << "Arrival" << endl;
	for (i = 0,j=0; i < numSouthboundTrains, j < 5; i++) {
		b0 = southboundTimetable[i].departureTimes[reservation.originStation][0];
		b1 = southboundTimetable[i].departureTimes[reservation.originStation][1];
		b3 = southboundTimetable[i].departureTimes[reservation.originStation][3];
		b4 = southboundTimetable[i].departureTimes[reservation.originStation][4];
		o = southboundTimetable[i].departureTimes[reservation.destinationStation][0];
		if(!(a0>b0||(a0==b0 && a1>b1)||(a0 == b0 && a1 == b1 && a3>b3)||(a0 == b0 && a1 == b1 && a3 == b3 && a4>b4)) && o!=45){
			j++;
			cout << setw(9) << southboundTimetable[i].trainNumber << setw(11) << southboundTimetable[i].departureTimes[reservation.originStation] << setw(9) << southboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
		}
	}

	cout << "\nEnter Train Number: ";
	cin >> reservation.trainNumber;
	cout << "\nTrip Details" << endl;
	display(reservation, southboundTimetable, stations, carClass);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) {

	char carClass[12];
	carClass[8] = '\0';
	if (reservation.carClass == 1) {
		carClass[0] = 'S'; carClass[1] = 't'; carClass[2] = 'a'; carClass[3] = 'n'; carClass[4] = 'd'; carClass[5] = 'a'; carClass[6] = 'r'; carClass[7] = 'd';
	}
	else {
		carClass[0] = 'B'; carClass[1] = 'u'; carClass[2] = 's'; carClass[3] = 'i'; carClass[4] = 'n'; carClass[5] = 'e'; carClass[6] = 's'; carClass[7] = 's';
	}
	char stations[13][12] = { "",
		"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying",
	};

	int i;
	int a0 = departureTimes[departureTime][0], a1 = departureTimes[departureTime][1], a3 = departureTimes[departureTime][3], a4 = departureTimes[departureTime][4];
	int b0, b1, b3, b4;
	cout << endl << setw(9) << "Train No." << setw(11) << "Departure" << setw(9) << "Arrival" << endl;
	for (i = 0; i < numNorthboundTrains; i++) {
		b0 = northboundTimetable[i].departureTimes[reservation.originStation][0];
		b1 = northboundTimetable[i].departureTimes[reservation.originStation][1];
		b3 = northboundTimetable[i].departureTimes[reservation.originStation][3];
		b4 = northboundTimetable[i].departureTimes[reservation.originStation][4];
		if (!(a0 > b0 || (a0 == b0 && a1 > b1) || (a0 == b0 && a1 == b1 && a3 > b3) || (a0 == b0 && a1 == b1 && a3 == b3 && a4 > b4)))
			cout << setw(9) << northboundTimetable[i].trainNumber << setw(11) << northboundTimetable[i].departureTimes[reservation.originStation] << setw(9) << northboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
	}

	cin >> reservation.trainNumber;
	cout << "Reservation Details" << endl << endl;
	display(reservation, northboundTimetable, stations, carClass);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation) {
	srand(static_cast<unsigned int>(time(0)));
	cout << "\nEnter Contact Person Information" << endl;
	cout << "\nID Number: ";
	cin >> reservation.idNumber;
	cout << "\nPhone: ";
	cin >> reservation.phone;
	cout << "\nReservation Number: ";
	for (int i = 0; i < 8; i++)
		reservation.reservationNumber[i] = (0 + rand() % 10)+48;
	for (int i = 8; i < 12; i++)
		reservation.reservationNumber[i] = '\0';
	cout << reservation.reservationNumber << endl;
	cout << "\nReservation Completed!" << endl << endl;
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation) {
	ofstream file("details.dat", ios::binary | ios::app);
	file.seekp(0, ios::end);
	file.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
	file.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]) {
	int i,trains,choice,k,j;
	Reservation a;
	fstream ioFile("details.dat", ios::binary | ios::in | ios::out );
	do{
		cout << "\nEnter ID Number: ";
		cin >> a.idNumber;
		cout << "\nEnter Reservation Number: ";
		cin >> a.reservationNumber;
	} while (!existReservation(ioFile, a));
		
	displayReservations(southboundTimetable, northboundTimetable, a);

	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 2:
			reduceSeats(ioFile,southboundTimetable, northboundTimetable, a);
			break;
		case 3:
			return;
			break;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}

		if (choice == 1) {
			for (k = 0; a.reservationNumber[k] != '\0'; k++)
				a.reservationNumber[k] = '\0';
			for (k = 0; a.idNumber[k] != '\0'; k++)
				a.idNumber[k] = '\0';
			for (k = 0; a.trainNumber[k] != '\0'; k++)
				a.trainNumber[k] = '\0';
			for (k = 0; a.phone[k] != '\0'; k++)
				a.phone[k] = '\0';
			for (k = 0; a.date[k] != '\0'; k++)
				a.date[k] = '\0';
			a.originStation=0;
			a.destinationStation=0;
			a.carClass=0;
			a.adultTickets=0;
			a.concessionTickets = 0;

			Reservation x[100];
			for (i = 0; !ioFile.eof(); i++) {
				ioFile.read(reinterpret_cast<char*>(&x[i]), sizeof(Reservation));
			}
			x[i].adultTickets = 0;
			x[i].concessionTickets = 0;
			for (j = 0; j < i; j++) {
				for (k = 0; x[j].idNumber[k] != '\0'; k++) {
					if (a.idNumber[k] != x[j].idNumber[k])
						break;
				}
				if (x[j].idNumber[k] == '\0' && a.idNumber[k] == '\0' && k != 0) {
					for (k = 0; x[j].reservationNumber[k] != '\0'; k++) {
						if (a.reservationNumber[k] != x[j].reservationNumber[k])
							break;
					}
					if (x[j].reservationNumber[k] == '\0' && a.reservationNumber[k] == '\0' && k != 0) {
						ioFile.seekp(j, ios::beg);
						ioFile.write(reinterpret_cast<const char*>(&a), sizeof(Reservation));
						break;
					}
				}
			}
			return;
		}
	}
	ioFile.close();
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation) {
	Reservation a[100];
	int i=0,j,k;
	while(ioFile.read(reinterpret_cast<char*>(&a[i]), sizeof(Reservation))) {
		i++;
	}

	for (j = 0; j < i; j++) {
		for (k = 0; a[j].idNumber[k] != '\0'; k++) {
			if (reservation.idNumber[k] != a[j].idNumber[k])
				break;
		}
		if (a[j].idNumber[k] == '\0' && reservation.idNumber[k] == '\0' && k != 0) {
			for (k = 0; a[j].reservationNumber[k] != '\0'; k++) {
				if (reservation.reservationNumber[k] != a[j].reservationNumber[k])
					break;
			}
			if (a[j].reservationNumber[k] == '\0' && reservation.reservationNumber[k] == '\0' && k!=0) {
				for (k = 0; a[j].trainNumber[k] != '\0'; k++)
					reservation.trainNumber[k] = a[j].trainNumber[k];
				for (k = 0; a[j].phone[k] != '\0'; k++)
					reservation.phone[k] = a[j].phone[k];
				for (k = 0; a[j].date[k] != '\0'; k++)
					reservation.date[k] = a[j].date[k];
				reservation.originStation = a[j].originStation;
				reservation.destinationStation = a[j].destinationStation;
				reservation.carClass = a[j].carClass;
				reservation.adultTickets = a[j].adultTickets;
				reservation.concessionTickets = a[j].concessionTickets;
				return true;
			}
		}
	}
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation) {
	char carClass[12];
	carClass[8] = '\0';
	if (reservation.carClass == 1) {
		carClass[0] = 'S'; carClass[1] = 't'; carClass[2] = 'a'; carClass[3] = 'n'; carClass[4] = 'd'; carClass[5] = 'a'; carClass[6] = 'r'; carClass[7] = 'd';
	}
	else {
		carClass[0] = 'B'; carClass[1] = 'u'; carClass[2] = 's'; carClass[3] = 'i'; carClass[4] = 'n'; carClass[5] = 'e'; carClass[6] = 's'; carClass[7] = 's';
	}
	char stations[13][12] = { "",
		"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying",
	};

	int i, trains;
	
	
	cout << "\nReservation Details" << endl << endl;
	if (reservation.destinationStation - reservation.originStation > 0) {
		loadSouthboundTimetable(southboundTimetable, trains);
		display(reservation, southboundTimetable, stations, carClass);
	}
	else {
		loadNorthboundTimetable(northboundTimetable, trains);
		display(reservation, northboundTimetable, stations, carClass);
	}
	

}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]) {
	int i, j,a,b;
	if (reservation.destinationStation - reservation.originStation > 0) {
		a = 0;
		b = 0;
	}
	else {
		
	}
	for (i = 0; trainTimetable[i].trainNumber != NULL; i++) {
		for (j = 0; trainTimetable[i].trainNumber[j] != '\0'; j++) {
			if (reservation.trainNumber[j] != trainTimetable[i].trainNumber[j])
				break;
		}
		if (trainTimetable[i].trainNumber[j] == '\0' && reservation.trainNumber[j] == '\0')
			break;
	}

	cout << setw(10) << "Date" << setw(11) << "Train No." << setw(8) << "From" << setw(10) << "To" << setw(11) << "Departure" << setw(9) << "Arrival" << setw(8) << "Adult" << setw(12) << "Concession" << setw(6) << "Fare" << setw(10) << "Class" << endl;
	cout << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation] << setw(11) << trainTimetable[i].departureTimes[reservation.originStation] << setw(9) << trainTimetable[i].departureTimes[reservation.destinationStation] << setw(8) << "����" << "*" << reservation.adultTickets << setw(12) << "*" << reservation.concessionTickets << setw(6) << a+b << setw(10) << carClass << endl;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation) {
	int i, j, k,x,y;
	char carClass[12];
	carClass[8] = '\0';
	if (reservation.carClass == 1) {
		carClass[0] = 'S'; carClass[1] = 't'; carClass[2] = 'a'; carClass[3] = 'n'; carClass[4] = 'd'; carClass[5] = 'a'; carClass[6] = 'r'; carClass[7] = 'd';
	}
	else {
		carClass[0] = 'B'; carClass[1] = 'u'; carClass[2] = 's'; carClass[3] = 'i'; carClass[4] = 'n'; carClass[5] = 'e'; carClass[6] = 's'; carClass[7] = 's';
	}
	char stations[13][12] = { "",
		"Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying",
	};
	
	x=reservation.adultTickets;
	y=reservation.concessionTickets;
	cout << "How many adult tickets to cancel�H";
	do {
		cin >> reservation.adultTickets;
	} while (reservation.adultTickets < 0 && reservation.adultTickets >= x);

	cout << "How many concession tickets to cancel�H";
	do {
		cin >> reservation.concessionTickets;
	} while (reservation.concessionTickets < 0 && reservation.concessionTickets >= y);

	if (reservation.adultTickets == 0 && reservation.concessionTickets) {
		for (k = 0; reservation.reservationNumber[k] != '\0'; k++)
			reservation.reservationNumber[k] = '\0';
		for (k = 0; reservation.idNumber[k] != '\0'; k++)
			reservation.idNumber[k] = '\0';
		for (k = 0; reservation.trainNumber[k] != '\0'; k++)
			reservation.trainNumber[k] = '\0';
		for (k = 0; reservation.phone[k] != '\0'; k++)
			reservation.phone[k] = '\0';
		for (k = 0; reservation.date[k] != '\0'; k++)
			reservation.date[k] = '\0';
		reservation.originStation = 0;
		reservation.destinationStation = 0;
		reservation.carClass = 0;
	}
	cout << "Reservation Details" << endl << endl;
	display(reservation, northboundTimetable, stations, carClass);

	fstream file("details.dat", ios::binary | ios::in | ios::out);
	Reservation a[100];
	for (i = 0; !ioFile.eof(); i++) {
		ioFile.read(reinterpret_cast<char*>(&a[i]), sizeof(Reservation));
	}
	a[i].adultTickets = 0;
	a[i].concessionTickets = 0;
	for (j = 0; j < i; j++) {
		for (k = 0; a[j].idNumber[k] != '\0'; k++) {
			if (reservation.idNumber[k] != a[j].idNumber[k])
				break;
		}
		if (a[j].idNumber[k] == '\0' && reservation.idNumber[k] == '\0' && k != 0) {
			for (k = 0; a[j].reservationNumber[k] != '\0'; k++) {
				if (reservation.reservationNumber[k] != a[j].reservationNumber[k])
					break;
			}
			if (a[j].reservationNumber[k] == '\0' && reservation.reservationNumber[k] == '\0' && k!=0) {
				file.seekp(j,ios::beg);
				file.write(reinterpret_cast<const char*>(&reservation), sizeof(Reservation));
				break;
			}
		}
	}
	file.close();
}