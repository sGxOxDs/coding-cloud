#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};
                                 // departureTimes[0] is not used

char stations[13][12] = { "", "Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli",
		"Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };

char carClass[12] ;


// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	string choice;
	cin >> choice;

	int CHOICE=0;
	if (choice.size() == 2)
		CHOICE = (choice[0] - '0') * 10 + (choice[1] - '0');

	else if (choice.size() == 1)
		CHOICE = (choice[0] - '0');

	if (CHOICE >= begin && CHOICE <= end)
		return CHOICE;
	else
		return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation user;
	int departureTime;
	int numLine=100;

	inputReservationDetails(user,departureTime);

	loadNorthboundTimetable(northboundTimetable, numLine);
	loadSouthboundTimetable(southboundTimetable, numLine);

	if (user.destinationStation > user.originStation)
		selectSouthboundTrain(southboundTimetable,numLine,user,departureTime);
	if (user.destinationStation < user.originStation)
		selectNorthboundTrain(northboundTimetable,numLine,user,departureTime);
	
	inputContactInfo(user);
	saveReservation(user);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	cout << "Origin Station" << endl;
	for (int i = 1; i < 13; i++)
		cout << setw(2) << i << ". " << setw(4) << stations[i] << endl;
	
	int start;
	do cout << "\n?";
	while ((start = inputAnInteger(1, 12)) == -1);
	reservation.originStation = start;

	cout << "\nDestination Station" << endl;
	for (int i = 1; i < 13; i++)
		cout << setw(2) << i << ". " << setw(4) << stations[i] << endl;

	int arrive;
	do cout << "\n?";
	while ((arrive = inputAnInteger(1, 12)) == -1 || arrive==start);
	reservation.destinationStation = arrive;
	
	cout << "\nCar Class" << endl;
	cout << "1. Standard Car" << endl << "2. Business Car" << endl;
	int car;
	do cout << "\n?";
	while ((car = inputAnInteger(1, 2)) == -1);
	reservation.carClass = car;

	cout << "\nDeparture Date: ";
	cin >> reservation.date;
	cout << "\nDeparture Time" << endl;
	for (int i = 1; i < 37; i++)
		cout << setw(2) << i << ". " << setw(2) << departureTimes[i] << endl;

	do cout << "\n?";
	while ((departureTime = inputAnInteger(1, 36)) == -1);

	cout << "\nHow many adult tickets?";
	cin >> reservation.adultTickets;
	cout << "\nHow many concession tickets?";
	cin >> reservation.concessionTickets;
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream File("Southbound timetable.txt", ios::in);

	File.seekg(0, ios::end);
	numSouthboundTrains = sizeof(southboundTimetable);
	File.seekg(0, ios::beg);
	for (int i = 0; i < numSouthboundTrains; i++)
		File.read((char*)(&southboundTimetable[i]), sizeof(southboundTimetable));
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream File("Northbound timetable.txt", ios::in);

	File.seekg(0, ios::end);
	numNorthboundTrains = sizeof(northboundTimetable);
	File.seekg(0, ios::beg);
	for (int i = 0; i < numNorthboundTrains; i++)
		File.read((char*)(&northboundTimetable[i]), sizeof(northboundTimetable));
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	char carClass[12];
	
	cout << endl;
	cout << setw(2) << "Train NO." << setw(15) << "Departure" << setw(25) << "Arrival" << endl;
	
	do {
		cout << "Enter Train Number: ";
		cin >> reservation.trainNumber;
	}while (reservation.trainNumber != southboundTimetable->trainNumber);

	cout << "Trip Details" << endl;
	display(reservation, southboundTimetable, stations, carClass);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	char carClass[12];
	char *departure,*arrival;
	departure = northboundTimetable->departureTimes[reservation.originStation];
	arrival = northboundTimetable->departureTimes[reservation.destinationStation];
	cout << setw(2) << "Train NO." << setw(15) << "Departure" << setw(25) << "Arrival" << endl;

	do {
		cout << "Enter Train Number: ";
		cin >> reservation.trainNumber;
	} while (reservation.trainNumber != northboundTimetable->trainNumber);

	cout << "Trip Details" << endl;
	display(reservation, northboundTimetable, stations, carClass);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	Reservation user;
	cout << "\nEnter Contact Person Information" << endl;
	cout << "\nID Number: ";
	cin >> user.idNumber;
	cout << "\nPhone: ";
	cin >> user.phone;
	cout << "\nReservation Number: ";

	srand(time(NULL));
	int x = rand() % 10;
	for (int i = 0; i < 8; i++)
		user.reservationNumber[i] = '9' - x;

	for (int i = 0; i < 8; i++)
		cout << user.reservationNumber[i];

	cout << "\n\nReservation Completed!";
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	fstream File("Reservation details.dat", ios::in | ios::app | ios::binary);

	File.write((char*)(&reservation), sizeof(reservation));
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	Reservation user;
	fstream File("Reservation details.dat", ios::in | ios::out | ios::binary);
	
	existReservation(File, user);
	displayReservations(southboundTimetable, northboundTimetable, user);

	while (true) {
		cout << "Enter Your Choice" << endl;
		cout << "1. Cancellation" << endl;
		cout << "2. Reduce" << endl;
		cout << "3. End" << endl;

		int choice = 0 ;
		do cout << "\n?";
		while ((choice = inputAnInteger(1, 3)) == -1);

		switch (choice)
		{
		case 1:
			for (int i = 0; i < 12; i++)
			{
				user.reservationNumber[i] = 0;
				user.idNumber[i] = 0;
				user.phone[i] = 0;
				user.date[i] = 0;
			}

			for (int i = 0; i < 8; i++)
				user.trainNumber[i] = 0;

			user.originStation = 0;
			user.destinationStation = 0;
			user.carClass = 0;
			user.adultTickets = 0;
			user.concessionTickets = 0;
			continue;

		case 2:
			reduceSeats(File, southboundTimetable, northboundTimetable, user);
			continue;

		case 3:
			saveReservation(user);
			return;
		}
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	Reservation user;
	cout << "Enter ID Number: ";
	cin >> user.idNumber;
	cout << "Enter Reservation Number: ";
	cin >> user.reservationNumber;

	ioFile.read((char*)(&reservation), sizeof(reservation));

	for(int i=0;i<sizeof(reservation);i++)
		if (strcmp(reservation.idNumber, user.idNumber)==0 && strcmp(reservation.reservationNumber, user.reservationNumber)==0)
			return true;
	return false;
}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	cout << "Reservation Details" << endl;
	if(reservation.destinationStation>reservation.originStation)
		display(reservation,southboundTimetable,stations,carClass);
	if (reservation.destinationStation < reservation.originStation)
		display(reservation, northboundTimetable, stations, carClass);
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	int adultprice = 0;
	int concessionprice = 0;
	int total = 0;
	adultprice = adultTicketPrice[reservation.originStation][reservation.destinationStation];
	concessionprice = adultprice / 2;
	total = adultprice * reservation.adultTickets + concessionprice * reservation.concessionTickets;

	cout << setw(10) << "Date" << setw(12) << "Train No." << setw(15) << "From" << setw(15) << "To" 
		<<setw(12) << "Departure" << setw(10) << "Arrival" << setw(8) << "Adult" << setw(12) << "Concession"
		<<setw(8) << "Fare" << setw(10) << "Class";
	
	cout << setw(10) << reservation.date << setw(12) << reservation.trainNumber << setw(15)
		<< reservation.originStation << setw(15) << reservation.destinationStation << setw(12)
		<< trainTimetable->departureTimes[reservation.originStation] << setw(10)
		<< trainTimetable->departureTimes[reservation.destinationStation] << setw(8)
		<< adultprice << "*" << reservation.adultTickets << setw(12)
		<< concessionprice << "*" << reservation.concessionTickets << setw(8) << total << setw(10) << carClass;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int adult, concession;
	do {
		cout << "\nHow many adult tickets to cancel�H";
		cin >> adult;
		cout << "How many concession tickets to cancel�H";
		cin >> concession;
	} while (adult > reservation.adultTickets || concession > reservation.concessionTickets);

	if (adult == reservation.adultTickets && concession == reservation.concessionTickets)
	{
		for (int i = 0; i < 12; i++)
		{
			reservation.reservationNumber[i] = 0;
			reservation.idNumber[i] = 0;
			reservation.phone[i] = 0;
			reservation.date[i] = 0;
		}

		for (int i = 0; i < 8; i++)
			reservation.trainNumber[i] = 0;

		reservation.originStation = 0;
		reservation.destinationStation = 0;
		reservation.carClass = 0;
		reservation.adultTickets = 0;
		reservation.concessionTickets = 0;
	}

	else
	{
		reservation.adultTickets -= adult;
		reservation.concessionTickets -= concession;
	}
}