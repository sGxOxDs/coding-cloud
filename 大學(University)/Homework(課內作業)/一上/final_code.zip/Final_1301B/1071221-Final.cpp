#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}
	system("pause");
} // end main
// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	string input;
	int number = 0;
	if (input.size() == 1)
	{
		number = input[0] - '0';
	}
	else if (input.size() == 2)
	{
		number = (input[0] - '0') * 10 + input[1] - '0';
	}
	if (number >= begin && number <= end)
	{
		return number;
	}
	else
	{
		return -1;
	}
}
void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation reversation;
	int department;
	int numberofsouth = 0, numberofnorth = 0;
	fstream file("Reservation details.dat", ios::in || ios::out || ios::binary);
	inputReservationDetails(reversation, department);
	if (reversation.originStation < reversation.destinationStation)
	{
		loadSouthboundTimetable(southboundTimetable, numberofsouth);
		selectSouthboundTrain(southboundTimetable, numberofsouth, reversation, department);
	}
	else if (reversation.originStation > reversation.destinationStation)
	{
		loadNorthboundTimetable(northboundTimetable, numberofnorth);
		selectNorthboundTrain(northboundTimetable, numberofnorth, reversation, department);
	}
	if (reversation.originStation > 0)
	{
		inputContactInfo(reversation);
		saveReservation(reversation);
	}
}
// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	while (cout << "\nOrigin Station\n" << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n"
		<< "4. Taoyuan\n" << "5. Hsinchu\n" << "6. Miaoli\n" << "7. Taichung\n" <<
		"8. Changhua\n" << "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" <<
		"12. Zuoying\n?")
	{
		cin >> reservation.originStation;
		if (reservation.originStation > 0 && reservation.originStation < 13)
		{
			break;
		}
		else
		{
			cout << "\nIncorrect choice" << endl;
		}
	}
	while (cout << "\nDestination Station\n" << "1. Nangang\n" << "2. Taipei\n" << "3. Banqiao\n"
		<< "4. Taoyuan\n" << "5. Hsinchu\n" << "6. Miaoli\n" << "7. Taichung\n" <<
		"8. Changhua\n" << "9. Yunlin\n" << "10. Chiayi\n" << "11. Tainan\n" <<
		"12. Zuoying\n?")
	{
		cin >> reservation.destinationStation;
		if (reservation.destinationStation > 0 && reservation.destinationStation < 13)
		{
			break;
		}
		else
		{
			cout << "\nIncorrect choice" << endl;
		}
	}
	while (cout << "\nCar Class\n" << "1. Standard Car\n" << "2. Bussiness Car\n?")
	{
		cin >> reservation.carClass;
		if (reservation.carClass > 0 && reservation.carClass < 3)
		{
			break;
		}
		else
		{
			cout << "\nIncorrect choice" << endl;
		}
	}
	cout << "\nDeparture Date: ";
	cin >> reservation.date;
	while (cout << "\nDeparture Time\n" << "1. 06:00\n" << "2. 06:30\n"<<"3. 07:00\n"
		<<"4. 07:30\n"<<"5. 08:00\n"<<"6. 08:30\n"<<"7. 09:00\n"<<"8. 09:30\n"<<"9. 10:00\n"
		<<"11. 11:00\n"<<"12. 11:30\n"<<"13. 12:00\n"<<"14. 12:30\n"<<"15. 13:00\n"
		<<"16. 13:30\n"<<"17. 14:00\n"<<"18. 14:30\n"<<"19. 15:00\n"<<"20. 15:30\n"
		<<"21. 16:00\n"<<"22. 16:30\n"<<"23. 17:00\n"<<"24. 17:30\n"<<"25. 18:00\n"
		<<"26. 18:30\n"<<"27. 19:00\n"<<"28. 19:30\n"<<"29. 20:00\n"<<"30. 20:30\n"
		<< "31. 21:00\n" << "32. 21:30\n" << "33. 22:00\n" << "34. 22:30\n\?")
	{
		cin >> departureTime;
		if (departureTime > 0 && departureTime < 35)
		{
			break;
		}
	}
	cout << "\nHow many adult tickets? ";
	cin >> reservation.adultTickets;
	cout << endl;
	cout << "\nHow many concession tickets? ";
	cin >> reservation.concessionTickets;
}
// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream south("Southbound timetable.txt", ios::in);
	while (south >> southboundTimetable[numSouthboundTrains].trainNumber)
	{
		for (int i = 0; i < 13; i++)
		{
			south >> southboundTimetable[numSouthboundTrains].departureTimes[i];
		}
		numSouthboundTrains++;
	}
}
// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream north("Northbound timetable.txt", ios::in);
	while (north >> northboundTimetable[numNorthboundTrains].trainNumber)
	{
		for (int i = 12; i >0; i--)
		{
			north >> northboundTimetable[numNorthboundTrains].departureTimes[i];
		}
		numNorthboundTrains++;
	}
}
// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	char stationname[13][12] = { "","Nangang","Taipei","Banqiao" , "Taoyuan" ,"Hsinchy","Yunlin" , "Chiayi" , "Tainan" ,"Zuoying" };
	char classcar[3][12] = { "","Standard","Business" };
	int southtime, dempt;
	int i, j, check = 0;
	for (i = 0; i < numSouthboundTrains; i++)
	{
		for (j = 0; j < 5; j++)
		{
			if (southboundTimetable[i].departureTimes[reservation.destinationStation][j] != '-' && southboundTimetable[i].departureTimes[reservation.originStation][j] != '-')
			{
				southtime = southboundTimetable[i].departureTimes[reservation.destinationStation][j]-'0';
				dempt = departureTimes[departureTime][j]-'0';
				if (southtime > dempt)
				{
					check++;
					break;
				}
				else
				{
					break;
				}
				if (j == 4)
				{
					check++;
				}
			}
			else
			{
				break;
			}
		}
		if (check != 0)
		{
			break;
		}
	}
	cout << "Train No." << setw(2) << "Departure" << setw(2) << "Arrival" << endl;
	if (check != 0)
	{
		int k = i;
		int five = 0;
		if (i == numSouthboundTrains)
		{
			k = i - 1;
		}
		for (; k < numSouthboundTrains; k++)
		{
			if (southboundTimetable[k].departureTimes[reservation.originStation][0] == '-' || southboundTimetable[k].departureTimes[reservation.destinationStation][0] == '-')
			{
				continue;
			}
			else
			{
				five++;
				cout << setw(6) << reservation.trainNumber << setw(6) << reservation.originStation << setw(4) << reservation.destinationStation;
			}
			if (five == 5)
			{
				break;
			}
		}
		cout << "\nEnter Train Number: ";
		cin >> reservation.trainNumber;
		cout << "\nTrip Datils ";
		display(reservation, southboundTimetable, stationname, classcar[reservation.carClass]);
	}
	else
		reservation.originStation = 0;
		cout << "sorry,not match";
}
// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	char stationname[13][12] = { "","Nangang","Taipei","Banqiao" , "Taoyuan" ,"Hsinchy","Yunlin" , "Chiayi" , "Tainan" ,"Zuoying" };
	char classcar[3][12] = { "","Standard","Business" };
	int northrime, dempt;
	int i, j, check = 0;
	for (i = 0; i < numNorthboundTrains; i++)
	{
		for (j = 0; j < 5; j++)
		{
			if (northboundTimetable[i].departureTimes[reservation.destinationStation][j] != '-' && northboundTimetable[i].departureTimes[reservation.originStation][j] != '-')
			{
				northrime = northboundTimetable[i].departureTimes[reservation.destinationStation][j]-'0';
				dempt = departureTimes[departureTime][j]-'0';
				if (northrime > dempt)
				{
					check++;
					break;
				}
				else
				{
					break;
				}
				if (j == 4)
				{
					check++;
				}
			}
			else
			{
				break;
			}
		}
		if (check != 0)
		{
			break;
		}
	}
	if (check != 0)
	{
		int k = i;
		int five = 0;
		if (i == numNorthboundTrains)
		{
			k = i - 1;
		}
		for (; k < numNorthboundTrains; k++)
		{
			if (northboundTimetable[k].departureTimes[reservation.originStation][0] == '-' || northboundTimetable[k].departureTimes[reservation.destinationStation][0] == '-')
			{
				continue;
			}
			else
			{
				five++;
				cout << setw(6) << reservation.trainNumber << setw(6) << reservation.originStation << setw(4) << reservation.destinationStation;
			}
			if (five == 5)
			{
				break;
			}
		}
		cout << "\nEnter Train Number: ";
		cin >> reservation.trainNumber;
		cout << "\nTrip Datils ";
		display(reservation, northboundTimetable, stationname, classcar[reservation.carClass]);
	}
	else
		reservation.originStation = 0;
		cout << "sorry,not match";
}
// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "\nEnter Contact Person Information" << endl;
	cout << "\nID Number: ";
	cin >> reservation.idNumber;
	cout << "\nPhone: ";
	cin >> reservation.phone;
	for (int i = 0; i < 8; i++)
	{
		reservation.reservationNumber[i] = rand() % 10 + '0';
	}
	reservation.reservationNumber[8] = '\0';
	cout << "\nReservation Number: ";
	cin >> reservation.reservationNumber;
	cout << "\nReservation Completed!" << endl;
}
// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	fstream save("Reservation details.dat", ios::in || ios::app || ios::binary);
	save.write(reinterpret_cast<char*>(&reservation), sizeof(reservation));
}
void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	Reservation reservation;
	int choice = 0;
	fstream file("Reservation details.dat", ios::in || ios::out || ios::binary);
	if (existReservation(file, reservation))
	{
		displayReservations(southboundTimetable, northboundTimetable, reservation);
		if (choice == inputAnInteger(1, 3) == -1)
		{
			switch (choice)
			{
			case 1:
				file.seekg(-76, ios::cur);
				reservation.adultTickets = 0;
				reservation.carClass = 0;
				reservation.concessionTickets = 0;
				reservation.destinationStation = 0;
				reservation.originStation = 0;
				for (int i = 0; i < 12; i++)
				{
					reservation.date[i] = '\0';
					reservation.idNumber[i] = '\0';
					reservation.phone[i] = '\0';
					reservation.reservationNumber[i] = '\0';
					if (i < 8)
					{
						reservation.trainNumber[i] = '\0';
					}
				}
				file.write(reinterpret_cast<char*>(&reservation), sizeof(reservation));
				cout << "\nReservation Cancelled!" << endl;
				break;
			case 2:
				reduceSeats(file, southboundTimetable, northboundTimetable, reservation);
				break;
			case 3:
				break;
			default:
				cout << "\nIncorrect choice" << endl;
				break;
			}
		}
	}
	else
	{
		cout << "can't find the file." << endl;
	}
}
// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	char idnumber[12];
	char resnumber[8];
	while (cout << "\nEnter ID Number: ") {
		ioFile.seekg(0);
		memset(idnumber, 0, sizeof(idnumber));
		cin >> idnumber;
		int check, i;
		while (ioFile.read(reinterpret_cast<char*>(&reservation), sizeof(reservation)))
		{
			if (ioFile.eof())
			{
				break;
			}
			check = 0;
			if (strlen(idnumber) == strlen(reservation.idNumber))
			{
				for (int i = 0; i < strlen(idnumber); i++)
				{
					if (reservation.idNumber[i] != idnumber[i])
					{
						check++;
						break;
					}
				}
				if (check != 0)
				{
					return false;
					break;
				}
				cout << "Enter ID Number:";
				check = 0;
				memset(resnumber, 0, sizeof(resnumber));
				cin >> resnumber;
				if (strlen(resnumber) == strlen(reservation.reservationNumber))
				{
					for (int i = 0; i < strlen(reservation.reservationNumber); i++)
					{
						if (reservation.reservationNumber[i] != resnumber[i])
						{
							check++;
							break;
						}
					}
				}
				else
				{
					check++;
				}
			}
			if (check != 0)
			{
				cout << "sorry";
				continue;
			}
		}
		return true;
	}
}
void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	char stationname[13][12] = { "","Nangang","Taipei","Banqiao" , "Taoyuan" ,"Hsinchy","Yunlin" , "Chiayi" , "Tainan" ,"Zuoying" };
	char classcar[3][12] = { "","Standard","Business" };
	int numberofsouth = 0, numerofnorth = 0;
	if (reservation.originStation < reservation.destinationStation)
	{
		loadSouthboundTimetable(southboundTimetable, numberofsouth);
		display(reservation, southboundTimetable, stationname, classcar[reservation.carClass]);
	}
	else if (reservation.originStation > reservation.destinationStation)
	{
		loadSouthboundTimetable(northboundTimetable, numerofnorth);
		display(reservation, northboundTimetable, stationname, classcar[reservation.carClass]);
	}
}
// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	int trainNO = 0;
	for (trainNO = 0; trainNO < 100; trainNO++)
	{
		if (strcmp(trainTimetable[trainNO].trainNumber, reservation.trainNumber) == 0)
		{
			break;
		}
	}
	cout << setw(6) << "Date" << setw(2) << "Train No." << setw(4) << "From" << setw(8) << "To" << setw(2) << "Departure" << setw(2)
		<< "Arrival" << setw(3) << "Adult" << setw(2) << "Concession" << setw(2) << "Fare" <<setw(5)<<"Class"<< endl;
	cout << reservation.date << setw(8) << reservation.trainNumber << setw(2) << stations[reservation.originStation] << setw(2) << stations[reservation.destinationStation] <<
		setw(6) << trainTimetable[trainNO].departureTimes[reservation.originStation]<< setw(4) << trainTimetable[trainNO].departureTimes[reservation.destinationStation] <<
		setw(3) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets <<
		setw(7) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.concessionTickets << setw(2) << adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets +
		adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.concessionTickets << setw(2) << reservation.carClass << endl;
}
// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	fstream save("Reservation details.dat", ios::in || ios::app || ios::binary);
	save.write(reinterpret_cast<char*>(&reservation), sizeof(reservation));
}