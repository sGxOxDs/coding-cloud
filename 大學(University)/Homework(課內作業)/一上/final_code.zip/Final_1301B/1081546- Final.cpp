#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{

	char num[100];
	cin >> num;
	int j = -1;
	for (int i = 0; num[0]!=0 && i < 3; i++)
	{
		if ('0' > num[i] && num[i] > '9')
		{
			return 0;
		}
		j++;
	}
	return -1;
	if (j + 1 > 2)
		return 0;

	if (j == 0)
	{
		if (begin < num[0] && num[0] < end)
			int number = num[1] - '0';
			return -1;
	}
	else
	{
		if (begin < num[10] && num[10] < end)
		{
			int number = (num[0] - '0') * 10 + num[1] - '0';
			return -1;
		}
		return 0;
	}
	return 0;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	Reservation Reservation;

	int departureTime;
	loadSouthboundTimetable(southboundTimetable, departureTime);
	loadNorthboundTimetable(northboundTimetable, departureTime);
	inputReservationDetails(Reservation, departureTime);
	if (Reservation.originStation < Reservation.destinationStation)
	{
		selectSouthboundTrain(southboundTimetable, Reservation.originStation, Reservation, departureTime);
	}
	else if (Reservation.originStation > Reservation.destinationStation)
	{
		selectNorthboundTrain(northboundTimetable, Reservation.originStation, Reservation, departureTime);
	}
	inputContactInfo(Reservation);
	saveReservation(Reservation);
	return;
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	Reservation Reservation;
	int choice;
	cout << "Origin Station " << endl;
	cout << "1. Nangang\n";
	cout << "2. Taipei\n";
	cout << "3. Banqiao\n";
	cout << "4. Taoyuan\n";
	cout << "5. Hsinchu\n";
	cout << "6. Miaoli\n";
	cout << "7. Taichung\n";
	cout << "8. Changhua\n";
	cout << "9. Yunlin\n";
	cout << "10. Chiayi\n";
	cout << "11. Tainan\n";
	cout << "12. Zuoying\n";
	do cout << "? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	Reservation.originStation = choice;
	cout << "Destination Station\n";
	cout << "1. Nangang\n";
	cout << "2. Taipei\n";
	cout << "3. Banqiao\n";
	cout << "4. Taoyuan\n";
	cout << "5. Hsinchu\n";
	cout << "6. Miaoli\n";
	cout << "7. Taichung\n";
	cout << "8. Changhua\n";
	cout << "9. Yunlin\n";
	cout << "10. Chiayi\n";
	cout << "11. Tainan\n";
	cout << "12. Zuoying\n";
	do cout << "? ";
	while ((choice = inputAnInteger(1, 12)) == -1);
	Reservation.destinationStation = choice;
	if (Reservation.originStation == Reservation.destinationStation)
	{
		inputReservationDetails(reservation, departureTime);
		return;
	}
	cout << "Car Class\n";
	cout << "1. Standard Car\n";
	cout << "2. Business Car\n";
	do cout << "? ";
	while ((choice = inputAnInteger(1, 2)) == -1);
	Reservation.carClass = choice;
	cout << "Departure Date:";
	cin >> Reservation.date;
	cout << "Departure Time\n";
	cout << "1. 06:00\n" << "2. 06:30\n" << "3. 07 : 00\n" << "4. 07 : 30\n" << "5. 08 : 00\n" << "6. 08 : 30\n" << "7. 09 : 00\n" << "8. 09 : 30\n" << "9. 10 : 00\n" << "10. 10 : 30\n" << "11. 11 : 00\n" << "12. 11 : 30\n" << "13. 12 : 00\n" << "14. 12 : 30\n" << "15. 13 : 00\n" << "16. 13 : 30\n" << "17. 14 : 00\n" << "18. 14 : 30\n" << "19. 15 : 00\n" << "20. 15 : 30\n" << "21. 16 : 00\n" << "22. 16 : 30\n" << "23. 17 : 00\n" << "24. 17 : 30\n" << "25. 18 : 00\n" << "26. 18 : 30\n" << "27. 19 : 00\n" << "28. 19 : 30\n" << "29. 20 : 00\n" << "30. 20 : 30\n" << "31. 21 : 00\n" << "32. 21 : 30\n" << "33. 22 : 00\n" << "34. 22 : 30\n";
	do cout << "? ";
	while ((choice = inputAnInteger(1, 34)) == -1);
	departureTimes[37][8] = choice ;
	do cout << "How many adult tickets?";
	while ((choice = inputAnInteger(0, 99)) == -1);
	Reservation.adultTickets = choice;
	do cout << "How many concession tickets?";
	while ((choice = inputAnInteger(0, 99)) == -1);
	Reservation.concessionTickets = choice;
}

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	fstream infile("Southbound timetable.txt", ios::in | ios::out | ios::binary);
	infile.seekg(0, ios::end);
	int numline = infile.tellg() / sizeof(Train);
	infile.seekg(0, ios::beg);
	for (int i = 0; i < numSouthboundTrains; i++)
	{
		infile.write(reinterpret_cast<char*>(&southboundTimetable[i]), sizeof(Train));
	}
	infile.close();
}

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	fstream input("Northbound timetable.txt", ios::in | ios::out | ios::binary);
	input.seekg(0, ios::end);
	int numline = input.tellg() / sizeof(Train);
	input.seekg(0, ios::beg);
	for (int i = 0; i < numNorthboundTrains; i++)
	{
		input.write(reinterpret_cast<char*>(&northboundTimetable[i]), sizeof(Train));
	}
	input.close();
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	Train train;
	cout << "Train No." << setw(5) << right << "Departure" << setw(5) << right << " Arrival " << endl;
	for (int i = 0; i < 10; i++)
	{
		cout << setw(4) << right << train.trainNumber[i] << setw(4) << right << train.departureTimes[i] << setw(4) << right << train.departureTimes[i] + '11' << endl;
	}
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) 
{
	Train train;
	cout << "Train No." << setw(5) << right << "Departure" << setw(5) << right << " Arrival " << endl;
	for (int i = 0; i < 10; i++)
	{
		cout << setw(4) << right << train.trainNumber[i] << setw(4) << right << train.departureTimes[i] << setw(4) << right << train.departureTimes[i] + '11' << endl;
	}
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	Reservation Reservation;

	cout << "Enter Contact Person Information\n";
	cout << "ID Number: ";
	cin >> Reservation.idNumber;
	cout << "Phone: ";
	cin >> Reservation.phone;
	cout << "Reservation Number: ";
	srand(static_cast<unsigned int>(time(0)));
	char number[10]{};
	for (int i = 0; i < 8; i++)
	{
		number[i] = '0' + number[i] % 10;
	}
	number[8] = '\0';
	cout << number[8];
	cout << "\nReservation Completed!";
	cout << endl << endl;

}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	fstream save("Reservation details.dat", ios::in | ios::out | ios::binary);
	save.seekg(0, ios::end);
	int numline = save.tellg() / sizeof(Train);
	save.seekg(0, ios::beg);
	for (int i = 0; i < numline; i++)
	{
		save.read(reinterpret_cast<char*>(&reservation), sizeof (reservation));
	}
	save.close();
	fstream save2("Reservation details.dat", ios::in | ios::out | ios::binary);
	for (int i = 0; i < numline; i++)
	{
		save2.write(reinterpret_cast<char*>(&reservation), sizeof(reservation));
	}
	save2.close();
}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{
	fstream infile("Reservation details.dat", ios::in | ios::out | ios::binary);
	Reservation Reservation;
	int choice;
	if (existReservation(infile, Reservation))
	{
		displayReservations(southboundTimetable, northboundTimetable, Reservation);
		cout << "Enter Your Choice\n ";
		cout << "1. Cancellation\n";
		cout << "2. Reduce\n";
		cout << "3. End\n";
		do cout << "?";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;
		switch (choice)
		{
			case 1:
				cout << "Reservation Cancelled!";
				return;
			case 2:
				reduceSeats(infile, southboundTimetable, northboundTimetable, Reservation);
				return;
			case 3:
				return;
			default: // display error if user does not select valid choice
				cerr << "Incorrect Choice!\n";
				break;
		}
	}
}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	Reservation Reservation;
	char idNumber[10], ReservationNumber[10];
	cout << "Enter ID Number:";
	cin >> idNumber;
	cout << "Enter Reservation Number: ";
	cin >> ReservationNumber;
	for (int i = 0; i < 10; i++)
	{
		if (strcmp(idNumber, Reservation.idNumber) == 0 && strcmp(ReservationNumber, Reservation.reservationNumber) == 0)
		{
			return true;
		}
		return false;
	}
	return false;
}

void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{
	Train trainTimetable[100];
	char stations[13][12], carClass[12];
	cout << "Reservation Details " << endl;
	display(reservation, trainTimetable, stations, carClass);
	int departureTime;

	loadSouthboundTimetable(southboundTimetable, departureTime);
	loadNorthboundTimetable(northboundTimetable, departureTime);
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12])
{
	Train train;
	cout << setw(5) << right << "Date  Train" << setw(2) << left << "No." << setw(4) << right << "From" << setw(6) << right << "To" << setw(3) << right << "Departure " << setw(2) << right << "Arrival" << setw(5) << right << "Adult" << setw(3) << right << "Concession" << setw(3) << right << "Fare" << setw(6) << right << "Class" << endl;
	cout << setw(1) << right << reservation.date << setw(2) << left << reservation.trainNumber << setw(2) << right << reservation.originStation << setw(2) << right << reservation.destinationStation << setw(2) << right << train.departureTimes << setw(2) << right << adultTicketPrice[13][13] * reservation.adultTickets << setw(2) << right << adultTicketPrice[13][13] * reservation.concessionTickets << setw(2) << right << (adultTicketPrice[13][13] * reservation.adultTickets) + (adultTicketPrice[13][13] * reservation.concessionTickets) << setw(2) << right << reservation.carClass << endl << endl;
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{
	int choice1,choice2;
	do cout << "How many adult tickets to cancel�H";
	while ((choice1 = inputAnInteger(0, 99)) == -1);
	do cout << "How many concession tickets to cancel�H";
	while ((choice2 = inputAnInteger(0, 99)) == -1);
	if (choice1 == 0 && choice2 == 0)
	{
		return;
	}
	else
	{
		reservation.adultTickets = choice1;
		reservation.concessionTickets = choice2;
	}
	displayReservations(southboundTimetable, northboundTimetable, reservation);
	cout << "You have successfully reduced the number of tickets!" << endl << endl << endl;
}