﻿#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include <string>
using namespace std;

int adultTicketPrice[13][13] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[37][8] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

char station[13][12] = { "","Nangang","Taipei","Banqiao",
							"Taoyuan","Hsinchu","Miaoli",
							"Taichung","Changhua","Yunlin",
							"Chiayi","Tainan","Zuoying" };

char carclass[3][13] = { "","Standard Car","Business Car" };

struct Reservation
{
	char reservationNumber[12]; // used to identify a reservation
	char trainNumber[8];  // used to identify a train
	char idNumber[12];    // the id number of the contact person
	char phone[12];       // the (local or mobile) phone number of the contact person
	char date[12];        // outbound date
	int originStation;      // the origin station code
	int destinationStation; // the destination station code
	int carClass;           // the car class code; 1:standard car, 2:business car
	int adultTickets;       // the number of adult tickets
	int concessionTickets;  // the number of concession tickets
};

struct Train
{
	char trainNumber[8];          // used to identify a train
	char departureTimes[13][8]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end);

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]);

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime);

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains);

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains);

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime);

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime);

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation);

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]);

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation);


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation);

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]);

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation);



//Define function
// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	string AnInt;
	cin >> AnInt;
	if (begin <= atoi(AnInt.c_str()) && atoi(AnInt.c_str()) <= end) {
		return atoi(AnInt.c_str());
	}
	else {
		return -1;
	}
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	int numNorthbound = 50;
	int numSouthbound = 100;
	loadNorthboundTimetable(northboundTimetable, numNorthbound);
	loadSouthboundTimetable(southboundTimetable,numSouthbound);
	/*char station[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu",
						"Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carclass[3][15] = { "","Standard Car","Business Car" };*/
	char carclass1[12] = {};
	for (int i = 0; i < 12; i++) {
		carclass1[i] = 0;
	}
	Reservation order;
	int depart;
	int numtimetable = 10;
	inputReservationDetails(order, depart);
	for (int j = 0; j < 12; j++) {
		carclass1[j] = carclass[order.carClass][j];
	}
	if (order.originStation < order.destinationStation) {
		selectSouthboundTrain(southboundTimetable, numtimetable, order, depart);
		display(order, southboundTimetable, station, carclass1);
		inputContactInfo(order);
		saveReservation(order);
		return;
	}
	else {
		selectNorthboundTrain(southboundTimetable, numtimetable, order, depart);
		display(order, southboundTimetable, station, carclass1);
		inputContactInfo(order);
		saveReservation(order);
		return;
	}

}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{
	/*char station[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu",
						"Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char carclass[3][15] = { "","Standard Car","Business Car" };*/

	cout << "Origin Station\n";
	for (int i = 1; i < 13; i++) {
		cout << i << ". " << station[i] << "\n";
	}
	do cout << "\n? ";
	while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
	cout << endl;

	cout << "Destination Station\n";
	for (int i = 1; i < 13; i++) {
		cout << i << ". " << station[i] << "\n";
	}
	do cout << "\n? ";
	while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1
				|| reservation.destinationStation==reservation.originStation );
	cout << endl;

	cout << "Car Class\n";
	if ((reservation.originStation == 1 && reservation.destinationStation == 2) ||
		(reservation.originStation == 2 && reservation.destinationStation == 1) ||
		(reservation.originStation == 1 && reservation.destinationStation == 3) ||
		(reservation.originStation == 3 && reservation.destinationStation == 1) ||
		(reservation.originStation == 2 && reservation.destinationStation == 3) ||
		(reservation.originStation == 3 && reservation.destinationStation == 2)) {
		for (int i = 1; i < 2; i++) {
			cout << i << ". " << carclass[i] << "\n";
		}
		do cout << "\n? ";
		while ((reservation.carClass = inputAnInteger(1, 1)) == -1);
		cout << endl;
	}
	else{
		for (int i = 1; i < 3; i++) {
			cout << i << ". " << carclass[i] << "\n";
		}
		do cout << "\n? ";
		while ((reservation.carClass = inputAnInteger(1, 2)) == -1);
		cout << endl;
	}

	cout << "Departure Date: ";
	cin >> reservation.date;
	cout << endl;

	cout << "Departure Time\n";
	for (int i = 1; i < 35; i++) {
		cout <<setw(3)<< i << ". " << departureTimes[i] << "\n";
	}
	do cout << "\n? ";
	while ((departureTime = inputAnInteger(1, 34)) == -1);
	cout << endl;

	do cout << "How many adult tickets? ";
	while (cin >> reservation.adultTickets && reservation.adultTickets<0);
	cout << endl;
	 
	
	do cout << "How many concession tickets? ";
	while (cin >> reservation.concessionTickets&& reservation.concessionTickets < 0);
	cout << endl;

	
}

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	ifstream inFile("Southbound timetable.txt", ios::in);
	if (!inFile.is_open()) {
		cout << "File not be opened!";
	}
	else{
		int k = 0;
		//cout << numSouthboundTrains;
		while (inFile.peek() != EOF) {
			inFile >> southboundTimetable[k].trainNumber;
			for (int i = 1; i < 13; i++) {
				inFile >> southboundTimetable[k].departureTimes[i];
			}
			//cout << endl;
			k++;
		}
		inFile.close();
	}
}

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	ifstream inFile("Northbound timetable.txt", ios::in);
	if (!inFile.is_open()) {
		cout << "File not be opened!";
	}
	else {
		int k = 0;
		while (inFile.peek() != EOF) {
			inFile >> northboundTimetable[k].trainNumber;
			for (int i = 1; i < 13; i++) {
				inFile >> northboundTimetable[k].departureTimes[i];
			}
			//cout << endl;
			k++;
		}
		inFile.close();
	}
}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime)
{
	//cout << departureTimes[departureTime];
	
	cout << setw(9) << "Train No." << setw(11) << "Departure" << setw(9) << "Arrival"<<"\n";
	for (int i = 0; i < 10; i++) {
		cout << setw(9) << southboundTimetable[i].trainNumber
			<< setw(11) << southboundTimetable[i].departureTimes[reservation.originStation]
			<< setw(9) << southboundTimetable[i].departureTimes[reservation.destinationStation]<<"\n";
	}

	cout << "\nEnter Train Number: ";
	cin >> reservation.trainNumber;

	cout << "\n\nTrip Details\n\n";


}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime)
{
	cout << setw(9) << "Train No." << setw(11) << "Departure" << setw(9) << "Arrival" << "\n";
	for (int i = 0; i < 10; i++) {
		cout << setw(9) << northboundTimetable[i].trainNumber
			<< setw(11) << northboundTimetable[i].departureTimes[reservation.originStation]
			<< setw(9) << northboundTimetable[i].departureTimes[reservation.destinationStation] << "\n";
	}

	cout << "\nEnter Train Number: ";
	cin >> reservation.trainNumber;

	cout << "\n\nTrip Details\n\n";


}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "\n\nEnter Contact Person Information\n";
	cout << "\nID Number: ";
	cin >> reservation.idNumber;
	cout << "\nPhone: ";
	cin >> reservation.phone;
	cout << "\nReservation Number: ";
	char num = '0' + rand() % (('0' + 1) - '0');
	for (int i = 0; i < 8; i++) {
		char num = '0' + rand() % (('9' + 1) - '0');
		cout << num;
	}
	cout << "\n\nReservation Completed!\n\n";
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream outFile("Reservation details.dat", ios::binary);
	if (!outFile.is_open()) {
		cout << "File hadn't been opened!";
	}

}

void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100])
{


}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{

	cout << "\nEnter ID Number: ";
	cin >> reservation.idNumber;
	cout << "\nEnter Reservation Number:";
	cin >> reservation.reservationNumber;
	return true;

}


void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation)
{

}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[13])
{	
	char station[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu",
						"Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	char classA[3][12] = { "","Standard","Business" };
	
	cout << "\n\n";
	cout << setw(10) << "Date" << setw(11) << "Train No." << setw(8) << "From" << setw(10) << "To" << setw(11) << "Departure"
		<< setw(9) << "Arrival" << setw(8) << "Adult" << setw(12) << "Concession" << setw(6) << "Fare" << setw(10) << "Class"<<"\n";

	int adultprice = adultTicketPrice[reservation.originStation][reservation.destinationStation];
	int oldprice = adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2;

	cout << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation]
		<< setw(10) << stations[reservation.destinationStation] 
		<< setw(11) << " " 
		<< setw(9) << " "
		<< setw(6)	<< adultprice <<setw(1)<< "*"<<setw(1) << reservation.adultTickets
		<< setw(10) << oldprice << setw(1) <<"*" << setw(1) << reservation.concessionTickets
		<< setw(6) << adultprice * reservation.adultTickets + oldprice * reservation.concessionTickets
		<< setw(10) <<classA[reservation.carClass] ;


}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation)
{

}

int main()
{
	cout << "Taiwan High Speed Rail Booking System\n";
	srand(static_cast<unsigned int>(time(0)));

	Train southboundTimetable[100];
	Train northboundTimetable[100];
	int choice; // store user choice

	// enable user to specify action
	while (true)
	{
		cout << "\nEnter Your Choice\n"
			<< "1. Booking\n"
			<< "2. Booking History\n"
			<< "3. End Program";

		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			makingReservation(southboundTimetable, northboundTimetable);
			break;
		case 2:
			reservationHistory(southboundTimetable, northboundTimetable);
			break;
		case 3:
			cout << "Thank you! Goodbye!\n\n";
			system("pause");
			return 0;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}

	system("pause");
} // end main