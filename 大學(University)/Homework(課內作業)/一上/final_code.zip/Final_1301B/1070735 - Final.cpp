#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation( Reservation reservation );

void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main

// input an integer in the range [ begin, end ]
int inputAnInteger(int begin, int end)
{
	int i;
	cin >> i;
	if (!cin.good())
	{
		cin.clear();
		cin.ignore();
		return -1;
	}
	if (i >= begin && i <= end)
		return i;
	cin.clear();
	cin.ignore();
	return -1;
}

void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100])
{
	int departureTime, numNorthboundTrains = 0, numsouthboundTrains = 0;
	Reservation reservation;
	inputReservationDetails(reservation, departureTime);
	if (reservation.destinationStation < reservation.originStation)
	{
		loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
		selectNorthboundTrain(northboundTimetable, numNorthboundTrains, reservation, departureTime);
	}
	else if (reservation.destinationStation > reservation.originStation)
	{
		loadSouthboundTimetable(southboundTimetable, numsouthboundTrains);
		selectSouthboundTrain(southboundTimetable, numsouthboundTrains, reservation, departureTime);
	}

	inputContactInfo(reservation);
	saveReservation(reservation);
}

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails(Reservation& reservation, int& departureTime)
{

	cout << "\nOrigin Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying";
	do cout << "\n? ";
	while ((reservation.originStation = inputAnInteger(1, 12)) == -1);//�_�l��
	cout << endl;

	cout << "Destination Station\n1. Nangang\n2. Taipei\n3. Banqiao\n4. Taoyuan\n5. Hsinchu\n6. Miaoli\n7. Taichung\n8. Changhua\n9. Yunlin\n10. Chiayi\n11. Tainan\n12. Zuoying";
	do cout << "\n? ";
	while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1);//���I��
	cout << endl;

	if (reservation.originStation == reservation.destinationStation)//if�_�ׯ��ۦP
	{
		cout << "�_�l�P���I���ۦP!" << endl;
		return  inputReservationDetails(reservation, departureTime);
	}

	cout << "Car Class\n1. Standard Car\n2. Business Car";//��ܲ�����
	do cout << "\n? ";
	while ((reservation.carClass = inputAnInteger(1, 2)) == -1);
	cout << endl;

	if (reservation.carClass == 1)
	{
		if (reservation.originStation == 2 && reservation.destinationStation == 1)
		{
			cout << "\n���s�b�зǨ��[" << endl;
			return inputReservationDetails(reservation, departureTime);
		}
		if (reservation.originStation == 3 && reservation.destinationStation == 1)
		{
			cout << "\n���s�b�зǨ��[" << endl;
			return inputReservationDetails(reservation, departureTime);
		}
		if (reservation.originStation == 3 && reservation.destinationStation == 2)
		{
			cout << "\n���s�b�зǨ��[" << endl;
			return inputReservationDetails(reservation, departureTime);
		}
	}

	cout << "Departure Date: ";//��ܤ��
	cin >> reservation.date;
	cout << endl;

	cout << "Departure Time";
	for (int i = 1; i < 35; i++)
	{
		cout << "\n" << right << setw(2) << i << ". " << departureTimes[i];
	}
	do cout << "\n? ";
	while ((departureTime = inputAnInteger(1, 34)) == -1);

	do
	{
		do {
			cout << "\nHow many adult tickets? ";
			cin >> reservation.adultTickets;
		} while (reservation.adultTickets < 0);

		do {
			cout << "\nHow many concession tickets? ";
			cin >> reservation.concessionTickets;
		} while (reservation.concessionTickets < 0);
		cout << endl;
	} while (reservation.adultTickets == 0 && reservation.concessionTickets == 0);
}

// loads the southbound timetable from the file "Southbound timetable.txt"
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains)
{
	fstream loadsouthbound("Southbound timetable.txt", ios::in | ios::out);
	if (!loadsouthbound)
	{
		cout << "File could not be open!" << endl;
		exit(1);
	}

	while (loadsouthbound >> southboundTimetable[numSouthboundTrains].trainNumber)
	{
		for (int j = 1; j < 13; j++)
		{
			loadsouthbound >> southboundTimetable[numSouthboundTrains].departureTimes[j];
		}
		numSouthboundTrains++;
	}

	loadsouthbound.close();
}

// loads the northbound timetable from the file "Northbound timetable.txt"
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains)
{
	fstream loadNorthbound("Northbound timetable.txt", ios::in | ios::out);
	if (!loadNorthbound)
	{
		cout << "File could not be open!" << endl;
		exit(1);
	}

	while (loadNorthbound >> northboundTimetable[numNorthboundTrains].trainNumber)
	{
		for (int j = 1; j < 13; j++)
		{
			loadNorthbound >> northboundTimetable[numNorthboundTrains].departureTimes[j];
		}
		numNorthboundTrains++;
	}

	loadNorthbound.close();

}

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains, Reservation& reservation, int departureTime)
{
	char carClass[12];
	if (reservation.carClass == 1)
		strcpy_s(carClass, "Standard");
	else
		strcpy_s(carClass, "Business");

	char stations[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	cout << "Train No.  Departure  Arrival" << endl;
	for (int i = 0; i < numSouthboundTrains; i++)
	{
		if (strcmp(southboundTimetable[i].departureTimes[reservation.originStation], "-") != 0 && strcmp(southboundTimetable[i].departureTimes[reservation.destinationStation], "-") != 0)
		{
			if (strcmp(southboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) == 0 || strcmp(southboundTimetable[i].departureTimes[reservation.originStation], departureTimes[departureTime]) == 1)
			{
				cout << right << setw(9) << southboundTimetable[i].trainNumber << setw(11) << southboundTimetable[i].departureTimes[reservation.originStation] << setw(9) << southboundTimetable[i].departureTimes[reservation.destinationStation] << endl;
			}
		}
	}



	cout << "\nEnter Train Number: ";
	cin >> reservation.trainNumber;
	cout << "\nTrip Details" << endl;
	display(reservation, southboundTimetable, stations, carClass);
}

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains, Reservation& reservation, int departureTime)
{
	char carClass[12];
	if (reservation.carClass == 1)
		strcpy_s(carClass, "Standard");
	else
		strcpy_s(carClass, "Business"); 


	char stations[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	cout << "Train No.  Departure  Arrival" << endl;
	for (int i = 0; i < numNorthboundTrains; i++)
	{
		if (strcmp(northboundTimetable[i].departureTimes[13-reservation.originStation], "-") != 0 && strcmp(northboundTimetable[i].departureTimes[13-reservation.destinationStation], "-") != 0)
		{
			if (strcmp(northboundTimetable[i].departureTimes[13-reservation.originStation], departureTimes[departureTime]) == 0 || strcmp(northboundTimetable[i].departureTimes[13-reservation.originStation], departureTimes[departureTime]) == 1)
			{
				cout << right << setw(9) << northboundTimetable[i].trainNumber << setw(11) << northboundTimetable[i].departureTimes[13-reservation.originStation] << setw(9) << northboundTimetable[i].departureTimes[13-reservation.destinationStation] << endl;
			}
		}
	}



	cout << "\nEnter Train Number: ";
	cin >> reservation.trainNumber;
	cout << "\nTrip Details" << endl;
	display(reservation, northboundTimetable, stations, carClass);
}

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo(Reservation& reservation)
{
	cout << "\nEnter Contact Person Information" << endl;
	cout << "\nID Number: ";
	cin >> reservation.idNumber;
	cout << "\nPhone: ";
	cin >> reservation.phone;
	
	for (int i = 0; i < 8; i++)
	{
		reservation.reservationNumber[i] = rand() % 10 + '0';
	}
	for (int i = 8; i < sizeof(reservation.reservationNumber); i++)
	{
		reservation.reservationNumber[i] = '\0';
	}
	cout << "\nReservation Number: " << reservation.reservationNumber << endl;
	cout << "\nReservation Completed!" << endl;
}

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation)
{
	ofstream savereservation("Reservation details.dat", ios::app | ios::binary);

	savereservation.write(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
}

void reservationHistory(Train southboundTimetable[100], Train northboundTimetable[100])
{
	int num=0, choice, departureTime, numNorthboundTrains = 0, numsouthboundTrains = 0;
	Reservation reservation;
	fstream load("Reservation details.dat", ios::in | ios::out | ios::binary);

	while (!existReservation(load, reservation))
		cout << "\nReservation record not found." << endl;
	displayReservations(southboundTimetable, northboundTimetable, reservation);

	char carClass[12];
	char stations[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };
	if (reservation.carClass == 1)
		strcpy_s(carClass, "Standard");
	else
		strcpy_s(carClass, "Business");

	cout << "\nEnter Your Choice\n"
		<< "1. Cancellation\n"
		<< "2. Reduce\n"
		<< "3. End";

	do cout << "\n? ";
	while ((choice = inputAnInteger(1, 3)) == -1);
	cout << endl;

	switch (choice)
	{
	case 1:
		Reservation tmp;
		while (load.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation)))
		{
			if (strcmp(tmp.idNumber, reservation.idNumber) == 0 && strcmp(tmp.reservationNumber, reservation.reservationNumber) == 0)
			{
				strcpy_s(reservation.date, "");
				strcpy_s(reservation.phone, "");
				strcpy_s(reservation.trainNumber, "");
				strcpy_s(reservation.idNumber, "");
				strcpy_s(reservation.reservationNumber, "");

				reservation.carClass = 0;
				reservation.destinationStation = 0;
				reservation.originStation = 0;

				load.seekp(num * sizeof(Reservation), ios::beg);
				load.write(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
			}
			num++;
		}
		break;
	case 2:
		reduceSeats(load, southboundTimetable, northboundTimetable,reservation);
		if (reservation.destinationStation < reservation.originStation)
		{
			display(reservation, northboundTimetable, stations, carClass);
		}
		else if (reservation.destinationStation > reservation.originStation)
		{
			display(reservation, southboundTimetable, stations, carClass);
		}
		break;
	case 3:
		break;
	default: // display error if user does not select valid choice
		cerr << "Incorrect Choice!\n";
		break;
	}

}

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation(fstream& ioFile, Reservation& reservation)
{
	cout << "\nEnter ID Number: ";
	cin >> reservation.idNumber;
	cout << "\nEnter Reservation Number: ";
	cin>>reservation.reservationNumber;
	Reservation tmp;
	while (ioFile.read(reinterpret_cast<char*> (&tmp),sizeof(Reservation)))
	{
		if (strcmp(tmp.idNumber, reservation.idNumber) == 0 && strcmp(tmp.reservationNumber, reservation.reservationNumber) == 0)
		{
			strcpy_s(reservation.date, tmp.date);
			strcpy_s(reservation.phone, tmp.phone);
			strcpy_s(reservation.trainNumber, tmp.trainNumber);

			reservation.adultTickets = tmp.adultTickets;
			reservation.carClass = tmp.carClass;
			reservation.concessionTickets = tmp.concessionTickets;
			reservation.destinationStation = tmp.destinationStation;
			reservation.originStation = tmp.originStation;
			return true;
		}
		
	}
	return false;
}


void displayReservations(Train southboundTimetable[100], Train northboundTimetable[100], Reservation reservation)
{
	cout << "\nReservation Details" << endl;
	int departureTime, numNorthboundTrains = 0, numsouthboundTrains = 0;

	char carClass[12];
	char stations[13][12] = { "","Nangang","Taipei","Banqiao","Taoyuan","Hsinchu","Miaoli","Taichung","Changhua","Yunlin","Chiayi","Tainan","Zuoying" };

	if (reservation.carClass == 1)
		strcpy_s(carClass, "Standard");
	else
		strcpy_s(carClass, "Business");

	if (reservation.destinationStation < reservation.originStation)
	{
		loadNorthboundTimetable(northboundTimetable, numNorthboundTrains);
		display(reservation, northboundTimetable, stations, carClass);
	}
	else if (reservation.destinationStation > reservation.originStation)
	{
		display(reservation, southboundTimetable, stations, carClass);
		loadSouthboundTimetable(southboundTimetable, numsouthboundTrains);
	}
}

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display(Reservation reservation, Train trainTimetable[100], char stations[13][12], char carClass[12])
{
	int num = 0;
	int fare;
	while (strcmp(reservation.trainNumber, trainTimetable[num].trainNumber) != 0)
		num++;

	cout << "\n      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class" << endl;

	if (reservation.destinationStation < reservation.originStation)
	{
		if (strcmp(carClass, "Business"))
		{
			fare = adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets + adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 * reservation.concessionTickets;
			cout << right << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation] << setw(11) <<
				trainTimetable[num].departureTimes[13-reservation.originStation] << setw(9) << trainTimetable[num].departureTimes[13-reservation.destinationStation] << setw(6) <<
				adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets << setw(10) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << "*" << reservation.concessionTickets << setw(6) << fare << setw(10) << carClass << endl;
		}
		else
		{
			fare = adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets + adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 * reservation.concessionTickets;

			cout << right << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation] << setw(11) <<
				trainTimetable[num].departureTimes[13-reservation.originStation] << setw(9) << trainTimetable[num].departureTimes[13-reservation.destinationStation] << setw(6) <<
				adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets << setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << "*" << reservation.concessionTickets << setw(6) << fare << setw(10) << carClass << endl;
		}
	}
	else if (reservation.destinationStation > reservation.originStation)
	{
		if (strcmp(carClass, "Business"))
		{
			fare = adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets + adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 * reservation.concessionTickets;
			cout << right << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation] << setw(11) <<
				trainTimetable[num].departureTimes[reservation.originStation] << setw(9) << trainTimetable[num].departureTimes[reservation.destinationStation] << setw(6) <<
				adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << reservation.adultTickets << setw(10) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2 << "*" << reservation.concessionTickets << setw(6) << fare << setw(10) << carClass << endl;
		}
		else
		{
			fare = adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets + adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 * reservation.concessionTickets;

			cout << right << setw(10) << reservation.date << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation] << setw(10) << stations[reservation.destinationStation] << setw(11) <<
				trainTimetable[num].departureTimes[reservation.originStation] << setw(9) << trainTimetable[num].departureTimes[reservation.destinationStation] << setw(6) <<
				adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << reservation.adultTickets << setw(10) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2 << "*" << reservation.concessionTickets << setw(6) << fare << setw(10) << carClass << endl;
		}
	}

	
}

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats(fstream& ioFile, Train southboundTimetable[100], Train northboundTimetable[100], Reservation& reservation)
{
	int num = 0, adultTickets, concessionTickets;
	do
	{
		if (reservation.adultTickets > 0)
			cout << "\nHow many adult tickets to cancel�H";
	}
	while ((adultTickets = inputAnInteger(0, reservation.adultTickets)) == -1);
	reservation.adultTickets -= adultTickets;

	do
	{
		if (reservation.concessionTickets > 0)
			cout << "How many concession tickets to cancel�H";
	} while ((concessionTickets = inputAnInteger(0, reservation.concessionTickets)) == -1);
	reservation.concessionTickets -= concessionTickets;
	
	if (reservation.adultTickets == 0 && reservation.concessionTickets == 0)
	{
		strcpy_s(reservation.date,"");
		strcpy_s(reservation.phone,"");
		strcpy_s(reservation.trainNumber, "");
		strcpy_s(reservation.idNumber, "");
		strcpy_s(reservation.reservationNumber, "");

		reservation.carClass = 0;
		reservation.destinationStation = 0;
		reservation.originStation = 0;
	}

	Reservation tmp;
	while (ioFile.read(reinterpret_cast<char*> (&tmp), sizeof(Reservation)))
	{
		if (strcmp(tmp.reservationNumber, reservation.reservationNumber) == 0)
		{
			ioFile.seekp(num * sizeof(Reservation), ios::beg);
			ioFile.write(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
		}
		num++;
	}
}