#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

int adultTicketPrice[ 13 ][ 13 ] = {
   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   0,    0,    0,    0,  500,  700,  920, 1330, 1510, 1660, 1880, 2290, 2500,
   0,   40,    0,    0,  440,  640,  850, 1250, 1430, 1600, 1820, 2230, 2440,
   0,   70,   40,    0,  400,  590,  800, 1210, 1390, 1550, 1780, 2180, 2390,
   0,  200,  160,  130,    0,  400,  620, 1010, 1210, 1370, 1580, 1990, 2200,
   0,  330,  290,  260,  130,    0,  410,  820, 1010, 1160, 1390, 1790, 2000,
   0,  480,  430,  400,  280,  140,    0,  610,  790,  950, 1160, 1580, 1790,
   0,  750,  700,  670,  540,  410,  270,    0,  400,  550,  770, 1180, 1390,
   0,  870,  820,  790,  670,  540,  390,  130,    0,  370,  580, 1000, 1210,
   0,  970,  930,  900,  780,  640,  500,  230,  110,    0,  430,  830, 1040,
   0, 1120, 1080, 1050,  920,  790,  640,  380,  250,  150,    0,  620,  820,
   0, 1390, 1350, 1320, 1190, 1060,  920,  650,  530,  420,  280,    0,  410,
   0, 1530, 1490, 1460, 1330, 1200, 1060,  790,  670,  560,  410,  140,    0 };

char departureTimes[ 37 ][ 8 ] = { "",
   "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30",
   "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
   "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
   "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30",
   "22:00", "22:30", "23:00", "23:30" };

struct Reservation
{
   char reservationNumber[ 12 ]; // used to identify a reservation
   char trainNumber[ 8 ];  // used to identify a train
   char idNumber[ 12 ];    // the id number of the contact person
   char phone[ 12 ];       // the (local or mobile) phone number of the contact person
   char date[ 12 ];        // outbound date
   int originStation;      // the origin station code
   int destinationStation; // the destination station code
   int carClass;           // the car class code; 1:standard car, 2:business car
   int adultTickets;       // the number of adult tickets
   int concessionTickets;  // the number of concession tickets
};

struct Train
{
   char trainNumber[ 8 ];          // used to identify a train
   char departureTimes[ 13 ][ 8 ]; // the departure time of a train for each station,
};                                 // departureTimes[0] is not used

// input an integer in the range [ begin, end ]
int inputAnInteger( int begin, int end );

void makingReservation( Train southboundTimetable[ 100 ], Train northboundTimetable[ 100 ] );

// inputs originStation, destinationStation, carClass,
// date, departureTime, adultTickets and concessionTickets
void inputReservationDetails( Reservation &reservation, int &departureTime );

// loads the southbound timetable from the file "Southbound timetable.dat"
void loadSouthboundTimetable( Train southboundTimetable[ 100 ], int &numSouthboundTrains );

// loads the northbound timetable from the file "Northbound timetable.dat"
void loadNorthboundTimetable( Train northboundTimetable[ 100 ], int &numNorthboundTrains );

// displays timetables for 10 coming southbound trains, then let user select one
void selectSouthboundTrain( Train southboundTimetable[ 100 ], int numSouthboundTrains,
                            Reservation &reservation, int departureTime );

// displays timetables for 10 coming northbound trains, then let user select one
void selectNorthboundTrain( Train northboundTimetable[ 100 ], int numNorthboundTrains,
                            Reservation &reservation, int departureTime );

// inputs idNumber and phone, and randomly generate reservationNumber
void inputContactInfo( Reservation &reservation );

// save reservation to the end of the file Reservation details.dat
void saveReservation(Reservation reservation);



void reservationHistory( Train southboundTimetable[ 100 ],
                         Train northboundTimetable[ 100 ] );

// inputs idNumber and reservationNumber, and
// checks if the corresponding reservation exists
bool existReservation( fstream &ioFile, Reservation &reservation );


void displayReservations( Train southboundTimetable[ 100 ],
                          Train northboundTimetable[ 100 ], Reservation reservation );

// displays date, originStation, destinationStation, departureTime, arrival time,
// fare for adultTickets, fare for concessionTickets and total fare
void display( Reservation reservation, Train trainTimetable[ 100 ],
              char stations[ 13 ][ 12 ], char carClass[ 12 ] );

// reduces adultTickets and/or concessionTickets in reservation
void reduceSeats( fstream &ioFile, Train southboundTimetable[ 100 ],
                  Train northboundTimetable[ 100 ], Reservation &reservation );

int main()
{
   cout << "Taiwan High Speed Rail Booking System\n";
   srand( static_cast< unsigned int >( time( 0 ) ) );

   Train southboundTimetable[ 100 ];
   Train northboundTimetable[ 100 ];
   int choice; // store user choice

   // enable user to specify action
   while( true )
   {
      cout << "\nEnter Your Choice\n"
         << "1. Booking\n"
         << "2. Booking History\n"
         << "3. End Program";

      do cout << "\n? ";
      while( ( choice = inputAnInteger( 1, 3 ) ) == -1 );
      cout << endl;

      switch( choice )
      {
      case 1:
         makingReservation( southboundTimetable, northboundTimetable );
         break;
      case 2:
         reservationHistory( southboundTimetable, northboundTimetable );
         break;
      case 3:
         cout << "Thank you! Goodbye!\n\n";
         system( "pause" );
         return 0;
      default: // display error if user does not select valid choice
         cerr << "Incorrect Choice!\n";
         break;
      }
   }

   system( "pause" );
} // end main
int inputAnInteger(int begin, int end) {
	char input[100];
	cin >> input;
	if (strlen(input) > 3) {
		return -1;
	}
	if (strlen(input) == 1 && input[0] == '0'&&begin<=0) {
		return 0;
	}
	int i = atoi(input);
	if (i >= begin && i <= end) {
		return i;
	}
	else {
		return -1;
	}

}
void loadSouthboundTimetable(Train southboundTimetable[100], int& numSouthboundTrains) {
	ifstream infile("Southbound timetable.txt");
	numSouthboundTrains = 0;
	while (infile) {
		Train tmp;
		infile >> tmp.trainNumber;
		if (!infile) {
			break;
		}
		for (int i = 0; i < 12; i++) {
			infile >> tmp.departureTimes[i];
		}
		southboundTimetable[numSouthboundTrains] = tmp;
		numSouthboundTrains++;
	}


	
}
void loadNorthboundTimetable(Train northboundTimetable[100], int& numNorthboundTrains) {
	ifstream infile("Northbound timetable.txt");
	numNorthboundTrains = 0;
	while (infile) {
		Train tmp;
		infile >> tmp.trainNumber;
		if (!infile) {
			break;
		}
		for (int i = 0; i < 12; i++) {
			infile >> tmp.departureTimes[i];
		}
		northboundTimetable[numNorthboundTrains] = tmp;
		numNorthboundTrains++;
	}
}
void inputReservationDetails(Reservation& reservation, int& departureTime) {
		cout << "Origin Station\n"
			<< "1. Nangang\n"
			<< "2. Taipei\n"
			<< "3. Banqiao\n"
			<< "4. Taoyuan\n"
			<< "5. Hsinchu\n"
			<< "6. Miaoli\n"
			<< "7. Taichung\n"
			<< "8. Changhua\n"
			<< "9. Yunlin\n"
			<< "10. Chiayi\n"
			<< "11. Tainan\n"
			<< "12. Zuoying\n";
		do cout << "\n? ";
		while ((reservation.originStation = inputAnInteger(1, 12)) == -1);
		cout << endl;
		cout << "Destination Station\n"
			<< "1. Nangang\n"
			<< "2. Taipei\n"
			<< "3. Banqiao\n"
			<< "4. Taoyuan\n"
			<< "5. Hsinchu\n"
			<< "6. Miaoli\n"
			<< "7. Taichung\n"
			<< "8. Changhua\n"
			<< "9. Yunlin\n"
			<< "10. Chiayi\n"
			<< "11. Tainan\n"
			<< "12. Zuoying\n";
		do cout << "\n? ";
		while ((reservation.destinationStation = inputAnInteger(1, 12)) == -1);
		cout << endl;
		if (reservation.originStation == reservation.destinationStation) {
			return inputReservationDetails(reservation, departureTime);
		}
		cout << "Car Class\n"
			<< " 1. Standard Car\n"
			<< "2. Business Car\n";
		do cout << "\n? ";
	while ((reservation.carClass = inputAnInteger(1, 2)) == -1);
	cout << endl;
	cout << "Departure Date:8787-12-28\n";
	cout << "Departure Time\n";
	for (int i = 1; i < 35; i++) {
		cout << i << ". " << departureTimes[i] << endl;
	}
	do cout << "\n? ";
	while ((departureTime = inputAnInteger(1, 34)) == -1);
	do cout << "How many adult tickets? ";
	while ((reservation.adultTickets=inputAnInteger(1,999)) == -1);
	do cout << "How many concession tickets? ";
	while ((reservation.concessionTickets = inputAnInteger(1, 999)) == -1);
}
void inputContactInfo(Reservation& reservation) {
	cout << "Enter Contact Person Information\n\n";
	cout << "ID number: ";
	cin >> reservation.idNumber;
	cout << "Phone: ";
	cin >> reservation.phone;
	srand(time(NULL));
	for (int i = 0; i < 8; i++) {
		reservation.reservationNumber[i] = rand() % 10 + '0';
	}
	reservation.reservationNumber[8] = '\0';
	cout << "Reservation Number:" << reservation.reservationNumber;
	cout << "\nReservation Completed!\n";
}
void selectNorthboundTrain(Train northboundTimetable[100], int numNorthboundTrains,
	Reservation& reservation, int departureTime) {
	char hour[19][3] = { "06",  "07", "08", "09",
   "10",  "11", "12", "13", 
   "14",  "15",  "16", "17",
   "18",  "19", "20",  "21",
   "22",  "23" };
	

	char departhour2[88][3];

	
	cout << "Train No.  Departure  Arrival\n";
	for (int i = 0; i < numNorthboundTrains; i++) {
		strncpy_s(departhour2[i], northboundTimetable[i].departureTimes[reservation.originStation], 2);
			if (strcmp(departhour2[i], (const char*)hour[departureTime / 2]) == 0) {
				if (departureTime % 2 == 1) {
					for (int k = i; k < i + 10; k++) {
						cout << setw(9) << northboundTimetable[k].trainNumber << setw(12)
							<< northboundTimetable[k].departureTimes[reservation.originStation]
							<< setw(9) << northboundTimetable[k].departureTimes[reservation.destinationStation]<<endl;
					}
					cout << "Enter Train Number: ";
					cin >> reservation.trainNumber;
					cout << "Trip Detail\n\n";
					return;
				}
				else {
					for (int l = i; l < i + 6; l++) {
							if (northboundTimetable[l].departureTimes[reservation.originStation][3]>=3+'0') {
								for (int p = l; p < l + 10; p++) {
									cout << setw(9) << northboundTimetable[p].trainNumber << setw(12)
										<< northboundTimetable[p].departureTimes[reservation.originStation]
										<< setw(9) << northboundTimetable[p].departureTimes[reservation.destinationStation]<<endl;
								}
								cout << "Enter Train Number: ";
								cin >> reservation.trainNumber;
								cout << "Trip Detail\n\n";
								return;
							}
						
					}
				}
			}
		
	}

}
void selectSouthboundTrain(Train southboundTimetable[100], int numSouthboundTrains,
	Reservation& reservation, int departureTime) {
	char hour[19][3] = { "06",  "07", "08", "09",
"10",  "11", "12", "13",
"14",  "15",  "16", "17",
"18",  "19", "20",  "21",
"22",  "23" };
	char minute[6][3];

	char departhour2[88][3];


	cout << "Train No.  Departure  Arrival\n";
	for (int i = 0; i < numSouthboundTrains; i++) {
		/*for (int j = 0; j < 2; j++) {
			departhour2[i][j] = southboundTimetable[i].departureTimes[reservation.originStation][j];
		}*/
		strncpy_s(departhour2[i], southboundTimetable[i].departureTimes[reservation.originStation], 2);
			if (strcmp(departhour2[i], (const char*)hour[departureTime / 2]) == 0) {
				if (departureTime % 2 == 1) {
					for (int k = i; k < i + 10; k++) {
						cout << setw(8) << southboundTimetable[k].trainNumber << setw(10)
							<< southboundTimetable[k].departureTimes[reservation.originStation]
							<< setw(8) << southboundTimetable[k].departureTimes[reservation.destinationStation]<<endl;
					}
					cout << "Enter Train Number: ";
					cin >> reservation.trainNumber;
					cout << "Trip Detail\n\n";
					return;
				}
				else {
					for (int l = i; l < i + 6; l++) {
						if (southboundTimetable[l].departureTimes[reservation.originStation][3] >= 3 + '0') {
								for (int p = l; p < l + 10; p++) {
									cout << setw(9) << southboundTimetable[p].trainNumber << setw(12)
										<< southboundTimetable[p].departureTimes[reservation.originStation]
										<< setw(9) << southboundTimetable[p].departureTimes[reservation.destinationStation]<<endl;
								}
								cout << "Enter Train Number: ";
								cin >> reservation.trainNumber;
								cout << "Trip Detail\n\n";

								return;
							
						}
					}
				}
			}
		
	}

}
void makingReservation(Train southboundTimetable[100], Train northboundTimetable[100]) {
	Reservation myreservation;
	int depart;
	int numnorth = 0;
	int numsouth = 0;
	char station[13][12] = { "",
			 " Nangang",
			 " Taipei",
			 " Banqiao",
			" Taoyuan",
			 " Hsinchu",
			" Miaoli",
			 " Taichung",
			 " Changhua",
			 " Yunlin",
			 " Chiayi",
			 " Tainan",
			" Zuoying" };
	inputReservationDetails(myreservation, depart);
	if (myreservation.destinationStation < myreservation.originStation) {
		if (myreservation.carClass == 1) {
			loadNorthboundTimetable(northboundTimetable, numnorth);
			selectNorthboundTrain(northboundTimetable, numnorth, myreservation, depart);
			display(myreservation, northboundTimetable, station, (char*)"Standard Car");
		}
		else {
			loadNorthboundTimetable(northboundTimetable, numnorth);
			selectNorthboundTrain(northboundTimetable, numnorth, myreservation, depart);
			display(myreservation, northboundTimetable, station, (char*)"Business Car");
		}
	}
	else {
		if (myreservation.carClass == 1) {
			loadSouthboundTimetable(southboundTimetable, numsouth);
			selectSouthboundTrain(southboundTimetable, numsouth, myreservation, depart);
			display(myreservation, southboundTimetable, station, (char*)"Standard Car");
		}
		else {
			loadSouthboundTimetable(southboundTimetable, numsouth);
			selectSouthboundTrain(southboundTimetable, numsouth, myreservation, depart);
			display(myreservation, southboundTimetable, station, (char*)"Business Car");
		}
	}
	inputContactInfo(myreservation);
	saveReservation(myreservation);
}
void display(Reservation reservation, Train trainTimetable[100],
	char stations[13][12], char carClass[12]) {
	if (reservation.carClass == 1) {
		for (int i = 0; i < 88; i++) {
			if (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) == 0) {
				cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class\n"
					<< setw(10) << "8787-12-28" << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation]
					<< setw(10) << stations[reservation.destinationStation] << setw(11) << trainTimetable[i].departureTimes[reservation.originStation]
					<< setw(9) << trainTimetable[i].departureTimes[reservation.destinationStation]
					<< setw(6) << adultTicketPrice[reservation.originStation][reservation.destinationStation] << "*" << setw(1)
					<< reservation.adultTickets << setw(8) << adultTicketPrice[reservation.originStation][reservation.destinationStation] / 2
					<< "*" << setw(1) << reservation.concessionTickets << setw(8) <<
					adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.adultTickets
					+ adultTicketPrice[reservation.originStation][reservation.destinationStation] * reservation.concessionTickets / 2 <<
					setw(9) << carClass;
			}
		}
	}
	else {
		for (int i = 0; i < 88; i++) {
			if (strcmp(reservation.trainNumber, trainTimetable[i].trainNumber) == 0) {
				cout << "      Date  Train No.    From        To  Departure  Arrival   Adult  Concession  Fare     Class\n"
					<< setw(10) << "8787-12-28" << setw(11) << reservation.trainNumber << setw(8) << stations[reservation.originStation]
					<< setw(10) << stations[reservation.destinationStation] << setw(12) << trainTimetable[i].departureTimes[reservation.originStation]
					<< setw(10) << trainTimetable[i].departureTimes[reservation.destinationStation]
					<< setw(6) << adultTicketPrice[reservation.destinationStation][reservation.originStation] << "*" << setw(2)
					<< reservation.adultTickets << setw(8) << adultTicketPrice[reservation.destinationStation][reservation.originStation] / 2
					<< "*" << setw(2) << reservation.concessionTickets << setw(6) <<
					adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.adultTickets
					+ adultTicketPrice[reservation.destinationStation][reservation.originStation] * reservation.concessionTickets / 2 <<
					setw(9) << carClass;

			}
		}
	}
}
void saveReservation(Reservation reservation) {
	ofstream outfile("Reservation detail.dat", ios::binary | ios::app);
	outfile.write(reinterpret_cast<const char*>(&reservation), sizeof(reservation));

}
bool existReservation(fstream& ioFile, Reservation& reservation) {
	char id[10];
	char resnum[10];
	cout << "Enter ID Number:";
	cin >> id;
	cout << "Enter Reservation Number:";
	cin >> resnum;

	Reservation tmp;
	while (ioFile) {
		ioFile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
		if (strcmp(tmp.idNumber,id) == 0 && strcmp(tmp.reservationNumber,resnum) == 0) {
			reservation = tmp;
			return true;
		}
	}

	return false;
}
void displayReservations(Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation reservation) {
	char station[13][12] = { "",
			 " Nangang",
			 " Taipei",
			 " Banqiao",
			" Taoyuan",
			 " Hsinchu",
			" Miaoli",
			 " Taichung",
			 " Changhua",
			 " Yunlin",
			 " Chiayi",
			 " Tainan",
			" Zuoying" };
	cout << "Reservation Details\n\n";
	if (reservation.destinationStation < reservation.originStation) {
		if (reservation.carClass == 1)
			display(reservation, northboundTimetable, station, (char*)"Standard Car");
		else
			display(reservation, northboundTimetable, station, (char*)"Business Car");
	}
	else {
		if (reservation.carClass == 1)
			display(reservation, southboundTimetable, station, (char*)"Standard Car");
		else
			display(reservation, southboundTimetable, station, (char*)"Business Car");
	}


}
void reduceSeats(fstream& ioFile, Train southboundTimetable[100],
	Train northboundTimetable[100], Reservation& reservation) {
	Reservation tmp;
			int num = 0;
			do {
				if (reservation.adultTickets == 0)
					break;
				cout << "How many adult tickets to cancel�H";
				num = inputAnInteger(0, reservation.adultTickets);
			} while (num != -1);
			reservation.adultTickets -= num;
			do {
				if (reservation.concessionTickets == 0) {
					break;
				}
				cout << "How many concession tickets to cancel�H";
				num = inputAnInteger(0, reservation.concessionTickets);
			} while (num != -1);
			reservation.adultTickets -= num;
			tmp = reservation;
			ioFile.open("Reservation detail.dat", ios::out | ios::app | ios::binary);
			ioFile.write(reinterpret_cast<const char*>(&tmp), sizeof(tmp));
		

	
}
void reservationHistory(Train southboundTimetable[100],
	Train northboundTimetable[100]) {
	fstream iofile("Reservation detail.dat");
	Reservation my;
	Reservation deleted = {};
	if (existReservation(iofile, my)) {
		displayReservations(southboundTimetable, northboundTimetable, my);
		int choice;
		cout << "\nEnter Your Choice\n"
			<< "1. Cancellation\n"
			<< "2. Reduce\n"
			<< "3. End";
		do cout << "\n? ";
		while ((choice = inputAnInteger(1, 3)) == -1);
		cout << endl;

		switch (choice)
		{
		case 1:
			my = deleted;
			saveReservation(my);
			break;
		case 2:
			reduceSeats(iofile, southboundTimetable, northboundTimetable, my);
			break;
		case 3:
			return;
		default: // display error if user does not select valid choice
			cerr << "Incorrect Choice!\n";
			break;
		}
	}
	else {
		cout << "Reservation record not found.\n";
		return reservationHistory(southboundTimetable, northboundTimetable);
	}
}



	
