﻿#include <iostream>
#include <cstring>
#include<vector>
#include <queue>
#include <algorithm>
using namespace std;

int main()
{


   system( "pause" );
}