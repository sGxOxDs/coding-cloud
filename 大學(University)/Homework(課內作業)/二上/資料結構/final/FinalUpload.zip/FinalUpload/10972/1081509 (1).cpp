#include<cstdio>
#include<iostream>
#include<vector>
#include<cstring>
#include<string>
#include<cmath>
#include<math.h>
#include<set>
using namespace std;
const int maxn = 1005;
vector<int>v[maxn];//  Graph
vector<int>s; // stack
vector<int>compo[maxn];// SCC
set<int>S;//set for whether in stack
int low[maxn],dfn[maxn];
int cnt;
int ans;
int compoIdx;
int n, m;//n ::the number of nodes,m :: the number of edges
void init() {
	for (int i = 0; i < n; i++) {
		v[i].clear();
		compo[i].clear();
	}
	s.clear();
	S.clear();
	memset(low, 0, sizeof(low));
	memset(dfn, 0, sizeof(dfn));
	compoIdx = 0,ans = 0, cnt = 0;
}
void dfs(int now,int parent) {//  Tarjan
	low[now] = dfn[now] = ++cnt;
	s.push_back(now);
	S.insert(now);
	for (int i = 0; i < v[now].size(); i++) {
		int other = v[now][i];
		if (other == parent) continue;//link to parent
		if (!dfn[other]) {
			dfs(other, now);
			if (low[now] < low[other])	low[now] = low[now];
			else low[now] = low[other];
		//	low[now] = min(low[now], low[other]);
		}
		else if (S.count(other)) {
			if (low[now] < dfn[other])	low[now] = low[now];
			else low[now] = dfn[other];
			//low[now] = min(low[now], dfn[other]);
		}
	}
	if (low[now] == dfn[now]) {
		ans++;//ans must need to add one for new SCC
		int w;
		do {
			if (s.size() != 0) {
				w = s[s.size() - 1];
				s.pop_back();
				compo[compoIdx].push_back(w);
				S.erase(w);
			}
		} while (w != now);
		compoIdx++;
	}
}
int main() {
	while (cin >> n >> m && n&& m) {
		init();
		int  a,b;
		for (int i = 0; i < m; i++) {//unidirectional Graph created
			cin >> a >> b;
			v[a].push_back(b);
			v[b].push_back(a);
		}
		dfs(1,0);
		cout << ans << endl;
	}
	return 0;
}
/*
1 ::2
2 ::3 8
3 ::4 7
4 ::5
5 ::3 6
6 ::
7 ::6
8 ::1 7
*/