#include<iostream>
#include<vector>

using namespace std;

void dfs(bool G[1000][1000],int n)
{
	int ans = 0,b1=0,bri,now=0,time=1, p[1000][2] = { 0 };
	vector<int> path;
	vector<int> S;
	vector<int> bridge0;
	vector<int> bridge1;
	path.push_back(0);
	S.push_back(0);
	for (int i = 0; i < n; i++)
	{
		if (p[i][0] == 0)
		{
			p[i][0] = time;
			p[i][1] = time;
			bridge0.clear();
			bridge1.clear();
			time++;
			now = i;
			for (int j = 0; true; j++)
			{
				if (j == n)
				{
					if (now != i)
					{
						for (int k = 0; k < n; k++)
							if (G[now][k] && p[k][1] < p[now][1])
								p[now][1] = p[k][1];
						if (p[now][1] == p[now][0])
						{
							bridge0.push_back(path[path.size() - 2]);
							bridge1.push_back(now);
							for (bri=0;S[S.size() - 1] != now;S.pop_back())
							for (int x = 0; x < bridge0.size(); x++)
								if (S[S.size() - 1] == bridge0[x]|| S[S.size() - 1] == bridge1[x])
									bri++;
							for (int x = 0; x < bridge0.size(); x++)
								if (now == bridge0[x] || now == bridge1[x])
									bri++;
							S.pop_back();
							if (bri == 0)
								ans++;
							if (bri == 1)
								b1++;
						}
						j = now;
						path.pop_back();
						now = path[path.size() - 1];
					}
					else
					{
						if (bridge0.size() == 0)
							ans++;
						break;
					}
				}
				else if (G[now][j] && p[j][0] == 0)
				{
					path.push_back(j);
					S.push_back(j);
					G[j][now] = 0;
					now = j;
					p[now][0] = time;
					p[now][1] = time;
					time++;
					j = -1;
				}
			}
		}
	}
	ans += (b1 + 1) / 2;

	cout << ans << endl;
}

void draw(int n,int m)
{
	bool G[1000][1000] = { 0 };//��
	for (int i = 0, j, k; i < m; i++)
	{
		cin >> j >> k;
		j--;
		k--;
		G[j][k] = 1;
		G[k][j] = 1;
	}
	dfs(G,n);
}

int main()
{
	int n, m;//n�Im�u
	
	while (cin >> n)
	{
		cin >> m;
		draw(n,m);
	}
	return 0;
}