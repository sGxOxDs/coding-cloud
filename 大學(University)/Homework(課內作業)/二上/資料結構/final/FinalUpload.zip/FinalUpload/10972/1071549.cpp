#include <iostream>
#include <string>
#include <deque>
#include <stack>

using namespace std;
struct Scaryval
{
	size_t low = 0, f = 0, d = 0, pi = 0, low_s = 0, d_s = 0, pi_s = 0,cor=0;
	deque<int> undir,next;
};
void BC(deque<deque<int>> &element, deque<Scaryval> &data,stack<int> &tmp, size_t &time, int &current) {
	time = time + 1;
	data[current].d = time;
	data[current].low = time;
	tmp.push(current);
	for (deque<int>::iterator it = data[current].undir.begin()
		; it != data[current].undir.end(); it++) {
		if (data[*it].d == 0) {
			data[*it].pi = current;
			BC(element, data, tmp, time, *it);
			data[current].low = (data[current].low <= data[*it].low) ? data[current].low : data[*it].low;
		}
		else if (*it!=data[current].pi)
			data[current].low = (data[current].low <= data[*it].d) ? data[current].low : data[*it].d;
	}
	if (data[current].low == data[current].d) {
		deque<int> new_ele;
		do {
			new_ele.push_back(tmp.top());
			tmp.pop();
		} while (new_ele.back() != current);
		element.push_back(new_ele);
	}
}

void  DFS_V(deque<deque<int>>& element, deque<Scaryval>& data, size_t& time, int& current , size_t &ans) {
	data[current].cor = 1;
	time = time + 1;
	data[current].d_s = time;
	for (deque<int>::iterator it = data[current].undir.begin()
		; it != data[current].undir.end(); it++) {
		if (data[*it].cor == 0) {
			ans++;
			data[current].next.push_back(*it);
			data[*it].pi_s = current;
			DFS_V(element, data, time, *it, ans);
		}
	}
	bool judge = false;
	if (data[current].next.empty())
		ans++;
	data[current].cor = 2;
	time = time + 1;
	data[current].f = time;
}

void DFS(deque<deque<int>>& element, deque<Scaryval>& data, size_t& time, int& current , size_t &ans) {
	for (deque<int>::iterator it = data[current].undir.begin()
		; it != data[current].undir.end(); it++) {
		if (data[current].cor == 0) {
			DFS_V(element, data, time,current,ans);
		}
	}
}

int main() {
	size_t node_num = 0, edge_num = 0 ,time=0,ans = 0;
	int current = 1;
	deque<Scaryval> data;
	while (cin >> node_num >> edge_num) {
		time = 0;
		ans = 0;
		data.clear();
		deque<deque<int>> element;
		stack<int> tmp_s;
		Scaryval tmp;
		data.assign(node_num + 1, tmp);
		for (size_t n = 0; n < edge_num; n++) {
			int tmp_a = -1, tmp_b = -1;
			cin >> tmp_a >> tmp_b;
			data[tmp_a].undir.push_back(tmp_b);
			data[tmp_b].undir.push_back(tmp_a);
		}
		for (int n = 1; n < data.size(); n++) {
			if (data[n].undir.empty()) {
				data[n].undir.push_back(1);
				data[1].undir.push_back(n);
				ans++;
			}
		}
		/*BC(element, data, tmp_s, time, current);
		deque<deque<int>>::iterator it = element.begin();
			it++;
		for (;it != element.end(); it++) {
			data[element.begin()->front()].undir.push_back(it->front());
			data[it->front()].undir.push_back(element.begin()->front());
		}
		*/
		element.clear();
		while (!tmp_s.empty())
			tmp_s.pop();
		time = 0;
		current = 1;
		DFS(element, data, time, current,ans);



		cout << ans-edge_num<<endl;

		
	}
	return 0;
}