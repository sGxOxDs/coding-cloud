#include<iostream>
#include<stack>
#include<string>
#include<vector>
using namespace std;

class Node {
public:
	int d;
	int index;
	Node* pi;

	Node() { index = 0; }
	Node(int i) { index = i; }
};

class edge {
public:
	Node* frontNode;
	Node* backNode;
	edge(Node* f, Node* b) { frontNode = f; backNode = b; }
	edge() { frontNode = 0; backNode = 0; }
};


void DFS(vector<Node> v);
void DFS_VISIT(Node* u);
vector<Node*> searchV(Node* u);

//����
int time = 0;
vector<edge> myEdge;
vector<Node> myNode;
//
int main() {
	int N;
	int E;
	cin >> N >> E;
	int e = E;
	int* edgeNum = new int[N];
	for (int i = 0; i < N; i++) {
		edgeNum[i] = 0;
	}
	for (int i = 1; i <= N; i++) {
		Node tempN(i);
		myNode.push_back(tempN);
	}
	//��J��
	while (e > 0) {
		int a, b;
		cin >> a >> b;
		edge temp(&myNode[a - 1], &myNode[b - 1]);
		myEdge.push_back(temp);
		edgeNum[a - 1]++;
		edgeNum[b - 1]++;
		e--;
	}
	//reset
	DFS(myNode);

	for (int i = 0; i < myNode.size(); i++) {
		if (edgeNum[i] >= 1) {
			DFS_VISIT(&myNode[i]);
			break;
		}
	}
	//pair
	int total = 0;
	int lessEdge = 0;

	for (int i = 0; i < N; i++) {
		if (edgeNum[i] == 1)
			lessEdge += 1;
	}
	total += lessEdge / 2;
	//alone
	int t = 0;
	for (int i = 0; i < myNode.size(); i++) {
		if (myNode[i].d == 0) {
			t++;
		}
	}
	if(t != 0)
		total = total + 1 + t;
	cout << total << endl;
	return 0;
}

void DFS(vector<Node> v) {
	for (int i = 0; i < v.size(); i++) {
		v[i].d = 0;
		v[i].pi = nullptr;
	}
	time = 0;
	/*
	for (int i = 1; i < v.size(); i++) {
		if (v[i].d == 0)
			DFS_VISIT(v[i]);
	}*/
}
void DFS_VISIT(Node* u) {
	time = time + 1;
	u->d = time;
	vector<Node*> myV = searchV(u);
	//for each v belong G.Adj[u] **
	for (int i = 0; i < myV.size();i++) {
		if (myV[i]->d == 0) {
			myV[i]->pi = u;
			DFS_VISIT(myV[i]);
		}
	}
}

vector<Node*> searchV(Node* u) {
	vector<Node*> temp;
	for (int i = 0; i < myEdge.size(); i++) {
		if (myEdge[i].frontNode == u)
			temp.push_back(myEdge[i].backNode);
	}
	for (int i = 0; i < myEdge.size(); i++) {
		if (myEdge[i].backNode == u)
			temp.push_back(myEdge[i].frontNode);
	}
	return temp;
}