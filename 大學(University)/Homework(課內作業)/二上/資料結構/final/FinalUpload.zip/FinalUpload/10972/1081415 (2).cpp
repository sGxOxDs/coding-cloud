#include <iostream>
#include <vector>

struct node {
	int name = 0;
	int connect = 0;
};

int main() {
	int nodeNum, edgeNum;
	
	std::vector<int> ans;
	while (std::cin >> nodeNum >> edgeNum) {
		if (nodeNum < 2) {
			ans.push_back(0);
		}
		else {

			// input
			int noC  = 0,  // noConnect
				oneC = 0,  // oneConnect
				sum  = 0;  
			bool aloneNode = false;
			std::vector<node> graph(nodeNum + 1);  // graph[0] unuse
			for (int i = 1; i <= nodeNum; i++) {
				graph[i].name = i;
			}
			for (int i = 0; i < edgeNum; i++) {
				int tmp1, tmp2;
				std::cin >> tmp1 >> tmp2;
				graph[tmp1].connect++;
				graph[tmp2].connect++;
			}

			// compute
			for (int i = 1; i < graph.size(); i++) {  // compute connect
				if (graph[i].connect == 0) {
					noC++;
				}
				else if (graph[i].connect == 1) {
					oneC++;
				}
			}
			if (noC > 0) {  // check noC
				if (noC == graph.size() - 1) {
					sum = noC;
				}
				else {
					oneC -= 2;
					sum = noC + 1;
					aloneNode = true;
				}
			}
			if (!aloneNode || oneC > 2) {
				sum += (oneC + 1) / 2;
			}
			ans.push_back(sum);

		}
	}

	// output
	for (int i = 0; i < ans.size(); i++) {
		std::cout << ans[i] << std::endl;
	}

	return 0;
}