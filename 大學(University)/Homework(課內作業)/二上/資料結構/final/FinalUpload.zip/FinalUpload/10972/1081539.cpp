//10972
#include<iostream>
#include<vector>
#include<stack>
#include<map>
#include<set>
using namespace std;

int time = 0;

stack<int> buffer;

map<int, set<int> > b;

vector<vector<int> > com;

struct node
{
	int d=0;
	int p=0;
	int low=0;

};

void BRIDGE_CONNECT(vector<node> Node,int u);

int main()
{
	int n, m;
	while (!cin.eof())
	{
		
		cin >> n;
		cin >> m;

		b.clear();
		com.clear();
		int u, v;

		for (int i = 0; i < m; i++)
		{
			cin >> u; cin >> v;
			b[u].insert(v);
		}

		vector<node> N(n+1);

		time = 0;
		while (!buffer.empty())
			buffer.pop();

		for (int i = 1; i <= n; i++)
		{
			if (N[i].d == 0)
				BRIDGE_CONNECT(N,i);
		}

		int comN = com.size();
		int bridge = 0;
		for (int i=0;i<comN;i++)
		{
			for (int x = 0; x < comN; x++)
			{
				if (i != x)
				{
					for (int aa = 0; aa < com[i].size(); aa++)
					{
						for (int ab = 0; ab < com[x].size(); ab++)
						{
							if (b[com[i][aa]].find(com[x][ab]) != b[com[i][aa]].end())
								bridge++;
						}
					}





				}
			}

		}

		int ans = comN - bridge;

		if (ans <= 0)cout << 0;
		else cout << ans;


		cout << endl;


	}


	return 0;
}

void BRIDGE_CONNECT(vector<node> Node,int u)
{
	time = time + 1;
	Node[u].d = time;
	Node[u].low = time;
	buffer.push(u);
	set<int>::iterator it = b[u].begin();
	for (int i = 0; i < b[u].size(); i++,it++)
	{
		int v = *it;

		if (Node[v].d == 0)
		{
			Node[v].p = u;
			BRIDGE_CONNECT(Node, v);

			if (Node[v].low < Node[u].low)
				Node[u].low = Node[v].low;

			if (Node[v].low > Node[u].d)
			{
				int w;
				vector<int> bu;
				
				do {
					w = buffer.top();
					buffer.pop();
					bu.push_back(w);
				} while (w != v);
				com.push_back(bu);

			}


		}
		else if (v != Node[u].p)
		{
			if (Node[v].d < Node[u].low)
				Node[u].low = Node[v].d;
		}

	}
}
