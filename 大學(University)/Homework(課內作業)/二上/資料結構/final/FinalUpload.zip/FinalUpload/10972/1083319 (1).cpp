#include <iostream>
#include <stack>
#include <vector>
//#include <list>
#include <map>
#include <string>
using namespace std;

class NodeValue
{
public:
	vector<int> adj[ 10 ];
	int d, low;
	int p;
	int help;
};

int time, plusEage, newEage, h;
map<int, NodeValue> nodelst;
stack<int> s;

int min( int a, int b )
{
	if( a < b ) return a;
	return b;
}

void connect(int uId)
{
	map<int, NodeValue>::iterator u;
	map<int, NodeValue>::iterator v;
	map<int, NodeValue>::iterator ww;
	map<int, NodeValue>::iterator f;
	

	u = nodelst.find( uId );
	time++;
	u->second.d = time;
	u->second.low = time;
	s.push( uId );

	int vId;
	for( int i = 0; i < u->second.adj->size(); i++ )
	{
		vId = *(u->second.adj->begin() + i);
		v = nodelst.find( vId );
		if( v->second.d == 0 )
		{
			v->second.p = uId;
			connect( vId );
			u->second.low = min( u->second.low, v->second.low );
		}
		else if (u->second.p != vId )
			u->second.low = min( u->second.low, v->second.d );
	}

	if( u->second.d == u->second.low )
	{
		int w;
		do
		{
			w = s.top(); s.pop();
			ww = nodelst.find( w );
			h += ww->second.help;
		} while( w != uId );

		f = nodelst.find( u->second.p );
		if( u->second.p != 0 )
		{
			plusEage++;
			f->second.help++;
		}
	}
}

int main()
{
	int inNode, inEage;
	while( cin >> inNode >> inEage )
	{
		if( inEage == 0)//�d�I
		{
			if ( inNode > 2 )
				cout << inNode << endl;
			else if( inNode == 2 )
				cout << '1' << endl;
			else if (inNode <= 1 )
				cout << '0' << endl;
			continue;
		}

		//�إ�G
		nodelst.clear();//nodelst�M��
		map<int, NodeValue>::iterator it;
		int nodeId1, nodeId2;
		for( int i = 0; i < inEage; i++ )
		{
			cin >> nodeId1 >> nodeId2;

			it = nodelst.find( nodeId1 );
			if( it == nodelst.end() )
			{
				NodeValue tmp;
				tmp.adj->push_back( nodeId2 );
				tmp.d = tmp.low = tmp.p = tmp.help = 0;
				nodelst.insert( pair<int, NodeValue>( nodeId1, tmp) );
			}
			else
			{
				it->second.adj->push_back( nodeId2 );
			}

			it = nodelst.find( nodeId2 );
			if( it == nodelst.end() )
			{
				NodeValue tmp;
				tmp.adj->push_back( nodeId1 );
				tmp.d = tmp.low = tmp.p = tmp.help = 0;
				nodelst.insert( pair<int, NodeValue>( nodeId2, tmp ) );
			}
			else
			{
				it->second.adj->push_back( nodeId1 );
			}
		}
		
		//�s�u
		newEage = 0;
		it = nodelst.begin();
		for( int i = 0; i < nodelst.size(); i++, it++ )
		{
			if( it->second.d == 0 )
			{
				if( i != 0 )//�ϧ��_���A�q�s�s�u
				{
					nodelst.begin()->second.adj->push_back( i + 1 );
					it->second.adj->push_back( 1 );
					newEage++;

					map<int, NodeValue>::iterator iter = nodelst.begin();
					for( int j = 0; j < nodelst.size(); j++, iter++ )//d��l��
					{
						iter->second.d = 0;
					}
				}

				//��l��
				while( !s.empty() ) s.pop();
				time = plusEage = h = 0;

				connect( nodelst.begin()->first );
			}
		}
		
		plusEage -= ( h / 2 );
		if( plusEage == 0 && ( inNode - nodelst.size() ) != 0 )
			plusEage++;
		plusEage += ( inNode - nodelst.size() );//��W��node
		plusEage += newEage;

		cout << plusEage << endl;
	}

	return 0;
}