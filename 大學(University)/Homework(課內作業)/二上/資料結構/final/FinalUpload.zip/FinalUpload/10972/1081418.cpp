#include<iostream>
#include<vector>
#include<functional>
#include<algorithm>
using namespace std;
struct node {
	int u = 0;
	int low = 0;
	int p = 0;
};

int main() {
	int n, m;
	while (cin >> n >> m) {
		vector<node> g(n + 1);
		bool G[1001][1001] = {};
		for (int i = 0; i < m; i++) {
			int a, b;
			cin >> a >> b;
			G[a][b] = 1;
			G[b][a] = 1;
		}
		int time = 0;
		int ans = 0;
		int buf = 0;
		int o;
		bool emp = 1;
		vector<bool> visit(n + 1, 0);
		function<void(int)> dfs = [&](int a) {
			o = a;
			time++;
			g[a].u = time;
			g[a].low = time;
			if (!visit[a]) {
				visit[a] = 1;
				for (int j = 1; j <= n; j++) {
					if (G[a][j]) {
						
						if (!visit[j]) {
							emp = 0;
							g[j].p = a;
							dfs(j);
							g[a].low = min(g[a].low, g[j].low);
						}
						else if (g[a].p != j) {
							g[a].low = min(g[a].low, g[j].u);
						}
					}
				}
				if (g[a].low == g[a].u && emp == 0) {
					ans++;
				}
				//if (emp == 1) buf++;
			}

		};
		bool t = 0;
		int c = 0;
		if (n != 1) {
			for (int i = 1; i <= n; i++) {
				if (g[i].u == 0) {
					c++;
					o = i;
					emp = 1;
					dfs(i);
					for (int i = 0; i < n + 1; i++)
						visit[i] = 0;
					if (emp == 1)
						buf++;
					//if (emp = 0) t = 1;
				}
			}
		}
		//if (buf - 1 < 0) buf = 1;
		if (ans == n && buf == 0 && c >= 2)  ans = c * 2;
		cout << ans / 2 + buf << endl;
	}
}