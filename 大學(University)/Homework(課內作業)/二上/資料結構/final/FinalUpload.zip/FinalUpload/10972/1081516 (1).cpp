#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include<stack>
#include<algorithm>
#include<map>
using namespace std;
struct vertex {
	int integer = 0;
	vector<vertex*> Adj;
	int d = 0;
	int low = 0;
	string color = "white";
	vertex* pi = 0;
};
void BridgeC(map<int, vertex> data);
void BridgeC(map<int, vertex> data, vertex& u);
int time = 0;
int com = 0;
stack<vertex> S;
int main() {
	int Case = 0;
	while (cin >> Case) {
		int number = 0;
		cin >> number;
		int temp1, temp2;
		//vector<vertex>data(Case);
		map<int, vertex>data;
		/*for (int i = 0; i < data.size();i++) {
			data[i].integer = i + 1;
		}*/
		for (int i = 1; i <= Case; i++) {
			data[i].integer = i;
		}
		for (int i = 0; i < number; i++) {
			cin >> temp1 >> temp2;
			if (data.count(temp2)) {
				map<int,vertex> ::iterator it = data.find(temp1);
				map<int,vertex> ::iterator it1 = data.find(temp2);
				it1->second.Adj.push_back(&it->second);
				it->second.Adj.push_back(&it1->second);
			}
			else {

			}
			//data[temp1 - 1].Adj[temp1 - 1] = &data[temp2];
			//data[temp2 - 1].Adj[temp2 - 1] = &data[temp1];
		}
		BridgeC(data);
		cout << com << endl;
		while (!S.empty()) {
			S.pop();
		}
	}
}
void BridgeC(map<int, vertex> data) {
	for (map<int, vertex>::iterator it = data.begin(); it != data.end(); ++it) {
		if (it->second.d == 0 && it->second.color =="white") {
			com++;
			BridgeC(data, data[it->first]);
		}
		vertex w;
		if(!S.empty())
			do {
				w = S.top();
				S.pop();
			} while (w.d != it->second.d);
	}
}
void BridgeC(map<int, vertex> data, vertex& u) {
	time++;
	u.d = u.low = time;
	u.color = "black";
	S.push(u);
	for (int i = 0; i < u.Adj.size(); i++) {
		if (u.Adj[i]->d == 0 && u.Adj[i]->color == "white") {
			u.Adj[i]->pi = &u;
			BridgeC(data, data[u.Adj[i]->integer]);
			u.low = min(u.low, u.Adj[i]->low);
			/*if (u.Adj[i]->low > u.d) {
				vertex* w;
				if(!S.empty())
					do {
						w = &S.top();
						S.pop();
					} while (w != u.Adj[i]);
			}*/
		}
		else if (u.Adj[i] != u.pi) {
			u.low = min(u.low, data[i].d);
		}
	}
	if (u.low == u.d) {
		vertex w;
		if (!S.empty())
			do {
				w = S.top();
				S.pop();
			} while (w.d != u.d);
	}
}