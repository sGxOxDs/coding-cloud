#include <iostream>
#include <unordered_map>
#include <vector>
#include <stack>

using namespace std;

class Node {
public:
	Node() {}
	Node(int index) {
		this->idx = index;
	}
	int idx;
	vector<Node*> nei;
	vector<Node*> child;
	Node* p;
	bool isVisited = false;
	int w;
	int d;
	int bcc;

};

class Edge {
public:
	Edge() {}
	Edge(Node* n1,Node* n2) {
		this->n1 = n1;
		this->n2 = n2;
	}
	Node* n1;
	Node* n2;
};

unordered_map<int, Node*> map;
vector<Edge> bridges;
stack<Node*> st;
vector<vector<Node*> > bcc;
int leaf = 0;
int single_node = 0;

int ti = 1;

void _dfs(Node* n) {
	st.push(n);
	n->d = ti++;
	n->w = n->d;

	for (auto i : n->nei){
		if (!i->isVisited) {
			i->p = n;
			i->isVisited = true;
			n->child.push_back(i);
			_dfs(i);
		}

		if (n->p != i) {
			// set low
			if (i->w <= n->w) {
				n->w = i->w;
			}

			// check bridge
			if (i->w > n->d) {
				bridges.push_back(Edge(n,i));
			}
		}
	}

	if (n->d == n->w) {

		// add biconnected component
		int bcc_cnt = bcc.size();
		bcc.resize(bcc.size() + 1);
		while (st.top() != n) {
			bcc[bcc_cnt].push_back(st.top());
			st.top()->bcc = bcc_cnt;
			st.pop();
		}
		bcc[bcc_cnt].push_back(st.top());
		st.top()->bcc = bcc_cnt;
		st.pop();
		

	}

}

void dfs(Node* root) {
	root->d = ti++;
	root->w = root->d;
	root->isVisited = true;
	st.push(root);
	// rec nei
	for (auto i : root->nei) {
		if (!i->isVisited) {
			i->p = root;
			i->isVisited = true;
			root->child.push_back(i);
			_dfs(i);
		}
		// check bridge
		if (i->w > root->d) {
			bridges.push_back(Edge(root, i));
		}
	}

	int bcc_cnt = bcc.size();
	bcc.resize(bcc.size() + 1);
	while (st.top() != root) {
		bcc[bcc_cnt].push_back(st.top());
		st.top()->bcc = bcc_cnt;
		st.pop();
	}
	bcc[bcc_cnt].push_back(st.top());
	st.top()->bcc = bcc_cnt;
	st.pop();
}

void _dfs2(Node* n) {
	n->isVisited = true;

	if (n->nei.size() == 1) {
		leaf++;
		return;
	}
	for (auto i : n->nei) {
		if (!i->isVisited) {
			i->p = n;
			n->child.push_back(i);
			_dfs2(i);
		}
	}
}

void dfs2(Node* root) {
	root->isVisited = true;
	
	if (root->nei.size() == 0) {
		single_node++;
		return;
	}

	if (root->nei.size() == 1) {
		leaf++;
	}

	for (auto i : root->nei) {
		if (!i->isVisited) {
			i->p = root;
			root->child.push_back(i);
			_dfs2(i);
		}
	}
	
}

int main() {
	int M, N;
	//vector<int> ans;
	while (cin >>N>>M) {

		// create map
		for (int i = 1; i <= N; i++) {
			map[i] = new Node(i);
		}
		int n1, n2;
		while (M--) {
			cin >> n1 >> n2;
			map[n1]->nei.push_back(map[n2]);
			map[n2]->nei.push_back(map[n1]);
		}
		
		for (auto i : map) {
			if (!i.second->isVisited) {
				dfs(i.second);
			}
		}

		unordered_map<int,Node*> bigMap;
		for (int i = 0; i < bcc.size(); i++) {
			bigMap[i] = new Node(i);
		}
		for (auto i : bridges) {
			bigMap[i.n1->bcc]->nei.push_back(bigMap[i.n2->bcc]);
			bigMap[i.n2->bcc]->nei.push_back(bigMap[i.n1->bcc]);
		}

		if (bigMap.size() == 1) {
			cout << "0" << endl;
			//ans.push_back(0);
		} else {

			for (auto i : bigMap) {
				if (!i.second->isVisited) {
					dfs2(i.second);
				}
			}


			if (leaf % 2) {
				leaf++;
			}
			cout << leaf / 2 + single_node << endl;
			//ans.push_back(leaf / 2 + single_node);
		}

		leaf = 0;
		single_node = 0;

		for (auto i : map) {
			delete i.second;
		}
		map.clear();
		for (auto i : bigMap) {
			delete i.second;
		}
		st = stack<Node*>();
		ti = 1;
		bcc.clear();
		bridges.clear();
	}
	/*
	cout << "\n\n\n\n\n" << endl;
	for (auto i : ans) {
		cout << i << endl;
	}
	*/
}