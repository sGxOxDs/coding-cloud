#include<iostream>
#include<vector>
#include<stack>
using namespace std;

void dfs(int point, vector<vector<int>> graph, int num, const int m, int a)
{
	if (num < m)
	{
		for (auto it = graph[point].begin(); it != graph[point].end(); ++it)
		{
			auto it1 = graph[*it].begin();
			for (; it1 != graph[*it].end(); ++it1)
			{
				if (*it1 == point)
					break;
			}
			graph[*it].erase(it1);
			break;
		}
		dfs(graph[point][a], graph, num + 1, m, a);
		if (a + 1 < graph[point].size())
			dfs(graph[point][a], graph, num + 1, m, a + 1);
	}
}

int main()
{
	int n, m;
	
	while (cin >> n >> m)
	{
		vector<vector<int>> graph(1000);
		vector<vector<int>> cop = graph;
		vector<vector<bool>> check(1000);

		for (int i = 0; i < 1000; i++)
		{
			for (int j = 0; j < check[i].size(); j++)
				check[i][j] = 0;
		}

		int node1, node2;
		for (int i = 0; i < m; i++)
		{
			cin >> node1 >> node2;
			graph[node1].push_back(node2);
			graph[node2].push_back(node1);
		}

		//stack<int> dfs;
		for (int i = 1; i < m + 1; i++)
		{
			dfs(i, graph, 1, m, 0);

			//if (check[i][0] == 0)
			//{
			//	dfs.push(i);
			//	check[i][0] = 1;

			//}
		}
	}

}