#include <iostream>
#include <algorithm>
#include <vector>
#include <functional>
#include <stack>
#include <unordered_set>

using namespace std;

struct graph
{
	vector< int > adj;
	int d = 0;
	int low = 0;
	graph* p = NULL;
};

int main()
{
	int edge, cases;
	while (cin >> edge >> cases)
	{
		vector< graph >G(edge + 1);
		vector< int >comp(edge + 1);
		vector< int > bridge;

		int u, v;
		while (cases--)
		{
			cin >> u >> v;
			G[u].adj.push_back(v);
			G[v].adj.push_back(u);
		}

		int time = 0, ans = 0;
		stack<int>S;
		function< void(int) > BCC = [&](int u)
		{
			G[u].d = G[u].low = ++time;
			S.push(u);
			for (auto v : G[u].adj)
			{
				if (G[v].d == 0)
				{
					G[v].p = &G[u];
					BCC(v);
					G[u].low = min(G[u].low, G[v].low);
					/*if (G[v].low > G[u].d)
						bridge.push_back(u);*/
				}
				else if (&G[v] != G[u].p)
					G[u].low = min(G[u].low, G[v].d);
			}
			if (G[u].low == G[u].d)
			{
				int w;
				bridge.push_back(u);
				do
				{
					w = S.top();
					S.pop();
					comp[w] = ans;
				} while (w != u);
				++ans;
			}
		};

		int bridge0 = 0;
		for (int i = 1; i <= edge; ++i)
			if (G[i].d == 0)
			{
				int size = bridge.size();
				BCC(i);
				if (size + 1 == bridge.size()) ++bridge0;
			}

		if (bridge.size() == 1 && bridge0 == 1) cout << "0\n";
		else
		{
			int bridge1 = 0;
			vector< int > deg(ans);
			for (int i = 0; i < ans; ++i)
			{
				if (bridge[i] == 1)
					continue;
				for (auto v : G[bridge[i]].adj)
					if (comp[v] != comp[bridge[i]])
						deg[i]++;
			}
			for (int i = 0; i < ans; ++i)
				if (deg[i] == 1)
					++bridge1;
			cout << bridge0 + (bridge1 + 1) / 2 << endl;
		}

	}
}