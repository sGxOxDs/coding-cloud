#include <iostream>
#include <stack>
#include <vector>
#include <algorithm>

using namespace std;

struct Element {
	int d = 0;
	int low = 0;
	Element* p = nullptr;
};

void BridgeConnect(vector< Element > node, vector< vector< int > > G, Element u, int time, stack< int > s, vector< vector< int > > comp, int cur)
{
	time += 1;
	u.d = time;
	u.low = time;
	s.push(u.d);
	for (int i = 0; i < G[u.d].size(); i++)
	{
		auto v = node[G[u.d][i]];
		if (v.d == 0)
		{
			v.p = &u;
			BridgeConnect(node, G, v, time, s, comp, cur);
			u.low = min(u.low, v.low);
		}
		else if (&v != u.p)
			u.low = min(u.low, v.d);
	}

	if (u.low == u.d)
	{
		vector< int > temp;
		comp.push_back(temp);
		int w;
		do {
			w = s.top();
			s.pop();
			comp[cur].push_back(w);
		} while (w != u.d);
		cur++;
	}
}

int main() {
	int n, m; // n cities, m roads
	while (cin >> n >> m)
	{
		vector< vector< int > > graph(n + 1);
		vector< Element > node(n + 1);

		int city1, city2;
		int time = 0;
		for (int i = 0; i < m; ++i)
		{
			cin >> city1 >> city2;
			graph[city1].push_back(city2);
			graph[city2].push_back(city1);
		}

		stack< int > s;
		vector< vector< int > > component;
		int current = 0;
		for (int i = 1; i < node.size(); i++)
			if (node[i].d == 0)
				BridgeConnect(node, graph, node[i], time, s, component, current);

		cout << component.size() << endl;
	}
}