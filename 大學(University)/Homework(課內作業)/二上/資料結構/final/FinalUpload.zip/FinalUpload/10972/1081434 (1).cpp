#include<vector>
#include<iostream>
#include<stack>
#include<algorithm>

using namespace std;

struct element {
	int d = 0;
	int low = 0;
	int pi = 0;
	int bridgeNum = 0;
};

vector<vector<int>> G;
vector<element> SetOfPoints;
int times = 0;
stack<int> BCbuffer;
vector<vector<int>> SetOfBCbuffer;

void BridgeConnect(int position) {
	times++;
	SetOfPoints[position].d = times;
	SetOfPoints[position].low = times;
	BCbuffer.push(position + 1);
	for (int i = 0; i < G[position].size(); i++) {
		if (SetOfPoints[G[position][i] - 1].d == 0) {
			SetOfPoints[G[position][i] - 1].pi = position + 1;
			BridgeConnect(G[position][i] - 1);
			SetOfPoints[position].low = min(SetOfPoints[position].low, SetOfPoints[G[position][i] - 1].low);
			if (SetOfPoints[G[position][i] - 1].low > SetOfPoints[position].d) {
				SetOfPoints[G[position][i] - 1].bridgeNum++;
				SetOfPoints[position].bridgeNum++;
			}
		}
		else if(SetOfPoints[position].pi!= G[position][i])
			SetOfPoints[position].low = min(SetOfPoints[position].low, SetOfPoints[G[position][i] - 1].d);
	}
	if (SetOfPoints[position].low == SetOfPoints[position].d) {
		int w = 0;
		vector<int> temp;
		do {
			w = BCbuffer.top();
			temp.push_back(w);
			BCbuffer.pop();
		} while (w != position + 1);
		SetOfBCbuffer.push_back(temp);
	}
}

int main() {
	int points = 0;
	while (cin >> points) {
		G.clear();
		SetOfPoints.clear();
		times = 0;
		int roads = 0,temp1,temp2;
		
		cin >> roads;
		if (points == 0&& roads==0) {
			cout << '0' << endl;
			continue;
		}
		G.resize(points);
		for (int i = 0; i < roads; i++) {
			cin >> temp1 >> temp2;
			G[temp1 - 1].push_back(temp2);
			G[temp2 - 1].push_back(temp1);
		}
		SetOfPoints.resize(points);
		SetOfBCbuffer.clear();
		for (int i = 0; i < SetOfPoints.size(); i++) {
			if (SetOfPoints[i].d == 0) {
				BridgeConnect(i);
			}
		}
		int BridgeOneNum = 0;
		int BridgeZeroNum = 0;
		for (int i = 0; i < SetOfBCbuffer.size(); i++) {
			int BridgeNum = 0;
			for (int j = 0; j < SetOfBCbuffer[i].size(); j++) {
				BridgeNum += SetOfPoints[SetOfBCbuffer[i][j] - 1].bridgeNum;
			}
			if (BridgeNum == 0)
				BridgeZeroNum++;
			else if (BridgeNum == 1)
				BridgeOneNum++;
		}
		if (SetOfBCbuffer.size() == 1)
			cout << '0' << endl;
		else if (BridgeOneNum >= 1) {
			if (BridgeZeroNum == 0)
				cout << (BridgeOneNum+1) /2<< endl;
			else {
				if (BridgeZeroNum > BridgeOneNum) {
					cout << ((BridgeOneNum - 1) / 2) + BridgeZeroNum + 1 << endl;
					//cout << BridgeOneNum+(BridgeZeroNum- BridgeOneNum)+1<< endl;
				}
				else if(BridgeZeroNum == BridgeOneNum)
					cout << (BridgeZeroNum + 1)/2+ BridgeZeroNum << endl;
				else {
					cout << ((BridgeOneNum - 1) / 2 )+BridgeZeroNum + 1 << endl;
					//cout << BridgeZeroNum * 2 +(BridgeOneNum- BridgeZeroNum * 2+1)/2<< endl;
				}
			}
		}
		else {
			if (BridgeZeroNum == SetOfBCbuffer.size())
				cout << BridgeZeroNum<< endl;
			else
				cout << BridgeZeroNum+1 << endl;
		}
		points = 0;
	}
}