#include<iostream>
#include<vector>
#include<algorithm>
#include<stack>
using namespace std;

vector<int>edges[ 1001 ];
vector<pair<int, int>>bridges;
int d[ 1001 ], low[ 1001 ], parents[ 1001 ], belong[ 1001 ], de[ 1001 ];
bool inStack[ 1001 ];
int Time, bcc_count;
stack<int>s;
void BRIDGECONNECTED( int );

int main()
{
	int n, m;
	while( cin >> n >> m )
	{
		Time = bcc_count = 0;
		for( int i = 0; i <= n; i++ )
		{
			edges[ i ].clear();
			d[ i ] = low[ i ] = belong[ i ] = de[ i ] = 0;
			inStack[ i ] = false;
			parents[ 1 ] = -1;
		}
		bridges.clear();
		while( !s.empty() )
			s.pop();

		int u, v;
		for( int i = 0; i < m; i++ )
		{
			cin >> u >> v;
			edges[ u ].push_back( v );
			edges[ v ].push_back( u );
		}

		for( int i = 1; i <= n; i++ )
		{
			if( !d[ i ] )
			{
				BRIDGECONNECTED( i );

				bcc_count++;
				int w;
				while( !s.empty() )
				{
					w = s.top();
					s.pop();
					inStack[ w ] = false;
					belong[ w ] = bcc_count;
					if( w == i )
						break;
				}
			}
		}

		int res = 0;
		if( bcc_count == 1 )
		{
			cout << 0 << endl;
			continue;
		}

		for( int i = 0; i < bridges.size(); i++ )
		{
			int u = bridges[ i ].first;
			int v = bridges[ i ].second;
			de[ belong[ u ] ]++;
			de[ belong[ v ] ]++;
		}

		for( int i = 1; i <= bcc_count; i++)
		{
			if( de[ i ] == 0 )
				res += 2;
			else if( de[ i ] == 1 )
				res++;
		} 
		cout << ( res + 1 ) / 2 << endl;
	}
}

void BRIDGECONNECTED( int u )
{
	d[ u ] = low[ u ] = ++Time;
	s.push( u );
	inStack[ u ] = true;

	for( int i = 0; i < edges[ u ].size(); i++ )
	{
		int v = edges[ u ][ i ];
		if( !d[ v ] )
		{
			parents[ v ] = u;
			BRIDGECONNECTED( v );
			low[ u ] = min( low[ u ], low[ v ] );
			if( low[ v ] > d[ u ] )
			{
				bridges.push_back( make_pair( u, v ) );
				bcc_count++;

				while( true )
				{
					int w = s.top();
					s.pop();
					inStack[ w ] = false;
					belong[ w ] = bcc_count;
					if( w == v )
						break;
				}
			}
		}
		else if( v != parents[ u ] )
			low[ u ] = min( low[ u ], d[ v ] );
	}
}