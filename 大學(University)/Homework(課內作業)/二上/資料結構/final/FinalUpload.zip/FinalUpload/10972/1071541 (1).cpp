#include<iostream>
#include<string>
#include<sstream>
#include<stack>
using namespace std;

int numPoint;
int numBri;
int tree[1001][1001] = {};
int time;
stack<int> s;
int counter;

struct n
{
	int num = 0;
	int d = 0;
	int pi;
	//n* pi;
	int low = 0;
};


void bridgeconnect(n *graph, n u)
{
	n w;
	time = time + 1;
	u.d = time;
	u.low = time;
	s.push(u.num);

	for (int i = 1; i <= numPoint; i++)
	{
		if (tree[u.num][graph[i].num] == 1 && u.d == 0)//u.pi !=graph[i].num)
		{
			n v = graph[i];
			if (v.d == 0)
			{
				v.pi = u.num;
				bridgeconnect(graph,v);
				if (v.low < u.low)
				{
					u.low = v.low;
				}
				//cout << u.low << " " << u.d << endl;
				if (u.low == u.d)
				{
					counter++;
					do 
					{
						w.num = s.top();
						s.pop();
					} while (w.num != v.num);
				}
					
			}
			else if (v.num != u.pi)
			{
				if (u.low < v.d)
					u.low = v.d;
			}

		}
	}

}

int main()
{
	string line;
	time = 0;
	counter = 0;
	while (getline(cin, line))
	{
		stringstream ss(line);
		ss >> numPoint >> numBri;

		for (int i = 0; i < numBri; i++)
		{
			int a, b;
			getline(cin, line);
			stringstream ss1(line);
			ss1 >> a >> b;
			tree[a][b] = 1;
			tree[b][a] = 1;
		}
		n graph[1001];
		for (int i = 1; i < numPoint; i++)
		{
			graph[i].num = i;
			//graph[i].low = i;
		}

 		for (int i = 1; i <= numPoint; i++)
		{
			if (graph[i].d == 0)
			{
				bridgeconnect(graph, graph[i]);
			}
		}

		cout << counter << endl;
	}
}