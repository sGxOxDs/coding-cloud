#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <stack>

using namespace std;

void BRIDGECONNECT();
void bridgeconnect( int place, int time );

struct L {
	int first;
	int second;
	bool pass = false;
	bool bridge = false;
};

struct N {
	int low;
	int d;
	int pi = 0;
	int count = 0;
};

int node, line, component = 0, bridge = 0, last;
vector <L> allL;
vector <N> allN;

int main()
{
	while( cin >> node >> line ) {
		int answer = 0;
		component = 0;
		allL.resize( line );
		allN.resize( node + 1 );
		for( int i = 0; i < line; i++ ) {
			cin >> allL[ i ].first;
			cin >> allL[ i ].second;
		}
		BRIDGECONNECT();

	}
}

void BRIDGECONNECT()
{
	for( int i = 1; i < allN.size(); i++ ) {
		allN[ i ].d = 0;
		allN[ i ].pi = 0;
	}
	int time = 0;
	for( int i = 1; i < allN.size(); i++ ) {
		if( allN[ i ].d == 0 ) {
			component++;
			bridgeconnect( i, time );
		}
	}
}
//u == place
void bridgeconnect( int place, int time )
{
	time++;
	allN[ place ].d = time;
	allN[ place ].low = time;
	for( int i = 0; i < allL.size(); i++ ) {
		if( allL[ i ].first == place && allL[ i ].pass == false ) {// allL[i].second == v
			allL[ i ].pass = true;
			if( allN[ allL[ i ].second ].d == 0 ) {
				allN[ allL[ i ].second ].pi = place;
				bridgeconnect( allL[ i ].second, time );
				if( allN[ place ].low > allN[ allL[ i ].second ].low )
					allN[ place ].low = allN[ allL[ i ].second ].low;
				if( allN[ allL[ i ].second ].low > allN[ place ].d ) {
					component++;
					allL[ i ].bridge = true;
				}
			}
			else if( allL[ i ].second != allN[ place ].pi ) {
				if( allN[ place ].low > allN[ allL[ i ].second ].d )
					allN[ place ].low = allN[ allL[ i ].second ].d;
			}
		}
		else if( allL[ i ].second == place && allL[ i ].pass == false ) {// allL[i].first == v
			allL[ i ].pass = true;
			if( allN[ allL[ i ].first ].d == 0 ) {
				allN[ allL[ i ].first ].pi = place;
				bridgeconnect( allL[ i ].first, time );
				if( allN[ place ].low > allN[ allL[ i ].first ].low )
					allN[ place ].low = allN[ allL[ i ].first ].low;
				if( allN[ allL[ i ].first ].low > allN[ place ].d ) {
					component++;
					allL[ i ].bridge = true;
				}
			}
			else if( allL[ i ].first != allN[ place ].pi ) {
				if( allN[ place ].low > allN[ allL[ i ].first ].d )
					allN[ place ].low = allN[ allL[ i ].first ].d;
			}
		}
	}
}
