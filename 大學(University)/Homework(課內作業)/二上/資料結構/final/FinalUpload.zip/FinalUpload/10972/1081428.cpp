#include <iostream>
#include <vector>
#include <map>
#include <stack>
#include <algorithm>
#include <queue>
#include <set>
using namespace std;

struct node {
	vector<node*> neighbor;
	int id, low, d, pi;
	node(int i) {
		id = i;
		d = 0;
		pi = 0;
	}
};

int time = 0;
stack<node*> st;

void BrigeConnect(int last,int now,map<int,node*>& map) {
	time += 1;
	auto nowNode = map[now];
	nowNode->d = nowNode->low = time;
	st.push(nowNode);
	for (auto nei : nowNode->neighbor) {
		if (nei->d == 0) {
			nei->pi = nowNode->id;
			BrigeConnect(now, nei->id, map);
			nowNode->low = min(nowNode->low, nei->d);
		}
		else if (nei->id != nowNode->pi)
			nowNode->low = min(nowNode->low, nei->d);
	}
}


int main() {
	int n, m;
	while (cin >> n >> m) {
		map<int, node*> cityMap;
		while (m--) {
			int This, Next;
			cin >> This >> Next;
			if (!cityMap.count(This)) {
				cityMap[This] = new node(This);
				if (!cityMap.count(Next)) {
					cityMap[Next] = new node(Next);
				}
				cityMap[This]->neighbor.push_back(cityMap[Next]);
			}
			else {
				if (!cityMap.count(Next)) {
					cityMap[Next] = new node(Next);
				}
				cityMap[This]->neighbor.push_back(cityMap[Next]);
			}
		}
		//int now = 1;
		//time = 0;
		//time += 1;
		//auto nowNode = cityMap[now];
		//nowNode->d = nowNode->low = time;
		//st.push(nowNode);
		//for (auto nei : nowNode->neighbor) {
		//	if (nei->d == 0) {
		//		nei->pi = nowNode->id;
		//		BrigeConnect(now, nei->id, cityMap);
		//		nowNode->low = min(nowNode->low, nei->d);
		//	}
		//	else if (nei->id != nowNode->pi)
		//		nowNode->low = min(nowNode->low, nei->d);
		//}

		int time = 0;
		vector<bool> isStrong(n, false);
		for (int i = 1; i <= n; i++) {
			auto current = cityMap[i];
			if (current == nullptr)
				continue;
			time += 1;
			current->d = current->low = time;
			for (auto nei : current->neighbor) {
				if (nei->d == 0) {
					nei->pi = current->id;
					BrigeConnect(current->id, nei->id, cityMap);
					current->low = min(current->low, nei->low);
				}
				else if (nei->id != current->pi)
					current->low = min(current->low, nei->d);
			}
			while (!st.empty()) {
				isStrong[st.top()->id - 1] = true;
				st.pop();
			}
		}
		int answer = 0;
		for (int i = 0; i < isStrong.size();i++) {
			if (isStrong[i] == false) {
				if (cityMap.count(i + 1)) {
					answer += 1;
				}
				else {
					answer += 2;
				}
			}
		}

		cout << answer << endl;
		/*while (true) {
			bool isGoing = false;
			time += 1;
			auto nownode = cityMap[now];
			nownode->t = nownode->d = nownode->low = time;
			st.push(nownode);
			for (auto nei : nownode->neighbor) {
				if (nei->d == 0) {
					nei->pi = nownode->id;
					now = nei->id;
					isGoing = true;
					break;
				}
				else if(nei->id!=nownode->pi){
					nownode->low = min(nownode->low, nei->d);
				}
			}
			if (isGoing) {
				continue;
			}
			if (nownode->low == nownode->d) {
				cout << endl;
			}
		}*/
	}
}