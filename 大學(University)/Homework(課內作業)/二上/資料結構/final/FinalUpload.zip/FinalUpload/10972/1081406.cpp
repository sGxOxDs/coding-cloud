#include<iostream>
#include<vector>
#include<set>
#include<stack>
#include<algorithm>
#include<list>

using namespace std;
struct Node {
	int value = -1;
	int d = 0;
	int low = 0;
	int parent = -1;
	vector<pair<int, int> >edg;
};
int findmypos(int myval);

int findmyedgpos(int pos, int myval);

void strongstart();

void strongconnect(int u);

bool checkinstack(int value);

void transformundirected();

void bridgestart();

void bridgeconnect(int u);

int time = 0;
stack<int> compstack;
list<vector<Node> >allcomp;
vector<Node> myvec;
vector<Node> component;
int main() {
	int n,m;//1 =< n =< 1000
	
	while (cin >> n >> m)
	{
		myvec.clear();
		vector<pair<int, int> >myedge;
		set<int> nodeval;
		for (int i = 0; i < m; i++) {
			int u, v;//1 =< u,v =< 1000
			cin >> u >> v;
			nodeval.insert(u);
			nodeval.insert(v);
			myedge.push_back(pair<int, int>(u, v));
		}

		while (!nodeval.empty()) {
			Node temp;
			temp.value = *nodeval.begin();
			for (unsigned int i = 0; i < myedge.size(); i++) {
				if (myedge[i].first == temp.value) {				
					temp.edg.push_back(myedge[i]);
				}
				else if (myedge[i].second == temp.value) {
					pair<int, int>ddd;
					ddd.first = myedge[i].second;
					ddd.second = myedge[i].first;
					temp.edg.push_back(ddd);
				}
			}
			myvec.push_back(temp);
			nodeval.erase(*nodeval.begin());
		}

		//Debug only -- output the inputted undirected graph
		/*for (unsigned int lkl = 0; lkl < myvec.size(); lkl++) {
			cout << "Node " << myvec[lkl].value << " ";
			for (unsigned int dr = 0; dr < myvec[lkl].edg.size(); dr++) {
				cout << "(" << myvec[lkl].edg[dr].first << "," << myvec[lkl].edg[dr].second << ") ";
			}
			cout << endl;
		}*/

		

		//Debug only -- output the directed graph
		/*for (unsigned int lkl = 0; lkl < myvec.size(); lkl++) {
			cout << "Node " << myvec[lkl].value << " ";
			for (unsigned int dr = 0; dr < myvec[lkl].edg.size(); dr++) {
				cout << "(" << myvec[lkl].edg[dr].first << "," << myvec[lkl].edg[dr].second << ") ";
			}
			cout << endl;
		}*/

		bridgestart();
		
		cout << allcomp.size() << endl;
		//transform graph into directed
		transformundirected();
		
		strongstart();
		
		//Debug only -- output all strongly connected component
		/*int tempcount = 0;
		for (auto it = allcomp.begin(); it != allcomp.end(); it++,tempcount++) {
			cout << "Component " << tempcount<<": ";
			for (unsigned int kl = 0; kl < it->size();kl++) {
				auto fsfs = it->begin() + kl;
				cout << fsfs->value << " ";
			}
			cout << endl;
		}*/
	}
}

int findmypos(int myval) {
	for (unsigned int i = 0; i < myvec.size(); i++) {
		if (myvec[i].value == myval) {
			return i;
		}
	}
	return -1;
};

int findmyedgpos(int pos, int myval) {
	if (pos == -1)return -1;
	for (unsigned int i = 0; i < myvec.size(); i++) {
		if (myvec[pos].edg[i].second == myval) {
			return i;
		}
	}
	return -1;
}

void strongstart()
{
	allcomp.clear();
	component.clear();
	time = 0;
	while (!compstack.empty()) {
		compstack.pop();
	}
	for (unsigned int i = 0; i < myvec.size(); i++) {	
		if (myvec[i].d == 0) {
			strongconnect(i);
			component.clear();
			while (!compstack.empty()) {
				component.push_back(myvec[compstack.top()]);
				compstack.pop();
			}
			if (!component.empty())allcomp.push_back(component);
			component.clear();
		}		
	}

	
/*
		STRONGStart
		1	for each vertex u of G.V
		2		u.d = 0
		3	time = 0
		4	let S be an empty vertex stack
		5	for each vertex u of G.V
		6		if u.d == 0
		7			STRONG-CONNECT(G, u)
		*/
}

void strongconnect(int u)
{
	time++;
	myvec[u].d = time;
	myvec[u].low = time;
	compstack.push(u);
	for (unsigned int i = 0; i < myvec[u].edg.size(); i++) {
		int v = findmypos(myvec[u].edg[i].second);
		if (myvec[v].d == 0) {
			strongconnect(v);
			myvec[u].low = min(myvec[u].low, myvec[v].d);
		}
		else if (myvec[v].d < myvec[u].d && checkinstack(v)) {
			myvec[u].low = min(myvec[u].low, myvec[v].d);
		}
	}
	if (myvec[u].low == myvec[u].d) {
		int w;
		do{
			w = compstack.top();
			compstack.pop();
			component.push_back(myvec[w]);
		} while (w != u && myvec[w].d >= myvec[u].d);
		allcomp.push_back(component);
		component.clear();
	}
	/*
	STRONG-CONNECT(G, u)
		1	time = time + 1
		2	u.d = time
		3	u.low = time
		4	PUSH(u, S)
		5	for each v in G.Adj[u]
		6		if v.d == 0
		7			STRONG-CONNECT(G, v)
		8			u.low = min(u.low, v.low)
		9		else if v.d < u.d and v inside S
		10			u.low = min(u.low, v.d)
		11	if u.low == u.d
		12		start new component
		13		do
		14			w = POP(S)
		15			put w in current component
		16		while w != u and w.d >= u.d
		*/
}
;

bool checkinstack(int value) {
	stack<int>temp(compstack);
	while (!temp.empty()) {
		if (value == temp.top()) {
			return true;
		}
		temp.pop();
	}
	return false;
};

void transformundirected() {

	for (unsigned int i = 0; i < myvec.size(); i++) {
		for (unsigned int p = 0; p < myvec[i].edg.size(); p++) {
			if (myvec[i].edg[p].first > myvec[i].edg[p].second) {
				int pos = findmypos(myvec[i].edg[p].second);
				int edgpos = findmyedgpos(pos, myvec[i].edg[p].first);
				if (edgpos >= 0) {
					auto it = myvec[i].edg.begin() + p;
					myvec[i].edg.erase(it);
					p--;
				}
			}
		}
	}
}

void bridgestart()
{
	time = 0;
	allcomp.clear();
	component.clear();
	while (!compstack.empty()) {
		compstack.pop();
	}
	for (unsigned int i = 0; i < myvec.size(); i++) {
		if (myvec[i].d == 0) {
			bridgeconnect(i);
		}
		component.clear();
		while (!compstack.empty()) {
			int w = compstack.top();
			compstack.pop();
			component.push_back(myvec[w]);
		}
		if(!component.empty()) allcomp.push_back(component);
	}
	/*BRIDGE()
	1   for each vertex u in G.V
	2          u.d = 0
	3          u.parent =  NIL
	4   time = 0
	5   let S be an empty node stack
	6   for each vertex u in G.V
	7          if u.d == 0
	8              BRIDGE-CONNECT(G, u)
	9              start new component
	10              while not STACK-EMPTY(S)
	11                        w = POP(S)
	12                        put w in cur. comp.

	*/
}

void bridgeconnect(int u)
{
	time++;
	myvec[u].d = time;
	myvec[u].low = time;
	compstack.push(u);
	for (unsigned int i = 0; i < myvec[u].edg.size(); i++) {
		int v = findmypos(myvec[u].edg[i].second);
		if (myvec[v].d == 0) {
			myvec[v].parent = u;
			bridgeconnect(v);
			myvec[u].low = min(myvec[u].low, myvec[v].low);
			if (myvec[v].low > myvec[u].d) {
				component.clear();
				int w;
				do {
					w = compstack.top();
					compstack.pop();
					component.push_back(myvec[w]);
				} while (w != v);
				allcomp.push_back(component);
			}
		}
		else if (v != myvec[u].parent) {
			myvec[u].low = min(myvec[u].low, myvec[v].d);
		}
	}
	/*BRIDGE-CONNECT(G, u)
	1	time = time + 1
	2	u.d = time
	3	u.low = time
	4	PUSH(u, S)
	5	for	each v in G.Adj[u]
	6		if	v.d == 0
	7			v.parent = u
	8			BRIDGE-CONNECT(G, v)
	9			u.low = min(u.low, v.low)
	10			if	v.low > u.d
	11				start new component
	12				do
	13					w = POP(S)
	14					put w in cur. comp.
	15				while w != v
	16		else if v != u.parent
	17				u.low = min(u.low, v.d)
*/
}
