#include<iostream>
#include<vector>
#include<string>
using namespace std;
#define min(a, b) (a < b)? a : b

int maxLow;
int* d, * low;
vector<vector<int>> edge;

void init(int n)
{
	for (int i = 0; i < edge.size(); i++)
		edge[i].clear();
	edge.resize(n);
	d = new int[n]();
	low = new int[n]();
	maxLow = 1;
}

int dfs(int p, int u, int& time)
{
	d[u] = low[u] = ++time;
	int count = 0;
	int v;
	for (int i = 0; i < edge[u].size(); i++)
	{
		v = edge[u][i];
		if (d[v] == 0)
		{
			count += dfs(u, v, time);
			low[u] = min(low[u], low[v]);
		}
		else if(v != p)
			low[u] = min(low[u], d[v]);
	}

	if (low[u] > maxLow)
	{
		maxLow = low[u];
		count++;
	}
	return count;
}

int main()
{
	int nodeNum, edgeNum;
	while (cin >> nodeNum >> edgeNum)
	{
		init(nodeNum + 1);
		int u, v;
		for (int i = 0; i < edgeNum; i++)
		{
			cin >> u >> v;
			edge[u].push_back(v);
			edge[v].push_back(u);
		}
		int groupNum = 0, leafNum = 0, time = 0;
		if (nodeNum > 0)
		{
			int leaf;
			for (int i = 1; i <= nodeNum; i++)
				if (d[i] == 0)
				{
					leaf = dfs(0, i, time);
					if (leaf > 2 || (i == 1 && leaf == 1))
						leafNum += leaf;
					else
						groupNum++;
				}
		}

		if (groupNum == 1 && leafNum == 0)
			cout << 0 << endl;
		else
			cout << (groupNum * 2 + leafNum + 1) / 2 << endl;
	}
}