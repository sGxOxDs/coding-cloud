#include<iostream>
#include<map>
#include<vector>
#include<stack>
#include<algorithm>
using namespace std;

class vertex
{
	public:
		int v = 0;
		int d = 0;
		int low = 0;
		vector<vertex*>Adj;
		vertex* pi;

};

stack<vertex>Stack;
int time;

bool BelongStack(vertex u)
{
	stack<vertex>temp = Stack;

	while (!temp.empty())
	{
		if (u.v == temp.top().v)
			return true;
		else
			temp.pop();
	}

	return false;

}
void strongConnect(map<int, vertex>& G, vertex& u)
{
	time++;
	u.d = time;
	u.low = time;
	Stack.push(u);

	for (int i = 0; i < u.Adj.size(); i++)
	{
		if (u.Adj[i]->d == 0)
		{
			strongConnect(G, G[u.Adj[i]->v]);
			u.low = min(u.low, u.Adj[i]->low);
		}
		else if (BelongStack(G[u.Adj[i]->v]))
			u.low = min(u.low, u.Adj[i]->d);
	}
	vertex temp;
	if (u.low == u.d)
	{
		cout << endl;
		do
		{
			temp = Stack.top();
			Stack.pop();
			cout << temp.v << " ";
		} while (temp.v != u.v);
	}

}
void strongConnect(map<int, vertex>& G)
{
	time = 0;
	for (map<int, vertex>::iterator it = G.begin(); it != G.end(); it++)
		if (it->second.d == 0)
			strongConnect(G, it->second);
}

void Bridge(map<int, vertex>& G, vertex& u)
{
	time++;
	u.d = time;
	u.low = time;

	for (int i = 0; i < u.Adj.size(); i++)
	{
		if (u.Adj[i]->d == 0)
		{
			u.Adj[i]->pi = &u;
			Bridge(G, G[u.Adj[i]->v]);
			u.low = min(u.low, u.Adj[i]->low);
		}
		else if (u.Adj[i]!=u.pi)
			u.low = min(u.low, u.Adj[i]->d);
	}
	if (u.pi != 0 && u.low == u.d)
		cout << "(" << u.pi->v << "," << u.v << ")\n";

}
void Bridge(map<int, vertex>& G)
{
	time = 0;
	for (map<int, vertex>::iterator it = G.begin(); it != G.end(); it++)
		if (it->second.d == 0)
			Bridge(G, it->second);
}


int main()
{
	int nodeNumber = 0;

	while (cin >> nodeNumber)
	{
		map<int, vertex>G;
		int edgeNumber = 0;
		cin >> edgeNumber;

		for (int i = 1; i <= nodeNumber; i++)
			if (G.find(i) == G.end())
			{
				vertex temp;
				temp.v = i;
				G[i] = temp;
			}
	
		for (int i = 0; i < edgeNumber; i++)
		{
			int FirstCity = 0, SecondCity = 0;
			cin >> FirstCity >> SecondCity;
			
			G[FirstCity].Adj.push_back(&G[SecondCity]);
			G[SecondCity].Adj.push_back(&G[FirstCity]);

		}
		
		strongConnect(G);
		
		
	}

	
}