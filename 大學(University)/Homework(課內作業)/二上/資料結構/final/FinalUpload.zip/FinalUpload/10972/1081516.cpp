#include<iostream>
#include<map>
#include<vector>
#include<string>
#include<stack>
#include<algorithm>
#include<set>
using namespace std;
struct vertex {
	int integer = 0;
	vector<int> Adj;
	int d = 0;
	int low = 0;
	string color = "white";
	vertex* pi = 0;
};
/*struct combine {
	int connected;
};*/
void BridgeC(map<int, vertex> data);
void BridgeC(map<int, vertex> data, vertex& u);
int time = 0;
int com = 0;
stack<vertex> S;
int main() {
	int Case;
	//cin >> Case;
	while (cin >> Case) {
		//for (int q = 0; q < Case; q++) {
			int number;
			cin >> number;
			int temp1, temp2;
			vector<int> data(Case + 1);
			for (int i = 1; i <= number; i++) {
				cin >> temp1 >> temp2;
				data[temp1]++;
				data[temp2]++;
			}
			//multiset<int> Se;
			vector<int> se;
			int count = 0;
			int count1 = 0;
			int count0 = 0;
			for (int i = 1; i < data.size(); i++) {
				if (data[i] == 0) {
					count0++;
				}
				else if (data[i] == 1) {
					count1++;
				}
			}
			while (count0 != 0) {
				if (count0 == 1) {
					count0--;
					count1++;
					count++;
				}
				else {
					count += count0 / 2;
					count0 %= 2;
					count1 += 2 * count;
				}
			}
			while (count1 != 0) {
				if (count1 == 1) {
					count1--;
					count++;
				}
				else {
					count += count1 / 2;
					count1 %= 2;
				}
			}
			cout << count << endl;
		//}
	}


}
/*void BridgeC(map<int, vertex> data) {
	for (map<int, vertex>::iterator it = data.begin(); it != data.end(); ++it) {
		com++;
		if (it->second.d == 0) {
			BridgeC(data, it->second);
		}
		vertex w;
		do {
			w = S.top();
			S.pop();
			cout << w.d << endl;
		} while (w.d != it->second.d);
	}
}
void BridgeC(map<int, vertex> data, vertex& u) {
	time++;
	u.d = u.low = time;
	S.push(u);
	for (/*vector<int>::iterator it = u.Adj.begin(); it != u.Adj.begin(); ++itint i = 0; i < u.Adj.size(); i++) {
		if (data.find(u.Adj[i])->second.d == 0) {
			vertex v = data.find(u.Adj[i])->second;
			v.pi = &u;
			BridgeC(data, v);
			u.low = min(u.low, v.low);
		}
		else if (data.find(u.Adj[i])->second.pi != u.pi) {
			u.low = min(u.low, data.find(u.Adj[i])->second.d);
		}
	}
	if (u.low == u.d) {
		int w;
		do {
			w = S.top().d;
			S.pop();
		} while (w != u.d);
	}
}*/