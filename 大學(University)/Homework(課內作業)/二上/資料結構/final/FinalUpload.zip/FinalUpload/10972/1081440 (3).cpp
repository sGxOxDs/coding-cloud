#include<iostream>
#include<vector>
#include<set>

using namespace std;

struct MyStruct
{
	int index;
	int links = 0;
};
int main()
{
	int cities, roads, u, v;
	while (cin >> cities >> roads) {
		vector<MyStruct>cityLinks;
		for (int i = 0; i < roads; i++) {
			cin >> u;
			MyStruct cityU;
			cityU.index = u;
			cityU.links++;
			cin >> u;
			MyStruct cityV;
			cityV.index = v;
			cityV.links++;
			cityLinks.push_back(cityU);
			cityLinks.push_back(cityV);
		}
		set<MyStruct>checkrepeatCity;
		for (int i = 0; i < cityLinks.size(); i++) {
			if (checkrepeatCity.count(cityLinks[i]) == 0) {
				checkrepeatCity.insert(cityLinks[i]);
			}
			else {
				cityLinks[i].links++;
			}
		}
		set<MyStruct>::iterator it = checkrepeatCity.begin();
		int needToBuild = 0;
		for (; it != checkrepeatCity.end(); it++) {
			if (it->links == 0) {
				needToBuild += 2;
			}
			else if (it->links == 1) {
				needToBuild++;
			}
		}
		cout << needToBuild << endl;
	}
	return 0;
}