#include <iostream>
#include <vector>
using namespace std;

int main() {
	int node, line,s,e;
	
	while (cin >> node >> line) {
		vector<int> num(1000);
		for (int i = 0; i < line; ++i) {
			cin >> s >> e;
			num[s-1] += 1;
			num[e-1] += 1;
		}
		int a[2] = {0,0};
		for (int i = 0; i < node; ++i) {
			if (num[i] == 0) {
				a[1] += 1;
			}
			else if (num[i] == 1) {
				a[0] += 1;
			}
		}
		int sum;
		if (a[0] % 2) {
			if (a[1] == 0) {
				sum = a[0] / 2 + 1;
			}
			else
				sum = a[0] / 2 + a[1];
		}
		else {
			if (a[1] == 0) {
				sum = a[0] / 2;
			}
			else
				sum = a[0] / 2 + a[1] + 1;
		}
		if (line == 0)
			sum = node;
		if (line == 1)
			sum = node - 1;
		if (node == 1)
			sum = 0;
		cout << sum << endl;
	}
	system("pause");
	return 0;
}