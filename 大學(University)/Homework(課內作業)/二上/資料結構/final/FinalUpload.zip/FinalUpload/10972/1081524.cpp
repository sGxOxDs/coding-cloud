#include<iostream>
#include<vector>
#include<stack>
#include<algorithm>
#include<list>
using namespace std;
int u = 1,time = 0;
int ud[1005][3] = {};//u.d/u.3.14/u.low
vector<vector<int>>circle;
bool checkcircle(int ud[1005][3],int num) {
	for (int i = 1; i < num + 1; i++) {
		if (ud[i][0] == 0) {
			u = i;
			return false;
		}
	}
	return true;
}
void BRIDGE(vector<vector<int>>dict, int u, int ud[1005][3], stack<int>&S) {
	
	time = time + 1;
	ud[u][0] = time;//u.d
	ud[u][2] = time;//u.low
	S.push(u);
	for (int i = 0; i < dict[u].size(); i++) {
		if (dict[u][i] != ud[u][1]) {
			int v = dict[u][i];
			if (ud[dict[u][i]][0] == 0) {//if	v.d == 0
				ud[dict[u][i]][1] = u;
				BRIDGE(dict, v, ud, S);
				ud[u][2] = min(ud[u][2], ud[v][2]);
				if (ud[v][2] > ud[u][0]) {
					circle.push_back(vector<int>());
					int w = S.top();
					do {
						w = S.top();
						circle.back().push_back(w);
						S.pop();
					} while (w != v);
				}
			}
			else if (v != ud[u][1]) {
				ud[u][2] = min(ud[u][2], ud[v][0]);
			}
		}
	}


}
bool findlinkpos(list<int>link, int pos) {
	list<int>::iterator it = link.begin();
	for (; it != link.end(); it++) {
		if (*it == pos)
			return true;
	}
	return false;
}
bool checkrepeat(list<int>link, vector<vector<int>>road,int pos) {
	list<int>::iterator it = link.begin();
	for (; it != link.end(); it++) {
		if (*it != pos)
			return true;
	}
	return false;
}
void connectto(list<int>&link,vector<vector<int>>road, int& pos, int& sum) {
	if (road[pos].size() != 0&& checkrepeat(link,road,pos)==true) {
		for (int i = 0; i < road[pos].size(); i++) {
			if (findlinkpos(link, road[pos][i]) == false) {
				link.push_back(road[pos][i]);
				pos = road[pos][i];
				break;
			}
		}
	}
	else {
		for (int i = 0; i < road.size(); i++) {
			if (findlinkpos(link, i) == false) {
				link.push_back(i);
				pos = i;
				sum++;
				break;
			}
		}
	}
}

int main() {
	int node, num;
	while (cin >> node >> num) {
		//bool check[1005] = {};
		vector<vector<int>>dict;
		for(int i=0;i<node+1;i++)
			dict.push_back(vector<int>());
		for (int i = 0; i < num; i++) {
			int a, b;
			cin >> a>>b;
			dict[a].push_back(b);
			dict[b].push_back(a);
		}
		time = 0;
		stack<int>S;
		if (node > 0){
			while (!checkcircle(ud, node)) {
				if (ud[u][0] == 0) {
					BRIDGE(dict, u, ud, S);
					circle.push_back(vector<int>());
					while (!S.empty()) {
						int w = S.top();
						circle.back().push_back(w);
						S.pop();
					}
				}
			}
		}
		/*for (int i = 0; i < circle.size(); i++) {
			for (int j = 0; j < circle[i].size(); j++)
				cout << circle[i][j] << " ";
			cout << endl;
		}*/
		vector<vector<int>>road(circle.size());
		int count = 1;
		for (int i = 0; i < circle.size()-1&& node>0; i++) {
			bool linkcheck = false;
			while(count< circle.size()&& linkcheck == false){
				for (int j = 0; j < circle[i].size()&& linkcheck == false; j++) {//circle
					for (int k = 0; k < circle[count].size()&& linkcheck == false; k++) {
						for (int p = 0; p < dict[circle[i][j]].size(); p++) {
							if (circle[count][k] == dict[circle[i][j]][p]) {
								road[i].push_back(count);
								road[count].push_back(i);
								linkcheck = true;
								break;
							}

						}
					}
				}
				count++;
			}
			count = i + 2;
		}

		int max = 0, maxpos = 0;
		if (!road.empty())
			max = road[0].size();
		for (int i = 0; i < road.size() && node>0; i++) {
			if (road[i].size() > road[maxpos].size()) {
				max = road[i].size();
				maxpos = i;
			}

		}
		int pos = maxpos;
		int connect = 0,sum=0;
		list<int>link;
		link.push_back(pos);
		while (link.size()<road.size()) {
			connectto(link,road, pos,sum);
		}
		
		/*bool* con = new bool[node] {};
		int pos = maxpos;
		if(max!=0)
			con[pos] = true;
		if (node > 0) {
			while (connect<= road.size()) {
				pos = findcon(road, con, pos, sum);
				con[pos] = true;
				connect++;
			}
		}*/
		/*cout << maxpos << " " << max << endl;
		for (int i = 0; i < road.size(); i++) {
			cout << "circle : " << circle[i][0] << " : ";
			for (int j = 0; j < road[i].size(); j++)
				cout << road[i][j] << " ";
			cout << endl;
		}*/
		cout << sum << endl;
		circle.clear();
		//delete[]con;
		for (int i = 0; i < 1005; i++) {
			ud[i][0] = 0;
			ud[i][1] = 0;
			ud[i][2] = 0;
		}
	}
	return 0;
}