#include<iostream>
#include<vector>

using namespace std;

class node
{
public:
	node();

	~node();

	vector<int> next;

	void setnum(int);

private:
	int num;
};

int main()
{
	int nd,edge;
	while (cin >> nd && nd) {
		vector<node>n;
		for (int i = 1; i <= nd; i++) {
			node* temp = new node;
			temp->setnum(i);
			n.push_back(*temp);
		}
		cin >> edge;
		while (edge--) {
			int first, second;
			cin >> first >> second;
			n[first].next.push_back(second);
			n[second].next.push_back(first);

			//finish building graph
		}
	}
}

node::node()
{
}

node::~node()
{
}

void node::setnum(int n)
{
	num = n;
}