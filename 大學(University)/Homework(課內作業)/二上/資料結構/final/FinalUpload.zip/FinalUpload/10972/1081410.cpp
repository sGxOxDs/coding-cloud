﻿// 1081410.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include <iostream>
using namespace std;

int a[500] = {}, b[500] = {}, c[500] = {0};
void run(int n, int node, int edge)
{
	if (c[n] == 1)
		return;
	c[n] = 1;
	for (int i = 0; i < edge; i++)
	{
		if (a[i] == n)
			run(b[i], node, edge);
	}
	for (int i = 0; i < edge; i++)
	{
		if (b[i] == n)
			run(a[i], node, edge);
	}
}
int main()
{
	int node, edge;
	
	while (cin >> node >> edge)
	{		
		int sum = 0;
		for (int i = 0; i < 99; i++)
		{
			a[i] = 0; b[i] = 0;
		}
		for (int i = 0; i < 99; i++)
			c[i] = 0;
		int fir, sec;
		for (int i = 0; i < edge; i++)
		{
			cin >> fir >> sec;
			a[i] = fir; b[i] = sec;
			
		}
		for (int i = 1; i <= node; i++)
		{
			if (c[i] == 0)
			{
				run(i, node, edge);
				sum++;
			}
		}
		cout << sum << endl;
		sum = 0;
	}
}


