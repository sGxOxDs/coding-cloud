#include <iostream>
#include <vector>
#include <sstream>
#include <string>

using namespace std;
int Total = 0;
bool edge[1005][1005] = { false };
struct MyStruct
{
	bool compo = false;
	int edge = 0;
	bool root = false;
	bool visit = false;
	bool in = false;
	bool out = false;
	int P = 0;
};
bool ifover(vector<MyStruct>& myvec)
{
	for (int i = 1; i < myvec.size(); i++)
	{
		if (myvec[i].in == false || myvec[i].out == false)
		{
			return false;
		}
	}
	return true;
}
void minedge(vector<MyStruct>& myvec, int a)
{
	int min_i;
	int min = 200000;
	for (int i = 1; i < myvec.size(); i++)
	{
		if (myvec[i].edge <= min && myvec[a].P != i && a != i)
		{
			min = myvec[i].edge;
			min_i = i;
		}
	}
	edge[a][min_i] = true;
	Total++;
	myvec[min_i].edge += 1;
	myvec[a].edge += 1;
}
void dfs(vector<MyStruct>& myvec, int a)
{
	bool ac = true;
	for (int i = 1; i < myvec.size(); i++)
	{
		if (edge[a][i] == true && myvec[i].visit == false)
		{
			myvec[i].compo = true;
			edge[i][a] = false;
			myvec[i].visit = true;
			myvec[a].out = true;
			myvec[i].in = true;
			myvec[i].P = a;
			dfs(myvec, i);
		}
		else if (edge[a][i] == true && myvec[i].visit == true)
		{
				myvec[i].in = true;
				myvec[a].out = true;
				if (myvec[i].compo == true)
				{
					ac = false;
				}
		}
	}
	if (!ifover(myvec) && ac == true)
	{
		minedge(myvec, a);
		dfs(myvec, a);
	}
}
int main()
{
	string line;
	string buffer;
	int N, E, n1, n2;
	while (getline(cin, line))
	{
		for (int i = 0; i < 1005; i++)
		{
			for (int j = 0; j < 1005; j++)
			{
				edge[i][j] = false;
			}
		}
		Total = 0;
		vector<MyStruct> myvec;
		stringstream SS;
		SS << line;
		SS >> N;
		SS >> E;
		myvec.clear();
		myvec.resize(N + 1);

		while (E--)
		{
			stringstream ss;
			getline(cin, buffer);
			ss << buffer;
			while (ss >> n1)
			{
				ss >> n2;
				myvec[n1].edge += 1;
				myvec[n2].edge += 1;
				edge[n1][n2] = true;
				edge[n2][n1] = true;
			}
		}
		if (N > 1)
		{
			myvec[1].visit = true;
			myvec[1].compo = true;
		}
		if (myvec.size() != 2)
		{
			dfs(myvec, 1);
		}
		cout << Total << endl;
	}
}
