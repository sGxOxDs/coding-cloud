#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;
fstream out("out.txt", ios::out);
/*
3 2
1 2
2 3

10 11
1 2
2 3
3 1
3 7
4 5
5 6
6 4
7 9
6 3
9 8
7 8

1
2
*/

class vertex
{
public:
	int v = 0;
	int d = 0;
	int low = 0;
	vector< vertex* > Adj;
	vertex* pi = 0;
};

int times, num, w, br;
vector< int > S;

bool vBs(int v)
{
	for (auto it : S)
		if (it == v)
			return 1;
	return 0;
}

void strong(map< int, vertex >& G, vertex& u)
{
	times++;
	u.d = times;
	u.low = times;
	S.push_back(u.v);
	for (int i(0); i < u.Adj.size(); i++)
		if (u.Adj[i]->d == 0)
		{
			strong(G, G[u.Adj[i]->v]);
			u.low = min(u.low, u.Adj[i]->low);
		}
		else if(u.Adj[i] != u.pi)
			u.low = min(u.low, u.Adj[i]->d);
	if (u.low == u.d)
	{
		num++;
		do
		{
			w = S[S.size() - 1];
			S.pop_back();
		} while (w != u.v);
	}
}

void bri(map< int, vertex >& G, vertex& u)
{
	times++;
	u.d = times;
	u.low = times;
	for (int i(0); i < u.Adj.size(); i++)
		if (u.Adj[i]->d == 0)
		{
			u.Adj[i]->pi = &u;
			bri(G, G[u.Adj[i]->v]);
			u.low = min(u.low, u.Adj[i]->low);
		}
		else if (u.Adj[i] != u.pi)
			u.low = min(u.low, u.Adj[i]->d);
	if (u.pi != 0 && u.low == u.d)
		br++;
}

int main()
{
	int vn, en, u, v;

	while (cin >> vn >> en)
	{
		br = num = 0;

		map< int, vertex > G;

		for (int i(1); i <= vn; i++)
		{
			G[i] = vertex();
			G[i].v = i;
		}

		for (int i(0); i < en; i++)
		{
			cin >> u >> v;
			G[u].Adj.push_back(&G[v]);
			G[v].Adj.push_back(&G[u]);
		}

		for (map< int, vertex >::iterator it(G.begin()); it != G.end(); it++)
			if (it->second.d == 0)
				strong(G, it->second);

		for (map< int, vertex >::iterator it(G.begin()); it != G.end(); it++)
			it->second.low = it->second.d = 0;

		for (map< int, vertex >::iterator it(G.begin()); it != G.end(); it++)
			if (it->second.d == 0)
				bri(G, it->second);

		out << num << " " << br << endl;
	}
}
