#include<iostream>
#include<vector>
#include<set>
#include<stack>
#include<map>
using namespace std;

struct content {
	int d = 0;
	int low;
	int parent = 0;
	set<int> next;
	int no;
	int color = 0;
};

void bridgecomponent(vector<content>& figure, int dot, int& time, map<int, int>& reducepoint, stack<int>& temp, int& count) {
	time++;
	figure[dot].d = figure[dot].low = time;
	temp.push(dot);
	set<int>::iterator it = figure[dot].next.begin();
	for (; it != figure[dot].next.end(); it++) {
		if (figure[(*it)].d == 0) {
			figure[(*it)].parent = dot;
			bridgecomponent(figure, (*it), time, reducepoint, temp, count);
			if (figure[(*it)].low < figure[dot].low)
				figure[dot].low = figure[(*it)].low;

			if (figure[(*it)].low > figure[dot].d) {
				int a;
				count++;
				reducepoint.insert(pair<int, int>(count, 0));
				do {
					a = temp.top();
					figure[a].no = count;
					temp.pop();
				} while (a != (*it));
			}
		}
		else if (*it != figure[dot].parent)
			if (figure[(*it)].d < figure[dot].low)
				figure[dot].low = figure[(*it)].d;
	}
}

void dfs(vector<content>& figure, int dot, map<int, int>& reducepoint) {
	figure[dot].color = 1;
	set<int>::iterator it = figure[dot].next.begin();
	for (; it != figure[dot].next.end(); it++) {
		if (figure[(*it)].color == 0) {
			if (figure[dot].no != figure[(*it)].no) {
				map<int, int>::iterator s1 = reducepoint.find(figure[dot].no);
				(*s1).second++;
				s1 = reducepoint.find(figure[(*it)].no);
				(*s1).second++;
			}
			dfs(figure, *it, reducepoint);
		}
	}
}

int main() {
	int n, m;

	while (cin >> n >> m) {
		vector<content> figure(n + 1);
		int a, b;
		while (m--) {
			cin >> a >> b;
			figure[a].next.insert(b);
			figure[b].next.insert(a);
		}


		int count = 0, time = 0;
		stack<int> temp;
		vector<double> city;
		int degree0 = 0;
		for (int i = 1; i < figure.size(); i++) {
			if (figure[i].d == 0) {
				map<int, int> reducepoint;
				bridgecomponent(figure, i, time, reducepoint, temp, count);
				int a;
				count++;
				reducepoint.insert(pair<int, int>(count, 0));
				do {
					a = temp.top();
					figure[a].no = count;
					temp.pop();
				} while (a != i);

				dfs(figure, i, reducepoint);
				if (reducepoint.size() == 1) {
					city.push_back(0);
					degree0++;
				}
				else {
					map<int, int>::iterator it = reducepoint.begin();
					int x = 0;
					for (; it != reducepoint.end(); it++) {
						if ((*it).second == 1)
							x++;
					}
					city.push_back(x);
				}
			}
		}
		

		double total = 0;
		for (int i = 0; i < city.size(); i++) 
			if (city[i] != 0) 
				total += city[i];
		if(total == 0 && degree0 == 1)
			cout << 0 << endl;
		else if (total == 0)
			cout << degree0 << endl;
		else if (degree0 == 0)
			cout << ceil(total / 2) << endl;
		else
			cout << degree0 + ceil(total / 2) << endl;
	}

	return 0;
}