#include <iostream>
#include <set>
#include <vector>
using namespace std;

struct cycle {
	set<int> s;
	int count = 0;
};

int found(int num1, int num2, vector<cycle> sets) {
	for (unsigned int i = 0; i < sets.size(); i++)
		if (sets[i].s.count(num1) == 1) return i;
		else if (sets[i].s.count(num2) == 1) return i;
	return 1001;
}

int main() {
	int nodes, edges = 0;
	cin >> nodes >> edges;

	int f = 0;
	int num1, num2 = 0;
	cycle tempCycle;
	vector<cycle> sets;
	for (unsigned int i = 0; i < edges; i++) {
		cin >> num1 >> num2;
		f = found(num1, num2, sets);
		if (f != 1001) {
			sets[f].s.insert(num1); sets[f].count++;
			sets[f].s.insert(num2); sets[f].count++;
		}
		else {
			tempCycle.s.insert(num1); tempCycle.count++;
			tempCycle.s.insert(num2); tempCycle.count++;
			sets.push_back(tempCycle);
		}
	}

	auto it2 = sets[0].s.begin();
	auto it3 = sets[0].s.begin();
	auto it4 = sets.begin();
	for (unsigned int i = 0; i < sets.size()-1; i++) {
		for (unsigned int j = i; j < sets.size(); j++) {

			for (auto it = sets[i].s.begin(); it != sets[i].s.end();it++) {
				if (sets[j].s.count(*it) == 1) {
					it2 = sets[j].s.begin();
					it3 = sets[j].s.end();
					sets[i].s.insert(it2, it3);
					sets[i].count += sets[j].count;
					it4 = sets.begin() + j;
					sets.erase(it4);
				}
			}

		}
	}

	int total_node = 0;
	int total_count = 0;
	int ans = 0;
	for (unsigned int i = 0; i < sets.size(); i++) {
		total_node += sets[i].s.size();
		total_count += sets[i].count;
		ans += sets[i].count - sets[i].s.size();
	}
	
	ans += nodes - total_node + sets.size();

	cout << ans << endl;

	return 0;
}