#include<iostream>
#include<vector>
#include<string>
#include<fstream>
using namespace std;
#define min(a, b) (a < b)? a : b

int maxLow, nowNode;
int* d, * low;
vector<vector<int>> edge;

void init(int n)
{
	for (int i = 0; i < edge.size(); i++)
		edge[i].clear();
	edge.resize(n);
	d = new int[n]();
	low = new int[n]();
	maxLow = 0;
	nowNode = 1;
}

int dfs(int p, int u, int& time)
{
	d[u] = low[u] = ++time;
	int count = 0;
	int v;
	for (int i = 0; i < edge[u].size(); i++)
	{
		v = edge[u][i];
		if (d[v] == 0)
		{
			count += dfs(u, v, time);
			low[u] = min(low[u], low[v]);
		}
		else if(v != p)
			low[u] = min(low[u], d[v]);
	}

	if (d[u] == low[u] && low[u] > maxLow && low[u] != low[nowNode])
	{
		maxLow = low[u];
		count++;
	}
	return count;
}

int main()
{
	int nodeNum, edgeNum;
	ofstream out("answer.txt");
	while (cin >> nodeNum >> edgeNum)
	{
		init(nodeNum + 1);
		int u, v;
		for (int i = 0; i < edgeNum; i++)
		{
			cin >> u >> v;
			edge[u].push_back(v);
			edge[v].push_back(u);
		}
		int groupNum = 0, leafNum = 0, time = 0;
		if (nodeNum > 0)
		{
			int leaf = 0;
			for (; nowNode <= nodeNum; nowNode++)
				if (d[nowNode] == 0)
				{
					leaf = dfs(0, nowNode, time);
					if (edge[nowNode].size() == 1)
						leaf++;
					leafNum += leaf;
					if (leaf == 0)
						groupNum++;
				}
		}
		if (groupNum == 1 && leafNum == 0)
			out << 0 << endl;
		else
			out << (groupNum * 2 + leafNum + 1) / 2 << endl;
		cout << endl;
	}
}
/* 1
 2 4 5
 3 
*/