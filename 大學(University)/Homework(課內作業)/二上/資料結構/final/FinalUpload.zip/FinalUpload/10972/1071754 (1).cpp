#include <iostream>
#include <list>
#include <stack>
#include <algorithm>

struct node
{
	int index;
	node* ptr;
	node* parent;
	int d;
	int low;
};

using namespace std;

int time = 0;					//global variable
int bridge_conponent_size = 0;		//global variable
stack <int> S;					//global stack


node* Adj(list<node*>& G, node*& u)
{
	for (list<node*>::iterator it = G.begin(); it != G.end(); it++)
		if ((*it)->index = u->index)
			return (*it);
	node* ptr = new node;
	cout << "error occur!!\n";
	return ptr;
}


void BRIDGE_CONNECT(list<node*>& G, node*& u)
{
	time = time + 1;
	u->d = time;
	u->low = time;
	S.push(u->index);
	node* ptr = Adj(G, u);
	node* v = &*ptr;
	do
	{
		if (v->d == 0)
		{
			v->parent = u;
			BRIDGE_CONNECT(G, v);
			u->low = min(u->low, v->low);
		}
		else if (v != u->parent)
			u->low = min(u->low, v->d);
		v = v->ptr;
	} while (v != ptr);

	if (u->low == u->d)
	{
		bridge_conponent_size += 1;
	}
}

int main()
{
	int edge_size, node_size;
	while (cin >> node_size >> edge_size)
	{
		time = 0;
		bridge_conponent_size = 0;		//global variable
		while (!S.empty())
			S.pop();
		list <node*> mygraph;
		int u, v;
		for (int i = 0; i < edge_size; i++)
		{
			cin >> u >> v;
			bool exist_u = 0, exist_v = 0;
			node* node_u = new node;
			node* node_v = new node;
			node_u->d = 0;
			node_v->d = 0;
			node_u->index = u;
			node_v->index = v;
			node_u->ptr = node_u;
			node_v->ptr = node_v;
			for (list<node*>::iterator it = mygraph.begin(); it != mygraph.end(); it++)
			{
				if (node_u->index == ((*it)->index))
				{
					node* gg = new node;
					gg->d = 0;
					gg->index = node_v->index;
					gg->ptr = (*it)->ptr;
					(*it)->ptr = gg;
					exist_u = 1;
				}
				if (node_v->index == ((*it)->index))
				{
					node* qq = new node;
					qq->d = 0;
					qq->index = node_u->index;
					qq->ptr = (*it)->ptr;
					(*it)->ptr = qq;
					exist_v = 1;
				}
			}
			if (!exist_u)
			{
				node* temp1 = new node;
				temp1->d = 0;
				temp1->index = v;
				temp1->ptr = node_u;
				node_u->ptr = temp1;
				mygraph.push_back(node_u);
			}
			if (!exist_v)
			{
				node* temp2 = new node;
				temp2->d = 0;
				temp2->index = u;
				temp2->ptr = node_v;
				node_v->ptr = temp2;
				mygraph.push_back(node_v);

			}
		}
		/*for (list<node*>::iterator it = mygraph.begin(); it != mygraph.end(); it++)   //�ˬdedge���Y�O�_���T
		{
			node* temp = *it;
			do
			{
				cout << temp->index;
				temp = temp->ptr;
			}while ((temp)->index != (*it)->index);
			cout << endl;
		}*/
		int count = 0;
		for (list<node*>::iterator it = mygraph.begin(); it != mygraph.end(); it++)
		{

			if ((*it)->d == 0)
			{
				BRIDGE_CONNECT(mygraph, *mygraph.begin());
				count += 1;
			}
		}
		if (count > 1)
			bridge_conponent_size += count;
		cout << (bridge_conponent_size/5) << endl;

	}
	return 0;
}