#include <iostream>
#include <stack>
#include <vector>
#include <string>

int main() {
	int caseNum;
	std::cin >> caseNum;

	std::vector<bool> ans;
	std::string s;
	getline(std::cin, s);  // clear buffer
	while (caseNum--) {

		// input
		std::stack<char> stack;
		getline(std::cin, s);

		// check
		if (s == "") {
			ans.push_back(1);
		}
		else {
			// run
			bool correct = true;
			for (int i = 0; i < s.size(); i++) {
				if (s[i] == '(') {
					stack.push('(');
				}
				else if (s[i] == '[') {
					stack.push('[');
				}
				else if (s[i] == ')') {
					if (!stack.empty() && stack.top() == '(') {
						stack.pop();
					}
					else {
						correct = false;
						break;
					}
				}
				else if (s[i] == ']') {
					if (!stack.empty() && stack.top() == '[') {
						stack.pop();
					}
					else {
						correct = false;
						break;
					}
				}
			}

			if (!stack.empty()) {
				correct = false;
			}

			// result
			(correct) ? ans.push_back(1) : ans.push_back(0);
		}

	}

	// output
	for (int i = 0; i < ans.size(); i++) {
		if (ans[i]) {
			std::cout << "Yes" << std::endl;
		}
		else {
			std::cout << "No" << std::endl;
		}
	}

	return 0;
}