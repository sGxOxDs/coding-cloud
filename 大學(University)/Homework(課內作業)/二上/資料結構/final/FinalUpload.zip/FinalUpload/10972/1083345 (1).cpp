#include<iostream>
#include<vector>
#include<list>

using namespace std;

int main()
{
	int n, m, a, b;
	while (cin >> n >> m)
	{
		vector<vector<int>> link(n + 1);
		for (int i = 0; i < m; ++i)
		{
			cin >> a >> b;
			link[a].push_back(b);
			link[b].push_back(a);
		}

		list<int> RN;
		for (auto& i : link)
		{
			if (i.empty())
				RN.push_back(2);
			else if (i.size() == 1)
				RN.push_back(1);
		}
		RN.pop_front();

		int N = 0;
		while (RN.size() > 1)
		{
			auto it1 = RN.begin();
			auto it2 = ++RN.begin();
			if (*it1 == *it2 && *it1 == 1)
			{
				++N;
				if (*it1 == 1)
				{
					RN.pop_front();
					RN.pop_front();
				}
				else
					--* it1, --* it2;

			}
			else
			{
				++N;
				RN.pop_front();
				RN.pop_front();
				RN.push_front(1);
			}
		}

		if (!RN.empty()&&link.size()>2)
			N += RN.back();

		cout << N << '\n';
	}
	return 0;
}