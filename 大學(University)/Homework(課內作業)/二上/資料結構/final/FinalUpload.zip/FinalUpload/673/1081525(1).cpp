#include<iostream>
#include<string>

using namespace std;
int main()
{
	int n = 0;
	cin >> n;
	string buf, ans;
	getline(cin, buf);
	for (; n > 0; n--)
	{
		buf.clear();
		getline(cin, buf);
		ans.clear();
		for (int i = 0; i<buf.size(); i++)
		{
			if (buf[i] == '(' || buf[i] == '[')
				ans.push_back(buf[i]);
			else if (buf[i] == ')')
			{
				if(ans.size() >0&& ans[ans.size()-1]== '(')
					ans.pop_back();
				else
				{
					ans.push_back('n');
					break;
				}
			}
			else if(buf[i] == ']')
			{
				if (ans.size() > 0 && ans[ans.size() - 1] == '[')
					ans.pop_back();
				else
				{
					ans.push_back('n');
					break;
				}
			}
		}
		if (ans.size() > 0)
			cout << "No\n";
		else
			cout << "Yes\n";
	}
	return 0;
}