#include<iostream>
#include<string>
#include<stack>

using namespace std;

int main()
{
	int n;
	string str;
	cin >> n;
	cin.ignore();
	while (n--)
	{
		getline(cin, str);
		stack<char> s;
		for (int i = 0; i < str.length(); ++i)
		{
			if (str[i] == ' ')
				continue;
			if (!s.empty())
			{
				bool pop = false;
				if (str[i] == ')' && s.top() == '(')
					pop = true;
				if (str[i] == ']' && s.top() == '[')
					pop = true;

				if (pop)
				{
					s.pop();
					continue;
				}
			}
			s.push(str[i]);
		}

		if (s.empty())
			cout << "Yes\n";
		else
			cout << "No\n";
	}
	return 0;
}