#include <iostream>
#include <stack>
#include <string>

using namespace std;

char cL[2] = { '(','[' };
char cR[2] = { ')',']' };

int main() {
	int n;
	cin >> n;
	cin.ignore();
	while (n--)
	{
		string input;
		getline(cin, input);
		stack< char > s;
		if (input.empty())
		{
			cout << "Yes" << endl;
			continue;
		}

		for (int i = 0; i < input.size(); i++)
		{
			if (input[i] == ' ')
				continue;
			if (!s.empty())
				if ((input[i] == cR[0] && s.top() == cL[0]) ||
					(input[i] == cR[1] && s.top() == cL[1]))
				{
					s.pop();
					continue;
				}

			s.push(input[i]);
		}

		if (s.empty())
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
}