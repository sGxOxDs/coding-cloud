#include <iostream>
#include <string>
#include <stack>
using namespace std;

int main()
{
	int test_case;
	cin >> test_case;
	getchar();
	while(test_case--)
	{
		bool counter = true;
		string token;
		stack<char> Stack;
		getline(cin, token);
		for (size_t i = 0; i < token.size()&&counter==true; i++)
		{
			if (token[i] == ')'&&!Stack.empty())
			{
				if (Stack.top() == '(')
					Stack.pop();
				else
				{
					//cout << "No" << endl;
					counter = false;
					break;
				}
			}
			else if (token[i] == ']'&& !Stack.empty())
			{
				if(Stack.top() == '[')
					Stack.pop();
				else
				{
					//cout << "No" << endl;
					counter = false;
					break;
				}
			}
			else
				Stack.push(token[i]);
		}
		if (Stack.empty() && counter == true)
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
	return 0;
}