#include <iostream>
#include <stack>
#include <string>

using namespace std;

int main() {
	stack<char> s;
	int asd;
	string input;
	while (cin >> asd) {
		cin.get();
		while (asd--) {
			getline(cin, input);
			if (!input.size()) {
				cout << "Yes" << endl;
				continue;
			}
			bool isCorrect = true;
			for (int i = 0; i < input.size(); i++) {
				switch (input[i]) {
				case '(':
					s.push('(');
					break;
				case '[':
					s.push('[');
					break;
				case']':
					if (!s.size() || s.top() != '[') {
						isCorrect = false;
					} else {
						s.pop();
					}
					break;
				case')':
					if (!s.size() ||s.top() != '(') {
						isCorrect = false;
					} else {
						s.pop();
					}
					break;
				default:
					break;
				}
				if (!isCorrect) {
					break;
				}
			}
			if (!isCorrect || s.size()) {
				cout << "No" << endl;
			} else {
				cout << "Yes" << endl;
			}
			s = stack<char>();

		}
	}
}

/*
3
([])
(([()])))
([()[]()])()
1
([()[]()])()
*/