#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using namespace std;
fstream out("out.txt", ios::out);

int main()
{
	int n;
	string s;
	cin >> n;
	while (n--)
	{
		getline(cin, s);
		vector< char > st;

		for (auto it : s)
		{
			st.push_back(it);
			if(st.size() > 1)
				if (st[st.size() - 2] == '(' && st[st.size() - 1] == ')')
					st.pop_back(), st.pop_back();
			if (st.size() > 1)
				if (st[st.size() - 2] == '[' && st[st.size() - 1] == ']')
					st.pop_back(), st.pop_back();
		}

		if (st.empty())
			cout << "YES" << endl;
		else
			cout << "NO" << endl;
	}
}