#include <iostream>
#include <stack>
#include <string>
using namespace std;

int main()
{
	bool YON = true;
	char buffer;
	int N;
	string line;
	cin >> N;
	getline(cin, line);
	while (N--)
	{
		YON = true;
		stack<char> mystack;
		getline(cin, line);
		if (line == "")
		{
			cout << "Yes" << endl;
		}
		else
		{
			for (int i = 0; i < line.size(); i++)
			{
				if (line[i] == '(' || line[i] == '{' || line[i] == '[')
				{
					mystack.push(line[i]);
				}
				else
				{
					if (!mystack.empty())
					{
						buffer = mystack.top();
						mystack.pop();
						if (line[i] == ')' && buffer != '(')
						{
							YON = false;
							break;
						}
						else if (line[i] == ']' && buffer != '[')
						{
							YON = false;
							break;
						}
						else if (line[i] == '}' && buffer != '{')
						{
							YON = false;
							break;
						}
					}
					else
					{
						YON = false;
						break;
					}
				}
			}
			if (YON == true && mystack.empty())
			{
				cout << "Yes" << endl;
			}
			else
			{
				cout << "No" << endl;
			}
		}
	}
}