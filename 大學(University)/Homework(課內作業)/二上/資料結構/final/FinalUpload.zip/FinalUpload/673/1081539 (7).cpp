//673-f
#include<iostream>
#include<stack>
#include<stdio.h>
using namespace std;

int main()
{
	/*char p[10];

	cin.getline(p,6) ;
	cout << p;



	return 0;*/

	int tN;

	while (cin >> tN)
	{
		string* li = new string[tN];
		char aa[130];
		cin.getline(aa, 129);
		for (int i = 0; i < tN; i++)
		{

			cin.getline(aa, 129);
			/*if (aa == " ")
				li[i] = "!!";
			else*/
			li[i] = aa;



			/*cin >> li[i];*/

		}

		for (int i = 0; i < tN; i++)
		{

			stack<char> buffer;
			int size = li[i].size();
			string::iterator it = li[i].begin();
			int s = 0;
			for (; s < size; s++)
			{
				if (it[s] == ' ')continue;
				if (it[s] == '(' || it[s] == '[')
					buffer.push(it[s]);
				else if (it[s] == ')')
				{
					if (buffer.empty())
						break;
					if (buffer.top() == '(')
						buffer.pop();
					else
						break;
				}
				else if (it[s] == ']')
				{
					if (buffer.empty())
						break;
					if (buffer.top() == '[')
						buffer.pop();
					else
						break;
				}
				else break;
			}
			if (s == size && buffer.empty())
				cout << "Yes";
			else
				cout << "No";

			//if (i != tN - 1)
			cout << endl;


		}


	}








	return 0;
}
