#include <iostream>
#include <stack>
#include <string>
#include <fstream>

using namespace std;

int main()
{
	int number = 0;
	fstream out( "answer.txt", ios::out );
	cin >> number;
	cin.ignore();
	while( number-- ) {
		bool correct = true;
		stack<char> test;
		char input[ 1000 ] = {};
		cin.getline( input, 500 );
		for( int i = 0; i < 128; i++ ) {
			if( input[ i ] == '\0' )
				break;
			else if( input[ i ] == '(' ) {
				test.push( input[ i ] );
			}
			else if( input[ i ] == '[' ) {
				test.push( input[ i ] );
			}
			else if( test.size() ) {
				if( input[ i ] == ')' ) {
					if( test.top() == '(' ) {
						test.pop();
					}
					else {
						correct = false;
					}
				}
				else if( input[ i ] == ']' ) {
					if( test.top() == '[' ) {
						test.pop();
					}
					else {
						correct = false;
					}
				}
			}
			else {
				correct = false;
			}
		}
		if( correct && !test.size() )
			cout << "Yes";
		else
			cout << "No";
		if( number != 0 ) {
			cout << endl;
		}
	}
}