#include <iostream>
#include <stack>
#include <string>

using namespace std;

int main()
{
	int t;
	cin >> t;
	cin.ignore();
	while (t--)
	{
		bool out = false;
		stack<char>S;
		string input;
		getline(cin, input);
		if (input.empty())
		{
			cout << "Yes" << endl;
			continue;
		}

		for (auto v : input)
		{
			if (v == '(' || v == '[')
				S.push(v);

			else
			{
				if (S.empty())
				{
					cout << "No" << endl;
					out = 1;
					break;
				}
				char top = S.top();
				if (v == ')' && top == '(')
					S.pop();
				else if (v == ']' && top == '[')
					S.pop();
			}
		}

		if (!out)
		{
			if (S.empty())
				cout << "Yes" << endl;
			else
				cout << "No" << endl;
		}
	}
}