#include <iostream>
#include <stack>
#include <string>

using namespace std;

int main()
{
	int number = 0;
	cin >> number;
	cin.ignore();
	while( number-- ) {
		bool correct = true;
		stack<char> test;
		char input[ 1000 ] = {};
		cin.getline( input, 128 );
		for( int i = 0; i < 128; i++ ) {
			if( input[ i ] == '\0' )
				break;
			else if( input[ i ] == '(' ) {
				test.push( input[ i ] );
			}
			else if( input[ i ] == '[' ) {
				test.push( input[ i ] );
			}
			else if( test.size() ) {
				if( input[ i ] == ')' ) {
					if( test.top() == '(' ) {
						test.pop();
					}
					else {
						correct = false;
					}
				}
				else if( input[ i ] == ']' ) {
					if( test.top() == '[' ) {
						test.pop();
					}
					else {
						correct = false;
					}
				}
			}
			else {
				correct = false;
			}
		}
		if( correct && !test.size() )
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
}