#include <iostream>
#include <stack>
#include <string>
using namespace std;

int main() {
	
	size_t case_num = 0;
	string tmp_input;
	getline(cin, tmp_input);
	case_num = stoi(tmp_input);
	bool judge = false;
	stack<char> data;
	for (int i = 0; i < case_num; i++) {
		getline(cin, tmp_input);
		while (!data.empty())
			data.pop();
		judge = true;
		for (size_t n = 0; n < tmp_input.size(); n++) {
			if(tmp_input[n]=='(' || tmp_input[n]=='[')
				data.push(tmp_input[n]);
			else if(tmp_input[n] == ')' || tmp_input[n] == ']'){
				if (!data.empty()) {
					if ((data.top() == '(' && tmp_input[n] != ')') || (data.top() == '[' && tmp_input[n] != ']'))
						judge = false;
					else
						data.pop();
				}
				else judge = false;
					
			}
		}
		if (!data.empty())
			judge = false;
		if (!judge)
			cout << "No"<<endl;
		else
			cout << "Yes"<<endl;
		//if (i != case_num - 1)
		//	cout << endl;
	}
	return 0;
}