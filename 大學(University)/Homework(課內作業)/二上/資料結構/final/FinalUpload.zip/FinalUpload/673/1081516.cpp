#include<iostream>
#include<stack>
#include<string>
#include<vector>
using namespace std;
int main() {
	int number = 0;
	cin >> number;
	string temp;
	cin.get();
	for (int q = 0; q < number; q++) {
		int answer = -1;
		getline(cin, temp);
		stack<char> check;
		if (temp.size() == 0) {
			answer = 1;
		}
		for (int i = 0; i < temp.size(); i++) {
			if (temp[i] == '(' || temp[i] == '[') {
				check.push(temp[i]);
			}
			else if (temp[i] == ')' || temp[i] == ']') {
				if (check.empty()) {
					answer = 0;
					break;
				}
				char temp1 = check.top();
				check.pop();
				if (temp[i] == ')' && temp1 != '(') {
					answer = 0;
					break;
				}
				else if (temp[i] == ']' && temp1 != '[') {
					answer = 0;
					break;
				}
			}
		}
		if (!check.empty()) {
			answer = 0;
		}
		else {
			if (answer == -1) {
				answer = 1;
			}
		}
		if (answer == 1) {
			cout << "Yes" << endl;
		}
		else if (answer == 0) {
			cout << "No" << endl;
		}
	}
}