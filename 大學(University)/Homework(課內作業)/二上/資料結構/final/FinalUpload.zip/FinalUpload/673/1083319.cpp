#include <iostream>
#include <stack>
#include <string>
using namespace std;

int main()
{
	int Case;
	char ch;
	string str;

	cin >> Case;
	cin.ignore();
	for( int i = 0; i < Case ; i++)
	{
		getline( cin, str );

		if( str == "" )
		{
			cout << "Yes" << endl;
			continue;
		}

		stack<char> st;
		for( int j = 0; j < str.size(); j++ )
		{
			if( str[ j ] == ']' || str[ j ] == '}' )
			{
				if( st.empty() )
				{
					st.push( str[ j ] );
				}
				else if( str[ j ] == ']' && st.top() == '[' )
					st.pop();
				else if( str[ j ] == '}' && st.top() == '{' )
					st.pop();
			}
			else
				st.push( str[ j ] );
		}

		if( st.empty() )
		{
			cout << "Yes" << endl;
		}
		else
		{
			cout << "No" << endl;
		}
	}

	return 0;
}