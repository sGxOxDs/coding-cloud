#include <iostream>
#include <stack>
#include <string>

using namespace std;

int main()
{
	int testcase;
	cin >> testcase;
	string none;
	getline(cin, none);
	while (testcase--)
	{
		stack <char>container;
		string temp="";
		getline(cin, temp);
		//cin.clear();
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp[i] == '(' || temp[i] == '[')
				container.push(temp[i]);
			else
			{
				if (temp[i] == ' ')
					;
				else
				{
					if (container.empty())
					{
						container.push('!');
						break;
					}
					if ((container.top() == '(' && temp[i] == ')') || (container.top() == '[' && temp[i] == ']'))
						container.pop();
					else
						break;
				}
			}
		}
		//if(temp=="")
		if (container.empty()||temp=="")
			cout << "Yes\n";
		else
			cout << "No\n";
	}
	return 0;
}