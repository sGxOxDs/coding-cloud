#include <iostream>
#include <stack>
#include <string>
using namespace std;
int main() {
	int cases;
	cin >> cases;
	cin.get();
	for (int c = 0; c < cases; c++) {
		string s;
		stack<char> input;
		bool OK = true;
		getline(cin, s);
		for (int i = 0; i < s.size(); i++) {
			if (s[i] == '(' || s[i] == '[') 
				input.push(s[i]);
			else if (s[i] == ')') {
				if (input.empty()) {
					OK = false;
					break;
				}
				if (input.top() == '(')
					input.pop();
			}
			else if (s[i] == ']') {
				if (input.empty()) {
					OK = false;
					break;
				}
				if (input.top() == '[')
					input.pop();
			}
		}
		if (input.empty() && OK)
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
}