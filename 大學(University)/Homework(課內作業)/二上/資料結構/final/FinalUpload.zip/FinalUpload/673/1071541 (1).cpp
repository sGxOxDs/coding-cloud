#include<iostream>
#include<stack>
#include<vector>
#include<sstream>

using namespace std;

int main()
{
	string line;
	getline(cin, line);

	int cases;
	stringstream ss(line);
	ss >> cases;


	while (cases > 0)
	{
		//string line;
		getline(cin, line);
	    //stringstream ss(line);
		
		stack<char> w;
		for (unsigned int i = 0; i < line.length(); i++)
		{
			if (line[i] == '(' || line[i] == '[')
				w.push(line[i]);
			else if (line[i] == ')')
			{
				if (w.empty())
				{
					w.push(line[i]);
					break;
				}
				if (w.top() == '(')
					w.pop();
				else
				{
					//cout << "No" << endl;
					break;
				}
			}
			else if (line[i] == ']')
			{
				if (w.empty())
				{
					w.push(line[i]);
					break;
				}
				if (w.top() == '[')
					w.pop();
				else
				{
					//cout << "No" << endl;
					break;
				}
			}
		}
		if (w.empty())
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
		

		cases--;
	}
	
}