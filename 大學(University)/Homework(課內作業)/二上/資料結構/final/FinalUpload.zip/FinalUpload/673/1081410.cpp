﻿// 1081410.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include <iostream>
#include<string>
#include <stack>
using namespace std;
int main()
{
	int num;
	while (cin >> num)
	{
		string s;
		getline(cin, s);
		for (int i = 0; i < num; i++)
		{
			getline(cin, s);
				if (s[0] == ' ')
					cout << "Yes" << endl;
				else
				{
					stack<char> ss;
					for (int j = 0; j < s.length(); j++)
					{
						if (s[j] == ' ')
							;
						else if (!ss.empty())
						{
							
							if (s[j] == ')')
							{
								if (ss.top() == '(')
									ss.pop();
							}
							else if (s[j] == ']')
							{
								if (ss.top() == '[')
									ss.pop();
							}
							else
								ss.push(s[j]);
						}
						else
							ss.push(s[j]);
					}
					if (ss.empty())
						cout << "Yes" << endl;
					else
						cout << "No" << endl;
				}
			
		}
	}
}


