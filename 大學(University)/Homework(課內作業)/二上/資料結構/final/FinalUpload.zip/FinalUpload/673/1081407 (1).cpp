#include<iostream>
#include<stack>
#include<istream>
#include<list>
using namespace std;

int main()
{

	list<int> ansnwer;
	int times;
	cin >> times;
	cin.get();
	for (size_t i = 0; i < times; i++)
	{
		char input[128];
		cin.getline(input, 128);
		list<char>put;
		for (size_t i = 0; input[i] != '\0'; i++)
		{
			if(input[i]!=' ')
			put.push_back(input[i]);
		}
		stack<char> check;
		list<char>::iterator putIt = put.begin();
		for (; !put.empty();)
		{
			check.push(*putIt);
			put.pop_front();
			putIt = put.begin();
			while (!check.empty())
			{
				if (put.empty())
				{
					break;
				}
				if (check.top() == '(')
				{
					if (*putIt == ')')
					{
						check.pop();
						put.pop_front();
						putIt = put.begin();
					}
					else break;
				}
				else if (check.top() == '[')
				{
					if (*putIt == ']')
					{
						check.pop();
						put.pop_front();
						putIt = put.begin();
					}
					else break;
				}
				else if (check.top() == ']' || check.top() == ')')
					break;
			}

		}
		if (put.empty() && check.empty())
		{
			//cout << "Yes" << endl;
			ansnwer.push_back(1);
		}
		else
			//cout << "No" << endl;
			ansnwer.push_back(0);
	}
	list<int>::iterator ansnwerIt = ansnwer.begin();
	list<int>::iterator ansnwerLast = ansnwer.end();
	ansnwerLast--;
	for (;ansnwerIt!=ansnwer.end();ansnwerIt++)
	{
		if (*ansnwerIt == 1)
		{
			cout << "Yes" ;
			
		}
		else if (*ansnwerIt == 0)
			cout << "No" ;
		if (ansnwerIt != ansnwerLast)
		{
			cout << endl;
		}
	}








}