#include<iostream>
#include<stack>
#include<string>
using namespace std;

int main() {
	int a;
	cin >> a;
	cin.ignore();
	for (int i = 0; i < a; i++) {
		string str;
		stack<char> s;
		bool emp = 0;
		getline(cin, str);
		for (int j = 0; j < str.size(); j++) {
			if (str[j] == ']') {
				if (s.empty()) {
					emp = 1;
					break;
				}
				else if (s.top() == '[') {
					s.pop();
				}
				else {
					emp = 1;
					break;
				}
			}
			else if (str[j] == ')') {
				if (s.empty()) {
					emp = 1;
					break;
				}
				else if (s.top() == '(') {
					s.pop();
				}
				else {
					emp = 1;
					break;
				}
			}
			else s.push(str[j]);
		}
		if (s.empty() && !emp) {
			cout << "Yes\n";
		}
		else cout << "No\n";
	}
}