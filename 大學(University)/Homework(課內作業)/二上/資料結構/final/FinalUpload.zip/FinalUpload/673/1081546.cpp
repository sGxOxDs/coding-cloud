#include<iostream>
#include<stack>
#include<string>
#include<list>
using namespace std;
int main()
{
	stack<char>s;
	list<char>list;
	int n;
	cin >> n;
	while (n--)
	{
		string str;
		cin >> str;
		if (str == " ")cout << "Yes" << endl;
		else if (str.size() % 2 == 0)
		{

			/*s.push(str[0]);
			list.push_back(str[0]);*/
			for (int i = 0; i < str.size(); i++)
			{
				s.push(str[i]);
				list.push_back(str[i]);
				/*if (s.size() == 0)
				{
					s.push(str[i + t]);
					list.push_back(str[i + t]);
				}
				else if (s.top() == '(' || s.top() == '[')
				{

					s.push(str[i + t]);
					list.push_back(str[i + t]);

				}*/
				if (s.top() == ')')
				{
					list.pop_back();
					if (list.back() == '(')
					{
						s.pop();
						s.pop();
						list.pop_back();
					}
				}
				else if (s.top() == ']')
				{
					list.pop_back();
					if (list.back() == '[')
					{
						s.pop();
						s.pop();
						list.pop_back();
					}
				}
			}
			if (!s.empty())
				cout << "No" << endl;
			else
				cout << "Yes" << endl;
		}
		else
			cout << "No" << endl;
	}
	return 0;
}