#include<iostream>
#include<stack>
#include<vector>
#include<string>

using namespace std;

int main()
{
	string input;
	int n;
	while (getline(cin, input) && !input.empty() &&stoi(input)) {
		n = stoi(input);
		while (n--) {
			bool out = true;
			string str;
			stack<char> s;
			getline(cin, str);

			for (int i = 0; i < str.size(); i++) {
				if (str[i] == '[' || str[i] == '(') {
					s.push(str[i]);
				}
				else {
					if (str[i] == ']') {
						if (!s.empty()&&s.top() == '[') {
							s.pop();
						}
						else {
							out = false;
							break;
						}
					}
					if (str[i] == ')') {
						if (!s.empty() && s.top() == '(') {
							s.pop();
						}
						else {
							out = false;
							break;
						}
					}
				}
			}
			if (out&&s.empty()) {
				cout << "Yes\n";
			}
			else {
				cout << "No\n";
			}
		}
	}
}