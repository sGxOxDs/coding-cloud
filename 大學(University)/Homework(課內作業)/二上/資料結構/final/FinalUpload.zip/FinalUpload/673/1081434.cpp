#include<iostream>
#include<stack>
#include<string>

using namespace std;

int main() {
	int times = 0;
	string tempstr;
	
	

	cin >> times;
	getline(cin, tempstr);
	for (int i = 0; i < times; i++) {
		bool answer = 0;
		stack<char> buffer;
		getline(cin,tempstr);
		if(tempstr.size()==0)
			answer = 1;
		for (int j = 0; j < tempstr.size(); j++) {
			if (tempstr[j] == '[' || tempstr[j] == '(') {
				buffer.push(tempstr[j]);
				answer = 0;
			}
			else {
				if ((!buffer.empty() && tempstr[j] == ']' && buffer.top() == '[')) {
					buffer.pop();
					answer = 1;
				}
				else if (!buffer.empty() && (tempstr[j] == ')' && buffer.top() == '(')) {
					buffer.pop();
					answer = 1;
				}
				else if (tempstr[j] == ' ');
				else {
					answer = 0;
					break;
				}
			}
		}
		if (!buffer.empty())
			answer = 0;
		if (answer)
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
}