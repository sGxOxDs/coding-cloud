#include<iostream>
#include<string>
#include<stack>
//#include<fstream>
using namespace std;
int main() {
	int input;
	string temp;
	//fstream myfile("result.txt", ios::out);
	cin >> input;
	getline(cin, temp);
	for (int kkk = 0; kkk < input; kkk++) {
		getline(cin, temp);
		stack<char> mystack;
		bool check = 1;
		for (int i = 0; i < temp.size(); i++) {
			if (temp[i] == '[' || temp[i] == '(') {
				mystack.push(temp[i]);
			}
			else if (temp[i] == ']') {
				if (!mystack.empty() && mystack.top() == '[') {
					mystack.pop();
				}
				else {
					check = 0;
					break;
				}
			}
			else if (temp[i] == ')') {
				if (!mystack.empty() && mystack.top() == '(') {
					mystack.pop();
				}
				else {
					check = 0;
					break;
				}
			}
		}
		if (check && mystack.empty()) {
			//myfile << "Yes\n";
			cout << "Yes" << endl;
		}
		else {
			//myfile << "No\n";
			cout << "No" << endl;
		}
	}
}