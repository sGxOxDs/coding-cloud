#include <iostream>
#include <stack>

using namespace std;

int main()
{
	int testcase;
	cin >> testcase;
	while (testcase--)
	{
		stack <char>container;
		string temp;
		cin >> temp;
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp[i] == '(' || temp[i] == '[')
				container.push(temp[i]);
			else
			{
				if (container.empty())
				{	
					container.push('!');
					break;
				}
				if ((container.top()=='('&&temp[i]==')') || (container.top() == '[' && temp[i] == ']'))
					container.pop();
				else
					break;
			}
		}
		if (container.empty())
			cout << "Yes\n";
		else
			cout << "No\n";
	}
	return 0;
}