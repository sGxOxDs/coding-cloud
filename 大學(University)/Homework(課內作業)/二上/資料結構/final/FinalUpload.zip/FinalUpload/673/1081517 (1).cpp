#include<iostream>
#include<stack>
#include<string>
using namespace std;

int main()
{
	int n;
	while( cin >> n )
	{
		cin.get();
		while( n-- )
		{
			stack<char>s;
			//string line;
			//cin.ignore();
			string line;
			getline( cin, line );
			//cin.ignore();

			if( line.size() == 0 )
			{
				cout << "Yes" << endl;
				continue;
			}
			else
			{
				for( int i = 0; i < line.size(); i++ )
				{
					if( line[ i ] == ' ' )
						i++;
					s.push( line[ i ] );
					if( line[ i ] == ')' && s.size() > 1 )
					{
						s.pop();
						if( !s.empty() && s.top() == '(' )
							s.pop();
					}
					else if( line[ i ] == ']' && s.size() > 1 )
					{
						s.pop();
						if( !s.empty() && s.top() == '[' )
							s.pop();
					}
				}
			}

			if( s.empty() )
				cout << "Yes" << endl;
			else
				cout << "No" << endl;

			//cin.ignore();
		}
	}
}