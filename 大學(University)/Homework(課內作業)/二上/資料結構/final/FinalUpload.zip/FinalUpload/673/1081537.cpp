#include <iostream>
#include <string>
#include <stack>

using namespace std;

int main() {
	int num;
	while (cin >> num) {
		string fix;
			while (getline(cin, fix))
				break;
		for (int i = 0; i < num; ++i) {
			
			string in;
			stack<char> reg;
			getline(cin, in);
			bool jum=false;
			if (in.length() == 0) {
				cout << "Yes" << endl;
			}
			else {
				for (int j = 0; j < in.length(); ++j) {
					switch (in[j]) {
					case '[':
						reg.push(in[j]);
						break;
					case '(':
						reg.push(in[j]);
						break;
					case ']':
						if (!reg.empty() && reg.top() == '[')
							reg.pop();
						else
							jum = true;
						break;
					case ')':
						if (!reg.empty() && reg.top() == '(')
							reg.pop();
						else
							jum = true;
						break;
					case ' ':
						break;
					}
					if (jum)
						break;
				}
				if (jum) {
					cout << "No" << endl;
				}
				else if (!reg.empty()) {
					cout << "No" << endl;
				}
				else {
					cout << "Yes" << endl;
				}
			}
		}
	}
	system("pause");
	return 0;
}