#include<iostream>
#include<stack>
#include<string>
using namespace std;

int main()
{
	int n;
	cin >> n;
	string s;
	cin.ignore();
	while (n--)
	{
		stack<char> sta;
		getline(cin, s);
		bool ans = true;
		for (int i = 0; i < s.size(); i++)
		{
			if (s[i] == ']')
				if (sta.empty() || sta.top() != '[')
				{
					ans = false;
					break;
				}
				else
					sta.pop();
			else if (s[i] == ')')
				if (sta.empty() || sta.top() != '(')
				{
					ans = false;
					break;
				}
				else
					sta.pop();
			else
				sta.push(s[i]);
		}
		if (!sta.empty())
			ans = false;
		if (ans)
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
}