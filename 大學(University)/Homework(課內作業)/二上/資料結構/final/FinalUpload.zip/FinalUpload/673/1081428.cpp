#include <iostream>
#include <string>
#include <stack>
using namespace std;

int main() {
	int N;
	string str;
	cin >> N;
	cin.get();
	while (getline(cin,str) && N--) {
		bool isCorrect = true;
		stack<char> st;
		for (int i = 0; i < str.size(); i++) {
			if (str[i] == ')') {
				if (!st.empty() && st.top() == '(')
					st.pop();
				else {
					st.push(str[i]);
					isCorrect = false;
					break;
				}
			}
			else if (!st.empty() && str[i] == ']') {
				if (st.top() == '[') {
					st.pop();
				}
				else {
					st.push(str[i]);
					isCorrect = false;
					break;
				}
			}
			else if(str[i]!=' '){
				st.push(str[i]);
			}
		}
		if (!st.empty()) {
			cout << "No" << endl;
		}
		else {
			cout << "Yes" << endl;
		}
	}
}