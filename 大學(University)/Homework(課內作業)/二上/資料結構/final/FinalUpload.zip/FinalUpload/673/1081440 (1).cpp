#include<iostream>
#include<list>
#include<string>

using namespace std;

int main()
{
	int testCases;
	list<char>inputList;
	list<int>resultList;
	while (cin >> testCases) {
		int counter = 0;
		string input;
		resultList.clear();
		while (getline(cin, input)) {
			if (counter != 0) {
				--testCases;
				string::iterator it = input.begin();
				inputList.clear();
				for (; it != input.end(); it++) {
					if (*it != ' ') {
						inputList.push_back(*it);
					}
				}
				list<char>::iterator it1 = inputList.begin();
				for (; it1 != inputList.end(); it1++) {					
					list<char>::iterator it2 = it1;
					list<char>::iterator it3 = it2;
					if (it2 != inputList.begin()) {
						--it3;
					}
					if (*it2 == ')' && *it3 == '(') {
						inputList.erase(it2);
						inputList.erase(it3);
						it1 = inputList.begin();
					}
					else if (*it2 == ']' && *it3 == '[') {
						inputList.erase(it2);
						inputList.erase(it3);
						it1 = inputList.begin();
					}
					if (inputList.size() == 0) {
						break;
					}
				}
				if (inputList.size() == 0) {
					resultList.push_back(0);
				}
				else {
					resultList.push_back(1);
				}
			}
			if (testCases == 0 && resultList.size() != 0) {
				list<int>::iterator it4 = resultList.begin(),it5;
				for (; it4 != resultList.end(); it4++) {
					it5 = it4;
					if (*it4 == 0) {
						cout << "Yes";
						if ((++it5) != resultList.end()) {
							cout << endl;
						}
					}
					else {
						cout << "No";
						if ((++it5) != resultList.end()) {
							cout << endl;
						}
					}
				}
				break;
			}
			counter++;
		}
	}

	return 0;
}
