#include<iostream>
#include<string>
#include<stack>
using namespace std;

int main() {
	char* ch = new char[128]();
	int cases = 0;
	cin.getline(ch, 128);
	for (unsigned int i = 0; i < strlen(ch) - 1; i++) {
		cases += ch[i] - '0';
		cases *= 10;
	} cases += ch[strlen(ch) - 1] - '0';

	stack<char>stk;
	bool correct = false;
	for (unsigned int i = 0; i < cases; i++) {

		correct = false;
		cin.getline(ch, 128);
		if (strlen(ch) == 0) correct = true;
		else {

			for (unsigned int n = 0; n < strlen(ch); n++) {
				if (ch[n] != '(' && ch[n] != ')' && ch[n] != '[' && ch[n] != ']') {
					correct = false;
					break;
				}
				else if (ch[n] == '(' || ch[n] == '[') stk.push(ch[n]);
				else if (stk.empty()) {
					correct = false;
					break;
				}
				else {
					if ((ch[n] == ')' && stk.top() == '(') || (ch[n] == ']' && stk.top() == '['))
						stk.pop();
					else {
						correct = false;
						break;
					}
				}

				if (stk.empty()) correct = true;
				else correct = false;
			}

		}
		if (correct) cout << "Yes" << endl;
		else cout << "No" << endl;

		while (!(stk.empty())) stk.pop();
	}

	return 0;
}