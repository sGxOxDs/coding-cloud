#include<cstdio>
#include<iostream>
#include<vector>
#include<cstring>
#include<string>
using namespace std;
int main() {
	int T;
	while (cin >> T) {
		int a;
	//	cin >> a;
		cin.ignore();
		string str;
		while (getline(cin, str)) {
			if (str.size() == 0) {
				printf("Yes\n");
				continue;
			}
				//cout << "::" << str << "::" << endl;
			vector<char> s;//stack
			bool isSyn = false;
			int strLen = str.size();
			//cout << "llll " <<  strLen << endl;
			for (int i = 0; i < strLen; i++) {
				//	if (s.empty() || (s[s.size()-1] == '(' || s[s.size()-1] == '[')) {
				if (str[i] == '(' || str[i] == '[') {
					s.push_back(str[i]);
				}
				else {
					if (s.size() != 0)
					{
						if ( (str[i] == ']' && s[s.size() - 1] == '[') || (str[i] == ')' && s[s.size() - 1] == '('))
							s.pop_back();
						else {
							//   cout << i << "??" << endl;
							break;
						}
					}
					else break;
				}
				if (i == strLen - 1 && s.size() == 0)
					isSyn = true;
			}
			if (isSyn)
				printf("Yes\n");
			else
				printf("No\n");
		}
	}
	return 0;
}

