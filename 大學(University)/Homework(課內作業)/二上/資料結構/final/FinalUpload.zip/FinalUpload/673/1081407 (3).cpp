#include<iostream>
#include<stack>
#include<list>

using namespace std;

int main()
{
	int time;
	cin >> time;
	cin.get();
	for (size_t i = 0; i < time; i++)
	{
		char a[200];
		list<char> myA;
		cin.getline(a, 200);
		for (size_t i = 0; a[i] != '\0'; i++)
		{
			if (a[i] == ' ')i++;
			myA.push_back(a[i]);
		}
		stack<char> put;
		while (!myA.empty())
		{
			put.push(myA.front());
			myA.pop_front();
			while (!put.empty())
			{
				if (myA.empty())
				{
					break;
				}
				else if (put.top() - myA.front() == '(' - ')' || put.top() - myA.front() == '[' - ']')
				{
					put.pop();
					myA.pop_front();
				}
				else
					break;
			}
		}
		if (myA.empty() && put.empty())
		{
			cout << "Yes" << endl;
		}
		else
			cout << "No" << endl;


	}






}