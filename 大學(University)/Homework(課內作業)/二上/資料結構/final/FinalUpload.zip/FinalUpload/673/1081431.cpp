#include<iostream>
#include<stack>
#include<string>
using namespace std;

int main() {
	int case1;
	cin >> case1;
	cin.ignore();
	while (case1--) {
		string temp;
		getline(cin,temp);
		stack<char> result;
		bool condition = 0;
		result.push(temp[0]);
		int i;
		for (i = 1; i < temp.size(); i++) {
			if (!result.empty()) {
				if (temp[i] - result.top() == 1 || temp[i] - result.top() == 2)
					result.pop();
				else {
					if (temp[i] == 40 || temp[i] == 91)
						result.push(temp[i]);
					else {
						condition = 1;
						break;
					}	
				}	
			}
			else {
				if(temp[i]==41 || temp[i] == 93)
					condition = 1;
				else
					result.push(temp[i]);
			}
				
		}
		if (i== temp.size() && !result.empty())
			condition = 1;

		if (condition)
			cout << "No" << endl;
		else
			cout << "Yes" << endl;
	}
	return 0;
}