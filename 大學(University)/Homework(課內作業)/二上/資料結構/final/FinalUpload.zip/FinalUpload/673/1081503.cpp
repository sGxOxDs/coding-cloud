#include<iostream>
#include<stack>
#include<string>
using namespace std;

int main()
{
	int n;
	cin >> n;
	cin.ignore();

	while (n--)
	{
		stack<char> myStack;
		string buf;

		getline(cin, buf);

		for (int i = 0; i < buf.size(); i++)
		{
			if (myStack.empty())
				myStack.push(buf[i]);
			else
			{
				if ((myStack.top() == '[' && buf[i] == ']') || (myStack.top() == '(' && buf[i] == ')'))
				{
					myStack.pop();
				}
				else if (buf[i] == ' ')
				{

				}
				else
					myStack.push(buf[i]);
			}
		}

		if (myStack.empty())
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
}