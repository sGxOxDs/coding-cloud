#include<iostream>
#include<stack>
#include<string>
using namespace std;


int main()
{
	int test = 0;
	cin >> test;
	cin.ignore();
	while (test--)
	{	
		string example;
		stack<char>left;
		getline(cin, example);
		if (example[0]=='\n')
		{
			cout << "Yes\n";
			continue;
		}
		for (int i = 0; i < example.size(); i++)
		{

			if (example[i] == '(' || example[i] == '[')
				left.push(example[i]);
			else
			{
				if (left.empty())
					left.push(example[i]);
				else
				{
					if (!left.empty() && example[i] == ')' && left.top() == '(')
						left.pop();
					else if (!left.empty() && example[i] == ']' && left.top() == '[')
						left.pop();
				}

			}

		}
		if (left.empty())
			cout << "Yes\n";
		else
			cout << "No\n";



	}


}