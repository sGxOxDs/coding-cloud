#include <iostream>
#include <stack>
#include <string>

using namespace std;

int main()
{
	int number = 0;
	cin >> number;
	cin.ignore();
	while( number ) {
		number--;
		stack<char> test;
		char input[ 1000 ] = {};
		cin.getline( input, 500 );
		for( int i = 0; i < 128; i++ ) {
			if( input[ i ] == '\0' )
				break;
			else if( input[ i ] == '(' )
				test.push( input[ i ] );
			else if( input[ i ] == '[' )
				test.push( input[ i ] );
			else if( test.size() != 0 ) {
				if( input[ i ] == ')' ) {
					if( test.top() == '(' )
						test.pop();
					else
						test.push( input[ i ] );
				}
				else if( input[ i ] == ']' ) {
					if( test.top() == '[' )
						test.pop();
					else
						test.push( input[ i ] );
				}
			}
			else
				test.push( input[ i ] );
		}
		if( test.size() == 0)
			cout << "Yes";
		else
			cout << "No";
		if( number != 0 )
			cout << endl;
	}
}