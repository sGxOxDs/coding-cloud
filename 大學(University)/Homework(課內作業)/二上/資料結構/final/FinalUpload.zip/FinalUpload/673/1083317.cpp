#include<iostream>
#include<stack>
#include<string>
using namespace std;

int main() {
	int N;
	while (cin >> N) {
		int n = N;
		while (n > 0) {
			stack<int> myStack;
			string str;
			//��P
			if (n == N)
				getline(cin, str);
			//---
			getline(cin, str);
			if (str == "") {
				cout << "Yes" << endl;
				n--;
				continue;
			}

			for (int i = 0; i < str.length(); i++) {
				if (str[i] == '(' || str[i] == '[')
					myStack.push(str[i]);
				else if (str[i] == ')') {
					if (myStack.empty()) {
						myStack.push(str[i]);
						break;
					}
					else if (myStack.top() == '(')
						myStack.pop();
					else
						break;
				}
				else if (str[i] == ']') {
					if (myStack.empty()) {
						myStack.push(str[i]);
						break;
					}
					else if (myStack.top() == '[')
						myStack.pop();
					else
						break;
				}
			}
			if (myStack.empty())
				cout << "Yes" << endl;
			else
				cout << "No" << endl;
			n--;
		}
	}




	return 0;
}