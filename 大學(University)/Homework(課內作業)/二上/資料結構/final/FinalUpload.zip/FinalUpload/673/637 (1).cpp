#include<iostream>
#include<stack>
#include<string>
using namespace std;

int main()
{
	int n;
	while( cin >> n )
	{	
		while( n-- )
		{
			cin.ignore();
			stack<char>s;
			bool flag = false;
			string line;
			//cin >> line;
			getline( cin, line );
			

			if( line.size() == 0 )
			{
				cout << "Yes" << endl;
				break;
			}				
			else
			{
				for( int i = 0; i < line.size(); i++ )
				{
					if( line[ i ] == ' ' )
						i++;
					s.push( line[ i ] );
					if( line[ i ] == ')' && s.size() > 1 )
					{
						s.pop();
						if( !s.empty() && s.top() == '(' )
							s.pop();
					}
					else if( line[ i ] == ']' && s.size() > 1 )
					{
						s.pop();
						if( !s.empty() && s.top() == '[' )
							s.pop();
					}
				}
			}

			if( s.empty() )
				cout << "Yes" << endl;
			else
				cout << "No" << endl;

			getchar();
		}		
	}
}