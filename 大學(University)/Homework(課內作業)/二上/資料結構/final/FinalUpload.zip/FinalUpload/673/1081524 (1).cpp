#include<iostream>
#include<stack>
#include<string>
using namespace std;
int main() {
	int n;
	while (cin >> n) {
		cin.ignore();
		for (int i = 0; i < n; i++) {
			bool check = false;
			stack<char>dict;
			string line;
			getline(cin, line);
			if (line == "")
				check = true;
			else {
				for (int j = 0; j < line.size(); j++) {
					if (line[j] == '(' || line[j] == '[')
						dict.push(line[j]);
					else {
						if (!dict.empty()) {
							if (dict.top() == '(' && line[j] != ')') {
								break;
							}
							else if (dict.top() == '[' && line[j] != ']') {
								break;
							}
							else {
								dict.pop();
								if (dict.empty() && (j == line.size() - 1))
									check = true;
							}
						}
					}
				}
			}
			if (check == true)
				cout << "Yes" << endl;
			else
				cout << "No" << endl;

		}
	}

	return 0;
}