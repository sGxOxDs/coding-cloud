// xtree internal header
//check
#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
	   if (node->parent->parent == myHead || node->parent->color == Color::Black)
		   return;
	  //left=1,right=2 black=1,red=2
	   int glocted,plocated,sc = 0;
	   if (node->parent->left == node)
		   plocated = 1;
	   else
		   plocated = 2;

	   if (node->parent == node->parent->parent->left)
	   {
		   glocted = 1;
		   if (node->parent->parent->right->color == Color::Black)
			   sc = 1;
		   else
		   {
			   sc = 2;
			   node->parent->color = Color::Black;
			   node->parent->parent->color = Color::Red;
			   node->parent->parent->right->color = Color::Black;
		   }
	   }
	   else
	   {
		   glocted = 2;
		   if (node->parent->parent->left->color == Color::Black)
			   sc = 1;
		   else
		   {
			   sc = 2;
			   node->parent->color = Color::Black;
			   node->parent->parent->color = Color::Red;
			   node->parent->parent->left->color = Color::Black;
		   }
	   }
	   if (glocted == 1 && plocated == 1 && sc == 1)
	   {
		   node->parent->color = Color::Black;
		   node->parent->parent->color = Color::Red;
		   LLRotation(node->parent);
	   }
	   else if (glocted == 2 && plocated == 2 && sc == 1)
	   {
		   node->parent->color = Color::Black;
		   node->parent->parent->color = Color::Red;
		   RRRotation(node->parent);
	   }

   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
	   TreeNode<value_type>* gg = p->parent->parent;
	   if (p->right != myHead)
		   p->right->parent = p->parent;
	   p->parent->left = p->right;
	   p->right = p->parent;
	   p->parent->parent = p;
	   p->parent = gg;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
	   TreeNode<value_type>* gg = p->parent->parent;
	   if (p->left != myHead)
		   p->left->parent = p->parent;
	   p->parent->right = p->left;
	   p->left = p->parent;
	   p->parent->parent = p;
	   p->parent = gg;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne(TreeNode< value_type >* node)
   {
	   TreeNode<value_type>* n;
	   if (node->left != myHead)
		  n = node->left;
	   else
		  n = node->right;
	  
	   TreeNode<value_type>* p = node->parent;
	   
	   if (node->parent->left == node)
	   {
		   
		   if (node->parent == myHead)
			   myHead->parent = node->left;
		   else
			   node->parent->left = node->left;
		   node->left->parent = node->parent;

	   }
	   else
	   {
		   if (node->parent == myHead)
			   myHead->parent = node->right;
		   else
			   node->parent->right = node->right;
		   node->right->parent = node->right;
	   }
	   fixUp(n, p);
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
	   while (N->parent->color == Color::Red || myHead->parent != N)
	   {
		   TreeNode<value_type>* s;
		   if (N->parent->left == N)
			   s = N->parent->right;
		   else
			   s = N->parent->left;

		   if (s->color != Color::Red && s->right->color != Color::Black)
		   {
			   Color temp;
			   temp = P->color;
			   P->color = s->color;
			   s->color = temp;
			   s->right->color = Color::Black;
			   RRRotation(P);
			   N = P->parent;
		   }
		   else if (s->color != Color::Red && s->left->color != Color::Black)
		   {
			   Color temp;
			   temp = P->color;
			   P->color = s->color;
			   s->color = temp;
			   s->left->color = Color::Black;
			   LLRotation(P);
			   N = P->parent;
		   }
	   }
	   N->color = Color::Black;
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert(const value_type& val)
   {
	   TreeNode<value_type>* temp = new TreeNode<value_type>;
	   temp->color = Color::Red;
	   temp->isNil = false;
	   temp->myval = val;
	   temp->left = temp->right = scaryVal.myHead;
	   if (scaryVal.myHead->parent == scaryVal.myHead)
	   {
		   temp->color = Color::Black;
		   scaryVal.myHead->left = scaryVal.myHead->right = scaryVal.myHead->parent = temp;
		   temp->parent = scaryVal.myHead;
	   }

	   TreeNode<value_type> *current = scaryVal.myHead->parent;
	   while (current->left == scaryVal.myHead && current->right == scaryVal.myHead)
	   {
		   if (current->myval == val)
			   return;
		   else if (keyCompare(val, current->myval))
		   {
			   if (current->left == scaryVal.myHead)
			   {
				   if (scaryVal.myHead->left == current)
					   scaryVal.myHead->left = temp;
				   temp->parent = current;
				   current->left = temp;
				   break;
			   }
			   current = current->left;
		   }
		   else
		   {
			   if (current->right == scaryVal.myHead)
			   {
				   if (scaryVal.myHead->right == current)
					   scaryVal.myHead->right = temp;
				   temp->parent = current;
				   current->right = temp;
				   break;
			   }
			   current = current->right;
		   }
	   }
	   scaryVal.reBalance(temp);
	   scaryVal.mySize++;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
	   TreeNode<value_type>* it1 = scaryVal.myHead->parent;
	   while (it1->myval != val)
	   {
		   if (it1 == scaryVal.myHead)
			   return 0;
		   else if (keyCompare(val, it1->myval))
			   it1 = it1->left;
		   else
			   it1 = it1->right;

	   }
	   //0
	   if (it1->left == scaryVal.myHead && it1->right == scaryVal.myHead)
	   {
		   if (scaryVal.myHead->left == it1)
			   scaryVal.myHead->left = it1->parent;
		   else if (scaryVal.myHead->right == it1)
			   scaryVal.myHead->right = it1->parent;

		   if (it1->parent->left == it1)
			   it1->parent->left = scaryVal.myHead;
		   else
			   it1->parent->right = scaryVal.myHead;
		   scaryVal.fixUp(it1->left, it1->parent);
		   delete[] it1;
	   }
	   //1
	   else if (it1->left == scaryVal.myHead || it1->right == scaryVal.myHead)
		   scaryVal.eraseDegreeOne(it1);
	   //2
	   else
	   {
		   TreeNode<value_type>* it2 = it1;
		   it2 = it2->right;
		   while (it2->left != scaryVal.myHead)
			   it2 = it2->left;

		   it1->myval = it2->myval;
		   if (scaryVal.myHead->left == it2)
			   scaryVal.myHead->left = it2->parent;
		   delete[] it2;

	   }
	   scaryVal.mySize--;
	   
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE