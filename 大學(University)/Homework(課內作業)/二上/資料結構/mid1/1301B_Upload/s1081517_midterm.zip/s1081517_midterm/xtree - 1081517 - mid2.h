// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root

	   while (node != myHead->parent && node->color == Color::Red && node->parent->color == Color::Red)
	   {
		   NodePtr p = node->parent, g = p->parent;

		   if (p == g->left && (g->right)->color == Color::Red ||
			   p == g->right && (g->left)->color == Color::Red)
		   {
			   p->color = Color::Black;
			   if (p == g->left)
				   (g->right)->color = Color::Black;
			   else
				   (g->left)->color = Color::Black;
			   g->color = Color::Red;

			   node = g;
		   }
		   else
		   {
			   if (p == g->left && node == p->left)
			   {
				   p->color = Color::Black;
				   g->color = Color::Red;

				   LLRotation(p);
				   node = p;
			   }
			   else if (p == g->right && node == p->right)
			   {
				   p->color = Color::Black;
				   g->color = Color::Red;

				   RRRotation(p);
				   node = p;
			   }
		   }
	   }
	   myHead->parent->color = Color::Black;
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
	   NodePtr p1 = p->parent;

	   p1->left = p->right;
	   if (p->right != myHead)
		   p->right->parent = p1;
	   
	   p->right = p1;

	   if (p1->parent != myHead)
	   {
		   if (p1 == p1->parent->left)
			   p1->parent->left = p;
		   else
			   p1->parent->right = p;
	   }
	   else
		   myHead->parent = p;

	   p->parent = p1->parent;
	   p1->parent = p;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
	   NodePtr p1 = p->parent;

	   p1->right = p->left;
	   if (p->left != myHead)
		   p->left->parent = p1;

	   p->left = p1;

	   if (p1->parent != myHead)
	   {
		   if (p1 == p1->parent->left)
			   p1->parent->left = p;
		   else
			   p1->parent->right = p;
	   }
	   else
		   myHead->parent = p;

	   p->parent = p1->parent;
	   p1->parent = p;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
	   NodePtr child;

	   if (node->left != myHead)
		   child = node->left;
	   else if (node->right != myHead)
		   child = node->right;
	   else
		   child = myHead;

	   if (node->parent != myHead)
	   {
		   if (node == node->parent->left)
			   node->parent->left = child;
		   else
			   node->parent->right = child;
	   }
	   else
		   myHead->parent = child;

	   if (child != myHead)
		   child->parent = node->parent;

	   if (node->color == Color::Black)
		   fixUp(child, node->parent);

	   delete node;
	   mySize--;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
	   Color buffer;
	   NodePtr S;

	   while (N->parent != myHead && N->color == Color::Black)
	   {
		   if (N == P->left)
		   {
			   S = P->right;

			   if (S->color == Color::Black && S->right->color == Color::Red)
			   {
				   buffer = S->color;
				   S->color = P->color;
				   P->color = buffer;
				   S->right->color = Color::Black;

				   RRRotation(S);
				   break;
			   }
		   }
		   else if (N == P->right)
		   {
			   S = P->left;

			   if (S->color == Color::Black && S->left->color == Color::Red)
			   {
				   buffer = S->color;
				   S->color = P->color;
				   P->color = buffer;
				   S->left->color = Color::Black;

				   LLRotation(S);
				   break;
			   }
		   }
	   }
	   N->color = Color::Black;
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
	   TreeNode<value_type>* node = new TreeNode<value_type>();
	   node->myval = val;
	   node->isNil = false;
	   node->color = Color::Red;

	   if (scaryVal.mySize == 0)
	   {
		   node->color = Color::Black;
		   node->left = node->right = node->parent = scaryVal.myHead;
		   scaryVal.myHead->left = scaryVal.myHead->right = scaryVal.myHead->parent = node;
	   }
	   else
	   {
		   TreeNode<value_type>* p = scaryVal.myHead->parent, * pp = 0;

		   while (p != scaryVal.myHead)
		   {
			   pp = p;

			   if (keyCompare(val, p->myval))
				   p = p->left;
			   else if (keyCompare(p->myval, val))
				   p = p->right;
			   else
				   return;
		   }

		   if (pp)
		   {
			   if (keyCompare(val, pp->myval))
			   {
				   pp->left = node;
				   node->parent = pp;
				   node->left = node->right = scaryVal.myHead;
			   }
			   else
			   {
				   pp->right = node;
				   node->parent = pp;
				   node->left = node->right = scaryVal.myHead;
			   }
		   }

		   if (val < scaryVal.myHead->left->myval)
			   scaryVal.myHead->left = node;
		   else if (val > scaryVal.myHead->right->myval)
			   scaryVal.myHead->right = node;

		   if (node->parent->color == Color::Red)
			   scaryVal.reBalance(node);
	   }
	   scaryVal.mySize++;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
	   TreeNode<value_type>* p = scaryVal.myHead->parent;

	   while (p != scaryVal.myHead && val != p->myval)
	   {
		   if (keyCompare(val, p->myval))
			   p = p->left;
		   else
			   p = p->right;		   
	   }

	   if (p == scaryVal.myHead)
		   return 0;
	   else
	   {
		   if (p->left == scaryVal.myHead || p->right == scaryVal.myHead)
			   scaryVal.eraseDegreeOne(p);
		   else
		   {
			   TreeNode<value_type>* rightsubTreeMin = p->right;
			   while (rightsubTreeMin->left != scaryVal.myHead)
				   rightsubTreeMin = rightsubTreeMin->left;

			   p->myval = rightsubTreeMin->myval;

			   scaryVal.eraseDegreeOne(rightsubTreeMin);
		   }
	   }
	   return 1;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE