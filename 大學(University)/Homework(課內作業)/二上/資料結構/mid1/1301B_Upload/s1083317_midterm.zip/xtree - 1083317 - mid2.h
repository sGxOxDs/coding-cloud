// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
	   //1.-----------------------------
	   NodePtr p = node->parent;
	   NodePtr g = p->parent;
	   //�P�_�O���@�� case
	   //XYr (4��)
	   if (g->left->color == Color::Red && g->right->color == Color::Red) {
		   //�ܦ�
		   g->left->color = Color::Black;
		   g->right->color = Color::Black;
		   if(g != myHead->parent)
			   g->color = Color::Red;
	   }
	   //LLb �� RRb (2��)
	   //LLb
	   else if(p == g->left && node == p->left){
		   LLRotation(p);
	   }
	   //RRb
	   else if (p == g->right && node == p->right) {
		   RRRotation(p);
	   }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
	   //2.-----------------------------
	   NodePtr g = p->parent;
	   //g ���O ROOT
	   if (g != myHead) {
		   NodePtr gp = g->parent;
		   //����
		   g->left = p->right;
		   p->right = g;
		   g->parent = p;
		   p->parent = gp;
		   //�Y g ���O ROOT �h gp �α� p
		   if (g == gp->right)
			   gp->right = p;
		   else
			   gp->left = p;
	   }
	   //g �O ROOT
	   else if (g == myHead) {
		   g->left = p->right;
		   p->right = g;
		   g->parent = p;
		   p->parent = myHead;
		   myHead->parent = p;
	   }
	   //���C��
	   Color c = p->color;
	   p->color = g->color;
	   g->color = c;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
	   //3.-----------------------------
	   NodePtr g = p->parent;
	   //g ���O ROOT
	   if (g != myHead) {
		   NodePtr gp = g->parent;
		   //����
		   g->right = p->left;
		   p->left = g;
		   g->parent = p;
		   p->parent = gp;
		   //�Y g ���O ROOT �h gp �α� p
		   if (g == gp->right)
			   gp->right = p;
		   else
			   gp->left = p;
	   }
	   //g �O ROOT
	   else if (g == myHead) {
		   g->right = p->left;
		   p->left = g;
		   g->parent = p;
		   p->parent = myHead;
		   myHead->parent = p;
	   }
	   //���C��
	   Color c = p->color;
	   p->color = g->color;
	   g->color = c;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
	   //4.-----------------------------
	   //(5��cases 1.�R��ROOT 2.MbCr 3.MrCb 4.5.MbCb)
	   NodePtr p = node->parent;
	   NodePtr g = p->parent;
	   NodePtr c = myHead;
	   //�O���O�n�R��ROOT (1��)
	   if (node == myHead->parent) {
		   //myHead �s�ۤv
		   myHead->right = myHead->left = myHead;
		   myHead->parent = myHead;
	   }
	   //���O���� ���C
	   else {
		   if (node->right != myHead) {
			   c = node->right;
		   }
		   else if (node->left != myHead) {
			   c = node->left;
		   }
		   else {
			   c = myHead;
		   }

		   //�O C �� P �۳s
		   if(c != myHead)
			   c->parent = p;
		   if (node == p->left) {
			   p->left = c;
		   }
		   else {
			   p->right = c;
		   }
		   //simple cases
		   if (c->color == Color::Red && node->color == Color::Black) {
			   c->color = Color::Black;
		   }
		   //hard cases (Subcase 4-1-2�MSubcase 4-2-2)   (2��)
		   else if (node->color == Color::Black && c->color == Color::Black) {
			   fixUp(c, p);
		   }
	   }


	   //�վ� myHead �����k
	   //��
	   TreeNode<value_type>* temp = myHead->parent;//ROOT
	   while (temp != myHead) {
		   if (temp->left == myHead && temp == node) {
			   myHead->left = node->parent;
		   }
		   temp = temp->left;
	   }
	   //�k
	   TreeNode<value_type>* temp2 = myHead->parent;//ROOT
	   while (temp2 != myHead) {
		   if (temp2->right == myHead && temp2 == node) {
			   myHead->right = node->parent;
		   }
		   temp2 = temp2->right;
	   }
	   

	   //------------------
	   delete node;
	   mySize -= 1;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
	   //5.-----------------------------
	   NodePtr S = P->parent;
	   NodePtr SR = P->parent;
	   NodePtr SL = P->parent;
	   //�P�_ N �b�����٬O�k��
	   //���� (SR����)
	   if (N == P->left) {
		   S = P->right;
		   SR = S->right;
		   SL = S->left;
		   RRRotation(S);
		   SR->color = Color::Black;
	   }
	   //�k�� (SL����)
	   else {
		   S = P->left;
		   SR = S->right;
		   SL = S->left;
		   LLRotation(S);
		   SL->color = Color::Black;
	   }
   }

   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
		 cout << setw(5) << node->myval << (node->color == Color::Red ? "R" : "B");
         inorder( node->right );
      }
   }

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
	   //cout << "insert " << val << endl;
	   //6.-----------------------------
	   //insert �@ 8 �� case (����RLb LRb)
	   TreeNode<value_type>* u = new TreeNode<value_type>;
	   u->color = Color::Red;
	   u->isNil = 0;
	   u->myval = val;
	   u->left = u->right = scaryVal.myHead;
	   //u is ROOT (1��)
	   if (scaryVal.mySize == 0) {
		   u->color = Color::Black;
		   u->parent = scaryVal.myHead;
		   //HeaderNode
		   scaryVal.myHead->left = scaryVal.myHead->right = u;
		   scaryVal.myHead->parent = u;
	   }
	   //u isn't ROOT (7��)
	   else {
		   TreeNode<value_type>* it = scaryVal.myHead->parent;//ROOT
		   //����m it
		   while (it != scaryVal.myHead) {
			   //�j�󵥩� ���k�䨫 (�Hless�����)
			   if (!(keyCompare(val, it->myval))) {
				   //�k��̫�@�ӤF it �Y�� p
				   if (it->right == scaryVal.myHead) {
					   it->right = u;
					   u->parent = it;
					   break;
				   }
				   //���k��
				   else
					   it = it->right;
			   }
			   //�p�� �����䨫
			   else if (keyCompare(val, it->myval)){
				   if (it->left == scaryVal.myHead) {
					   it->left = u;
					   u->parent = it;
					   break;
				   }
				   else
					   it = it->left;
			   }
			   else {
				   cout << "���Ө���o��" << endl;
			   }
		   }

		   //�վ�myHead�����k
		   //��
		   TreeNode<value_type>* temp = scaryVal.myHead->parent;//ROOT
		   while (temp != scaryVal.myHead) {
			   if (temp->left == scaryVal.myHead && temp == u) {
				   scaryVal.myHead->left = u;
			   }
			   temp = temp->left;
		   }
		   //�k
		   TreeNode<value_type>* temp2 = scaryVal.myHead->parent;//ROOT
		   while (temp2 != scaryVal.myHead) {
			   if (temp2->right == scaryVal.myHead && temp2 == u) {
				   scaryVal.myHead->right = u;
			   }
			   temp2 = temp2->right;
		   }

		   //rebalance (7�ؤ� 6 �حnrebalance)
		   if (u->parent != scaryVal.myHead->parent) {
			   scaryVal.reBalance(u);
		   }
	   }
	   
	   cout << "-------------------------" << endl;
	   cout << "insert " << val << " ����" << endl;
	   scaryVal.inorder(scaryVal.myHead->parent);
	   cout << endl;
	   cout << "-------------------------" << endl;
	   scaryVal.mySize += 1;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
	   //cout << "erase " << val << endl;
	   //7.-----------------------------
	   TreeNode<key_type>* it = scaryVal.myHead->parent;//ROOT
	   //����X�n�R���� Node (= it)
	   while (it != scaryVal.myHead) {
		   //���� break
		   if (val == it->myval)
			   break;
		   //�j�󵥩� ���k�䨫 (�Hless�����)
		   else if (!(keyCompare(val, it->myval)))
			   it = it->right;
		   //�p�� �����䨫
		   else
			   it = it->left;
	   }
	   //�䤣��h���X
	   if (it == scaryVal.myHead) {
		   return scaryVal.mySize;
	   }
	   if (it->left == scaryVal.myHead && it->right == scaryVal.myHead) {
		   scaryVal.eraseDegreeOne(it);
	   }
	   //��쩹�k���ʤ@�B
	   else if (it->right == scaryVal.myHead) {
		   TreeNode<key_type>* it2 = it->left;
		   //��X����l�𤤳̤j��
		   while (it2->right != scaryVal.myHead) {
			   it2 = it2->right;
		   }
		   //�ƻs����
		   it->myval = it2->myval;
		   //erasedegreeone()
		   scaryVal.eraseDegreeOne(it2);
	   }
	   else {
		   TreeNode<key_type>* it2 = it->right;
		   //��X�k��l�𤤳̤p��
		   while (it2->left != scaryVal.myHead) {
			   it2 = it2->left;
		   }
		   //�ƻs����
		   it->myval = it2->myval;
		   //erasedegreeone()
		   scaryVal.eraseDegreeOne(it2);
	   }
	   
	   cout << "-------------------------" << endl;
	   cout << "erase " << val << " ����" << endl;
	   scaryVal.inorder(scaryVal.myHead->parent);
	   cout << endl;
	   cout << "-------------------------" << endl;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE