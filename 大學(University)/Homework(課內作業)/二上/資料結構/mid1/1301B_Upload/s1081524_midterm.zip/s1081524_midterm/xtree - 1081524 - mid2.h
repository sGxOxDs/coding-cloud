// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color { Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
	using NodePtr = TreeNode*;
	using value_type = Ty;

	NodePtr    left;   // left subtree, or smallest element if head
	NodePtr    parent; // parent, or root of tree if head
	NodePtr    right;  // right subtree, or largest element if head
	Color      color;  // Red or Black, Black if head
	bool       isNil;  // true only if head (also nil) node
	value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
	using NodePtr = TreeNode< Ty >*;

	using value_type = Ty;
	using size_type = size_t;

	TreeVal()
		: myHead(new TreeNode< value_type >),
		mySize(0)
	{
		myHead->left = myHead;
		myHead->parent = myHead;
		myHead->right = myHead;
		myHead->color = Color::Black;
		myHead->isNil = true;
	}

	~TreeVal()
	{
		clear(myHead->parent);
		delete myHead;
	}

	// Removes all elements from the set object (which are destroyed)
	void clear(TreeNode< value_type >* node)
	{
		if (!node->isNil) // node is not an external node
		{
			clear(node->left);
			clear(node->right);
			delete node;
		}
	}

	// rebalance for insertion
	void reBalance(TreeNode< value_type >* node)
	{  // node->parent cannot be the root
		if (node->parent->left == node
			&& node->parent->parent->left == node->parent
			&& node->parent->parent->right->color == Color::Red) {//LLr 
			if (node->parent->parent->parent->isNil != 1)
				node->parent->parent->color = Color::Red;
			node->parent->color = Color::Black;
			node->parent->parent->right->color = Color::Black;
			if (node->parent->parent->parent->isNil != 1)
				reBalance(node->parent->parent);
		}
		else if (node->parent->right == node
			&& node->parent->parent->left == node->parent
			&& node->parent->parent->right->color == Color::Red) {//LRr�S�g�L
			if (node->parent->parent->parent->isNil != 1)
				node->parent->parent->color = Color::Red;
			node->parent->color = Color::Black;
			node->parent->parent->right->color = Color::Black;
			if (node->parent->parent->parent->isNil != 1)
				reBalance(node->parent->parent);

		}
		else if (node->parent->right == node
			&& node->parent->parent->right == node->parent
			&& node->parent->parent->left->color == Color::Red) {//RRr
			if (node->parent->parent->parent->isNil != 1)
				node->parent->parent->color = Color::Red;
			node->parent->color = Color::Black;
			node->parent->parent->left->color = Color::Black;
			if (node->parent->parent->parent->isNil != 1)
				reBalance(node->parent->parent);

		}
		else if (node->parent->left == node
			&& node->parent->parent->right == node->parent
			&& node->parent->parent->left->color == Color::Red) {//RLr�S�g�L
			if (node->parent->parent->parent->isNil != 1)
				node->parent->parent->color = Color::Red;
			node->parent->color = Color::Black;
			node->parent->parent->left->color = Color::Black;
			if (node->parent->parent->parent->isNil != 1)
				reBalance(node->parent->parent);
		}
		else if (node->parent->left == node
			&& node->parent->parent->left == node->parent
			&& node->parent->parent->right->color == Color::Black) {//LLb 
			LLRotation(node->parent);
			node->parent->color = Color::Black;
			node->parent->right->color = Color::Red;
		}
		else if (node->parent->right == node
			&& node->parent->parent->right == node->parent
			&& node->parent->parent->left->color == Color::Black) {//RRb
			RRRotation(node->parent);
			node->parent->color = Color::Black;
			node->parent->left->color = Color::Red;
		}

	}

	// rotate right at g, where p = g->left and node = p->left
	//void set< Kty >::LLbRotation( TreeNode< value_type > *node )
	void LLRotation(TreeNode< value_type >* p)
	{
		TreeNode< value_type >* gu = p->parent;
		TreeNode< value_type >* puR = p->right;
		if (gu->parent->isNil == 1)
			gu->parent->parent = p;
		else if (gu->parent->left == gu)
			gu->parent->left = p;
		else if (gu->parent->right == gu)
			gu->parent->right = p;
		p->parent = gu->parent;
		gu->parent = p;
		p->right = gu;
		gu->left = puR;
		if (puR->isNil != 1)
			puR->parent = gu;

	}

	// rotate left at g, where p = g->right and node = p->right
	//void set< Kty >::RRbRotation( TreeNode< value_type > *node )
	void RRRotation(TreeNode< value_type >* p)
	{
		TreeNode< value_type >* gu = p->parent;
		TreeNode< value_type >* puL = p->left;
		if (gu->parent->isNil == 1)
			gu->parent->parent = p;
		else if (gu->parent->left == gu)
			gu->parent->left = p;
		else if (gu->parent->right == gu)
			gu->parent->right = p;
		p->parent = gu->parent;
		gu->parent = p;
		p->left = gu;
		gu->right = puL;
		if (puL->isNil != 1)
			puL->parent = gu;
	}

	// erase node provided that the degree of node is at most one
	void eraseDegreeOne(TreeNode< value_type >* node)
	{
		TreeNode< value_type >* child = myHead;
		if (node->left != myHead)
			child = node->left;
		if (node->right != myHead)
			child = node->right;
		if (child != myHead) {
			if (node->parent->right == node)
				node->parent->right = child;
			else if (node->parent->left == node)
				node->parent->left = child;

		}
		else if (child == myHead) {//�S���lnode
			if (node->parent->right == node)
				node->parent->right = myHead;
			else if (node->parent->left == node)
				node->parent->left = myHead;
			//child = node;
		}

		if (node->color == Color::Black && child->color == Color::Black)
			fixUp(child, node->parent);
		if (child->color == Color::Red && node->color == Color::Black)
			child->color = Color::Black;
		delete node;
		--mySize;


	}

	// rebalance for deletion
	void fixUp(TreeNode< value_type >* N, TreeNode< value_type >* P)
	{
		if (P->left == N) {
			if (P->right->color == Color::Black)
				if (P->right->right->color == Color::Red) {//(Case 2)
					RRRotation(P->right);
					Color s = P->parent->color;
					P->parent->color = P->color;
					P->color = s;
					P->parent->right->color = Color::Black;
				}
		}
		else if (P->right == N) {
			if (P->left->color == Color::Black)
				if (P->left->left->color == Color::Red) {//(Case 2)
					LLRotation(P->left);
					Color s = P->parent->color;
					P->parent->color = P->color;
					P->color = s;
					P->parent->left->color = Color::Black;
				}
		}
	}

	/*
	   // preorder traversal and inorder traversal
	   void twoTraversals()
	   {
		  cout << "Preorder sequence:\n";
		  preorder( myHead->parent );

		  cout << "\nInorder sequence:\n";
		  inorder( myHead->parent );
		  cout << endl;
	   }

	   // preorder traversal
	   void preorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 preorder( node->left );
			 preorder( node->right );
		  }
	   }

	   // inorder traversal
	   void inorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 inorder( node->left );
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 inorder( node->right );
		  }
	   }
	*/

	NodePtr myHead;   // pointer to head node
	size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
	using value_type = typename Traits::value_type;

protected:
	using ScaryVal = TreeVal< value_type >;

public:
	using key_type = typename Traits::key_type;
	using key_compare = typename Traits::key_compare;

	using size_type = size_t;

	Tree(const key_compare& parg)
		: keyCompare(parg),
		scaryVal()
	{
	}

	~Tree()
	{
	}

	// Extends the container by inserting a new element,
	// effectively increasing the container size by one.
	void insert(const value_type& val)
	{
		TreeNode< value_type >* newNode = new TreeNode< value_type >;
		newNode->color = Color::Red;
		newNode->parent = scaryVal.myHead;
		newNode->right = scaryVal.myHead;
		newNode->left = scaryVal.myHead;
		newNode->isNil = false;
		newNode->myval = val;
		if (scaryVal.mySize == 0)
		{
			newNode->color = Color::Black;
			scaryVal.myHead->left = newNode;
			scaryVal.myHead->right = newNode;
			scaryVal.myHead->parent = newNode;
			scaryVal.mySize++;
		}
		else
		{
			TreeNode< value_type >* nodeptr = scaryVal.myHead->parent;
			while (val != nodeptr->myval) {
				if (keyCompare(val, nodeptr->myval))
					if (nodeptr->left != scaryVal.myHead)
						nodeptr = nodeptr->left;
					else
						break;
				if (keyCompare(nodeptr->myval, val))
					if (nodeptr->right != scaryVal.myHead)
						nodeptr = nodeptr->right;
					else
						break;
			}
			if (val != nodeptr->myval)
			{
				if (keyCompare(val, nodeptr->myval)) {
					nodeptr->left = newNode;
					newNode->parent = nodeptr;
				}
				else {
					nodeptr->right = newNode;
					newNode->parent = nodeptr;
				}
				if (keyCompare(val, scaryVal.myHead->left->myval))
					scaryVal.myHead->left = newNode;
				if (keyCompare(scaryVal.myHead->right->myval, val))
					scaryVal.myHead->right = newNode;
				if (newNode->parent->color == Color::Red)
					scaryVal.reBalance(newNode);
				scaryVal.mySize++;
			}
		}

	}

	// Removes from the set container a single element whose value is val
	// This effectively reduces the container size by one, which are destroyed.
	// Returns the number of elements erased.
	size_type erase(const key_type& val)
	{
		size_type it = 0;
		TreeNode< value_type >* nodeptr = scaryVal.myHead->parent;
		while (val != nodeptr->myval) {
			if (keyCompare(val, nodeptr->myval))
				if (nodeptr->left != scaryVal.myHead)
					nodeptr = nodeptr->left;
				else
					break;
			if (keyCompare(nodeptr->myval, val))
				if (nodeptr->right != scaryVal.myHead)
					nodeptr = nodeptr->right;
				else
					break;
		}
		if (val == nodeptr->myval) {
			TreeNode< value_type >* DELnodeptr = nodeptr;
			if (nodeptr->left == scaryVal.myHead || nodeptr->right == scaryVal.myHead)
				scaryVal.eraseDegreeOne(DELnodeptr);
			else {
				DELnodeptr = DELnodeptr->right;
				while (DELnodeptr->left != scaryVal.myHead)
					DELnodeptr = DELnodeptr->left;
				nodeptr->myval = DELnodeptr->myval;
				scaryVal.eraseDegreeOne(DELnodeptr);
			}
			it = 1;
		}

		return it;
	}

private:
	key_compare keyCompare;
	ScaryVal scaryVal;
};

#endif // XTREE