// xtree internal header
//
#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance(TreeNode< value_type >* node)
   {  // node->parent cannot be the root
	   TreeNode<value_type>* p = node->parent;//parent
	   TreeNode<value_type>* g = p->parent;//grand
	   TreeNode<value_type>* u = (p == g->left ? g->right : g->left);//uncle
	   if (node->parent->isNil) { node->color = Color::Black; return; }

	   if (node->color = Color::Red) return;

	   if (g->right == p && p->right == node) {
		   RRRotation(p);
		   std::swap(p->color, g->color);
		   return;
	   }
	   if (g->left == p && p->left == node) {
		   LLRotation(p);
		   std::swap(p->color, g->color);
		   return;
	   }
	   if (g->right == p && p->left == node) {
		   //RLRotation(node)
		   LLRotation(node);
		   RRRotation(node);
		   std::swap(node->color, g->color);
		   return;
	   }
	   if (g->left == p && p->right == node) {
		   //LRRotation(node)
		   RRRotation(node);
		   LLRotation(node);
		   std::swap(node->color, g->color);
	   }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation(TreeNode< value_type >* p)
   {
	   TreeNode<value_type>* g = p->parent;
	   p->left = g->right;
	   if (!g->right->isNil) g->right->parent = p;

	   g->parent = p->parent;
	   if (p->parent->isNil)p->parent = g;
	   else
		   g == g->right->parent ? g->right = p : g->left = p;

	   g->right = p->left;
	   p->parent = g->left;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
	   TreeNode<value_type>* g = p->parent;
	   p->right = g->left;
	   if (!g->left->isNil) g->left->parent = p;
	   
	   g->parent = p->parent;
	   if (p->parent->isNil)p->parent = g;
	   else
		   g == g->right->parent ? g->right = p : g->left = p;
	   
	   g->left = p->right;
	   p->parent = g->right;

   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {

   }

   // rebalance for deletion
   void fixUp(TreeNode< value_type >* N, TreeNode< value_type >* P)
   {
	   TreeNode<value_type>* S = (N == P->right ? P->left : P->right);//N uncle
	   if (S->color == Color::Red) {//Case 1
		   std::swap(S->color, P->color);
	   }

	   if (S->color == Color::Black &&
		   S->right->color == Color::Black &&
		   S->right->color == Color::Red) {//S and Sr are black, but Sl is red (case3)
		   if (P->right == S) {//Case3.1
			   std::swap(S->color, S->left->color);
			   LLRotation(S);
		   }
		   if (P->left == S) {//Case3.2
			   std::swap(S->color, S->left->color);
			   RRRotation(S);
		   }
	   }
	   S = (N == P->right ? P->left : P->right);
	   if (S->color == Color::Black &&
		   S->right->color == Color::Red) {//Case2
		   if (P->right == S) {//Case2.1
			   RRRotation(P);
			   std::swap(P->color, S->color);
			   S->right->color == Color::Black;
		   }
		   if (P->left == S) {//Case2.2
			   LLRotation(P);
			   std::swap(P->color, S->color);
			   S->right->color == Color::Black;
		   }
	   }
	   S = (N == P->right ? P->left : P->right);
	   if (S->color == Color::Black &&
		   S->right->color == Color::Black &&
		   S->left->color == Color::Black &&
		   P->color == Color::Red) {//Case4
		   std::swap(S->color, P->color);
	   }
	   if (S->color == Color::Black &&
		   S->right->color == Color::Black &&
		   S->left->color == Color::Black &&
		   P->color == Color::Black) {//Case5
		   S->color = Color::Red;
		   fixUp(P);
	   }
	   
   }
/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert(const value_type& val)
   {
	   if (this.scaryVal.mySize()) {
		   TreeNode<value_type>* tmp;
		   tmp->color = Color::Black;
		   tmp->isNil = true;
		   tmp->myval = val;
		   this->scaryVal.myHead = tmp;
	   }
	   else {
			
	   }
   }
   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
	   
	   
	   return 0;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE