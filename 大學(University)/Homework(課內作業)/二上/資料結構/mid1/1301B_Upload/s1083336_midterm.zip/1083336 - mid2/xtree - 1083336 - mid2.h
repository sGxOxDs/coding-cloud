// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
	   TreeNode< value_type >* p = node->parent;
	   if (node == p->left)
		   LLRotation(p);
	   else
		   RRRotation(p);
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
	   TreeNode< value_type >* g = p->parent;
	   TreeNode< value_type >* gp = g->parent;
	   TreeNode< value_type >* pur = p->right;
	   if (g == gp->left)
		   gp->left = p;
	   else
		   gp->right = p;

	   p->parent = gp;
	   p->right = g;
	   g->parent = p;
	   g->left = pur;
	   pur->parent = g;

   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
	   TreeNode< value_type >* g = p->parent;
	   TreeNode< value_type >* gp = g->parent;
	   TreeNode< value_type >* pul = p->left;
	   if (g == gp->left)
		   gp->left = p;
	   else
		   gp->right = p;

	   p->parent = gp;
	   p->left = g;
	   g->parent = p;
	   g->right = pul;
	   pul->parent = g;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne(TreeNode< value_type >* node)
   {
	   TreeNode< value_type >* p = node->parent;
	   TreeNode< value_type >* n;
	   /*if (node->right != myHead && node->left != myHead)
	   {
		   TreeNode< value_type >* now = node->left;
		   while (now->right != myHead)
			   now = now->right;
		   node->myval = now->myval;
		   delete node
	   }
	   else
	   {*/
	   if (node == p->left)
	   {
		   n = node->left;
		   p->left = n;
	   }
	   else
	   {
		   n = node->right;
		   p->right = n;
	   }
	   n->parent = p;
	   delete node;
	   fixUp(n, p);
	   //}
	   mySize--;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
	   TreeNode< value_type >* an,* an1,* an2,* g = P->parent;
	   if (N == P->left)
	   {
		   an = P->right;
		   an1 = an->right;
		   an2 = an->left;
	   }
	   else
	   {
		   an = P->left;
		   an1 = an->left;
		   an2 = an->right;
	   }

	   if (an1->color == Color(0))
	   {
		   an->color = P->color;
		   P->color = Color(1);
		   if (P == g->left)
			   g->left = an;
		   else
			   g->right = an;
		   an->parent = g;
		   if (N == P->left)
		   {
			   P->right = an2;
			   an->left = P;
		   }
		   else
		   {
			   P->left = an2;
			   an->right = P;
		   }
		   an2->parent = P;
		   P->parent = an;
	   }
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
	   TreeNode< value_type >* now = scaryVal.myHead->parent;
	   bool left;
	   while (true)
		   if (val == now->myval)
			   return;
		   else if (keyCompare(val, now->myval))
			   if (now->right != scaryVal.myHead)
				   now = now->right;
			   else
			   {
				   now = now->right;
				   left = false;
				   break;
			   }
		   else
			   if (now->left != scaryVal.myHead)
				   now = now->left;
			   else
			   {
				   now = now->left;
				   left = true;
				   break;
			   }

	   TreeNode< value_type >* temp = new TreeNode< value_type >();
	   temp->color = Color(0);
	   temp->isNil = 0;
	   temp->myval = val;
	   temp->parent = now;
	   temp->left = temp->right = scaryVal.myHead;
	   if (left)
		   now->left = temp;
	   else
		   now->right = temp;
	   scaryVal.reBalance(temp);
	   scaryVal.mySize++;

	   if (scaryVal.myHead->left->left != scaryVal.myHead)
		   scaryVal.myHead->left = temp;
	   else if (scaryVal.myHead->right->right != scaryVal.myHead)
		   scaryVal.myHead->right = temp;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
	   TreeNode< value_type >* now = scaryVal.myHead->parent;
	   while (now->myval != val)
		   if (now == scaryVal.myHead)
			   return 0;
		   else if (keyCompare(val, now->myval))
			   now = now->right;
		   else
			   now = now->left;
	   scaryVal.eraseDegreeOne(now);
	   return 1;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE