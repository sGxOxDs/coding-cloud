// xtree internal header
// finish
#ifndef XTREE
#define XTREE

enum class Color { Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
	using NodePtr = TreeNode*;
	using value_type = Ty;

	NodePtr    left;   // left subtree, or smallest element if head
	NodePtr    parent; // parent, or root of tree if head
	NodePtr    right;  // right subtree, or largest element if head
	Color      color;  // Red or Black, Black if head
	bool       isNil;  // true only if head (also nil) node
	value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
	using NodePtr = TreeNode< Ty >*;

	using value_type = Ty;
	using size_type = size_t;

	TreeVal()
		: myHead(new TreeNode< value_type >),
		mySize(0)
	{
		myHead->left = myHead;
		myHead->parent = myHead;
		myHead->right = myHead;
		myHead->color = Color::Black;
		myHead->isNil = true;
	}

	~TreeVal()
	{
		clear(myHead->parent);
		delete myHead;
	}

	// Removes all elements from the set object (which are destroyed)
	void clear(TreeNode< value_type >* node)
	{
		if (!node->isNil) // node is not an external node
		{
			clear(node->left);
			clear(node->right);
			delete node;
		}
	}

	// rebalance for insertion
	void reBalance(TreeNode< value_type >* node)
	{  // node->parent cannot be the root

		if (node->parent->color == Color::Red)
		{
			NodePtr p = node->parent;
			NodePtr g = p->parent;
			NodePtr u;

			if (p == g->left)
				u = g->right;
			else
				u = g->left;

			if (u->color == Color::Red)
			{
				g->color = Color::Red;
				p->color = Color::Black;
				u->color = Color::Black;

				reBalance(g);
			}
			else // u->color==black
			{
				if (p == g->left)
				{
					if (node == p->left) // LL
					{
						p->color = Color::Black;
						g->color = Color::Red;
						LLRotation(p);
					}
					else // LR
					{
						node->color = Color::Black;
						g->color = Color::Red;
						RRRotation(node);
						LLRotation(node);
					}
				}
				else
				{
					if (node == p->left) // RL
					{
						node->color = Color::Black;
						g->color = Color::Red;
						LLRotation(node);
						RRRotation(node);
					}
					else // RR
					{
						p->color = Color::Black;
						g->color = Color::Red;
						RRRotation(p);
					}
				}

			}
		}




		myHead->parent->color = Color::Black;

	}

	// rotate right at g, where p = g->left and node = p->left
	//void set< Kty >::LLbRotation( TreeNode< value_type > *node )
	void LLRotation(TreeNode< value_type >* p)
	{
		NodePtr g = p->parent;


		if (g != myHead->parent)
		{
			if (g == (g->parent)->left)
				(g->parent)->left = p;
			else
				(g->parent)->right = p;
		}
		else
			myHead->parent = p;//p=new root

		p->parent = g->parent;

		g->left = p->right;
		if (p->right != myHead)
			p->right->parent = g;



		g->parent = p;
		p->right = g;



	}

	// rotate left at g, where p = g->right and node = p->right
	//void set< Kty >::RRbRotation( TreeNode< value_type > *node )
	void RRRotation(TreeNode< value_type >* p)
	{
		NodePtr g = p->parent;


		if (g != myHead->parent)
		{
			if (g == (g->parent)->left)
				(g->parent)->left = p;
			else
				(g->parent)->right = p;
		}
		else
			myHead->parent = p;//p=new root

		p->parent = g->parent;

		g->right = p->left;
		if (p->left != myHead)
			p->left->parent = g;



		g->parent = p;
		p->left = g;
	}

	// erase node provided that the degree of node is at most one
	void eraseDegreeOne(TreeNode< value_type >* node)
	{
		NodePtr p = node->parent;
		NodePtr child;

		if (node->left != myHead)
			child = node->left;
		else if (node->right != myHead)
			child = node->right;
		else
			child = myHead;

		if (node == myHead->parent)//node is root
			myHead->parent = child;//child become new root
		else
		{
			if (node == p->left)
				p->left = child;
			else
				p->right = child;
		}

		if (child != myHead)
			child->parent = p;


		if (node == myHead->left)
		{
			NodePtr x = myHead->parent;
			NodePtr xP = myHead;

			while (x != myHead)
			{
				xP = x;
				x = x->left;
			}

			myHead->left = xP;
		}

		if (node == myHead->right)
		{
			NodePtr x = myHead->parent;
			NodePtr xP = myHead;

			while (x != myHead)
			{
				xP = x;
				x = x->right;
			}

			myHead->right = xP;
		}

		if (node->color == Color::Black)
		{
			if (child->color == Color::Red)
				child->color = Color::Black;
			else
				fixUp(child, p);
		}




		delete node;
		mySize--;

	}

	// rebalance for deletion
	void fixUp(TreeNode< value_type >* N, TreeNode< value_type >* P)
	{
		NodePtr s;

		if (N == P->left)
			s = P->right;
		else
			s = P->left;


		NodePtr sR = s->right;
		NodePtr sL = s->left;


		if ((s->color == Color::Black) && (s == P->left) && (sL->color == Color::Red))
		{
			s->color = P->color;
			P->color = Color::Black;
			sL->color = Color::Black;
			LLRotation(s);
		}
		else if ((s->color == Color::Black) && (s == P->right) && (sR->color == Color::Red))
		{
			s->color = P->color;
			P->color = Color::Black;
			sR->color = Color::Black;
			RRRotation(s);
		}


	}


	// preorder traversal and inorder traversal
	void twoTraversals()
	{
		cout << "Preorder sequence:\n";
		preorder(myHead->parent);

		cout << "\nInorder sequence:\n";
		inorder(myHead->parent);
		cout << endl;
	}

	// preorder traversal
	void preorder(TreeNode< value_type >* node)
	{
		if (node != myHead)
		{
			cout << setw(5) << node->myval << (node->color == Color::Red ? "R" : "B");
			preorder(node->left);
			preorder(node->right);
		}
	}

	// inorder traversal
	void inorder(TreeNode< value_type >* node)
	{
		if (node != myHead)
		{
			inorder(node->left);
			cout << setw(5) << node->myval << (node->color == Color::Red ? "R" : "B");
			inorder(node->right);
		}
	}
	/**/

	NodePtr myHead;   // pointer to head node
	size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
	using value_type = typename Traits::value_type;

protected:
	using ScaryVal = TreeVal< value_type >;

public:
	using key_type = typename Traits::key_type;
	using key_compare = typename Traits::key_compare;

	using size_type = size_t;

	Tree(const key_compare& parg)
		: keyCompare(parg),
		scaryVal()
	{
	}

	~Tree()
	{
	}

	// Extends the container by inserting a new element,
	// effectively increasing the container size by one.
	void insert(const value_type& val)
	{
		TreeNode<value_type>* p = scaryVal.myHead->parent;
		TreeNode<value_type>* pp = scaryVal.myHead;

		while ((p != scaryVal.myHead) && (p->myval != val))
		{
			pp = p;

			if (keyCompare(p->myval, val))
				p = p->right;
			else
				p = p->left;
		}

		if (p == scaryVal.myHead)
		{
			TreeNode<value_type>* node = new TreeNode<value_type>;
			node->color = Color::Red;
			node->isNil = false;
			node->left = node->right = scaryVal.myHead;
			node->myval = val;
			node->parent = pp;

			if (scaryVal.mySize == 0)
			{
				//node->parent = scaryVal.myHead;
				node->color = Color::Black;
				scaryVal.myHead->parent = node;
				scaryVal.myHead->left = node;
				scaryVal.myHead->right = node;


			}
			else
			{
				if (keyCompare(pp->myval, val))
					pp->right = node;
				else
					pp->left = node;

				if (keyCompare(val, scaryVal.myHead->left->myval))
					scaryVal.myHead->left = node;

				if (keyCompare(scaryVal.myHead->right->myval, val))
					scaryVal.myHead->right = node;

				if (pp->color == Color::Red)
					scaryVal.reBalance(node);
			}

			scaryVal.mySize++;

		}

	}

	// Removes from the set container a single element whose value is val
	// This effectively reduces the container size by one, which are destroyed.
	// Returns the number of elements erased.
	size_type erase(const key_type& val)
	{
		TreeNode<value_type>* p = scaryVal.myHead->parent;


		while ((p != scaryVal.myHead) && (p->myval != val))
		{

			if (keyCompare(p->myval, val))
				p = p->right;
			else
				p = p->left;
		}

		if (p != scaryVal.myHead)
		{
			if ((p->left == scaryVal.myHead) && (p->right == scaryVal.myHead))
			{
				scaryVal.eraseDegreeOne(p);
				return 1;
			}
			else if ((p->left != scaryVal.myHead) && (p->right == scaryVal.myHead))
			{
				scaryVal.eraseDegreeOne(p);
				return 1;
			}
			else if (p->right != scaryVal.myHead)
			{
				TreeNode<value_type>* y = p->right;
				TreeNode<value_type>* rMin = y;

				while (y != scaryVal.myHead)
				{
					rMin = y;
					y = y->left;
				}

				p->myval = rMin->myval;
				scaryVal.eraseDegreeOne(rMin);

				return 1;
			}

		}

		return 0;


	}

private:
	key_compare keyCompare;
	ScaryVal scaryVal;
};

#endif // XTREE