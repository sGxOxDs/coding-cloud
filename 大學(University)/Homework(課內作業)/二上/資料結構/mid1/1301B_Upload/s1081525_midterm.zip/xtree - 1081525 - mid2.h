// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
	   TreeNode< value_type >* p = node->parent;
	   TreeNode< value_type >* g = p->parent;
	   TreeNode< value_type >* u;
	   if (g->left == p)
		   u = g->right;
	   else
		   u = g->left;
	   if (u->color == Color::Red)
	   {
		   u->color = Color::Black;
		   p->color = Color::Black;
		   if (myHead->parent != g)
		   {
			   g->color = Color::Red;
			   if (g->parent->color == Color::Red)
				   reBalance(g);
		   }
	   }
	   else if (node==p->left&&p==g->left)
	   {
		   p->color = Color::Black;
		   g->color = Color::Red;
		   LLRotation(p);
	   }
	   else if (node == p->right && p == g->right)
	   {
		   p->color = Color::Black;
		   g->color = Color::Red;
		   RRRotation(p);
	   }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {//g��p�k�U
	   TreeNode< value_type >* g = p->parent;
	   g->left = p->right;
	   if (!(p->right->isNil))
		   p->right->parent = g;
	   if (g->parent->left == g)
		   g->parent->left = p;
	   if(g->parent->right == g)
		   g->parent->right = p;
	   if (g->parent->parent == g)
		   g->parent->parent = p;
	   p->parent = g->parent;
	   p->right = g;
	   g->parent = p;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {//g��p���U
	   TreeNode< value_type >* g = p->parent;
	   g->right = p->left;
	   if (!(p->left->isNil))
		   p->left->parent = g;
	   if (g->parent->left == g)
		   g->parent->left = p;
	   if (g->parent->right == g)
		   g->parent->right = p;
	   if (g->parent->parent == g)
		   g->parent->parent = p;
	   p->parent = g->parent;
	   p->left = g;
	   g->parent = p;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne(TreeNode< value_type >* node)
   {
	   TreeNode< value_type >* p = node->parent;
	   TreeNode< value_type >* child = myHead;
	   if (!(node->right->isNil))
		   child = node->right;
	   else if (!(node->left->isNil))
		   child = node->left;
	   if (child->isNil == 0)
	   {
		   if (myHead->left == node)
			   myHead->left = child;
		   if (myHead->right == node)
			   myHead->right = child;
		   child->parent = p;
		   if (node->color == Color::Red)
		   {
			   if (node == p->left)
				   p->left = child;
			   if (node == p->right)
				   p->right = child;
		   }
		   else if (child->color == Color::Red)
		   {
			   child->color = Color::Black;
			   node->color = Color::Red;
			   if (myHead->parent == node)
				   p->parent = child;
			   else if (node == p->left)
				   p->left = child;
			   else
				   p->right = child;
		   }
		   else if (myHead->parent == node)
		   {
			   node->color = Color::Red;
			   p->parent = child;
		   }
		   else
		   {
			   if (node == p->left)
				   p->left = child;
			   else
				   p->right = child;
		   }
		   if (node->color == Color::Black)
			   fixUp(child, p);
	   }
	   else
	   {
		   if (myHead->left == node)
			   myHead->left = p;
		   if (myHead->right == node)
			   myHead->right = p;
		   if (node == p->left)
		   {
			   p->left = myHead;
		   }
		   else if (node == p->right)
		   {
			   p->right = myHead;
		   }
		   else
			   p->parent = myHead;
	   }
	   delete node;
	   mySize--;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
	   TreeNode< value_type >* S;
	   if (N == P->left)
		   S = P->right;
	   else
		   S = P->left;
	   if (N = P->left)
	   {
		   S->color = P->color;
		   P->color = Color::Black;
		   S->right->color = Color::Black;
		   RRRotation(S);
	   }
	   else
	   {
		   S->color = P->color;
		   P->color = Color::Black;
		   S->left->color = Color::Black;
		   LLRotation(S);
	   }
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert(const value_type& val)
   {
	   TreeNode< value_type >* node = new TreeNode< value_type >;
	   node->isNil = 0;
	   node->left = scaryVal.myHead;
	   node->right = scaryVal.myHead;
	   node->myval = val;
	   if (scaryVal.myHead->parent->isNil)
	   {
		   node->color = Color::Black;
		   node->parent = scaryVal.myHead;
		   scaryVal.myHead->left = node;
		   scaryVal.myHead->right = node;
		   scaryVal.myHead->parent = node;
		   scaryVal.mySize++;
		   return;
	   }
	   TreeNode< value_type >* it = scaryVal.myHead->parent;
	   while (true)
		   if (keyCompare(it->myval, val))
		   {
			   if (it->right->isNil)
				   break;
			   it = it->right;
		   }
		   else if (keyCompare(val, it->myval))
		   {
			   if (it->left->isNil)
				   break;
			   it = it->left;
		   }
		   else
		   {
			   delete node;
			   return;
		   }
	   node->color = Color::Red;
	   if (keyCompare(val, it->myval))
	   {
		   it->left = node;
		   node->parent = it;
		   if (scaryVal.myHead->left == it)
			   scaryVal.myHead->left = node;
	   }
	   else
	   {
		   it->right = node;
		   node->parent = it;
		   if (scaryVal.myHead->right == it)
			   scaryVal.myHead->right = node;
	   }
	   if (it->color == Color::Red)
		   scaryVal.reBalance(node);
	   scaryVal.mySize++;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
	   TreeNode< value_type >* it = scaryVal.myHead->parent;
	   while (true)
		   if (keyCompare(it->myval, val))
		   {
			   if (it->right->isNil)
				   return 0;
			   it = it->right;
		   }
		   else if (keyCompare(val, it->myval))
		   {
			   if (it->left->isNil)
				   return 0;
			   it = it->left;
		   }
		   else
			   break;
	   if (!(it->left->isNil || it->right->isNil))
	   {
		   TreeNode< value_type >* it1 = it->right;
		   while (!(it1->left->isNil))
			   it1 = it1->left;
		   it->myval = it1->myval;
		   it = it1;
	   }
	   scaryVal.eraseDegreeOne(it);
	   return 1;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE