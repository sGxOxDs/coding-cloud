// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
	   TreeNode< value_type >* p = node->parent;
	   TreeNode< value_type >* g = p->parent;

	   if (g->left->color == Color::Red && g->right->color == Color::Red)
	   {
		   if (g->parent->isNil != 1)
		   {
			   g->color = Color::Red;
		   }
		   g->left->color = g->right->color = Color::Black;

		   if (g->parent->color == Color::Red)
		   {
			   reBalance(g);
		   }
	   }
	   else
	   {
		   p->color = Color::Black;
		   g->color = Color::Red;
		   if (g->right != p)//LLb
		   {
			   LLRotation(p);
		   }
		   else//RRb
		   {
			   RRRotation(p);
		   }
	   }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
	   TreeNode< value_type >* n = p->left;
	   TreeNode< value_type >* g = p->parent;

	   if (g->parent->isNil != 1)
	   {
		   if (g->parent->right != g)
		   {
			   g->parent->left = p;
		   }
		   else
		   {
			   g->parent->right = p;
		   }
	   }
	   else
	   {
		   myHead->parent = p;
	   }
	   p->parent = g->parent;

	   if (p->right != myHead)
	   {
		   p->right->parent = g;
		   g->left = p->right;
	   }
	   else
	   {
		   g->left = myHead;
	   }

	   p->right = g;
	   g->parent = p;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
	   TreeNode< value_type >* n = p->right;
	   TreeNode< value_type >* g = p->parent;

	   if (g->parent->isNil != 1)
	   {
		   if (g->parent->left != g)
		   {
			   g->parent->right = p;
		   }
		   else
		   {
			   g->parent->left = p;
		   }
	   }
	   else
	   {
		   myHead->parent = p;
	   }
	   p->parent = g->parent;

	   if (p->left != myHead)
	   {
		   p->left->parent = g;
		   g->right = p->left;
	   }
	   else
	   {
		   g->right = myHead;
	   }

	   p->left = g;
	   g->parent = p;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
	   TreeNode< value_type >* child = myHead;
	   TreeNode< value_type >* p = node->parent;

	   if (node->right != myHead)
	   {
		   child = child->right;
	   }
	   else if (node->left != myHead)
	   {
		   child = child->left;
	   }

	   //simple case
	   if (p->isNil == 1)//node == root
	   {
		   myHead->parent = child;
		   child->color = Color::Black;
	   }
	   else if (node->color == Color::Red && child->color == Color::Black)
	   {
		   if (p->right == node)
		   {
			   p->right = child;
		   }
		   else
		   {
			   p->left = child;
		   }

		   if (child != myHead)
			   child->parent = p;
	   }
	   else if (node->color == Color::Black && child->color == Color::Red)
	   {
		   if (p->right == node)
		   {
			   p->right = child;
		   }
		   else
		   {
			   p->left = child;
		   }
		   child->parent = p;
		   child->color = Color::Black;
	   }

	   delete[] node;
	   
	   if (child->color == Color::Black && node->color == Color::Black)
	   {
		   fixUp(child, p);
	   }

	   mySize--;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
	   if (P->left == N)
	   {
		   P->right->color = P->color;
		   P->color = Color::Black;
		   P->right->right->color = Color::Black;

		   TreeNode< value_type >* S = P->right;
		   S->parent = P->parent;
		   if (P->parent->right == P)
			   P->parent->right = S;
		   else
			   P->parent->left = S;
		   
		   if (S->left != myHead)
		   {
			   S->left->parent = P;
		   }
		   P->right = S->left;

		   S->left = P;
		   P->parent = S;
	   }
	   else
	   {
		   P->left->color = P->color;
		   P->color = Color::Black;
		   P->left->left->color = Color::Black;
		   
		   TreeNode< value_type >* S = P->left;
		   S->parent = P->parent;
		   if (P->parent->left == P)
			   P->parent->left = S;
		   else
			   P->parent->right = S;

		   if (S->right != myHead)
		   {
			   S->right->parent = P;
		   }
		   P->left = S->right;

		   S->right = P;
		   P->parent = S;
	   }
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
	   TreeNode< value_type >* e = scaryVal.myHead;
	   TreeNode< value_type >* u = new TreeNode< value_type >;
	   u->isNil = 0;
	   u->myval = val;
	   u->left = u->right = e;

	   if (e->parent->isNil == 1)//u�Oroot
	   {
		   u->parent = e;
		   e->left = e->right = e->parent = u;
		   u->color = Color::Black;
	   }
	   else
	   {
		   TreeNode< value_type >* p = e->parent;
		   TreeNode< value_type >* pp = p;
		   while (p != e)
		   {
			   pp = p;
			   if (!(keyCompare(val, p->myval)))//right
			   {
				   p = p->right;
			   }
			   else
			   {
				   p = p->left;
			   }
		   }

		   if (!(keyCompare(val, pp->myval)))
		   {
			   pp->right = u;
			   if (!(keyCompare(val, e->right->myval)))
				   e->right = u;
		   }
		   else
		   {
			   pp->left = u;
			   if (keyCompare(val, e->left->myval))
				   e->left = u;
		   }
		   u->parent = pp;
		   u->color = Color::Red;
	   }

	   if (u->parent->color == Color::Red)
		   scaryVal.reBalance(u);

	   scaryVal.mySize++;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
	   TreeNode< value_type >* n = scaryVal.myHead->parent;

	   while (n != scaryVal.myHead)
	   {
		   if (keyCompare(n->myval, val))//right
		   {
			   n = n->right;
		   }
		   else if (keyCompare(val, n->myval))
		   {
			   n = n->left;
		   }
		   else
		   {
			   break;
		   }
	   }

	   if (n != scaryVal.myHead)
	   {
		   TreeNode< value_type >* m = n;
		   if (n->right != scaryVal.myHead)
		   {
			   m = m->right;
			   while (m->left != scaryVal.myHead)
			   {
				   m = m->left;
			   }

			   if(!(keyCompare(m->myval, scaryVal.myHead->right->myval)))
				   scaryVal.myHead->right = m->parent;
		   }

		   n->myval = m->myval;
		   scaryVal.eraseDegreeOne(m);
	   }

	   return scaryVal.mySize;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE