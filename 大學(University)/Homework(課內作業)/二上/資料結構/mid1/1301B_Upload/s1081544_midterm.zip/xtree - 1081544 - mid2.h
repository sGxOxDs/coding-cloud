// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
	   NodePtr pu = node->parent;
	   NodePtr gu = pu->parent;
	   if (gu->left->color == Color::Red && gu->right->color == Color::Red)
	   {
		   gu->left->color = Color::Black;
		   gu->right->color = Color::Black;
	   }
	   else
	   {
		   if (gu->left == pu && gu->right->color == Color::Black)
		   {
			   if (pu->left == node)
				   LLRotation(node);
			   pu->color = Color::Black;
			   gu->color = Color::Red;
		   }
		   else if (gu->right == pu && gu->left->color == Color::Black)
		   {
			   if (pu->right == node)
				   RRRotation(node);
			   pu->color = Color::Black;
			   gu->color = Color::Red;
		   }
	   }

   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
	   NodePtr pu = p->parent;
	   NodePtr gu = pu->parent;
	   gu->left = pu->right;
	   pu->parent = gu;
	   if (gu->myval < gu->parent->myval)
		   gu->parent->left = pu;
	   else
		   gu->parent->right = pu;
	   pu->parent = gu->parent;
	   pu->right = gu;
	   gu->parent = pu;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
	   NodePtr pu = p->parent;
	   NodePtr gu = pu->parent;
	   gu->right = pu->left;
	   pu->parent = gu;
	   if (gu->myval < gu->parent->myval)
		   gu->parent->left = pu;
	   else
		   gu->parent->right = pu;
	   pu->parent = gu->parent;
	   pu->left = gu;
	   gu->parent = pu;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
	   NodePtr p = node;
	   if (p->right != myHead)
	   {
		   p = p->right;
		   while (p->left != myHead)
			   p = p->left;
	   }
	   else if (p->left != myHead)
	   {
		   p = p->left;
		   while (p->right != myHead)
			   p = p->right;
	   }
	   node->myval = p->myval;
	   


	   delete[]p;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {

   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
	   if (scaryVal.mySize == 0) 
	   {
		   TreeNode< value_type >* newNode = new TreeNode< value_type >;
		   scaryVal.myHead->parent = newNode;
		   scaryVal.myHead->left = newNode;
		   scaryVal.myHead->right = newNode;
		   newNode->left = scaryVal.myHead;
		   newNode->right = scaryVal.myHead;
		   newNode->parent = scaryVal.myHead;
		   newNode->color = Color::Black;
		   newNode->myval = val;
		   newNode->isNil = false;
	   }
	   else
	   {
		   TreeNode< value_type >* p = scaryVal.myHead->parent;
		   TreeNode< value_type >* pp = scaryVal.myHead->parent;
		   while (p != scaryVal.myHead)
		   {
			   pp = p;
			   if (keyCompare(val, p->myval))
				   p = p->left;
			   else if (keyCompare(p->myval, val))
				   p = p->right;
			   else return;
		   }
		   p = new TreeNode< value_type >;
		   p->myval = val;
		   if (keyCompare(val, pp->myval))
			   pp->left = p;
		   else
			   pp->right = p;
		   p->parent = pp;
		   p->left = scaryVal.myHead;
		   p->right = scaryVal.myHead;
		   p->color = Color::Red;
		   p->isNil = false;
		   if (p->parent->left == p && scaryVal.myHead->left == p->parent)
			   scaryVal.myHead->left = p;
		   if (p->parent->right == p && scaryVal.myHead->right == p->parent)
			   scaryVal.myHead->right = p;
		   if (p->parent != scaryVal.myHead->parent && p->color == p->parent->color)
			   scaryVal.reBalance(p);
	   }
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
	   if (scaryVal.mySize == 0)
		   return 0;
	   TreeNode< value_type >* p = scaryVal.myHead->parent;
	   while (p->myval != val)
	   {
		   if (keyCompare(val, p->myval))
			   p = p->left;
		   if (keyCompare(p->myval, val))
			   p = p->right;
		   if (p == scaryVal.myHead)
			   break;
	   }
	   if (p == scaryVal.myHead)
		   return 0;
	   else
	   {
		   scaryVal.eraseDegreeOne(p);
		   return 1;
	   }
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE