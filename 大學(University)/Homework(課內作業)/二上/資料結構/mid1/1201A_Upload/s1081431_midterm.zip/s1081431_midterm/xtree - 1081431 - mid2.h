// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
       bool condition = 0;
       TreeNode< value_type >* temp1 = node->parent; TreeNode< value_type >* temp2;
       if (node->parent->left == node) {
           temp2 = node->parent->right;
           condition = 1;
       }
       else temp2 = node->parent->left;
       /*node->color = Color::Black;
       temp1->color = Color::Red;*/
       if (condition) {
           if (temp2->color == Color::Red) {
               temp2->color = node->color = Color::Black;
               temp1->color = Color::Red;
               if (temp1->parent->color == Color::Red)
                   reBalance(temp1->parent);
               else if (temp1->parent == myHead)
                   temp1->color = Color::Black;
           }
           else {
               node->color = Color::Black;
               temp1->color = Color::Red;
               LLRotation(node);
           }
                
       }
       else {
           if (temp2->color == Color::Red) {
               temp2->color = node->color = Color::Black;
               temp1->color = Color::Red;
               if (temp1->parent->color == Color::Red)
                   reBalance(temp1->parent);
               else if (temp1->parent == myHead)
                   temp1->color = Color::Black;
           }
           else {
               node->color = Color::Black;
               temp1->color = Color::Red;
               RRRotation(node);
           }
               
       }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       TreeNode< value_type >* temp1 = p->parent; TreeNode< value_type >* temp3 = temp1->parent;
       temp1->left = p->right;
       if (p->right != myHead) 
           p->right->parent = temp1;
       
       p->parent = temp3;
       if (temp3->left == temp1)
           temp3->left = p;
       else if (temp3->right == temp1)
           temp3->right = p;
       
       temp1->parent = p;
       p->right = temp1;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       TreeNode< value_type >* temp1 = p->parent; TreeNode< value_type >* temp3 = temp1->parent;

       temp1->right = p->left;
       if (p->left != myHead)
           p->left->parent = temp1;

       p->parent = temp3;
       if (temp3->right == temp1)
           temp3->right = p;
       else if (temp3->left == temp1)
           temp3->left = p;

       temp1->parent = p;
       p->left = temp1;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
       TreeNode< value_type >* child; TreeNode< value_type >* p = node->parent; TreeNode< value_type >* s;
       bool condition;
       if (node->left != myHead) 
            child = node->left;
       else if (node->right != myHead)
           child = node->right;
       else
           child = myHead;

       if (child != myHead) {
           child->parent = p;
       }
       if (p != myHead) {
           if (p->left == node)
               p->left = child;
           else if (p->right == node)
               p->right = child;
       }

       if (node->color == Color::Black && child->color == Color::Red) {
           node->color = Color::Red;
           child->color = Color::Black;
       }

       if (node->color == Color::Black)
           fixUp(child, p);
       delete[] node;
       mySize--;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       TreeNode< value_type >* s; bool condition=0;
       if (P->left == N) {
           condition = 1;
           s = P->right;
       } 
       else
           s = P->left;

       if (s->color == Color::Red) {
           s->color = Color::Black;
           P->color = Color::Red;
           if (condition)
               RRRotation(s);
           else
               LLRotation(s);
           fixUp(N, P);
       }
       else if (s->color == Color::Black) {
           Color temp = P->color;
           P->color = s->color;
           s->color = temp;
           if (condition && s->right->color == Color::Red) {
               s->right->color = Color::Black;
               RRRotation(s);
           }
           else if (s->left->color == Color::Red) {
               s->left->color = Color::Black;
               LLRotation(s);
           }
       }
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       bool condition = 0;
       TreeNode<value_type>* new1 = new TreeNode<value_type>;
       new1->myval = val;
       new1->left = new1->right = scaryVal.myHead;
       new1->isNil = 0;
       if (scaryVal.mySize == 0) {
           new1->color = Color::Black;
           new1->parent = scaryVal.myHead;
           scaryVal.myHead->left = scaryVal.myHead->right = scaryVal.myHead->parent = new1;
       }
       else {
           int i = 0, j = 0, k = 0;
           TreeNode<value_type>* it1 = scaryVal.myHead->parent;
           TreeNode<value_type> * temp = it1;
           while (!it1->isNil) {
               temp = it1;
               if (keyCompare(val, it1->myval)) {
                   condition = 1;
                   it1 = it1->left;
                   i++;
               }
               else if (keyCompare(it1->myval, val)) {
                   condition = 0;
                   it1 = it1->right;
                   j++;
               }
               else return;
               k++;
           }

           new1->parent = temp;
           new1->color = Color::Red;
           if (condition)
               temp->left = new1;
           else
               temp->right = new1;

           if (temp->color != Color::Black) 
               scaryVal.reBalance(temp);
           
           if (i == k) 
               scaryVal.myHead->left = new1;
           else if (j == k) 
               scaryVal.myHead->right = new1;
       }
       scaryVal.mySize++;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       int i = 0, j = 0, k = 0; //bool condition = 0;
       if (scaryVal.mySize == 0)
           return 0;
       else {
           TreeNode<value_type>* temp1 = scaryVal.myHead->parent; 
           while (!temp1->isNil) {
               if (keyCompare(val, temp1->myval)) {
                   //condition = 1;
                   temp1 = temp1->left;
                
               }
               else if (keyCompare(temp1->myval, val)) {
                   //condition = 0;
                   temp1 = temp1->right;
               }
               else
                   break;
           }

           if (temp1->isNil)
               return 0;
           TreeNode<value_type>* temp2 = temp1->right; TreeNode<value_type>* temp3 = temp2;
           if (temp1->left != scaryVal.myHead && temp1->right != scaryVal.myHead) {
               while (!temp2->isNil) {
                   temp3 = temp2;
                   temp2 = temp2->left;
               }
               temp1->myval = temp3->myval;
               temp1 = temp3;
           }

            scaryVal.eraseDegreeOne(temp1);
            
            if (!scaryVal.myHead->left) {
                TreeNode<value_type>* it1 = scaryVal.myHead;
                TreeNode<value_type>* it2 = it1;
                while (!it1->isNil) {
                    it2 = it1;
                    it1 = it1->left;
                }
                scaryVal.myHead->left = it2;
            }
            if (!scaryVal.myHead->right) {
                TreeNode<value_type>* it1 = scaryVal.myHead;
                TreeNode<value_type>* it2 = it1;
                while (!it1->isNil) {
                    it2 = it1;
                    it1 = it1->right;
                }
                scaryVal.myHead->right = it2;
            }

           
       }
       return 1;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE