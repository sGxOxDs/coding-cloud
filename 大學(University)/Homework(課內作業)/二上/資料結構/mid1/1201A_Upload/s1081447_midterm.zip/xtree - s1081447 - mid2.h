// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color { Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
	using NodePtr = TreeNode*;
	using value_type = Ty;

	NodePtr    left;   // left subtree, or smallest element if head
	NodePtr    parent; // parent, or root of tree if head
	NodePtr    right;  // right subtree, or largest element if head
	Color      color;  // Red or Black, Black if head
	bool       isNil;  // true only if head (also nil) node
	value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
	using NodePtr = TreeNode< Ty >*;

	using value_type = Ty;
	using size_type = size_t;

	TreeVal()
		: myHead(new TreeNode< value_type >),
		mySize(0)
	{
		myHead->left = myHead;
		myHead->parent = myHead;
		myHead->right = myHead;
		myHead->color = Color::Black;
		myHead->isNil = true;
	}

	~TreeVal()
	{
		clear(myHead->parent);
		delete myHead;
	}

	// Removes all elements from the set object (which are destroyed)
	void clear(TreeNode< value_type >* node)
	{
		if (!node->isNil) // node is not an external node
		{
			clear(node->left);
			clear(node->right);
			delete node;
		}
	}

	// rebalance for insertion
	void reBalance(TreeNode< value_type >* node)
	{  // node->parent cannot be the root
		TreeNode<value_type>* pnode = node->parent, * gnode = pnode->parent;
		while (node->color == pnode->color && pnode != myHead) {
			if (gnode->left == pnode) {
				if (gnode->right->color == Color::Red) {
					gnode->right->color = Color::Black;
					gnode->color = Color::Red;
				}
				else {
					LLRotation(pnode);
					gnode->color = Color::Red;
				}
				pnode->color = Color::Black;
			}
			else {
				if (gnode->left->color == Color::Red) {
					gnode->left->color = Color::Black;
					gnode->color = Color::Red;
				}
				else {
					RRRotation(pnode);
					gnode->color = Color::Red;
				}
				pnode->color = Color::Black;
			}
			node = gnode;
			pnode = node->parent;
			gnode = pnode->parent;
			myHead->parent->color = Color::Black;
		}
	}

	// rotate right at g, where p = g->left and node = p->left
	//void set< Kty >::LLbRotation( TreeNode< value_type > *node )
	void LLRotation(TreeNode< value_type >* p)
	{
		TreeNode<value_type>* gu = p->parent;

		if (gu->parent->left == gu) {
			gu->parent->left = p;
		}
		else {
			gu->parent->right = p;
		}
		p->parent = gu->parent;

		if (p->right != myHead) {
			p->right->parent = gu;
		}
		gu->left = p->right;

		gu->parent = p;
		p->right = gu;
	}

	// rotate left at g, where p = g->right and node = p->right
	//void set< Kty >::RRbRotation( TreeNode< value_type > *node )
	void RRRotation(TreeNode< value_type >* p)
	{
		TreeNode<value_type>* gu = p->parent;

		if (gu->parent->right == gu) {
			gu->parent->right = p;
		}
		else {
			gu->parent->left = p;
		}
		p->parent = gu->parent;

		if (p->left != myHead) {
			p->left->parent = gu;
		}
		gu->right = p->left;

		gu->parent = p;
		p->left = gu;
	}

	// erase node provided that the degree of node is at most one
	void eraseDegreeOne(TreeNode< value_type >* node)
	{
		TreeNode<value_type>* pnode = node->parent, * root = myHead->parent, * child = myHead;

		if (node->left != myHead) {
			child = node->left;
			if (pnode->left == node) {
				child->parent = pnode;
				pnode->left = child;
			}
			else {
				child->parent = pnode;
				pnode->right = child;
			}
		}
		else if (node->right != myHead) {
			child = node->right;
			if (pnode->left == node) {
				child->parent = pnode;
				pnode->left = child;
			}
			else {
				child->parent = pnode;
				pnode->right = child;
			}
		}
		else {
			if (pnode->left == node) {
				pnode->left = child;
			}
			else {
				pnode->right = child;
			}
		}

		if (node->color == Color::Black)
			fixUp(child, pnode);

		delete node;
		mySize--;
	}

	// rebalance for deletion
	void fixUp(TreeNode< value_type >* N, TreeNode< value_type >* P)
	{
		if (N->color == Color::Red)
			N->color = Color::Black;
		else if (N == P->left) {
			TreeNode<value_type>* S = P->right, * SR = S->right, * SL = S->left;
			if (S->color == Color::Black && SR->color == Color::Black && SL->color == Color::Black && P->color == Color::Red) {
				P->color = Color::Black;
				S->color = Color::Red;
			}
			else if (S->color == Color::Black && SR->color == Color::Red) {
				S->color = P->color;
				SR->color = Color::Black;
				P->color = Color::Black;
				RRRotation(S);
			}
		}
		else {//N == P->right
			TreeNode<value_type>* S = P->left, * SR = S->right, * SL = S->left;
			if (S->color == Color::Black && SR->color == Color::Black && SL->color == Color::Black && P->color == Color::Red) {
				P->color = Color::Black;
				S->color = Color::Red;
			}
			else if (S->color == Color::Black && SL->color == Color::Red) {
				S->color = P->color;
				SL->color = Color::Black;
				P->color = Color::Black;
				LLRotation(S);
			}
		}
	}

	/*
	   // preorder traversal and inorder traversal
	   void twoTraversals()
	   {
		  cout << "Preorder sequence:\n";
		  preorder( myHead->parent );

		  cout << "\nInorder sequence:\n";
		  inorder( myHead->parent );
		  cout << endl;
	   }

	   // preorder traversal
	   void preorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 preorder( node->left );
			 preorder( node->right );
		  }
	   }

	   // inorder traversal
	   void inorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 inorder( node->left );
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 inorder( node->right );
		  }
	   }
	*/

	NodePtr myHead;   // pointer to head node
	size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
	using value_type = typename Traits::value_type;

protected:
	using ScaryVal = TreeVal< value_type >;

public:
	using key_type = typename Traits::key_type;
	using key_compare = typename Traits::key_compare;

	using size_type = size_t;

	Tree(const key_compare& parg)
		: keyCompare(parg),
		scaryVal()
	{
	}

	~Tree()
	{
	}

	// Extends the container by inserting a new element,
	// effectively increasing the container size by one.
	void insert(const value_type& val)
	{
		TreeNode<value_type>* pp = scaryVal.myHead, * root = scaryVal.myHead->parent, * p = root;

		if (root == scaryVal.myHead) {
			p = new TreeNode<value_type>;
			p->color = Color::Black;
			p->isNil = false;
			p->left = p->right = p->parent = scaryVal.myHead;
			p->myval = val;

			scaryVal.myHead->parent = p;

			scaryVal.mySize++;

			return;
		}

		while (p != scaryVal.myHead) {
			pp = p;
			if (keyCompare(p->myval, val)) {
				p = p->right;
			}
			else if (keyCompare(val, p->myval)) {
				p = p->left;
			}
			else {
				return;
			}
		}

		p = new TreeNode<value_type>;
		p->color = Color::Red;
		p->isNil = false;
		p->left = scaryVal.myHead;
		p->right = scaryVal.myHead;
		p->parent = scaryVal.myHead;
		p->myval = val;

		if (keyCompare(pp->myval, val)) {
			pp->right = p;
		}
		else {
			pp->left = p;
		}
		p->parent = pp;

		scaryVal.mySize++;
		scaryVal.reBalance(p);
	}

	// Removes from the set container a single element whose value is val
	// This effectively reduces the container size by one, which are destroyed.
	// Returns the number of elements erased.
	size_type erase(const key_type& val)
	{
		TreeNode<value_type>* pp = scaryVal.myHead, * root = scaryVal.myHead->parent, * p = root;

		while (p != scaryVal.myHead && p->myval != val) {
			pp = p;
			if (keyCompare(p->myval, val)) {
				p = p->right;
			}
			else if (keyCompare(val, p->myval)) {
				p = p->left;
			}
		}

		if (p == scaryVal.myHead) {
			return 0;
		}

		if (p->right == scaryVal.myHead || p->left == scaryVal.myHead) {
			scaryVal.eraseDegreeOne(p);
			return 1;
		}
		TreeNode <value_type>* rightTreeMin = p->right;
		while (rightTreeMin->left != scaryVal.myHead) {
			rightTreeMin = rightTreeMin->left;
		}
		p->myval = rightTreeMin->myval;
		scaryVal.eraseDegreeOne(rightTreeMin);
		return 1;
	}

private:
	key_compare keyCompare;
	ScaryVal scaryVal;
};

#endif // XTREE