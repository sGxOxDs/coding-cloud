// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color { Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
	using NodePtr = TreeNode*;
	using value_type = Ty;

	NodePtr    left;   // left subtree, or smallest element if head
	NodePtr    parent; // parent, or root of tree if head
	NodePtr    right;  // right subtree, or largest element if head
	Color      color;  // Red or Black, Black if head
	bool       isNil;  // true only if head (also nil) node
	value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
	using NodePtr = TreeNode< Ty >*;

	using value_type = Ty;
	using size_type = size_t;

	TreeVal()
		: myHead(new TreeNode< value_type >),
		mySize(0)
	{
		myHead->left = myHead;
		myHead->parent = myHead;
		myHead->right = myHead;
		myHead->color = Color::Black;
		myHead->isNil = true;
	}

	~TreeVal()
	{
		clear(myHead->parent);
		delete myHead;
	}

	// Removes all elements from the set object (which are destroyed)
	void clear(TreeNode< value_type >* node)
	{
		if (!node->isNil) // node is not an external node
		{
			clear(node->left);
			clear(node->right);
			delete node;
		}
	}

	// rebalance for insertion
	void reBalance(TreeNode< value_type >* node)
	{  // node->parent cannot be the root
		if (node->parent != myHead->parent)
		{
			NodePtr other;
			NodePtr p = node->parent;
			NodePtr g = p->parent;

			if (g->right == p)
				other = g->left;
			else
				other = g->right;

			if (other->color == Color::Red)// xxr
			{
				p->color = other->color = Color::Black;
				g->color = Color::Red;

				if (g->parent != myHead && g->parent->color == Color::Red)
					reBalance(g);

				if (g->parent == myHead)
					g->color = Color::Black;
			}
			else
			{
				if (g->left == p && p->left == node) // LLb
				{
					p->color = Color::Black;
					g->color = Color::Red;
					LLRotation(p);
				}
				else if (g->left == p && p->right == node) // LRb
				{
					g->left = node;
					node->parent = g;
					p->right = node->left;
					node->left = p;
					p->parent = node;

					if (!p->right->isNil)
						p->right->parent = p;

					node->color = Color::Black;
					g->color = Color::Red;

					LLRotation(node);
				}
				if (g->right == p && p->left == node)// RLb
				{
					g->right = node;
					node->parent = g;
					p->left = node->right;
					node->right = p;
					p->parent = node;

					if (!p->left->isNil)
						p->left->parent = p;

					node->color = Color::Black;
					g->color = Color::Red;

					RRRotation(node);
				}
				else if (g->right == p && p->right == node)// RRb
				{
					p->color = Color::Black;
					g->color = Color::Red;
					RRRotation(p);
				}
			}
		}
	}

	// rotate right at g, where p = g->left and node = p->left
	//void set< Kty >::LLbRotation( TreeNode< value_type > *node )
	void LLRotation(TreeNode< value_type >* p)
	{
		NodePtr g = p->parent;
		NodePtr node = p->left;

		if (g->parent->isNil)
		{
			p->parent = myHead;
			myHead->parent = p;
		}
		else
		{
			if (g->parent->left == g)
				g->parent->left = p;
			else
				g->parent->right = p;
		}

		p->parent = g->parent;
		g->parent = p;
		g->left = p->right;
		p->right = g;

		if (!g->left->isNil)
			g->left->parent = g;
	}

	// rotate left at g, where p = g->right and node = p->right
	//void set< Kty >::RRbRotation( TreeNode< value_type > *node )
	void RRRotation(TreeNode< value_type >* p)
	{
		NodePtr g = p->parent;
		NodePtr node = p->right;

		if (g->parent->isNil)
		{
			p->parent = myHead;
			myHead->parent = p;
		}
		else
		{
			if (g->parent->left == g)
				g->parent->left = p;
			else
				g->parent->right = p;
		}

		p->parent = g->parent;
		g->parent = p;
		g->right = p->left;
		p->left = g;

		if (!g->right->isNil)
			g->right->parent = g;
	}

	// erase node provided that the degree of node is at most one
	void eraseDegreeOne(TreeNode< value_type >* node)
	{
		NodePtr child;

		if (node->left->isNil && !node->right->isNil)
		{
			child = node->right;
			node->right->parent = node;
		}
		else if (!node->left->isNil && node->right->isNil)
		{
			child = node->left;
			node->left->parent = node;
		}
		else
			child = myHead;

		if (!node->parent->isNil)
		{
			if (node->parent->left == node)
				node->parent->left = child;
			else
				node->parent->right = child;

			if (child->color == Color::Red)
			{
				node->color = Color::Red;
				child->color = Color::Black;
			}
		}
		else
		{
			myHead->parent = child;
			child->parent = myHead;
		}

		if (!node->parent->isNil)
			if (node->color == Color::Black)
				fixUp(child, node->parent);

		delete node;
		mySize--;
	}

	// rebalance for deletion
	void fixUp(TreeNode< value_type >* N, TreeNode< value_type >* P)
	{
		NodePtr S;

		if (P->left == N)
		{
			S = P->right;
			if (S->color == Color::Black && S->right->color == Color::Red)
			{
				S->color = P->color;
				P->color = Color::Black;
				S->right->color = Color::Black;
				RRRotation(S);
			}
		}
		else
		{
			S = P->left;
			if (S->color == Color::Black && S->left->color == Color::Red)
			{
				S->color = P->color;
				P->color = Color::Black;
				S->left->color = Color::Black;
				LLRotation(S);
			}
		}
	}

	/*
	   // preorder traversal and inorder traversal
	   void twoTraversals()
	   {
		  cout << "Preorder sequence:\n";
		  preorder( myHead->parent );

		  cout << "\nInorder sequence:\n";
		  inorder( myHead->parent );
		  cout << endl;
	   }

	   // preorder traversal
	   void preorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 preorder( node->left );
			 preorder( node->right );
		  }
	   }

	   // inorder traversal
	   void inorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 inorder( node->left );
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 inorder( node->right );
		  }
	   }
	*/

	NodePtr myHead;   // pointer to head node
	size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
	using value_type = typename Traits::value_type;

protected:
	using ScaryVal = TreeVal< value_type >;

public:
	using key_type = typename Traits::key_type;
	using key_compare = typename Traits::key_compare;

	using size_type = size_t;

	Tree(const key_compare& parg)
		: keyCompare(parg),
		scaryVal()
	{
	}

	~Tree()
	{
	}

	// Extends the container by inserting a new element,
	// effectively increasing the container size by one.
	void insert(const value_type& val)
	{
		TreeNode< value_type >* insertNode = new TreeNode< value_type >;
		insertNode->isNil = false;
		insertNode->myval = val;

		if (scaryVal.myHead->parent->isNil)
		{
			scaryVal.myHead->left = scaryVal.myHead->right = scaryVal.myHead->parent = insertNode;
			insertNode->left = insertNode->parent = insertNode->right = scaryVal.myHead;
			insertNode->color = Color::Black;
		}
		else
		{
			TreeNode< value_type >* p = scaryVal.myHead->parent;
			TreeNode< value_type >* pp = p;

			while (!p->isNil)
			{
				pp = p;
				if (p->myval == val)
					return;
				if (keyCompare(val, p->myval))
					p = p->left;
				else
					p = p->right;
			}

			if (keyCompare(val, pp->myval))
				pp->left = insertNode;
			else
				pp->right = insertNode;

			insertNode->left = insertNode->right = scaryVal.myHead;
			insertNode->parent = pp;
			insertNode->color = Color::Red;

			if (insertNode->parent->color == Color::Red)
				scaryVal.reBalance(insertNode);
		}

		scaryVal.mySize++;
	}

	// Removes from the set container a single element whose value is val
	// This effectively reduces the container size by one, which are destroyed.
	// Returns the number of elements erased.
	size_type erase(const key_type& val)
	{
		TreeNode< value_type >* del = scaryVal.myHead->parent;

		while (del->myval != val)
		{
			if (del == scaryVal.myHead)
				return 0;
			if (keyCompare(val, del->myval))
				del = del->left;
			else
				del = del->right;
		}

		if (del == scaryVal.myHead)
			return 0;

		if (!del->left->isNil && !del->right->isNil)
		{
			TreeNode< value_type >* rightSmallest = del->right;
			while (!rightSmallest->left->isNil)
				rightSmallest = rightSmallest->left;

			del->myval = rightSmallest->myval;

			scaryVal.eraseDegreeOne(rightSmallest);
		}
		else
			scaryVal.eraseDegreeOne(del);

		return 1;
	}

private:
	key_compare keyCompare;
	ScaryVal scaryVal;
};

#endif // XTREE