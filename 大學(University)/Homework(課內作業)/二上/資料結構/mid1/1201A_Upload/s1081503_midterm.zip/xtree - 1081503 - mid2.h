// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance(TreeNode< value_type >* node)
   {  // node->parent cannot be the root
       if (node->parent == myHead && node->color == Color::Red) //node is root
       {
           node->color = Color::Black;
           return;
       }

       NodePtr pu = node->parent;
       NodePtr gu = pu->parent;

       if ((gu->left == pu && gu->right->color == Color::Red) ||
           (gu->right == pu && gu->left->color == Color::Red)) //??r
       {
           if (node->color == Color::Red && pu->color == Color::Red)
           {
               pu->color = Color::Black;
               gu->color = Color::Red;
               if (gu->left == pu)
                   gu->right->color = Color::Black;
               else
                   gu->left->color = Color::Black;
               reBalance(gu);
           }
       }
       else if ((gu->left == pu && gu->right->color == Color::Black) ||
           (gu->right == pu && gu->left->color == Color::Black)) //??b
       {
           if (node->color == Color::Red && pu->color == Color::Red)
           {
               if (gu->left == pu && pu->left == node) //LLb
               {
                   LLRotation(pu);
                   pu->color = Color::Black;
                   gu->color = Color::Red;
               }
               else if (gu->right == pu && pu->right == node) //RRb
               {
                   RRRotation(pu);
                   pu->color = Color::Black;
                   gu->color = Color::Red;
               }
           }
       }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       NodePtr g = p->parent;
       NodePtr gp = g->parent;

       g->left = p->right;

       if (p->right != myHead)
           p->right->parent = g;

       p->right = g;
       g->parent = p;
       p->parent = gp;

       if (gp != myHead)
       {
           if (gp->left == g)
               gp->left = p;
           else
               gp->right = p;
       }
       else
           gp->parent = p;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       NodePtr g = p->parent;
       NodePtr gp = g->parent;

       g->right = p->left;

       if (p->left != myHead)
           p->left->parent = g;

       p->left = g;
       g->parent = p;
       p->parent = gp;

       if (gp != myHead)
       {
           if (gp->right == g)
               gp->right = p;
           else
               gp->left = p;
       }
       else
           gp->parent = p;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
       NodePtr p = node->parent;
       NodePtr child;

       if (node->left != myHead)
           child = node->left;
       else if (node->right != myHead)
           child = node->right;
       else
           child = node->left;

       if (p == myHead)
           p->parent = child;
       else
           if (p->left == node)
               p->left = child;
           else
               p->right = child;

       if (child != myHead)
           child->parent = p;

       if (node->color == Color::Black && child->color == Color::Red)
       {
           child->color = Color::Black;
           delete node;
           mySize--;
           return;
       }
       if (myHead->parent == node && node->color == Color::Black && child->color == Color::Black)
       {
           delete node;
           mySize--;
           return;
       }

       if (node->color == Color::Black && child->color == Color::Black && node != myHead->parent)
           fixUp(child, p);

       delete node;
       mySize--;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       if (P->left == N) //4-1
       {
           NodePtr S = P->right;
           if (S->color == Color::Red) //4-1-1
           {
               Color color = P->color;
               P->color = S->color;
               S->color = color;
               RRRotation(S);
               fixUp(N, P);
           }
           else
           {
               NodePtr SR = S->right;
               NodePtr SL = S->left;
               if (SR->color == Color::Red) //4-1-2
               {
                   RRRotation(S);
                   Color color = P->color;
                   P->color = S->color;
                   S->color = color;
                   SR->color = Color::Black;
               }
               else
               {
                   if (SL->color == Color::Red) //4-1-3
                   {
                       LLRotation(SL);
                       Color color = SL->color;
                       SL->color = S->color;
                       S->color = color;
                       fixUp(N, P);
                   }
                   else
                   {
                       if (P->color == Color::Red) //4-1-4
                       {
                           Color color = P->color;
                           P->color = S->color;
                           S->color = color;
                       }
                       else //4-1-5
                       {
                           S->color = Color::Red;
                           if (P != myHead->parent)
                               fixUp(P, P->parent);
                       }
                   }
               }
           }
       }
       else if (P->right == N) //4-2
       {
           NodePtr S = P->left;
           if (S->color == Color::Red) //4-2-1
           {
               Color color = P->color;
               P->color = S->color;
               S->color = color;
               LLRotation(S);
               fixUp(N, P);
           }
           else
           {
               NodePtr SR = S->right;
               NodePtr SL = S->left;
               if (SL->color == Color::Red) //4-2-2
               {
                   LLRotation(S);
                   Color color = P->color;
                   P->color = S->color;
                   S->color = color;
                   SL->color = Color::Black;
               }
               else
               {
                   if (SR->color == Color::Red) //4-2-3
                   {
                       LLRotation(SR);
                       Color color = SR->color;
                       SR->color = S->color;
                       S->color = color;
                       fixUp(N, P);
                   }
                   else
                   {
                       if (P->color == Color::Red) //4-2-4
                       {
                           Color color = P->color;
                           P->color = S->color;
                           S->color = color;
                       }
                       else //4-1-5
                       {
                           S->color = Color::Red;
                           if (P != myHead->parent)
                               fixUp(P, P->parent);
                       }
                   }
               }
           }
       }
   }


   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }


   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       TreeNode< value_type >* p = scaryVal.myHead->parent;
       TreeNode< value_type >* pp = scaryVal.myHead->parent;

       if (scaryVal.myHead->parent == scaryVal.myHead)
       {
           p = new TreeNode<value_type>;

           p->color = Color::Black;
           p->isNil = false;
           p->myval = val;
           p->left = scaryVal.myHead;
           p->right = scaryVal.myHead;
           p->parent = scaryVal.myHead;

           scaryVal.myHead->parent = p;
           scaryVal.myHead->left = p;
           scaryVal.myHead->right = p;
           scaryVal.mySize++;
           return;
       }

       while (p != scaryVal.myHead)
       {
           pp = p;
           if (keyCompare(val, p->myval))
               p = p->left;
           else if (keyCompare(p->myval, val))
               p = p->right;
           else
               return;
       }
       p = new TreeNode<value_type>;
       p->isNil = false;
       p->color = Color::Red;
       p->left = scaryVal.myHead;
       p->right = scaryVal.myHead;
       p->myval = val;
       p->parent = pp;

       if (keyCompare(val, pp->myval))
           pp->left = p;
       else
           pp->right = p;

       if (keyCompare(p->myval, scaryVal.myHead->left->myval))
           scaryVal.myHead->left = p;
       else if (keyCompare(scaryVal.myHead->right->myval, p->myval))
           scaryVal.myHead->right = p;

       scaryVal.mySize++;
       if (scaryVal.myHead->parent != p->parent)
           scaryVal.reBalance(p);
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       TreeNode< value_type >* p = scaryVal.myHead->parent;
       size_type returnValue = 0;

       while (p != scaryVal.myHead && p->myval != val)
       {
           if (keyCompare(val, p->myval))
               p = p->left;
           else
               p = p->right;
       }

       if (p == scaryVal.myHead)
           return 0;

       if (p->myval == val)
       {
           returnValue = 1;
           if (p->right == scaryVal.myHead)
           {
               if (keyCompare(p->myval, scaryVal.myHead->left->myval))
                   scaryVal.myHead->left = p->parent;
               else if (keyCompare(scaryVal.myHead->right->myval, p->myval))
                   scaryVal.myHead->right = p->parent;

               scaryVal.eraseDegreeOne(p);
           }
           else
           {
               TreeNode< value_type >* rightSubtreeMin = p->right;
               while (rightSubtreeMin->left != scaryVal.myHead)
                   rightSubtreeMin = rightSubtreeMin->left;
               p->myval = rightSubtreeMin->myval;

               if (keyCompare(rightSubtreeMin->myval, scaryVal.myHead->left->myval))
                   scaryVal.myHead->left = rightSubtreeMin->parent;
               else if (keyCompare(scaryVal.myHead->right->myval, rightSubtreeMin->myval))
                   scaryVal.myHead->right = rightSubtreeMin->parent;

               scaryVal.eraseDegreeOne(rightSubtreeMin);
           }
       }
       return returnValue;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE
