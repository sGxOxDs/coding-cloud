// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
       TreeNode<value_type>* p = node->parent;
       TreeNode<value_type>* pp = p->parent;
       if ((pp->left == p && pp->right->color == Color::Red) ||
           (pp->right == p && pp->left->color == Color::Red)) {
           if(pp!=myHead->parent)
               pp->color = Color::Red;
           p->color = Color::Black;
           if (pp->left == p)
               pp->right->color = Color::Black;
           else
               pp->left->color = Color::Black;
           if (pp->parent->color == Color::Red)
               reBalance(pp);
       }
       else {
           if (pp->left == p && p->left == node && pp->right->color == Color::Black) {
               pp->color = Color::Red;
               p->color = Color::Black;
               LLRotation(p);
           }
           if (pp->right == p && p->right == node && pp->left->color == Color::Black) {
               pp->color = Color::Red;
               p->color = Color::Black;
               RRRotation(p);
           }
       }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       TreeNode<value_type>* pp = p->parent;
       if (pp->parent->left == pp)
           pp->parent->left = p;
       else
           pp->parent->right = p;
       p->parent = pp->parent;
       if (p->right != myHead)
           p->right->parent = pp;
       pp->left = p->right;
       p->right = pp;
       pp->parent = p;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       TreeNode<value_type>* pp = p->parent;
       if (pp->parent->left == pp)
           pp->parent->left = p;
       else
           pp->parent->right = p;
       p->parent = pp->parent;
       if (p->left != myHead)
           p->left->parent = pp;
       pp->right = p->left;
       p->left = pp;
       pp->parent = p;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
       TreeNode<value_type>* child;
       if (node->right != myHead)
           child = node->right;
       else if (node->left != myHead)
           child = node->left;
       else
           child = myHead;

       if (node == myHead->parent) {
           child->parent = node->parent;
           myHead->parent = child;
           if (myHead->left == node)
               myHead->left = child;
           if (myHead->right == node)
               myHead->right = child;
       }
       else {
           if (node->parent->left == node)
               node->parent->left = child;
           else
               node->parent->right = child;
           if(child!=myHead)
               child->parent = node->parent;
       }

       if (node->color == Color::Black)
           fixUp(child, node->parent);
       delete[] node;
       
       mySize--;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       if (N->color == Color::Red)
           N->color = Color::Black;
       else {
           while (true) {
               TreeNode<value_type> *S;
               TreeNode<value_type> *SL;
               TreeNode<value_type> *SR;
               if (P->left == N) {
                   S = P->right;
                   SL = S->left;
                   SR = S->right;
               }
               else {
                   S = P->left;
                   SL = S->right;
                   SR = S->left;
               }
               if (S->color == Color::Red) {
                   P->color = Color::Red;
                   S->color = Color::Black;
                   if (P->left == N)
                       RRRotation(S);
                   else
                       LLRotation(S);
               }
               else {
                   if (SR->color == Color::Red) {
                       S->color = P->color;
                       P->color = Color::Black;
                       SR->color = Color::Black;
                       if (P->left == N)
                           RRRotation(S);
                       else
                           LLRotation(S);
                       return;
                   }
                   else {
                       if (SL->color == Color::Red) {
                           S->color = Color::Red;
                           SL->color = Color::Black;
                           if (P->left == N)
                               LLRotation(SL);
                           else
                               RRRotation(SL);
                       }
                       else {
                           if (P->color == Color::Red) {
                               P->color = Color::Black;
                               S->color = Color::Red;
                               return;
                           }
                           else {
                               if (S != myHead)
                                   S->color = Color::Red;
                               if (P == myHead->parent)
                                   return;
                               else {
                                   N = P;
                                   P = P->parent;
                               }
                           }
                       }
                   }
               }
           }
       }
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       if (scaryVal.mySize == 0) {
           TreeNode<value_type>* root = new TreeNode<value_type>;
           root->color = Color::Black;
           root->isNil = false;
           root->parent = scaryVal.myHead;
           root->left = scaryVal.myHead;
           root->right = scaryVal.myHead;
           root->myval = val;
           scaryVal.myHead->parent = root;
           scaryVal.myHead->right = root;
           scaryVal.myHead->left = root;
           scaryVal.mySize = 1;
       }
       else {
           TreeNode<value_type>* node = scaryVal.myHead->parent;
           while (node->myval != val) {
               if (!keyCompare(val, node->myval)) {
                   if (node->right != scaryVal.myHead)
                       node = node->right;
                   else
                       break;
               }
               else {
                   if (node->left != scaryVal.myHead)
                       node = node->left;
                   else
                       break;

               }
           }
           if (node->myval != val) {
               TreeNode<value_type>* newNode = new TreeNode<value_type>;
               newNode->myval = val;
               newNode->parent = node;
               newNode->isNil = false;
               newNode->color = Color::Red;
               newNode->left = scaryVal.myHead;
               newNode->right = scaryVal.myHead;
               scaryVal.mySize++;
               if (!keyCompare(val, node->myval))
                   node->right = newNode;
               else
                   node->left = newNode;
               if (scaryVal.myHead->left->myval > val)
                   scaryVal.myHead->left = newNode;
               if (scaryVal.myHead->right->myval < val)
                   scaryVal.myHead->right = newNode;
               if (node->color == Color::Red)
                   scaryVal.reBalance(newNode);
           }
       }
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       if (scaryVal.mySize != 0) {
           TreeNode<value_type>* node = scaryVal.myHead->parent;
           while (node != scaryVal.myHead && node->myval != val) {
               if (!keyCompare(val, node->myval)) {
                   node = node->right;
               }
               else
                   node = node->left;
           }
           if (node == scaryVal.myHead)
               return 0;
           else {
               if (node->left == scaryVal.myHead || node->right == scaryVal.myHead)
                   scaryVal.eraseDegreeOne(node);
               else {
                   TreeNode<value_type>* rightMin = node->right;
                   while (rightMin->left != scaryVal.myHead)
                       rightMin = rightMin->left;
                   node->myval = rightMin->myval;
                   scaryVal.eraseDegreeOne(rightMin);
               }
               return 1;
           }
       }
       return 0;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE