// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
       TreeNode<value_type>* root = myHead->parent;
       TreeNode<value_type>* u = node;
       TreeNode<value_type>* pu = u->parent;
       TreeNode<value_type>* gu = pu->parent;
       while (node->parent!=root&&pu->color == Color::Red)
       {
           root = myHead->parent;
           TreeNode<value_type>* uncle;
           if (pu==gu->left)
           {
               uncle = gu->right;
           }
           else
           {
               uncle = gu->left;
           }
           if (uncle->color ==Color::Red)//change color
           {
               gu->color = Color::Red;
               pu->color = Color::Black;
               uncle->color = Color::Black;

               u = gu;
               pu = u->parent;
               gu = pu->parent;

           }
           else//rotation
           {
               if (pu == gu->left)
               {
                   pu->color = Color::Black;
                   gu->color = Color::Red;
                   LLRotation(pu);
               }
               else
               {
                   pu->color = Color::Black;
                   gu->color = Color::Red;
                   RRRotation(pu);
               }
           }
       }
       root->color = Color::Black;
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       TreeNode< value_type >* gu = p->parent;
       gu->left = p->right;
       if (p->right!=myHead)
       {
           p->right->parent = gu;
       }
       p->parent = gu->parent;
       if (gu->parent->parent == gu)
       {
           gu->parent->parent = p;
       }
       if (gu->parent->left==gu)
       {
           gu->parent->left = p;
       }
       if (gu->parent->right == gu)
       {
           gu->parent->right = p;
       }
       gu->parent = p;
       p->right = gu;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       TreeNode< value_type >* gu = p->parent;
       gu->right = p->left;
       if (p->left!= myHead)
       {
           p->left->parent = gu;
       }
       p->parent = gu->parent;
       if (gu->parent->parent == gu)
       {
           gu->parent->parent = p;
       }
       if (gu->parent->left == gu)
       {
           gu->parent->left = p;
       }
       if (gu->parent->right == gu)
       {
           gu->parent->right = p;
       }
       gu->parent = p;
       p->left = gu;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
       TreeNode< value_type >* root = myHead->parent;
       TreeNode< value_type >* p = node;
       TreeNode< value_type >* pp = node->parent;
       TreeNode< value_type >* current = nullptr;
       if (p->left!=myHead)
       {
           current = p->left;
       }
       else if (p->right != myHead)
       {
           current = p->right;
       }
       else
       {
           current = myHead;
       }
       if (p==pp->left)
       {
            pp->left = current;
       }
       else
       {
           pp->right = current;
       }
       if (current!= myHead)
       {
           current->parent = pp;
           p->parent =current ;
       }
       
       if (node == root->parent->left)
       {
           root->parent->left = node->parent;
       }
       else if (node == root->parent->right)
       {
           root->parent->right = node->parent;
       }
       if (node->color==Color::Black&&node!=root)
       {
           fixUp(current,pp);
       }
       
       delete node;
       mySize--;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       if (N->color ==Color::Red)
       {
           N->color = Color::Black;
           return;
       }

       TreeNode< value_type >* S;
       if (N == P->left)
       {
           S = P->right;
           RRRotation(S);
           S->color = P->color;
           P->color = Color::Black;
           S->right->color = Color::Black;
       }
       else
       {
           S = P->left;
           LLRotation(S);
           S->color = P->color;
           P->color = Color::Black;
           S->left->color = Color::Black;
       }


     
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       TreeNode<value_type>* root = scaryVal.myHead->parent;
       TreeNode<value_type>* destination =nullptr;
       TreeNode<value_type>* current = root;
       while (current != scaryVal.myHead)
       {
           destination = current;
           if (keyCompare(val, current->myval))
           {
               current = current->left;
           }
           else if (keyCompare(current->myval, val))
           {
               current = current->right;
           }
           else
               return;
       }
       current = new TreeNode<value_type>;
       current->myval = val;
       if (root->isNil ==true)
       {
           root->parent = root->right = root->left = current;
           current->color = Color::Black;
           current->parent = root;
       }
       else
       {  
           if (keyCompare(current->myval, destination->myval))
           {
               destination->left = current;
               if (keyCompare(current->myval,root->parent->left->myval))
               {
                    root->parent->left = current;
               }
               
           }
           else if (keyCompare(destination->myval, current->myval))
           {
               destination->right = current;
                   if (keyCompare( root->parent->right->myval,current->myval))
                   {
                       root->parent->right = current;
                   }
           }
           current->parent = destination;
           current->color = Color::Red;
       }
       current->left = current->right = scaryVal.myHead;
       current->isNil = false;
       scaryVal.mySize++;
       scaryVal.reBalance(current);


   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       TreeNode<value_type>* root = scaryVal.myHead->parent;
       TreeNode<value_type>* current = root;
       while (current != scaryVal.myHead&&current->myval!=val)
       {
           if (keyCompare(val, current->myval))
           {
               current = current->left;
           }
           else if (keyCompare(current->myval, val))
           {
               current = current->right;
           }
       }
       if (current->isNil ==true)
       {
            return 0;  
       }
       else
       {
           if (current->left->isNil==true|| current->right->isNil == true)
           {
               scaryVal.eraseDegreeOne(current);
           }
           else
           {
               TreeNode<value_type>* myright = current;
               TreeNode<value_type>* right = current->right;
               while (right->isNil!=true)
               {
                   myright = right;
                   right = right->left;
               }
               current->myval = myright->myval;
               scaryVal.eraseDegreeOne(myright);
           }
       }
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE