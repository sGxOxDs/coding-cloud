// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
       TreeNode<value_type>* pu = node->parent;
       TreeNode<value_type>* gu = pu->parent;
       enum Direct{Left,Right};
       Direct first, second;
       if (gu->left == pu)
           first = Direct::Left;
       else
           first = Direct::Right;
       if (pu->left == node)
           second = Direct::Left;
       else
           second = Direct::Right;
       Color gchild;
       if (gu->color = Color::Black)
           gchild = Color::Black;
       else
           gchild = Color::Red;

       if (gchild == Color::Red) {
           pu->color == Color::Black;
           gu->color == Color::Red;
           reBalance(gu);
       }
       else {
           if (first == Direct::Left && second == Direct::Left) {//LLb rotate
               LLRotation(node);
               pu->color = Color::Black;
               gu->color = Color::Red;
           }
           else if (first == Direct::Right && second == Direct::Right) {//RRb
               RRRotation(node);
               pu->color = Color::Black;
               gu->color = Color::Red;
           }
           else if (first == Direct::Left && second == Direct::Right) {//LRb
               ;
           }
           else {//RLb
               ;
           }
       }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       TreeNode<value_type>* pu = p->parent;
       TreeNode<value_type>* gu = pu->parent;
       
       gu->left = pu->right;
       if (pu->right->isNil == false)
           pu->right->parent = gu;
       pu->right = gu;
       pu->parent = gu->parent;
       gu->parent = pu;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       TreeNode<value_type>* pu = p->parent;
       TreeNode<value_type>* gu = pu->parent;

       gu->right = pu->left;
       if (pu->left->isNil == false)
           pu->left->parent = gu;
       pu->left = gu;
       pu->parent = gu->parent;
       gu->parent = pu;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
       TreeNode<value_type>* M = node;//consider m = root case?
       TreeNode<value_type>* P = M->parent;
       TreeNode<value_type>* S = new TreeNode<value_type>;
       TreeNode<value_type>* N = new TreeNode<value_type>;
       if (M->left != myHead)//barely not possible?
           N = node->left;
       else if (M->right != myHead)
           N = M->right;
       else
           N = myHead;

       if (P->left == M)
           S = P->right;
       else
           S = P->left;

       //link
       /*if (P->left == M) 
           P->left = N;
       else //P->right == M
           P->right = N;
          
       if (N != myHead)
           N->parent = P;

       if (myHead->left == M && N != myHead)
           myHead->left = N;
       else if (myHead->left == M && N == myHead)
           myHead->left = P;

       if (myHead->right == M && N != myHead)
           myHead->right = N;
       else if (myHead->right == M && N == myHead)
           myHead->right = S;*/


       if (M->color == Color::Red) {//Case 1
           if (P->left == M)
               P->left = N;
           else //P->right == M
               P->right = N;

           if (N != myHead)
               N->parent = P;

           if (myHead->left == M && N != myHead)
               myHead->left = N;
           else if (myHead->left == M && N == myHead)
               myHead->left = P;

           if (myHead->right == M && N != myHead)
               myHead->right = N;
           else if (myHead->right == M && N == myHead)
               myHead->right = S;
           delete M;
           return;
       }
       else if (N->color == Color::Red) {//Case 2 M=Black N=Red
           if (P->left == M)
               P->left = N;
           else //P->right == M
               P->right = N;

           if (N != myHead)
               N->parent = P;

           if (myHead->left == M && N != myHead)
               myHead->left = N;
           else if (myHead->left == M && N == myHead)
               myHead->left = P;

           if (myHead->right == M && N != myHead)
               myHead->right = N;
           else if (myHead->right == M && N == myHead)
               myHead->right = S;
           N->color = Color::Black;
           delete M;
           return;
       }
       else if (myHead->parent == M) {//Case 3 M=Black N=Black M is root
           if (N == myHead) {
               myHead->left = myHead;
               myHead->right = myHead;
               myHead->parent = myHead;
           }
           else {
               myHead->parent = N;
               N->parent = myHead;
               if (myHead->right == M)
                   myHead->right = N;
               else if (myHead->left == M)
                   myHead->left = N;
           }
           delete M;
           return;
       }
       else {//Case 4
           if (P->left == M)
               P->left = N;
           else //P->right == M
               P->right = N;

           if (N != myHead)
               N->parent = P;

           if (myHead->left == M && N != myHead)
               myHead->left = N;
           else if (myHead->left == M && N == myHead)
               myHead->left = P;

           if (myHead->right == M && N != myHead)
               myHead->right = N;
           else if (myHead->right == M && N == myHead)
               myHead->right = S;
           delete M;
           fixUp(N, P);
           return;
       }
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       if (P->left == N) {
           TreeNode<value_type>* S = P->right;
           TreeNode<value_type>* Sr = S->right;
           TreeNode<value_type>* Sl = S->left;
           if (S->color == Color::Red) {//Subcase 4.1.1

           }
           else if (Sr->color == Color::Red) {//Subcase 4.1.2

           }
           else if (Sl->color == Color::Red) {//Subcase 4.1.3

           }
           else if (P->color == Color::Red) {//Subcase 4.1.4

           }
           else {//Subcase 4.1.5

           }
       }
       else if (P->right == N) {
           TreeNode<value_type>* S = P->left;
           TreeNode<value_type>* Sr = S->right;
           TreeNode<value_type>* Sl = S->left;
           if (S->color == Color::Red) {//Subcase 4.2.1

           }
           else if (Sr->color == Color::Red) {//Subcase 4.2.2

           }
           else if (Sl->color == Color::Red) {//Subcase 4.2.3

           }
           else if (P->color == Color::Red) {//Subcase 4.2.4

           }
           else {//Subcase 4.2.5

           }
       }
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       if (scaryVal.mySize == 0) {
           TreeNode<value_type>* root = new TreeNode<value_type>;
           root->left = scaryVal.myHead;
           root->myval = val;
           root->parent = scaryVal.myHead;
           root->color = Color::Black;
           root->isNil = false;
           root->right = scaryVal.myHead;

           scaryVal.myHead->parent = root;
           scaryVal.myHead->left = root;
           scaryVal.myHead->right = root;
       }
       else {
           TreeNode<value_type>* root = scaryVal.myHead->parent, *p;
           while (root != scaryVal.myHead ) {
               p = root;
               if (val < root->myval)
                   root = root->left;
               else if (val > root->myval)
                   root = root->right;
               else {
                   cout << "wtf" << endl;
                   return;
               }
           }

           TreeNode<value_type>* insert = new TreeNode<value_type>;
           insert->myval = val;
           insert->color = Color::Red;
           insert->isNil = false;
           insert->parent = p;
           insert->left = scaryVal.myHead;
           insert->right = scaryVal.myHead;
           if (val < p->myval) {
               p->left = insert;
               if (val < scaryVal.myHead->left)
                   scaryVal.myHead->left = insert;
           }
           else {
               p->right = insert;
               if (val > scaryVal.myHead->right)
                   scaryVal.myHead->right = insert;
           }
           scaryVal.reBalance(insert);
       }
       scaryVal.mySize++;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       TreeNode<value_type>* node = scaryVal.myHead->parent;
       while (node != scaryVal.myHead && node->myval != val) {
           if (val < node->myval)node = node->left;
           else node = node->right;
       }
       if (node == scaryVal.myHead) {//not found
           return 0;
       }
       else {//found
           if (node->right == scaryVal.myHead)
               scaryVal.eraseDegreeOne(node);
           else {
               TreeNode<value_type>* deleted = node->right;
               while (deleted != scaryVal.myHead) {
                   if (deleted->left == scaryVal.myHead)
                       break;
                   deleted = deleted->left;
               }
               node->myval = deleted->myval;
               scaryVal.eraseDegreeOne(deleted);
           }
           scaryVal.mySize--;
           return 1;
       }
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE