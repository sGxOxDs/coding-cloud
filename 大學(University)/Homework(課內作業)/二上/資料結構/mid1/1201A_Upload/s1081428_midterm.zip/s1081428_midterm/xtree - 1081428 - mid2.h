// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
       while (node->parent != myHead->parent && node->color == Color::Red && node->parent->color == Color::Red) 
       {
           TreeNode<value_type>* parentNode = node->parent;
           TreeNode<value_type>* grandparentNode = parentNode->parent;
           //XYr
           if (grandparentNode->right->color == Color::Red && grandparentNode->left->color == Color::Red) 
           {
               grandparentNode->color = Color::Red;
               grandparentNode->right->color = grandparentNode->left->color = Color::Black;
               node = grandparentNode;
               if (node == myHead->parent)
                   node->color = Color::Black;
           }
           //XYb
           else if (grandparentNode->right->color == Color::Black || grandparentNode->left->color == Color::Black)
           {
               //LYb
               if(grandparentNode->left==parentNode)
               {
                   //LLb
                   if (parentNode->left == node) {
                       LLRotation(parentNode);
                       node = parentNode;
                   }
                   //LRb
                   else {
                       RRRotation(node);
                       LLRotation(node);
                   }
               }
               //RYb
               else {
                   //RRb
                   if (parentNode->right == node) {
                       RRRotation(parentNode);
                       node = parentNode;
                   }
                   //RLb
                   else {
                       LLRotation(node);
                       RRRotation(node);
                   }
               }
           }
       }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       TreeNode<value_type>* g = p->parent;

       //if g is root
       //change myHead->parent to p
       //else change g->parent left/right to p
       if (g->parent == myHead)
           myHead->parent = p;
       else {
           if (g->parent->right == g)
               g->parent->right = p;
           else
               g->parent->left = p;
       }

       //change parent
       p->parent = g->parent;
       g->parent = p;
       if (!p->right->isNil)
           p->right->parent = g;

       //change child
       g->left = p->right;
       p->right = g;

       //change color
       g->color = Color::Red;
       p->color = Color::Black;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       TreeNode<value_type>* g = p->parent;

       //if g is root
       //change myHead->parent to p
       //else change g->parent left/right to p
       if (g->parent == myHead)
           myHead->parent = p;
       else {
           if (g->parent->right == g)
               g->parent->right = p;
           else
               g->parent->left = p;
       }

       //change parent
       p->parent = g->parent;
       g->parent = p;
       if (!p->left->isNil)
           p->left->parent = g;

       //change child
       g->right = p->left;
       p->left = g;

       //change color
       g->color = Color::Red;
       p->color = Color::Black;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {

   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       TreeNode<value_type>* S = (P->left == N) ? P->right : P->left;
       if (S == P->right && S->right->color == Color::Red) {
           RRRotation(N);
       }
       else if (S == P->left && S->left->color == Color::Red) {
           LLRotation(N);
       }
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       //create newnode
       TreeNode<value_type>* newNode = new TreeNode<value_type>;
       newNode->myval = val, newNode->isNil = false;
       scaryVal.mySize++;

       //is first
       if (scaryVal.myHead->parent == scaryVal.myHead) {
           scaryVal.myHead->parent = scaryVal.myHead->left = scaryVal.myHead->right = newNode;
           newNode->parent = newNode->left = newNode->right = scaryVal.myHead;
           return;
       }

       newNode->color = Color::Red;
       //find
       TreeNode<value_type>* currentNode = scaryVal.myHead->parent;
       while (true) 
       {
           if (!currentNode->left->isNil && keyCompare(val, currentNode->myval))
               currentNode = currentNode->left;
           else if (!currentNode->right->isNil && keyCompare(currentNode->myval, val))
               currentNode = currentNode->right;
           else if (currentNode->myval == val) {
               --scaryVal.mySize;
               return;
           }
           else
               break;
       }

       //insert newnode
       newNode->parent = currentNode;
       //left
       if (keyCompare(val, currentNode->myval)) {
           if (keyCompare(val, scaryVal.myHead->left->myval))
               scaryVal.myHead->left = newNode;
           newNode->left = newNode->right = currentNode->left;
           currentNode->left = newNode;
       }
       //right
       else {
           if (keyCompare(scaryVal.myHead->right->myval, val))
               scaryVal.myHead->right = newNode;
           newNode->right = newNode->left = currentNode->right;
           currentNode->right = newNode;
       }
       
       //check balance
       if (currentNode->color == Color::Red)
           scaryVal.reBalance(newNode);


   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       TreeNode<value_type>* M = scaryVal.myHead->parent;
       while (true) {
           if (!M->left->isNil && keyCompare(val, M->myval))
               M = M->left;
           else if (!M->right->isNil && keyCompare(M->myval, val))
               M = M->right;
           else if (M->myval == val)
               break;
           else
               return 0;
       }

       TreeNode<value_type>* N = (!M->left->isNil) ? M->left : M->right;
       TreeNode<value_type>* P = M->parent;
       N->parent = P;
       if (P->left == M)
           P->left = N;
       else
           P->right = N;
       scaryVal.fixUp(N, P);
       delete M;
       return 1;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE