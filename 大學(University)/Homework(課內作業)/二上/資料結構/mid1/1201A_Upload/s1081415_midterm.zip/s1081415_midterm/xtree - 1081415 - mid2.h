// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
       if (!node->parent->parent->isNil) {

           // change color
           if (node->parent->parent->color == Color::Black && node->parent->color == Color::Red && node->parent->parent->left->color == node->parent->parent->right->color) {
               if (!node->parent->parent->parent->isNil) {
                   node->parent->parent->color = Color::Red;
               }
               node->parent->parent->left->color = Color::Black;
               node->parent->parent->right->color = Color::Black;

               if (node->parent->parent->parent->color == Color::Red) {
                   reBalance(node->parent->parent);
               }
           }
           else {  // rotation
               if (node == node->parent->left && node->parent == node->parent->parent->left) {  // LL
                   LLRotation(node->parent);
               }
               else if (node == node->parent->right && node->parent == node->parent->parent->right) {  // RR
                   RRRotation(node->parent);
               }
           }
       }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       // change parent
       if (p->parent->parent->isNil) {
           p->parent->parent->parent = p;
       }
       else {
           if (p->parent->parent->left == p->parent) {
               p->parent->parent->left = p;
           }
           else {
               p->parent->parent->right = p;
           }
       }

       // rotation
       p->parent->left = p->right;
       p->right = p->parent;
       p->parent = p->right->parent;
       if (!p->right->left->isNil) {
           p->right->left->parent = p->right;
       }
       p->right->parent = p;

       // change color
       p->color = Color::Black;
       p->right->color = Color::Red;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       // change parent
       if (p->parent->parent->isNil) {
           p->parent->parent->parent = p;
       }
       else {
           if (p->parent->parent->left == p->parent) {
               p->parent->parent->left = p;
           }
           else {
               p->parent->parent->right = p;
           }
       }

       // rotation
       p->parent->right = p->left;
       p->left = p->parent;
       p->parent = p->left->parent;
       if (!p->left->right->isNil) {
           p->left->right->parent = p->left;
       }
       p->left->parent = p;

       // change color
       p->color = Color::Black;
       p->left->color = Color::Red;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
       if (node->color != Color::Red) {
           if (!node->left->isNil) {  // left exist
               if (node->left->color == Color::Red) {
                   node->left->color = Color::Black;
               }
               else {
                   fixUp(node->left, node->parent);
               }
           }
           else if(!node->right->isNil) {  // right exist
               if (node->right->color == Color::Red) {
                   node->right->color = Color::Black;
               }
               else {
                   fixUp(node->right, node->parent);
               }
           }
           else {  // leaf node
               fixUp(myHead, node->parent);
           }
       }

       delete node;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       if (P->left->isNil && P->right->isNil) {
           return;
       }

       if (P->left == N) {
           if (P->right->color == Color::Red) {
               // case 11
               RRRotation(P->right);
               fixUp(N, P);
           }
           else {
               if (P->right->right->color == Color::Red) {
                   // case 12
                   TreeNode< value_type > it;
                   it.color = P->color;
                   RRRotation(P->right);
                   P->parent->color = it.color;
                   P->color = Color::Black;
                   P->parent->right->color = Color::Black;
                   //fixUp(N, P);
               }
               else {
                   if (P->right->left->color == Color::Red) {
                       // case 13
                       LLRotation(P->right->left);
                       fixUp(N, P);
                   }
                   else {
                       if (P->color == Color::Red) {
                           // case 14
                           P->color = Color::Black;
                           P->right->color = Color::Red;
                       }
                       else {
                           // case 15
                           P->right->color = Color::Red;
                           if (!P->parent->isNil) {
                               fixUp(P, P->parent);
                           }
                       }
                   }
               }
           }
       }
       else {
           if (P->left->color == Color::Red) {
               // case 21
               LLRotation(P->left);
               fixUp(N, P);
           }
           else {
               if (P->left->left->color == Color::Red) {
                   // case 22
                   TreeNode< value_type > it;
                   it.color = P->color;
                   LLRotation(P->left);
                   P->parent->color = it.color;
                   P->color = Color::Black;
                   P->parent->left->color = Color::Black;
                   //fixUp(N, P);
               }
               else {
                   if (P->left->right->color == Color::Red) {
                       // case 23
                       RRRotation(P->left->right);
                       fixUp(N, P);
                   }
                   else {
                       if (P->color == Color::Red) {
                           // case 24
                           P->color = Color::Black;
                           P->left->color = Color::Red;
                       }
                       else {
                           // case 25
                           P->left->color = Color::Red;
                           if (!P->parent->isNil) {
                               fixUp(P, P->parent);
                           }
                       }
                   }
               }
           }
       }
   }

///*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
//*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       TreeNode< value_type >* newNode = new TreeNode< value_type >;
       newNode->myval = val;
       newNode->isNil = false;
       newNode->left = newNode->right = scaryVal.myHead;

       if (scaryVal.mySize == 0) {  // empty
           newNode->color = Color::Black;
           newNode->parent = scaryVal.myHead;
           scaryVal.myHead->parent = scaryVal.myHead->left = scaryVal.myHead->right = newNode;
       }
       else {
           // travesal
           TreeNode< value_type >* node = scaryVal.myHead->parent;  // root
           TreeNode< value_type >* prenode = scaryVal.myHead;  // header
           while (node != scaryVal.myHead) {
               if (keyCompare(val, node->myval)) {
                   prenode = node;
                   node = node->left;
               }
               else if(keyCompare(node->myval, val)) {
                   prenode = node;
                   node = node->right;
               }
               else {  // equal
                   return;
               }
           }

           // set node
           newNode->color = Color::Red;
           newNode->parent = prenode;
           if (keyCompare(val, prenode->myval)) {
               prenode->left = newNode;
           }
           else {
               prenode->right = newNode;
           }

           // set header's left or right
           if (keyCompare(val, scaryVal.myHead->left->myval)) {
               scaryVal.myHead->left = newNode;
           }
           else if(keyCompare(scaryVal.myHead->right->myval, val)) {
               scaryVal.myHead->right = newNode;
           }

           // rebalance
           if (newNode->parent->color == Color::Red) {
               scaryVal.reBalance(newNode);
           }
       }
       scaryVal.mySize++;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       // travesal
       TreeNode< value_type >* node = scaryVal.myHead->parent;  // root
       bool find = false;
       while (node != scaryVal.myHead) {
           if (keyCompare(val, node->myval)) {
               node = node->left;
           }
           else if (keyCompare(node->myval, val)) {
               node = node->right;
           }
           else {
               find = true;
               break;
           }
       }

       // esist
       if (find) {
           // right exist
           if (!node->right->isNil) {
               TreeNode< value_type >* it = node->right;
               while (!it->left->isNil) {
                   it = it->left;
               }

               node->myval = it->myval;
               node = it;
           }

           // reconnect
           if (!node->right->isNil) {
               if (node->parent->left == node) {
                   node->parent->left = node->right;
                   node->right->parent = node->parent;
               }
               else {
                   node->parent->right = node->right;
                   node->right->parent = node->parent;
               }
           }
           else if (!node->left->isNil) {
               if (node->parent->left == node) {
                   node->parent->left = node->left;
                   node->left->parent = node->parent;
               }
               else {
                   node->parent->right = node->left;
                   node->left->parent = node->parent;
               }
           }
           else {  // leaf node
               if (node->parent->left == node) {
                   node->parent->left = scaryVal.myHead;
               }
               else {
                   node->parent->right = scaryVal.myHead;
               }
           }

           // erase
           scaryVal.eraseDegreeOne(node);
           scaryVal.mySize--;

           return val;
       }

       return 0;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE