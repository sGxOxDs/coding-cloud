// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
       TreeNode<value_type>* p = node->parent;
       TreeNode<value_type>* g = p->parent;
       if (g->right == p) { // X = R
           if (g->left->color == Color::Red) {// r
               // LLr LRr
               g->color = Color::Red;
               g->left->color = Color::Black;
               p->color = Color::Black;

               if (g->parent != this->myHead && g->parent->parent != this->myHead && g->parent->color == Color::Red) {
                   this->reBalance(g);
               }

               if (g == this->myHead->parent) {
                   g->color = Color::Black;
               }
           } else { // b

               if (p->left == node) { // L
                    // RLb
                   this->RRRotation(node);
                   this->LLRotation(node);
                   node->color = Color::Black;
                   g->color = Color::Red;
               } else {
                    //RRb
                   this->RRRotation(p);
                   g->color = Color::Red;
                   p->color = Color::Black;
               }
           
           }
       } else { // X = L
           if (g->right->color == Color::Red) {// r
               // LLr LRr
               g->color = Color::Red;
               g->right->color = Color::Black;
               p->color = Color::Black;

               if (g->parent != this->myHead && g->parent->parent != this->myHead && g->parent->color == Color::Red) {
                   this->reBalance(g);
               }

               if (g == this->myHead->parent) {
                   g->color = Color::Black;
               }
           } else {
               if (p->left == node) { // L
                    // LLb
                   this->LLRotation(p);
                   g->color = Color::Red;
                   p->color = Color::Black;

               }
               else {
                   //LRb
                   this->LLRotation(node);
                   this->RRRotation(node);
                   node->color = Color::Black;
                   g->color = Color::Red;
               }
           }
       }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       TreeNode<value_type>* g = p->parent;
        
       // change p's right to g's left
       g->left = p->right;
       if (!g->left->isNil) {
           g->left->parent = g;
       }

       // change g's parent to p's parent
       if (g == this->myHead) {
           // if g is root
           this->myHead->parent = p;
       } else {
           if (g->parent->left == g) {
               g->parent->left = p;
           } else {
               g->parent->right = p;
           }
       }
       p->parent = g->parent;


       // change g's parent to p
       p->right = g;
       p->right->parent = p;



   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       TreeNode<value_type>* g = p->parent;

       // change p's left to g's right
       g->right = p->left;
       if (!g->left->isNil) {
           g->left->parent = g;
       }

       // change g's parent to p's parent
       if (g == this->myHead) {
           // if g is root
           this->myHead->parent = p;
       }
       else {
           if (g->parent->right == g) {
               g->parent->right = p;
           }
           else {
               g->parent->left = p;
           }
       }
       p->parent = g->parent;


       // change g's parent to p
       p->left = g;
       p->left->parent = p;

   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
       if (!node->left->isNil && !node->right->isNil) {
           cout << "WTF????" << endl;
       }

       if (node->color == Color::Red) { // delete red node  // Case 1
           if (!node->right->isNil) {
               if (node->parent->left = node) {
                   node->parent->left = node->right;
               }
               else {
                   node->parent->right = node->right;
               }
           }

           if (node->parent->right == node) {
               node->parent->right = this->myHead;
           } else {
               node->parent->left = this->myHead;
           }

           delete node;
       } else { // delete black node
           // set P to M(node)'s parent
           TreeNode<value_type>* P = node->parent;
           
           // set N to M(node)'s child,or Nil
           TreeNode<value_type>* N;
           if (!node->left->isNil) {
               N = node->left;
           } else if(!node->right->isNil){
               N = node->right;
           } else {
               N = this->myHead;
           }

           if (N->color == Color::Red) { // Case 2
               N->parent = node->parent;
               if (P->left == node) {
                   P->left = N;
               }
               else {
                   P->right = N;
               }
               N->color = Color::Black;
               delete node;
               return;
           }

           if (node->parent == this->myHead) { // if M is root  // Case 3
               this->myHead->parent = N;
               N->parent = this->myHead;
               N->color = Color::Black;
               delete node;
               return;
           } 


           if (!N->isNil) {
               N->parent = P;
           }
           if (P->left == node) {
               P->left = N;
           } else {
               P->right = N;
           }

           delete node;

           fixUp(N, P);
           


       }
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       TreeNode<value_type>* S;
       TreeNode<value_type>* Sr;
       TreeNode<value_type>* Sl;

       if (N == P->left) { // if N is at P's left
           S = P->right;
           Sr = S->right;
           Sl = S->left;
           if (S->color == Color::Red) { // AlgorithmNote:Case 1 , 4-2-1
               S->color = Color::Black;
               P->color = Color::Red;
               this->RRRotation(S);
               this->fixUp(N, Sr);
           }

           if (S->color == Color::Black) {

               if (Sr->color == Color::Red) { // AlgorithmNote:Case 4 , 4-2-2
                   S->color = P->color;
                   P->color = Color::Black;
                   Sr->color = Color::Black;
                   this->RRRotation(S);
                   return;
               }

               if (Sl->color == Color::Red) {  // AlgorithmNode:Cas 3 , 4-2-3

                   S->color = Color::Red;
                   Sl->color = Color::Black;
                   this->LLRotation(Sl);
                   this->fixUp(N, P);
               }

               if (S->color == Color::Black && Sr->color == Color::Black && Sl->color == Color::Black) { // AlgorithmNote:Case 2 , 4-2-4 / 4-2-5
                   P->color == Color::Black;
                   S->color == Color::Red;
                   if (P->parent == this->myHead) {
                       return;
                   }
                   else {
                       fixUp(P, P->parent);
                   }
               }


           }


       }
       else { // if N is at P's right
           S = P->left;
           Sr = S->right;
           Sl = S->left;

           if (S->color == Color::Red) { // AlgorithmNote:Case 1 , 4-2-1
               S->color = Color::Black;
               P->color = Color::Red;
               this->LLRotation(S);
               this->fixUp(N, Sl);
           }

           if (S->color == Color::Black) {
                
               if (Sl->color == Color::Red) { // AlgorithmNote:Case 4 , 4-2-2
                   S->color = P->color;
                   P->color = Color::Black;
                   Sl->color = Color::Black;
                   this->LLRotation(S);
                   return;
               }

               if (Sr->color == Color::Red) {  // AlgorithmNode:Cas 3 , 4-2-3

                   S->color = Color::Red;
                   Sr->color = Color::Black;
                   this->RRRotation(Sr);
                   this->fixUp(N, P);
               }

               if (S->color == Color::Black && Sl->color == Color::Black && Sr->color == Color::Black) { // AlgorithmNote:Case 2 , 4-2-4 / 4-2-5
                   P->color == Color::Black;
                   S->color == Color::Red;
                   if (P->parent == this->myHead) {
                       return;
                   } else {
                       fixUp(P, P->parent);
                   }
               }


           }

       }



       


   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       TreeNode<value_type>* root = this->scaryVal.myHead->parent;
       if (root == this->scaryVal.myHead) { // empty tree
           TreeNode<value_type>* newNode = new TreeNode<value_type>;
           newNode->isNil = false;
           newNode->color = Color::Black;
           newNode->parent = root;
           newNode->left = newNode->right = this->scaryVal.myHead;
           root->parent = newNode;
           newNode->myval = val;
           this->scaryVal.mySize++;
           return;
       }

       if (root->myval == val) {
           return;
       }


       TreeNode<value_type>* previous = root;
       TreeNode<value_type>* current;
       if (keyCompare(previous->myval, val)) {
           current = previous->right;
       } else {
           current = previous->left;
       }

       while (!current->isNil) {
           previous = current;
           if (keyCompare(current->myval, val)) {
               current = current->right;
           }else if (current->myval == val) {
               return;
           } else {
               current = current->left;
           }
       }

       TreeNode<value_type>* newNode = new TreeNode<value_type>;
       newNode->isNil = false;
       newNode->color = Color::Red;
       newNode->parent = previous;
       newNode->left = newNode->right = this->scaryVal.myHead;
       newNode->myval = val;

       if (keyCompare( previous->myval, val )) {
           previous->right = newNode;
       } else {
           previous->left = newNode;
       }

       if (previous->color == Color::Red) {
           this->scaryVal.reBalance(newNode);
       }

       this->scaryVal.mySize++;

   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       if (this->scaryVal.mySize == 0) {
           return 0;
       }

       if (this->scaryVal.mySize == 1) {
           if (this->scaryVal.myHead->parent->myval == val) {
               this->scaryVal.clear(this->scaryVal.myHead->parent);
               this->scaryVal.mySize--;
               return 1;
           } else {
               return 0;
           }
       }

       TreeNode<value_type>* previous = this->scaryVal.myHead->parent;
       TreeNode<value_type>* current;
       if (keyCompare(previous->myval,val)) {
           current = previous->right;
       } else {
           current = previous->left;
       }

       while (!current->isNil) {
           previous = current;
           if (keyCompare(current->myval, val)) {
               current = previous->right;
           } else if (current->myval == val) {
               break;
           } else {
               current = previous->left;
           }
       }

       if(current->isNil){
           return 0;
       }

       if (!current->right->isNil && !current->left->isNil) { // if current have two child
           // find it sucessor
           TreeNode<value_type>* successor = current->right;
           while (!successor->left->isNil) {
               successor = successor->left;
           }

           current->myval = successor->myval;
           this->scaryVal.eraseDegreeOne(successor);

       } else {
           this->scaryVal.eraseDegreeOne(current);
       }
       this->scaryVal.mySize--;
       return 1;

   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE