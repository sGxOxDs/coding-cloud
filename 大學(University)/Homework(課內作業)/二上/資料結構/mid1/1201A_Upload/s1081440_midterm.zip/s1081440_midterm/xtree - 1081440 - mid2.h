// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color { Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
	using NodePtr = TreeNode*;
	using value_type = Ty;

	NodePtr    left;   // left subtree, or smallest element if head
	NodePtr    parent; // parent, or root of tree if head
	NodePtr    right;  // right subtree, or largest element if head
	Color      color;  // Red or Black, Black if head
	bool       isNil;  // true only if head (also nil) node
	value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
	using NodePtr = TreeNode< Ty >*;

	using value_type = Ty;
	using size_type = size_t;

	TreeVal()
		: myHead(new TreeNode< value_type >),
		mySize(0)
	{
		myHead->left = myHead;
		myHead->parent = myHead;
		myHead->right = myHead;
		myHead->color = Color::Black;
		myHead->isNil = true;
	}

	~TreeVal()
	{
		clear(myHead->parent);
		delete myHead;
	}

	// Removes all elements from the set object (which are destroyed)
	void clear(TreeNode< value_type >* node)
	{
		if (!node->isNil) // node is not an external node
		{
			clear(node->left);
			clear(node->right);
			delete node;
		}
	}

	// rebalance for insertion
	void reBalance(TreeNode< value_type >* node)
	{  // node->parent cannot be the root
		TreeNode< value_type >* parentNode = node->parent;
		TreeNode< value_type >* grandparentNode = parentNode->parent;
		if (grandparentNode->left == parentNode) {
			if (grandparentNode->right->color == Color::Red) {
				grandparentNode->left->color = Color::Black;
				grandparentNode->right->color = Color::Black;
				grandparentNode->color = Color::Red;
			}
			else {
				if (parentNode->left == node) {//LLb
					LLRotation(parentNode);

					parentNode->color = Color::Black;
					grandparentNode->color = Color::Red;
				}
				else {//LRb					
					LLRotation(node);
					RRRotation(node);
					node->color = Color::Black;
					grandparentNode->color = Color::Red;
				}
			}
		}
		else {
			if (grandparentNode->left->color == Color::Red) {
				grandparentNode->left->color = Color::Black;
				grandparentNode->right->color = Color::Black;
				grandparentNode->color = Color::Red;
			}
			else {
				if (parentNode->left == node) {//RLb
					RRRotation(node);
					LLRotation(node);
					node->color = Color::Black;
					grandparentNode->color = Color::Red;
				}
				else {//RRb
					RRRotation(parentNode);
					parentNode->color = Color::Black;
					grandparentNode->color = Color::Red;
				}
			}
		}
	}

	// rotate right at g, where p = g->left and node = p->left
	//void set< Kty >::LLbRotation( TreeNode< value_type > *node )
	void LLRotation(TreeNode< value_type >* p)
	{
		TreeNode< value_type >* g = p->parent;
		if (g == myHead->parent) {//rotate root
			myHead->parent = p;
		}
		else {
			if (g->parent->left == g) {
				g->parent->left = p;
			}
			if (g->parent->right == g) {
				g->parent->right = p;
			}
		}

		g->left = p->right;
		if (!p->right->isNil) {
			p->right->parent = g;
		}
		p->right = g;
		p->parent = g->parent;
		g->parent = p;
	}

	// rotate left at g, where p = g->right and node = p->right
	//void set< Kty >::RRbRotation( TreeNode< value_type > *node )
	void RRRotation(TreeNode< value_type >* p)
	{
		TreeNode< value_type >* g = p->parent;
		if (g == myHead->parent) {//rotate root
			myHead->parent = p;
		}
		else {
			if (g->parent->left == g) {
				g->parent->left = p;
			}
			if (g->parent->right == g) {
				g->parent->right = p;
			}
		}
		g->right = p->left;
		if (!p->left->isNil) {
			p->left->parent = g;
		}
		p->left = g;
		p->parent = g->parent;
		g->parent = p;
	}

	// erase node provided that the degree of node is at most one
	void eraseDegreeOne(TreeNode< value_type >* node)
	{

	}

	// rebalance for deletion
	void fixUp(TreeNode< value_type >* N, TreeNode< value_type >* P)
	{

	}

	/*
	   // preorder traversal and inorder traversal
	   void twoTraversals()
	   {
		  cout << "Preorder sequence:\n";
		  preorder( myHead->parent );

		  cout << "\nInorder sequence:\n";
		  inorder( myHead->parent );
		  cout << endl;
	   }

	   // preorder traversal
	   void preorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 preorder( node->left );
			 preorder( node->right );
		  }
	   }

	   // inorder traversal
	   void inorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 inorder( node->left );
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 inorder( node->right );
		  }
	   }
	*/

	NodePtr myHead;   // pointer to head node
	size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
	using value_type = typename Traits::value_type;

protected:
	using ScaryVal = TreeVal< value_type >;

public:
	using key_type = typename Traits::key_type;
	using key_compare = typename Traits::key_compare;

	using size_type = size_t;

	Tree(const key_compare& parg)
		: keyCompare(parg),
		scaryVal()
	{
	}

	~Tree()
	{
	}

	// Extends the container by inserting a new element,
	// effectively increasing the container size by one.
	void insert(const value_type& val)
	{
		if (scaryVal.mySize == 0) {//insert root
			TreeNode<value_type>* insertNode = new TreeNode<value_type>;
			insertNode->parent = scaryVal.myHead;
			insertNode->left = scaryVal.myHead;
			insertNode->right = scaryVal.myHead;
			insertNode->color = Color::Black;
			insertNode->isNil = false;
			insertNode->myval = val;

			scaryVal.myHead->parent = insertNode;
			scaryVal.myHead->left = insertNode;
			scaryVal.myHead->right = insertNode;
			scaryVal.mySize++;
		}
		else {
			TreeNode<value_type>* rootNode = scaryVal.myHead->parent;
			TreeNode<value_type>* parentNode = rootNode;
			TreeNode<value_type>* childNode = parentNode;
			if (keyCompare(parentNode->myval, val)) {
				childNode = parentNode->right;
			}
			if (parentNode->myval == val) {//�o�{�ۦP�ȴN���X
				return;
			}
			if (keyCompare(val, parentNode->myval)) {
				childNode = parentNode->left;
			}
			while (!childNode->isNil) {//parentNode��insertNode��parent
				parentNode = childNode;
				if (keyCompare(parentNode->myval , val)) {
					childNode = childNode->right;
				}
				if (parentNode->myval == val) {//�o�{�ۦP�ȴN���X
					return;
				}
				if (keyCompare(val , parentNode->myval)) {
					childNode = childNode->left;
				}
			}

			TreeNode<value_type>* insertNode = new TreeNode<value_type>;
			insertNode->parent = parentNode;
			insertNode->left = scaryVal.myHead;
			insertNode->right = scaryVal.myHead;
			insertNode->color = Color::Red;
			insertNode->isNil = false;
			insertNode->myval = val;
			//�վ�parentNode��left/right
			if (keyCompare(parentNode->myval, val)) {
				parentNode->right = insertNode;
			}
			if (keyCompare(val, parentNode->myval)) {
				parentNode->left = insertNode;
			}

			TreeNode<value_type>* rightMaxNode = rootNode;
			TreeNode<value_type>* searchrightNode = rightMaxNode->right;
			while (!searchrightNode->isNil) {//�M��̥k��
				rightMaxNode = searchrightNode;
				searchrightNode = rightMaxNode->right;
			}
			TreeNode<value_type>* leftMaxNode = rootNode;
			TreeNode<value_type>* searchleftNode = leftMaxNode->left;
			while (!searchleftNode->isNil) {//�M��̥���
				leftMaxNode = searchleftNode;
				searchleftNode = leftMaxNode->left;
			}
			scaryVal.myHead->left = leftMaxNode;
			scaryVal.myHead->right = rightMaxNode;
			scaryVal.mySize++;

			while (parentNode->color == Color::Red) {//inbalance
				scaryVal.reBalance(insertNode);
				scaryVal.myHead->parent->color = Color::Black;//�û��Nroot�լ��¦�
				insertNode = insertNode->parent->parent;
				parentNode = insertNode->parent;
			}
		}
	}

	// Removes from the set container a single element whose value is val
	// This effectively reduces the container size by one, which are destroyed.
	// Returns the number of elements erased.
	size_type erase(const key_type& val)
	{
		TreeNode<value_type>* rootNode = scaryVal.myHead->parent;
		TreeNode<value_type>* searchNode = rootNode;
		while (!searchNode->isNil) {
			if (searchNode->myval == val) {
				break;
			}
			else if (keyCompare(searchNode->myval, val)) {
				searchNode = searchNode->left;
			}
			else if (keyCompare(val, searchNode->myval)) {
				searchNode = searchNode->right;
			}
		}
		//�L�p��

		//�@�Ӥp��

		//��Ӥp��

		return 0;
	}

private:
	key_compare keyCompare;
	ScaryVal scaryVal;
};

#endif // XTREE