// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
       NodePtr p = node->parent, g = p->parent, other;
       bool otherRorL = (g->right == p);

       if (otherRorL)
           other = g->left;
       else
           other = g->right;

       if (other->color == Color::Red) {
           p->color = Color::Black;
           other->color = Color::Black;
           g->color = Color::Red;
           if (g == myHead->parent) {
               g->color = Color::Black;
               return;
           }
           if (g->parent->color==Color::Red)
               reBalance(g);
       }
       else {
           if (!otherRorL && p->left == node) {
               p->color = Color::Black;
               g->color = Color::Red;
               LLRotation(p);
           }
           else if (!otherRorL && p->right == node) {
               node->color = Color::Black;
               g->color = Color::Red;
               RRRotation(node);
               LLRotation(node);
           }
           else if (otherRorL && p->left == node) {
               node->color = Color::Black;
               g->color = Color::Red;
               LLRotation(node);
               RRRotation(node);
           }
           else if (otherRorL && p->right == node) {
               p->color = Color::Black;
               g->color = Color::Red;
               RRRotation(p);
           }
       }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       NodePtr g = p->parent;

       size_t gRorL = 0;

       if (g->parent->right == g)
           gRorL = 1;
       else if (g->parent->left == g)
           gRorL = 2;

       p->parent = g->parent;
       if (gRorL == 1) 
           g->parent->right = p;
       else if (gRorL == 2)
           g->parent->left = p;
       else 
           myHead->parent = p;
       
       g->left = p->right;
       if (g->left != myHead)
           g->left->parent = g;
       p->right = g;
       g->parent = p;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       NodePtr g = p->parent;

       size_t gRorL = 0;

       if (g->parent->right == g)
           gRorL = 1;
       else if (g->parent->left == g)
           gRorL = 2;

       p->parent = g->parent;
       if (gRorL == 1)
           g->parent->right = p;
       else if (gRorL == 2)
           g->parent->left = p;
       else
           myHead->parent = p;

       g->right = p->left;
       if (g->right != myHead)
           g->right->parent = g;
       p->left = g;
       g->parent = p;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
       NodePtr p = node->parent,child;
       bool nRorL = p->left == node;

       if (node->left != myHead)
           child = node->left;
       else if (node->right != myHead)
           child = node->right;
       else
           child = myHead;

       if (node->color == Color::Red) {
           if (nRorL)
               p->left = child;
           else
               p->right = child;
           if (child != myHead)
               child->parent = p;
       }
       else {
           if (p != myHead) {
               if (nRorL)
                   p->left = child;
               else
                   p->right = child;
               if (child != myHead)
                   child->parent = p;
               if (child->color == Color::Red) {
                   node->color = Color::Red;
                   child->color = Color::Black;
               }
           }
           else {
               child->parent = p;
               p->parent = child;
               return;
           }
       }
       if (node->color == Color::Black)
           fixUp(child, p);

       delete node;
       mySize--;

   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       
       if (P->left == N && P->right->color == Color::Black && P->right->right->color == Color::Red) {
           P->right->color = P->color;
           P->color = Color::Black;
           P->right->right->color = Color::Black;
           RRRotation(P);
       }
       else if (P->right == N && P->left->color == Color::Black && P->left->left->color == Color::Red) {
           P->left->color = P->color;
           P->color = Color::Black;
           P->left->left->color = Color::Black;
           LLRotation(P);
       }
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       TreeNode< value_type >* node = scaryVal.myHead->parent;
       TreeNode< value_type >* pNode = scaryVal.myHead->parent;
       bool nRorL;

       while (node != scaryVal.myHead) {
           pNode = node;
           if (node->myval == val)
               return;
           if (keyCompare(node->myval, val)) {
               node = node->right;
               nRorL = false;
           }
           else {
               node = node->left;
               nRorL = true;
           }
       }

       TreeNode< value_type >* insertNode = new TreeNode< value_type >();
       insertNode->isNil = 0;
       insertNode->myval = val;
       insertNode->left = insertNode->right= scaryVal.myHead;
       if (pNode == scaryVal.myHead) {
           insertNode->color = Color::Black;
           insertNode->parent = scaryVal.myHead;
           pNode->parent = insertNode;
           pNode->left = pNode->right = insertNode;
       }
       else {
           insertNode->color = Color::Red;
           insertNode->parent = pNode;
           if (nRorL)
               pNode->left = insertNode;
           else
               pNode->right = insertNode;
       }

       if (insertNode->parent->color == Color::Red)
           scaryVal.reBalance(insertNode);
       scaryVal.mySize++;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       TreeNode< value_type >* node = scaryVal.myHead->parent;

       TreeNode< value_type >* eraseNode = scaryVal.myHead->parent;

       while (node != scaryVal.myHead) {
           if (node->myval == val)
               break;
           if (keyCompare(node->myval, val)) 
               node = node->right;
           else 
               node = node->left;
       }
       
       if (node != scaryVal.myHead) {
           eraseNode = node;
           if (node->left != scaryVal.myHead && node->right != scaryVal.myHead) {
               eraseNode = node->right;
               while (eraseNode->left != scaryVal.myHead)
                   eraseNode = eraseNode->left;
               node->myval = eraseNode->myval;
           }
           scaryVal.eraseDegreeOne(eraseNode);
           return 1;
       }
       return 0;
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE