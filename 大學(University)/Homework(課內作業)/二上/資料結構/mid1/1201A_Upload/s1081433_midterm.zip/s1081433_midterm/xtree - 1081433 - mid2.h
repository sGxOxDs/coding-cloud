// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color { Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
	using NodePtr = TreeNode*;
	using value_type = Ty;

	NodePtr    left;   // left subtree, or smallest element if head
	NodePtr    parent; // parent, or root of tree if head
	NodePtr    right;  // right subtree, or largest element if head
	Color      color;  // Red or Black, Black if head
	bool       isNil;  // true only if head (also nil) node
	value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
	using NodePtr = TreeNode< Ty >*;

	using value_type = Ty;
	using size_type = size_t;

	TreeVal()
		: myHead(new TreeNode< value_type >),
		mySize(0)
	{
		myHead->left = myHead;
		myHead->parent = myHead;
		myHead->right = myHead;
		myHead->color = Color::Black;
		myHead->isNil = true;
	}

	~TreeVal()
	{
		clear(myHead->parent);
		delete myHead;
	}

	// Removes all elements from the set object (which are destroyed)
	void clear(TreeNode< value_type >* node)
	{
		if (!node->isNil) // node is not an external node
		{
			clear(node->left);
			clear(node->right);
			delete node;
		}
	}

	// rebalance for insertion
	void reBalance(TreeNode< value_type >* node)
	{  // node->parent cannot be the root
		if (node->parent->color == Color::Black)
			return;

		NodePtr pu = node->parent;
		NodePtr gu = pu->parent;
		NodePtr other;
		if (gu->left == pu)
			other = gu->right;
		else
			other = gu->left;

		if (other->color == Color::Red) // XXr
		{
			pu->color = Color::Black;
			gu->color = Color::Red;
			other->color = Color::Black;

			if (gu->parent->color == Color::Red)
				reBalance(gu);
		}
		else // XXb
		{
			if (gu->left == pu && pu->left == node) // LLb
			{
				gu->color = Color::Red;
				pu->color = Color::Black;
				LLRotation(pu);
			}
			else if (gu->right == pu && pu->right == node) // RRb
			{
				gu->color = Color::Red;
				pu->color = Color::Black;
				RRRotation(pu);
			}
		}
	}

	// rotate right at g, where p = g->left and node = p->left
	//void set< Kty >::LLbRotation( TreeNode< value_type > *node )
	void LLRotation(TreeNode< value_type >* p)
	{
		NodePtr g = p->parent;
		NodePtr node = p->left;
		if (g->parent == myHead)
			myHead->parent = p;
		else
		{
			if (g->parent->left == g)
				g->parent->left = p;
			else
				g->parent->right = p;
		}
		p->parent = g->parent;

		g->left = p->right;

		p->right = g;
		g->parent = p;

		if (g->left != myHead)
			g->left->parent = g;
	}

	// rotate left at g, where p = g->right and node = p->right
	//void set< Kty >::RRbRotation( TreeNode< value_type > *node )
	void RRRotation(TreeNode< value_type >* p)
	{
		NodePtr g = p->parent;
		NodePtr node = p->right;
		if (g->parent == myHead)
			myHead->parent = p;
		else
		{
			if (g->parent->right == g)
				g->parent->right = p;
			else
				g->parent->left = p;
		}
		p->parent = g->parent;

		g->right = p->left;

		p->left = g;
		g->parent = p;

		if (g->right != myHead)
			g->right->parent = g;
	}

	// erase node provided that the degree of node is at most one
	void eraseDegreeOne(TreeNode< value_type >* node)
	{
		NodePtr child;
		if (node->left == myHead)
			child = node->right;
		else
			child = node->left;

		if (node->parent == myHead)
		{
			child->color = Color::Black;
			myHead->parent = child;
			child->parent = myHead;

			delete node;
			mySize--;
			return;
		}

		if (child != myHead)
		{
			if (node->parent->left == node)
				node->parent->left = child;
			else
				node->parent->right = child;
			child->parent = node->parent;
		}

		if (node->color == Color::Black && child->color == Color::Red)
		{
			child->color = Color::Black;

			delete node;
			mySize--;
			return;
		}

		if (node->color == Color::Black && child->color == Color::Black)
			fixUp(child, child->parent);

		delete node;
		mySize--;
	}

	// rebalance for deletion
	void fixUp(TreeNode< value_type >* N, TreeNode< value_type >* P)
	{
		if (N == P->left)
		{
			NodePtr S = P->right;
			if (S->color == Color::Black && S->right->color == Color::Red)
			{
				S->color = P->color;
				P->color = Color::Black;
				RRRotation(S);
			}
		}
		else
		{
			NodePtr S = P->left;
			if (S->color == Color::Black && S->left->color == Color::Red)
			{
				S->color = P->color;
				P->color = Color::Black;
				RRRotation(S);
			}
		}
	}

	/*
	   // preorder traversal and inorder traversal
	   void twoTraversals()
	   {
		  cout << "Preorder sequence:\n";
		  preorder( myHead->parent );

		  cout << "\nInorder sequence:\n";
		  inorder( myHead->parent );
		  cout << endl;
	   }

	   // preorder traversal
	   void preorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 preorder( node->left );
			 preorder( node->right );
		  }
	   }

	   // inorder traversal
	   void inorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 inorder( node->left );
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 inorder( node->right );
		  }
	   }
	*/

	NodePtr myHead;   // pointer to head node
	size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
	using value_type = typename Traits::value_type;

protected:
	using ScaryVal = TreeVal< value_type >;

public:
	using key_type = typename Traits::key_type;
	using key_compare = typename Traits::key_compare;

	using size_type = size_t;

	Tree(const key_compare& parg)
		: keyCompare(parg),
		scaryVal()
	{
	}

	~Tree()
	{
	}

	// Extends the container by inserting a new element,
	// effectively increasing the container size by one.
	void insert(const value_type& val)
	{
		TreeNode< value_type >* newNode = new TreeNode< value_type >;
		if (scaryVal.myHead->parent->isNil) // only myHead, so create a root
		{
			scaryVal.myHead->left = newNode;
			scaryVal.myHead->right = newNode;
			scaryVal.myHead->parent = newNode;
			newNode->left = scaryVal.myHead;
			newNode->right = scaryVal.myHead;
			newNode->parent = scaryVal.myHead;
			newNode->isNil = 0;
			newNode->myval = val;
			newNode->color = Color::Black;
		}
		else
		{
			TreeNode< value_type >* p = scaryVal.myHead->parent;
			while (true)
			{
				if (p->myval == val)
					return;

				if (keyCompare(val, p->myval))
				{
					if (p->left == scaryVal.myHead && p == scaryVal.myHead->left)
					{
						p->left = newNode;
						scaryVal.myHead->left = newNode;
						break;
					}
					else if (p->left == scaryVal.myHead)
					{
						p->left = newNode;
						break;
					}
					else
						p = p->left;
				}
				else
				{
					if (p->right == scaryVal.myHead && p == scaryVal.myHead->right)
					{
						p->right = newNode;
						scaryVal.myHead->right = newNode;
						break;
					}
					else if (p->right == scaryVal.myHead)
					{
						p->right = newNode;
						break;
					}
					else
						p = p->right;
				}
			}
			newNode->left = scaryVal.myHead;
			newNode->right = scaryVal.myHead;
			newNode->parent = p;
			newNode->isNil = 0;
			newNode->myval = val;
			newNode->color = Color::Red;

			if (p->color == Color::Red)
				scaryVal.reBalance(newNode);
		}
		scaryVal.mySize++;
	}

	// Removes from the set container a single element whose value is val
	// This effectively reduces the container size by one, which are destroyed.
	// Returns the number of elements erased.
	size_type erase(const key_type& val)
	{
		TreeNode< value_type >* p = scaryVal.myHead->parent;
		while (p != scaryVal.myHead)
		{
			if (p->myval == val)
			{
				if (p->left == scaryVal.myHead || p->right == scaryVal.myHead) // only one child or no child
				{
					scaryVal.eraseDegreeOne(p);
				}
				else
				{
					TreeNode< value_type >* rightSmallest = p->right;
					while (rightSmallest->left != scaryVal.myHead)
						rightSmallest = rightSmallest->left;
					p->myval = rightSmallest->myval;
					scaryVal.eraseDegreeOne(rightSmallest);
				}
				return 1;
			}

			if (keyCompare(val, p->myval))
				p = p->left;
			else
				p = p->right;
		}
		return 0;
	}

private:
	key_compare keyCompare;
	ScaryVal scaryVal;
};

#endif // XTREE