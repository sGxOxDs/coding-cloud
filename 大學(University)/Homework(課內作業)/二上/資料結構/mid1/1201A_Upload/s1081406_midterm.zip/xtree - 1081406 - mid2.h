// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color{ Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
   using NodePtr = TreeNode *;
   using value_type = Ty;

   NodePtr    left;   // left subtree, or smallest element if head
   NodePtr    parent; // parent, or root of tree if head
   NodePtr    right;  // right subtree, or largest element if head
   Color      color;  // Red or Black, Black if head
   bool       isNil;  // true only if head (also nil) node
   value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
   using NodePtr = TreeNode< Ty > *;

   using value_type = Ty;
   using size_type  = size_t;

   TreeVal()
      : myHead( new TreeNode< value_type > ),
        mySize( 0 )
   {
      myHead->left = myHead;
      myHead->parent = myHead;
      myHead->right = myHead;
      myHead->color = Color::Black;
      myHead->isNil = true;
   }

   ~TreeVal()
   {
      clear( myHead->parent );
      delete myHead;
   }

   // Removes all elements from the set object (which are destroyed)
   void clear( TreeNode< value_type > *node )
   {
      if( !node->isNil ) // node is not an external node
      {
         clear( node->left );
         clear( node->right );
         delete node;
      }
   }

   // rebalance for insertion
   void reBalance( TreeNode< value_type > *node )
   {  // node->parent cannot be the root
       if (node->parent == myHead->parent) {
           return;
       }
       TreeNode< value_type >* p = node->parent;
       TreeNode< value_type >* g = p->parent;
       if (node == p->left) {
           if (p == g->left) {//LL
               if (g->right->color == Color::Red) {//LLr
                   if (g != myHead->parent) {
                       g->color = Color::Red;
                       g->right->color = Color::Black;
                       p->color = Color::Black;
                       reBalance(g);
                   }
                   else {
                       p->color = Color::Black;
                       g->right->color = Color::Black;
                   }
               }
               else {//LLb
                   //cout << "LL" << endl;
                   LLRotation(p);
               }
           }
           else if (p == g->right) {//LR
               if (g->left->color == Color::Red) {//LRr
                   if (g != myHead->parent) {
                       g->color = Color::Red;
                       g->left->color = Color::Black;
                       p->color = Color::Black;
                       reBalance(g);
                   }
                   else {
                       p->color = Color::Black;
                       g->left->color = Color::Black;
                   }
               }
               else {//LRb
                   node->parent = g->parent;
                   if (g->parent == myHead) {
                       myHead->parent = node;
                   }
                   else {
                       if (g == g->parent->left) {
                           g->parent->left = node;
                       }
                       else if (g == g->parent->right) {
                           g->parent->right = node;
                       }
                       else {
                           cout << "Bad connection" << endl;
                       }
                   }
                   g->parent = node;
                   p->parent = node;
                   p->left = node->right;
                   if (!node->right->isNil) {
                       node->right->parent = p;
                   }
                   g->right = node->left;
                   if (!node->left->isNil) {
                       node->left->parent = g;
                   }
                   node->color = Color::Black;
                   g->color = Color::Red;
                   node->left = g;
                   node->right = p;
               }
           }
           else {
               cout << "Bad connection" << endl;
           }
       }
       else if (node == p->right) {
           if (p == g->left) {//LR
               if (g->right->color == Color::Red) {//LRr
                   g->color = Color::Red;
                   g->right->color = Color::Black;
                   p->color = Color::Black;
               }
               else {//LRb                   

                   //correct
                   node->parent = g->parent;
                   if (g->parent == myHead) {
                       myHead->parent = node;
                   }
                   else {
                       if (g == g->parent->left) {
                           g->parent->left = node;
                       }
                       else if (g == g->parent->right) {
                           g->parent->right = node;
                       }
                       else {
                           cout << "Bad connection" << endl;
                       }
                   }
                   g->parent = node;
                   p->parent = node;
                   p->right = node->left;
                   if (!node->left->isNil) {
                       node->left->parent = p;
                   }
                   g->left = node->right;
                   if (!node->right->isNil) {
                       node->right->parent = g;
                   }
                   node->color = Color::Black;
                   g->color = Color::Red;
                   node->left = p;
                   node->right = g;
               }
           }
           else if (p == g->right) {//RR
               if (g->left->color == Color::Red) {//RRr
                   if (g != myHead->parent) {
                       g->color = Color::Red;
                       g->left->color = Color::Black;
                       p->color = Color::Black;
                       reBalance(g);
                   }
                   else {
                       p->color = Color::Black;
                       g->left->color = Color::Black;
                   }
               }
               else {//RRb
                   //cout << "RR" << endl;
                   RRRotation(p);
               }
           }
           else {
               cout << "Bad connection" << endl;
           }
       }
       else {
           cout << "Bad connection" << endl;
       }
   }

   // rotate right at g, where p = g->left and node = p->left
   //void set< Kty >::LLbRotation( TreeNode< value_type > *node )
   void LLRotation( TreeNode< value_type > *p )
   {
       TreeNode< value_type >* g = p->parent;
       p->parent = g->parent;
       if (g->parent == myHead) {
           myHead->parent = p;
       }
       else {
           if (g == g->parent->left) {
               g->parent->left = p;
           }
           else if (g == g->parent->right) {
               g->parent->right = p;
           }
           else {
               cout << "Bad connection" << endl;
           }
       }
       g->left = p->right;
       if (p->right!=myHead) {
           p->right->parent = g;
       }
       p->right = g;
       g->parent = p;
       p->color = Color::Black;
       g->color = Color::Red;
   }

   // rotate left at g, where p = g->right and node = p->right
   //void set< Kty >::RRbRotation( TreeNode< value_type > *node )
   void RRRotation( TreeNode< value_type > *p )
   {
       TreeNode< value_type >* g = p->parent;
       p->parent = g->parent;
       if (g->parent == myHead) {
           myHead->parent = p;
       }
       else {
           if (g == g->parent->left) {
               g->parent->left = p;
           }
           else if (g == g->parent->right) {
               g->parent->right = p;
           }
           else {
               cout << "Bad connection" << endl;
           }
       }
       g->right = p->left;
       if (p->left != myHead) {
           p->left->parent = g;
       }
       p->left = g;
       g->parent = p;
       p->color = Color::Black;
       g->color = Color::Red;
   }

   // erase node provided that the degree of node is at most one
   void eraseDegreeOne( TreeNode< value_type > *node )
   {
       if (mySize==1) {
           myHead->parent = myHead;
           myHead->right = myHead;
           myHead->left = myHead;
       }
       else {
           if (!node->right->isNil) {
               TreeNode< value_type >* minnode = node->right;// copy the minimum value in node's right subtree
               //cout << "node " << node->myval << endl;
               //cout << "node->right " << node->right->myval << endl;
               //cout << "node->left " << node->left->myval << endl;
               //cout << "parent " << node->parent->myval << endl;
               //cout << "parent->right " << node->parent->right->myval << endl;
               //cout << "parent->left " << node->parent->left->myval << endl;
               //find the node with at most degree one
               while (!minnode->left->isNil) {
                   minnode = minnode->left;
               }
               //cout << "minnode " << minnode->myval << endl;
               //cout << "node->right " << minnode->right->myval << endl;
               //cout << "node->left " << minnode->left->myval << endl;
               //cout << "minnode parent " << minnode->parent->myval << endl;
               //cout << "minnode parent->right " << minnode->parent->right->myval << endl;
               //cout << "minnode parent->left " << minnode->parent->left->myval << endl;
               //connect the node to be deleted
               node->myval = minnode->myval;
               node = minnode;
               TreeNode< value_type >* child = node->right;
               if (node == node->parent->left) {
                   node->parent->left = child;
               }
               else if (node == node->parent->right) {
                   node->parent->right = child;
               }
               else {
                   cout << "Bad connection" << endl;
               }
               if (!child->isNil) {
                   child->parent = node->parent;
               }

               //fix the node to fit Red Black Tree
               if (child->color == Color::Black && node->color == Color::Red) {
                   ;
               }
               else if (child->color == Color::Red && node->color == Color::Black) {
                   child->color = Color::Black;
               }
               else if (child->color == Color::Black && node->color == Color::Black) {
                   fixUp(child, node->parent);
               }
               else {
                   cout << "Consecutive red node" << endl;
               }
           }
           else if (node->right->isNil && !node->left->isNil) {//only has left child
               //connect the left child
               TreeNode< value_type >* child = node->left;
               if (node == node->parent->left) {
                   node->parent->left = child;
               }
               else if (node == node->parent->right) {
                   node->parent->right = child;
               }
               else {
                   cout << "Bad connection" << endl;
               }
               child->parent = node->parent;
               
               //fix the leftchild to fit Red Black Tree
               if (child->color == Color::Black && node->color == Color::Red) {
                   ;
               }
               else if (child->color == Color::Red && node->color == Color::Black) {
                   child->color = Color::Black;
               }
               else if (child->color == Color::Black && node->color == Color::Black) {
                   fixUp(child, node->parent);
               }
               else {
                   cout << "Consecutive red node" << endl;
               }
           }
           else {//leaf node
               
               if (node == node->parent->left) {
                   node->parent->left = myHead;
               }
               else if (node == node->parent->right) {
                   node->parent->right = myHead;
               }
               else {
                   cout << "Bad connection" << endl;
               }
               if (node->color == Color::Black) {                   
                   fixUp(myHead,node->parent);
               }
           }
       }
       delete node;
       mySize--;
   }

   // rebalance for deletion
   void fixUp( TreeNode< value_type > *N, TreeNode< value_type > *P )
   {
       if (N == P->left) {
           TreeNode< value_type >* S = P->right;
           if (S->color==Color::Red) {//case1.1
               //cout << "case1.1" << endl;
               S->color = Color::Black;
               P->color = Color::Red;
               S->parent = P->parent;
               if (P->parent == myHead) {
                   myHead->parent = S;
               }
               else {
                   if (P == P->parent->left) {
                       P->parent->left = S;
                   }
                   else if (P == P->parent->right) {
                       P->parent->right = S;
                   }
                   else {
                       cout << "Bad connection" << endl;
                   }
               }
               P->parent = S;
               P->right = S->left;
               if (S->left != myHead) {
                   S->left->parent = P;
               }
               S->left = P;
               fixUp(N, P);
           }
           else {
               if (S->right->color == Color::Red) {//case 2.1
                   //cout << "case2.1" << endl;
                   S->parent = P->parent;
                   if (P->parent == myHead) {
                       myHead->parent = S;
                   }
                   else {
                       if (P == P->parent->left) {
                           P->parent->left = S;
                       }
                       else if (P == P->parent->right) {
                           P->parent->right = S;
                       }
                       else {
                           cout << "Bad connection" << endl;
                       }
                   }
                   P->parent = S;
                   S->color = P->color;
                   P->color = Color::Black;
                   S->right->color = Color::Black;
                   P->right = S->left;
                   if (S->left != myHead) {
                       S->left->parent = P;
                   }
                   S->left = P;
               }
               else {
                   if (S->left->color == Color::Red) {//Case 3.1
                       cout << "case 3.1" << endl;
                       TreeNode< value_type >* SL = S->left;
                       P->right = SL;
                       SL->parent = P;
                       S->left = SL->right;
                       if (SL->right != myHead) {
                           SL->right->parent = S;
                       }
                       SL->color = Color::Black;
                       S->color = Color::Red;
                       fixUp(N, P);

                   }
                   else {
                       if (P->color == Color::Red) {//Case 4
                           //cout << "case4.1" << endl;
                           P->color = Color::Black;
                           S->color = Color::Red;
                       }
                       else {//case 5
                           cout << "case5.1" << endl;
                           S->color = Color::Red;
                           fixUp(P, P->parent);
                       }
                   }
               }
           }
       }
       else {
           TreeNode< value_type >* S = P->left;
           if (S->color == Color::Red) {//case1.2
               //cout << "case1.2" << endl;
               S->color = Color::Black;
               P->color = Color::Red;
               S->parent = P->parent;
               if (P->parent == myHead) {
                   myHead->parent = S;
               }
               else {
                   if (P == P->parent->left) {
                       P->parent->left = S;
                   }
                   else if (P == P->parent->right) {
                       P->parent->right = S;
                   }
                   else {
                       cout << "Bad connection" << endl;
                   }
               }
               P->parent = S;
               P->left = S->right;
               if (S->right != myHead) {
                   S->right->parent = P;
               }
               S->right = P;
               fixUp(N, P);
           }
           else {
               if (S->left->color == Color::Red) {//case 2.2
                  // cout << "case2.2" << endl;
                   S->parent = P->parent;
                   if (P->parent == myHead) {
                       myHead->parent = S;
                   }
                   else {
                       if (P == P->parent->left) {
                           P->parent->left = S;
                       }
                       else if (P == P->parent->right) {
                           P->parent->right = S;
                       }
                       else {
                           cout << "Bad connection" << endl;
                       }
                   }
                   P->parent = S;
                   S->color = P->color;
                   P->color = Color::Black;
                   S->left->color = Color::Black;
                   P->left = S->right;
                   if (S->right != myHead) {
                       S->right->parent = P;
                   }
                   S->right = P;
               }
               else {
                   if (S->right->color == Color::Red) {//Case 3.2
                       cout << "case3.2" << endl;
                       TreeNode< value_type >* SR = S->right;
                       P->left = SR;
                       SR->parent = P;
                       S->right = SR->left;
                       if (SR->left != myHead) {
                           SR->left->parent = S;
                       }
                       SR->color = Color::Black;
                       S->color = Color::Red;
                       fixUp(N, P);
                   }
                   else {
                       if (P->color == Color::Red) {//Case 4
                           //cout << "case4.2" << endl;
                           P->color = Color::Black;
                           S->color = Color::Red;
                       }
                       else {//case 5
                           cout << "case5.2" << endl;
                           S->color = Color::Red;
                           fixUp(P, P->parent);
                       }
                   }
               }
           }
       }
   }

/*
   // preorder traversal and inorder traversal
   void twoTraversals()
   {
      cout << "Preorder sequence:\n";
      preorder( myHead->parent );

      cout << "\nInorder sequence:\n";
      inorder( myHead->parent );
      cout << endl;
   }

   // preorder traversal
   void preorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         preorder( node->left );
         preorder( node->right );
      }
   }

   // inorder traversal
   void inorder( TreeNode< value_type > *node )
   {
      if( node != myHead )
      {
         inorder( node->left );
         cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
         inorder( node->right );
      }
   }
*/

   NodePtr myHead;   // pointer to head node
   size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
   using value_type = typename Traits::value_type;

protected:
   using ScaryVal = TreeVal< value_type >;

public:
   using key_type      = typename Traits::key_type;
   using key_compare   = typename Traits::key_compare;

   using size_type       = size_t;

   Tree( const key_compare &parg )
      : keyCompare( parg ),
        scaryVal()
   {
   }

   ~Tree()
   {
   }

   // Extends the container by inserting a new element,
   // effectively increasing the container size by one.
   void insert( const value_type &val )
   {
       /*if (val == 8)
           cout << "stop" << endl;*/
       TreeNode< value_type > *newnode = new TreeNode< value_type >;
       newnode->myval = val;
       newnode->left = scaryVal.myHead;
       newnode->right = scaryVal.myHead;
       newnode->isNil = false;
       if (scaryVal.mySize==0) {
           newnode->parent = scaryVal.myHead;
           newnode->color = Color::Black;
           scaryVal.myHead->parent = newnode;
           scaryVal.myHead->left = newnode;
           scaryVal.myHead->right = newnode;
 
       }
       else {
           newnode->color = Color::Red;
           TreeNode< value_type >* mynode = scaryVal.myHead->parent;
           TreeNode< value_type >* temp = mynode;
           while (!mynode->isNil) {
               temp = mynode;
               if (keyCompare(mynode->myval,val)) {
                   mynode = mynode->right;
               }
               else if (keyCompare(val, mynode->myval)) {
                   mynode = mynode->left;
               }
               else {
                   return;
               }
           }
           if (keyCompare(temp->myval, val)) {
               temp->right = newnode;
               newnode->parent = temp;
           }
           else if (keyCompare(val, temp->myval)) {
               temp->left = newnode;
               newnode->parent = temp;
           }
           if (temp->color == Color::Red && newnode->color == Color::Red) {
               scaryVal.reBalance(newnode);
           }
       }
       scaryVal.mySize++;
   }

   // Removes from the set container a single element whose value is val
   // This effectively reduces the container size by one, which are destroyed.
   // Returns the number of elements erased.
   size_type erase( const key_type &val )
   {
       
       TreeNode< value_type >* mynode = scaryVal.myHead->parent;
       while(!mynode->isNil) {
           if (keyCompare(mynode->myval, val)) {
               mynode = mynode->right;
           }
           else if (keyCompare(val, mynode->myval)) {
               mynode = mynode->left;
           }
           else {
               break;
           }
       }
       if (mynode->myval == val && !mynode->isNil) {
           scaryVal.eraseDegreeOne(mynode);
           return 1;
       }
       else {
            return 0;
       }      
   }

private:
   key_compare keyCompare;
   ScaryVal scaryVal;
};

#endif // XTREE