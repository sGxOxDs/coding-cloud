// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color { Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
	using NodePtr = TreeNode*;
	using value_type = Ty;

	NodePtr    left;   // left subtree, or smallest element if head
	NodePtr    parent; // parent, or root of tree if head
	NodePtr    right;  // right subtree, or largest element if head
	Color      color;  // Red or Black, Black if head
	bool       isNil;  // true only if head (also nil) node
	value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
	using NodePtr = TreeNode< Ty >*;

	using value_type = Ty;
	using size_type = size_t;

	TreeVal()
		: myHead(new TreeNode< value_type >),
		mySize(0)
	{
		myHead->left = myHead;
		myHead->parent = myHead;
		myHead->right = myHead;
		myHead->color = Color::Black;
		myHead->isNil = true;
	}

	~TreeVal()
	{
		clear(myHead->parent);
		delete myHead;
	}

	// Removes all elements from the set object (which are destroyed)
	void clear(TreeNode< value_type >* node)
	{
		if (!node->isNil) // node is not an external node
		{
			clear(node->left);
			clear(node->right);
			delete node;
		}
	}

	// rebalance for insertion
	void reBalance(TreeNode< value_type >* node)
	{  // node->parent cannot be the root
		TreeNode< value_type >* p = node->parent;
		TreeNode< value_type >* g = p->parent;
		//LLr,LRr,RLr,RRr
		if ((p == g->right && g->left->color == Color::Red) ||
			(p == g->left && g->right->color == Color::Red)) {
			g->color = Color::Red;
			g->right->color = g->left->color = Color::Black;
		}
		else {
			g->color = Color::Red;
			if (p == g->left && node == p->left) { //LLb
				p->color = Color::Black;
				LLRotation(p);
			}
			else if (p == g->right && node == p->right) { //RRb
				p->color = Color::Black;
				RRRotation(p);
			}
		}
	}

	// rotate right at g, where p = g->left and node = p->left
	//void set< Kty >::LLbRotation( TreeNode< value_type > *node )
	void LLRotation(TreeNode< value_type >* p)
	{
		if (p->parent->parent != myHead) {
			if (p->parent->parent->left->myval == p->parent->myval)
				p->parent->parent->left = p;
			else
				p->parent->parent->right = p;
		}
		else
			myHead->parent = p;
		if (p->right != myHead) {
			p->right->parent = p->parent;
			p->parent->left = p->right;
		}
		else
			p->parent->left = myHead;
		p->right = p->parent;
		p->parent = p->right->parent;
		p->parent->parent = p;
	}

	// rotate left at g, where p = g->right and node = p->right
	//void set< Kty >::RRbRotation( TreeNode< value_type > *node )
	void RRRotation(TreeNode< value_type >* p)
	{
		if (p->parent->parent != myHead) {
			if (p->parent->parent->right->myval == p->parent->myval)
				p->parent->parent->right = p;
			else
				p->parent->parent->left = p;
		}
		else
			myHead->parent = p;
		if (p->left != myHead) {
			p->left->parent = p->parent;
			p->parent->right = p->left;
		}
		else
			p->parent->right = myHead;
		p->left = p->parent;
		p->parent = p->left->parent;
		p->parent->parent = p;
	}

	// erase node provided that the degree of node is at most one
	void eraseDegreeOne(TreeNode< value_type >* node)
	{
		TreeNode< value_type >* child;
		if (node->left != myHead)
			child = node->left;
		else if (node->right != myHead)
			child = node->right;
		else
			child = myHead;
		if (child == myHead) {
			if (myHead->right->myval == node->parent->myval)
				myHead->right = node->parent;
			else if (myHead->left->myval == node->parent->myval)
				myHead->left = node->parent;
			if (node->parent->right->myval = node->myval)
				node->parent->right = myHead;
			else
				node->parent->left = myHead;
		}
		else if (child->myval == node->left->myval){
			if (node->parent->right->myval = node->myval)
				node->parent->right = node->left;
			else
				node->parent->left = node->left;
		}
		else if (child->myval == node->right->myval) {
			if (node->parent->right->myval = node->myval)
				node->parent->right = node->right;
			else
				node->parent->left = node->right;
		}
		
		delete node;
		mySize--;
	}

	// rebalance for deletion
	void fixUp(TreeNode< value_type >* N, TreeNode< value_type >* P)
	{
		TreeNode< value_type >* S;
		if (N == P->right)
			S = P->left;
		else
			S = P->right;
		if (N->color == Color::Black && N == P->left) {//4-1-1
			if (S->color == Color::Red) {
				S->color = P->color;
				P->color = Color::Red;
				LLRotation(P);
				P = P->parent;
			}
			else {
				if (S->right->color == Color::Red) {//4-1-2
					LLRotation(P);
					S->color = P->color;
					P->color = Color::Black;
					S->right->color = Color::Black;
				}
				else {
					if (S->left->color = Color::Red) {//4-1-3
						RRRotation(S);
						S->left->color = S->color;
						S->color = Color::Red;
						S = P->right;

						if (S->right->color == Color::Red) {//4-1-2
							LLRotation(P);
							S->color = P->color;
							P->color = Color::Black;
							S->right->color = Color::Black;
						}
					}
					else {
						if (P->color == Color::Red) {//4-1-4
							P->color = S->color;
							S->color = Color::Red;
						}
						else {//4-1-5
							S->color = Color::Red;
							if (P != myHead->parent)
								reBalance(P);
						}
					}
				}
			}
		}
		else if (N->color == Color::Black && N == P->right) {//4-1-1
			if (S->color == Color::Red) {
				S->color = P->color;
				P->color = Color::Red;
				RRRotation(P);
				P = P->parent;
			}
			else {
				if (S->left->color == Color::Red) {//4-1-2
					RRRotation(P);
					S->color = P->color;
					P->color = Color::Black;
					S->left->color = Color::Black;
				}
				else {
					if (S->right->color = Color::Red) {//4-1-3
						LLRotation(S);
						S->right->color = S->color;
						S->color = Color::Red;
						S = P->left;

						if (S->left->color == Color::Red) {//4-1-2
							RRRotation(P);
							S->color = P->color;
							P->color = Color::Black;
							S->left->color = Color::Black;
						}
					}
					else {
						if (P->color == Color::Red) {//4-1-4
							P->color = S->color;
							S->color = Color::Red;
						}
						else {//4-1-5
							S->color = Color::Red;
							if (P != myHead->parent)
								reBalance(P);
						}
					}
				}
			}
		}
	}

	/*
	   // preorder traversal and inorder traversal
	   void twoTraversals()
	   {
		  cout << "Preorder sequence:\n";
		  preorder( myHead->parent );

		  cout << "\nInorder sequence:\n";
		  inorder( myHead->parent );
		  cout << endl;
	   }

	   // preorder traversal
	   void preorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 preorder( node->left );
			 preorder( node->right );
		  }
	   }

	   // inorder traversal
	   void inorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 inorder( node->left );
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 inorder( node->right );
		  }
	   }
	*/

	NodePtr myHead;   // pointer to head node
	size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
	using value_type = typename Traits::value_type;

protected:
	using ScaryVal = TreeVal< value_type >;

public:
	using key_type = typename Traits::key_type;
	using key_compare = typename Traits::key_compare;

	using size_type = size_t;

	Tree(const key_compare& parg)
		: keyCompare(parg),
		scaryVal()
	{
	}

	~Tree()
	{
	}

	// Extends the container by inserting a new element,
	// effectively increasing the container size by one.
	void insert(const value_type& val)
	{
		TreeNode< value_type >* p = scaryVal.myHead->parent, *pp = scaryVal.myHead->parent;
		TreeNode< value_type >* currentNode = new TreeNode< value_type>;
		currentNode->isNil = false;
		currentNode->color = Color::Red;
		
		if (p == scaryVal.myHead) {
			currentNode->color = Color::Black;
			scaryVal.myHead->right = scaryVal.myHead->left = scaryVal.myHead->parent = currentNode;
			currentNode->right = currentNode->left = currentNode->parent = scaryVal.myHead;
			currentNode->myval = val;
		}
		else {
			while (p != scaryVal.myHead && val != p->myval) {
				pp = p;
				if (keyCompare(val, p->myval))
					p = p->left;
				else
					p = p->right;
			}
			if (pp->left == p)
				pp->left = currentNode;
			else
				pp->right = currentNode;
			currentNode->left = currentNode->right = scaryVal.myHead;
			currentNode->parent = pp;
			if (keyCompare(val, scaryVal.myHead->parent->myval) && keyCompare(val, pp->myval))
				scaryVal.myHead->left = currentNode;
			else if (keyCompare(scaryVal.myHead->parent->myval, val) && keyCompare(pp->myval, val))
				scaryVal.myHead->right = currentNode;
			
			currentNode->myval = val;
			while (currentNode->color == Color::Red && currentNode->parent->color == Color::Red && currentNode->parent->parent != scaryVal.myHead->parent) {
				scaryVal.reBalance(currentNode);
				currentNode = currentNode->parent->parent;
			}
		}
		scaryVal.mySize++;
	}

	// Removes from the set container a single element whose value is val
	// This effectively reduces the container size by one, which are destroyed.
	// Returns the number of elements erased.
	size_type erase(const key_type& val)
	{
		TreeNode< value_type >* p = scaryVal.myHead->parent, *pp = scaryVal.myHead->parent;
		while (p != scaryVal.myHead && val != p->myval) {
			pp = p;
			if (keyCompare(val, p->myval))
				p = p->left;
			else if (keyCompare(p->myval, val))
				p = p->right;
		}
		if (p != scaryVal.myHead) {
			if (pp->left == scaryVal.myHead || pp->right == scaryVal.myHead)
				scaryVal.eraseDegreeOne(p);
			TreeNode< value_type >* rightsubtreeMin = p->right;
			while (rightsubtreeMin->left != scaryVal.myHead)
				rightsubtreeMin = rightsubtreeMin->left;
			p->myval = rightsubtreeMin->myval;
			if (rightsubtreeMin->color == Color::Black) {
				if (rightsubtreeMin->parent->color == Color::Black) {
					rightsubtreeMin->parent->color = Color::Red;
				}
				
			}
			scaryVal.eraseDegreeOne(rightsubtreeMin);
		}
		return val;
	}

private:
	key_compare keyCompare;
	ScaryVal scaryVal;
};

#endif // XTREE