// xtree internal header

#ifndef XTREE
#define XTREE

enum class Color { Red, Black }; // colors for link to parent

template< typename Ty >
struct TreeNode
{
	using NodePtr = TreeNode*;
	using value_type = Ty;

	NodePtr    left;   // left subtree, or smallest element if head
	NodePtr    parent; // parent, or root of tree if head
	NodePtr    right;  // right subtree, or largest element if head
	Color      color;  // Red or Black, Black if head
	bool       isNil;  // true only if head (also nil) node
	value_type myval;  // the stored value, unused if head
};

// CLASS TEMPLATE TreeVal
template< typename Ty >
class TreeVal
{
public:
	using NodePtr = TreeNode< Ty >*;

	using value_type = Ty;
	using size_type = size_t;

	TreeVal()
		: myHead(new TreeNode< value_type >),
		mySize(0)
	{
		myHead->left = myHead;
		myHead->parent = myHead;
		myHead->right = myHead;
		myHead->color = Color::Black;
		myHead->isNil = true;
	}

	~TreeVal()
	{
		clear(myHead->parent);
		delete myHead;
	}

	// Removes all elements from the set object (which are destroyed)
	void clear(TreeNode< value_type >* node)
	{
		if (!node->isNil) // node is not an external node
		{
			clear(node->left);
			clear(node->right);
			delete node;
		}
	}

	// rebalance for insertion
	void reBalance(TreeNode< value_type >* node)
	{  // node->parent cannot be the root
		TreeNode< value_type >* ptr = node;
		TreeNode< value_type >* guother;

		while (ptr->parent != myHead && ptr->parent->parent != myHead)
		{
			if (ptr->color == Color::Red && ptr->parent->color == Color::Red)
			{
				guother = ptr->parent->parent->left;
				if (ptr->parent == guother)
					guother = ptr->parent->parent->right;

				if (guother->color == Color::Red)
				{
					ptr->parent->color = Color::Black;
					ptr->parent->parent->color = Color::Red;
					if (ptr->parent->parent == myHead->parent) //if gu is Root
						ptr->parent->parent->color = Color::Black;
					guother->color = Color::Black;

					ptr = ptr->parent->parent;
				}
				else
				{
					if (ptr->parent->parent->left == ptr->parent)
					{
						if (ptr == ptr->parent->left)
						{
							LLRotation(ptr->parent);
							ptr->parent->color = Color::Black;
							ptr->parent->right->color = Color::Red;
							ptr = ptr->parent;
						}
					}
					else if (ptr->parent->parent->right == ptr->parent)
					{
						if (ptr = ptr->parent->right)
						{
							RRRotation(ptr->parent);
							ptr->parent->color = Color::Black;
							ptr->parent->left->color = Color::Red;
							ptr = ptr->parent;
						}
					}
				}
			}
			else
				break;
		}
	}

	// rotate right at g, where p = g->left and node = p->left
	//void set< Kty >::LLbRotation( TreeNode< value_type > *node )
	void LLRotation(TreeNode< value_type >* p)
	{
		TreeNode< value_type >* gu = p->parent;
		TreeNode< value_type >* ggu = gu->parent;
		if (ggu == myHead)
			ggu->parent = p;
		else
		{
			if (ggu->left == gu)
				ggu->left = p;
			else
				ggu->right = p;
		}
		p->parent = ggu;
		gu->left = p->right;
		if (p->right != myHead)
			p->right->parent = gu;
		gu->parent = p;
		p->right = gu;
	}

	// rotate left at g, where p = g->right and node = p->right
	//void set< Kty >::RRbRotation( TreeNode< value_type > *node )
	void RRRotation(TreeNode< value_type >* p)
	{
		TreeNode< value_type >* gu = p->parent;
		TreeNode< value_type >* ggu = gu->parent;
		if (ggu == myHead)
			ggu->parent = p;
		else
		{
			if (ggu->left == gu)
				ggu->left = p;
			else
				ggu->right = p;
		}
		p->parent = ggu;
		gu->right = p->left;
		if (p->left != myHead)
			p->left->parent = gu;
		gu->parent = p;
		p->left = gu;
	}

	// erase node provided that the degree of node is at most one
	void eraseDegreeOne(TreeNode< value_type >* node)
	{
		TreeNode< value_type >* P = node->parent;
		TreeNode< value_type >* child = node->left;
		if (child == myHead)
			child = node->right;
		if (node->left == myHead && node->right == myHead) //��node�S������child
		{
			if (node->parent->left == node)
				node->parent->left = myHead;
			if(node->parent->right == node)
				node->parent->right = myHead;
			if (node->parent == myHead)
				myHead->parent = myHead;
		}
		else
		{
			child->parent = P;
			if (P->parent == myHead)
				P->parent = child;
			else
			{
				if (P->left == node)
					P->left = child;
				else
					P->right = child;
				child->parent = P;
			}
			if (myHead->left == node)
				myHead->left = child;
			if (myHead->right == node)
				myHead->right = child;
		}

		if (node->color != Color::Red)  //�L�osimple case 1
			fixUp(child, P);
		delete node;
	}

	// rebalance for deletion
	void fixUp(TreeNode< value_type >* N, TreeNode< value_type >* P)
	{
		if (N->color == Color::Red) //simlpe case 2
			N->color = Color::Black;
		else
		{
			if (N == myHead->parent) //simple case 3
				return;
			else
			{
				TreeNode< value_type >* S = P->left;
				if (N == S)
					S = P->right;
				TreeNode< value_type >* SL = S->left;
				TreeNode< value_type >* SR = S->right;
				while (1)
				{
					if (N == P->left)	//N�b����
					{
						if (S->color == Color::Red)			//case 1
						{
							RRRotation(S);
							Color P_reverse = Color::Red;
							if (P->color == Color::Red)
								P_reverse = Color::Black;
							P->color = P_reverse;
							S->color = Color::Black;
							S = P->right;
							SL = S->left;
							SR = S->right;
						}
						else
						{
							if (SR->color == Color::Red)	//case 2
							{
								RRRotation(S);
								Color P_color = P->color;
								S->color = P_color;
								P->color = Color::Black;
								SR->color = Color::Black;
								break;
							}
							else
							{
								if (SL->color == Color::Red)	//case3
								{
									LLRotation(SL);
									S->color = Color::Red;
									SL->color = Color::Black;

									S = SL;
									SL = S->left;
									SR = S->right;
								}
								else
								{
									if (P->color == Color::Red)	//case4
									{
										P->color = Color::Black;
										S->color = Color::Red;
										break;
									}
									else						//case 5
									{
										S->color = Color::Red;
										N = P;
										P = N->parent;
										S = P->left;
										if (S == N)
											S = P->right;
										SL = S->left;
										SR = S->right;
									}
								}
							}
						}
					}
					else		//N�b�k��
					{
						if (S->color == Color::Red)			//case 1
						{
							LLRotation(S);
							Color P_reverse = Color::Red;
							if (P->color == Color::Red)
								P_reverse = Color::Black;
							P->color = P_reverse;
							S->color = Color::Black;
							S = P->left;
							SL = S->left;
							SR = S->right;
						}
						else
						{
							if (SL->color == Color::Red)	//case 2
							{
								LLRotation(S);
								Color P_color = P->color;
								S->color = P_color;
								P->color = Color::Black;
								SL->color = Color::Black;
								break;
							}
							else
							{
								if (SR->color == Color::Red)	//case3
								{
									RRRotation(SR);
									S->color = Color::Red;
									SR->color = Color::Black;

									S = SR;
									SL = S->left;
									SR = S->right;
								}
								else
								{
									if (P->color == Color::Red)	//case4 ok
									{
										P->color = Color::Black;
										S->color = Color::Red;
										break;
									}
									else						//case 5
									{
										S->color = Color::Red;
										N = P;
										P = N->parent;
										S = P->left;
										if (S == N)
											S = P->right;
										SL = S->left;
										SR = S->right;
									}
								}
							}
						}
					}
				}
			}
		}
	}

	/*
	   // preorder traversal and inorder traversal
	   void twoTraversals()
	   {
		  cout << "Preorder sequence:\n";
		  preorder( myHead->parent );

		  cout << "\nInorder sequence:\n";
		  inorder( myHead->parent );
		  cout << endl;
	   }

	   // preorder traversal
	   void preorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 preorder( node->left );
			 preorder( node->right );
		  }
	   }

	   // inorder traversal
	   void inorder( TreeNode< value_type > *node )
	   {
		  if( node != myHead )
		  {
			 inorder( node->left );
			 cout << setw( 5 ) << node->myval << ( node->color == Color::Red ? "R" : "B" );
			 inorder( node->right );
		  }
	   }
	*/

	NodePtr myHead;   // pointer to head node
	size_type mySize; // number of elements
};

// CLASS TEMPLATE Tree
template< typename Traits >
class Tree // ordered red-black tree for map/multimap/set/multiset
{
public:
	using value_type = typename Traits::value_type;

protected:
	using ScaryVal = TreeVal< value_type >;

public:
	using key_type = typename Traits::key_type;
	using key_compare = typename Traits::key_compare;

	using size_type = size_t;

	Tree(const key_compare& parg)
		: keyCompare(parg),
		scaryVal()
	{
	}

	~Tree()
	{
	}

	// Extends the container by inserting a new element,
	// effectively increasing the container size by one.
	void insert(const value_type& val)
	{
		TreeNode< value_type >* node=new TreeNode< value_type >;
		node->color = Color::Red;
		node->isNil = false;
		node->myval = val;
		node->left = scaryVal.myHead;
		node->right = scaryVal.myHead;

		if (scaryVal.myHead->parent == scaryVal.myHead) //��tree nodes�ӼƬ�0
		{
			node->color = Color::Black;
			scaryVal.myHead->parent = node;
			scaryVal.myHead->left = node;
			scaryVal.myHead->right = node;
			node->parent = scaryVal.myHead;
		}
		else
		{
			TreeNode< value_type >* ptr = scaryVal.myHead->parent;
			while (ptr != scaryVal.myHead)
			{
				if (keyCompare(val, ptr->myval))	//left subtree
				{
					if (ptr->left != scaryVal.myHead)
						ptr = ptr->left;
					else
					{
						ptr->left = node;
						node->parent = ptr;
						if (scaryVal.myHead->left == ptr)
							scaryVal.myHead->left = node;
						break;
					}
				}
				else if (keyCompare(ptr->myval, val))	//right subtree
				{
					if (ptr->right != scaryVal.myHead)
						ptr = ptr->right;
					else
					{
						ptr->right = node;
						node->parent = ptr;
						if (scaryVal.myHead->right == ptr)
							scaryVal.myHead->right = node;
						break;
					}
				}
				else  //��쭫�ƪ��Ʀr =>��������ʧ@
					return;
			}
		}
		scaryVal.reBalance(node);
		scaryVal.mySize += 1;
	}

	// Removes from the set container a single element whose value is val
	// This effectively reduces the container size by one, which are destroyed.
	// Returns the number of elements erased.
	size_type erase(const key_type& val)
	{
		TreeNode< value_type >* node = scaryVal.myHead->parent;
		while (node!=scaryVal.myHead)
		{
			if (keyCompare(val, node->myval))
				node = node->left;
			else if (keyCompare(node->myval, val))
				node = node->right;
			else	//���val����node����m
				break;
		}

		if (node != scaryVal.myHead)
		{
			if (node->left != scaryVal.myHead && node->right != scaryVal.myHead) //�����child
			{
				TreeNode< value_type >* BigChild = node->right;
				while (BigChild->left != scaryVal.myHead)
					BigChild = BigChild->left;
				value_type target = node->myval;
				node->myval = BigChild->myval;
				BigChild->myval = target;

				scaryVal.eraseDegreeOne(BigChild); //BigChild�̦h�@��child
			}
			else
				scaryVal.eraseDegreeOne(node);
		}
		else
			return 0;
		scaryVal.mySize -= 1;
		return 1;
	}

private:
	key_compare keyCompare;
	ScaryVal scaryVal;
};

#endif // XTREE