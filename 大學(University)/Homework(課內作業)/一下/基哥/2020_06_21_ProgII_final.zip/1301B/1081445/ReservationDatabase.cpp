#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++) {
		if (reservations[i].getPhoneNumber() == phoneNumber) {
			return true;
		}
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++) {
		if (reservations[i].getPhoneNumber() == phoneNumber) {
			reservations[i].displayReservationInfo();
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream infile("Reservations.dat", ios::binary);

	infile.seekg(0, ios::end);
	int num = infile.tellg() / sizeof(Reservation);
	infile.seekg(0, ios::beg);
	reservations.resize(num);

	for (int i = 0; i < num; i++) {
		infile.read(reinterpret_cast<char*>(&reservations[i]), sizeof(Reservation));
	}

	infile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outfile("Reservations.dat", ios::binary);

	for (int i = 0; i < reservations.size(); i++) {
		outfile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(Reservation));
	}

	outfile.close();
}