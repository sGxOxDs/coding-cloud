#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	loadAvailSeats();
	if (availSeats.empty()) {
		availSeats.resize(30);
		Date cur;
		computeCurrentDate(cur);
		cur = cur + 1;
		for (int i = 0; i < 30; i++, cur = cur + 1) {
			availSeats[i].setDate(cur);
			for (int j = 1; j <= 5; j++) {
				availSeats[i].setNumAvailSeats(j, 18);
			}
		}
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
	storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats(Date date, int timeCode, int requiredSeats)
{
	for (int i = 0; i < availSeats.size(); i++) {
		if (availSeats[i].getDate() == date) {
			if (availSeats[i].getNumAvailSeats(timeCode) >= requiredSeats) {
				availSeats[i].setNumAvailSeats(timeCode, availSeats[i].getNumAvailSeats(timeCode) - requiredSeats);
			}
			break;
		}
	}
}

bool AvailSeatsDatabase::availableTimes(Date date, int requiredSeats)
{
	for (int i = 0; i < availSeats.size(); i++) {
		if (availSeats[i].getDate() == date) {
			if (availSeats[i].getNumAvailSeats(1) + availSeats[i].getNumAvailSeats(2) + availSeats[i].getNumAvailSeats(3) + availSeats[i].getNumAvailSeats(4) > requiredSeats) {
				return true;
			}
			return false;
		}
	}
	return false;
}

bool AvailSeatsDatabase::availableTimes(Date date, int timeCode, int requiredSeats)
{
	for (int i = 0; i < availSeats.size(); i++) {
		if (availSeats[i].getDate() == date) {
			if (availSeats[i].getNumAvailSeats(timeCode) >= requiredSeats) {
				return true;
			}
			return false;
		}
	}
	return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats(Date date)
{
	vector< AvailSeats >::iterator it = availSeats.begin();

	for (; it >= availSeats.end(); ++it) {
		if (it->getDate() == date) {
			return it;
		}
	}
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream infile("AvailSeats.dat", ios::binary);

	infile.seekg(0, ios::end);
	int num = infile.tellg() / sizeof(AvailSeats);
	infile.seekg(0, ios::beg);
	availSeats.resize(num);

	for (int i = 0; i < num; i++) {
		infile.read(reinterpret_cast<char*>(&availSeats[i]), sizeof(AvailSeats));
	}

	infile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outfile("AvailSeats.dat", ios::binary);

	for (int i = 0; i < availSeats.size(); i++) {
		outfile.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(AvailSeats));
	}

	outfile.close();
}