// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
#include<vector>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger(int begin, int end);

MakeReservation::MakeReservation(ReservationDatabase& theReservationDatabase,
	AvailSeatsDatabase& theSeatsDatabase)
	: reservationDatabase(theReservationDatabase),
	availSeatsDatabase(theSeatsDatabase)
{
}

void MakeReservation::execute()
{
	cout << "\nEnter the party size (1~6): ";

	int partySize;
	do cout << "? ";
	while ((partySize = inputAnInteger(1, 6)) == -1);

	Date currentDate;
	computeCurrentDate(currentDate);

	Date date;
	inputDate(date, currentDate, partySize);

	int timeCode;
	inputTimeCode(timeCode, date, partySize);

	string name;
	cout << "\nEnter name: ";
	cin >> name;

	string phoneNumber;
	cout << "\nEnter phone Number: ";
	cin >> phoneNumber;
	cin.ignore();

	cout << "\nChoose a menu:\n";
	cout << "1. NT$ 1080\n";
	cout << "2. NT$ 1680\n";
	cout << "3. NT$ 2280\n";

	int menuCode;
	do cout << "? ";
	while ((menuCode = inputAnInteger(1, 3)) == -1);

	Reservation newReservation(phoneNumber, name, date, timeCode, partySize, menuCode);

	cout << endl;
	newReservation.displayReservationInfo();

	cout << "\nReservation Completed\n";

	reservationDatabase.pushBack(newReservation);

	availSeatsDatabase.decreaseAvailSeats(date, timeCode, partySize);
}

void MakeReservation::inputDate(Date& date, Date currentDate, int partySize)
{
	vector<Date>a;
	Date tmp = currentDate + 1;

	for (int i = 0; i < 30; i++, tmp + 1) {
		a.push_back(tmp);
	}

	cout <<endl<< "Choose a date" << endl;

	for (int i = 0, n = 0; i < 30; i++) {
		if (availSeatsDatabase.availableTimes(a[i], partySize)) {
			cout << setw(2) << i + 1 << ". " << a[i].getYear() << "/";
			if (a[i].getMonth() < 10) {
				cout << "0";
			}
			cout << a[i].getMonth() << "/";
			if (a[i].getDay() < 10) {
				cout << "0";
			}
			cout << a[i].getDay() << "  ";
			n++;
		}
		if (n == 4) {
			cout << endl;
			n = 0;
		}
	}
	cout << endl;

	int n = -1;
	do {
		cout << "? ";
		n = inputAnInteger(1, 30);
		if (n != -1&&!availSeatsDatabase.availableTimes(a[n-1], partySize)  ) {
			n == -1;
		}
	} while (n == -1);

	date = a[n-1];
}

void MakeReservation::inputTimeCode(int& timeCode, Date date, int partySize)
{
	cout <<endl<< "Choose a time:" << endl;
	for (int i = 1; i <= 4; i++) {
		if (availSeatsDatabase.availableTimes(date, i, partySize)) {
			switch (i)
			{
			case 1:
				cout << "1. 11:30" << endl;
				break;
			case 2:
				cout << "2. 13:30" << endl;
				break;
			case 3:
				cout << "3. 17:45" << endl;
				break;
			case 4:
				cout << "4. 19:45" << endl;
				break;
			default:
				break;
			}
		}
	}
	int n = -1;
	do {
		cout << "? ";
		n = inputAnInteger(1, 4);
		if (!availSeatsDatabase.availableTimes(date, n, partySize)) {
			n = -1;
		}
	} while (n == -1);
	timeCode = n;
	//availSeatsDatabase.decreaseAvailSeats(date, timeCode, partySize);
}