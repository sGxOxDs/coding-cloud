#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	Date tmp;
	Date today;
	Date date;
	AvailSeats avail;
	int exist = 0;
	for (int i = 1; i < 5; i++)
		avail.setNumAvailSeats(i, 20);
	avail.setNumAvailSeats(0, 0);
	computeCurrentDate(today);
	tmp = today;
	loadAvailSeats();
	if (availSeats.size() == 0)
		while (tmp.operator<(today.operator+(30)))
		{
			tmp = tmp.operator+(1);
			avail.setDate(tmp);
			availSeats.push_back(avail);
		}
	else
	{
		vector<AvailSeats>::iterator it = availSeats.begin();
		date = it->getDate();
		if (date.operator==(today))
		{
			availSeats.erase(it);
			it->setDate(today.operator+(30));
			for (int i = 1; i < 5; i++)
				it->setNumAvailSeats(i, 20);
			it->setNumAvailSeats(0, 0);
		}
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	int tmp = it->getNumAvailSeats(timeCode);
	tmp -= requiredSeats;
	it->setNumAvailSeats(timeCode, tmp);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	for (int i = 0; i < 5; i++)
		if (it->getNumAvailSeats(i) > 0)
			return true;
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	if (it->getNumAvailSeats(timeCode) > requiredSeats)
	{
		int tmp = it->getNumAvailSeats(timeCode);
		return true;
	}
	else
		return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector<AvailSeats>::iterator it = availSeats.begin();
	Date tmp;
	tmp = it->getDate();
	if (tmp.operator==(date))
		return it;
	while (it != availSeats.end())
	{
		it++;
		if (it == availSeats.end())
			break;
		tmp = it->getDate();
		if (tmp.operator==(date))
			break;
	}
	return it;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	AvailSeats buf;
	ifstream infile("AvailSeats.dat", ios::in | ios::binary);
	while (!infile.eof())
	{
		infile.read(reinterpret_cast<char*>(&buf), sizeof(AvailSeats));
		if (infile.eof())
			break;
		availSeats.push_back(buf);
	}
	infile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outfile("AvailSeats.dat", ios::out | ios::binary);
	for (int i = 0; i < availSeats.size(); i++)
		outfile.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(availSeats[i]));
}