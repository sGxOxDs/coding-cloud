#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	vector<Reservation>::iterator it = reservations.begin();
	string tmp = it->getPhoneNumber();
	if (tmp == phoneNumber)
		return true;
	while (it != reservations.end())
	{
		it++;
		if (it == reservations.end())
			break;
		tmp = it->getPhoneNumber();
		if (tmp == phoneNumber)
			return true;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	int i = 1;
	string tmpPhoneNumber;
	vector<Reservation>::iterator it = reservations.begin();
	cout << endl;
	for (; it != reservations.end(); it++)
	{
		tmpPhoneNumber = it->getPhoneNumber();
		if (tmpPhoneNumber == phoneNumber)
		{
			cout << setw(2) << i << ". ";
			it->displayReservationInfo();
			cout << endl;
			i++;
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	Reservation buf;
	ifstream infile("Reservations.dat", ios::in | ios::binary);
	while (!infile.eof())
	{
		infile.read(reinterpret_cast<char*>(&buf), sizeof(buf));
		if (infile.eof())
			break;
		reservations.push_back(buf);
	}
	infile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outfile("Reservations.dat", ios::out | ios::binary);
	for (int i = 0; i < reservations.size(); i++)
		outfile.write(reinterpret_cast<char*>(&reservations[i]), sizeof(reservations[i]));
}