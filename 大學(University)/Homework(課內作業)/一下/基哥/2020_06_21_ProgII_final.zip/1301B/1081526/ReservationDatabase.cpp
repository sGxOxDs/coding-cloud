#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
	{
		if (phoneNumber == reservations[i].getPhoneNumber())
			return true;	
	}
	return false;

	/*if (phoneNumber.size()== reservations[i].getPhoneNumber().size())
		{
			bool pass = true;
			for (int k = 0; k < phoneNumber.size(); k++)
			{
				if (phoneNumber[k] != reservations[i].getPhoneNumber()[k])
				{
					pass = false;
					break;
				}
			}

			if (pass)
				return true;
		}*/
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	cout << endl;
	if (exist(phoneNumber))
	{
		int count = 1;
		for (int i = 0; i < reservations.size(); i++)
		{
			if (phoneNumber == reservations[i].getPhoneNumber())
			{
				string forTime;
				switch (reservations[i].getTime())
				{
				case 1:
					forTime = "11:30";
					break;
				case 2:
					forTime = "13:30";
					break;
				case 3:
					forTime = "17:45";
					break;
				case 4:
					forTime = "19:45";
					break;
				}
				cout << count << ". " << reservations[i].getPartySize() << " guests "
					<< reservations[i].getDate().getYear() << "/"
					<< reservations[i].getDate().getMonth() << "/"
					<< reservations[i].getDate().getDay() << " " << forTime << endl;
				count++;
			}
		}
		cout << endl;
	}
	else
		cout << "No reservations!" << endl << endl;
	
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream in("Reservations.dat", ios::in | ios::binary);
	if (!in)
	{
		cout << "The file can't be opened." << endl;
		system("pause");
		exit(1);
	}

	Reservation temp;
	while (in.read(reinterpret_cast<char*>(&temp), sizeof(temp)))
	{
		reservations.push_back(temp);
	}

}

void ReservationDatabase::storeReservations()
{
	ofstream out("Reservations.dat", ios::in | ios::binary);
	if(!out)
	{
		cout << "The file can't be opened." << endl;
		system("pause");
		exit(1);
	}

	for (int i = 0; i < reservations.size(); i++)
	{
		out.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(Reservation));
	}
}