// Date.cpp
// AvailSeats-function definitions for class Date.
#include <iostream>
#include <iomanip>
#include <ctime>
using namespace std;
#include "Date.h"

extern bool leapYear( int year );

Date::Date()
{
   year = 2000;
   month = 0;
   day = 0;
}

// const return avoids: ( a1 = a2 ) = a3
const Date &Date::operator=( const Date &right )
{
   if( &right != this ) // avoid self-assignment
   {
      month = right.month;
      day = right.day;
      year = right.year;
   } // end if

   return *this; // enables x = y = z, for example
} // end function operator=

void Date::setDate( int y, int m, int d )
{
   year = ( y >= 2000 ) ? y : 2000; // sets year
   month = ( m >= 1 && m <= 12 ) ? m : 1; // sets month

   if( month == 2 && leapYear( year ) )
      day = ( d >= 1 && d <= 29 ) ? d : 1;
   else
      day = ( d >= 1 && d <= days[ month ] ) ? d : 1;
}

void Date::setYear( int y )
{
   year = ( y >= 2000 ) ? y : 2000; // sets year
} // end function setYear

void Date::setMonth( int m )
{
   month = ( m >= 1 && m <= 12 ) ? m : 1; // sets month
} // end function setMonth

void Date::setDay( int d )
{
   if( month == 2 && leapYear( year ) )
      day = ( d >= 1 && d <= 29 ) ? d : 1;
   else
      day = ( d >= 1 && d <= days[ month ] ) ? d : 1;
} // end function setDay

int Date::getYear() const
{
   return year;
}

int Date::getMonth() const
{
   return month;
}

int Date::getDay() const
{
   return day;
}

bool Date::operator==( const Date &date2 )
{
   return ( year == date2.year && month == date2.month && day == date2.day );
}

bool Date::operator<( const Date &date2 )
{
   if( year < date2.year )
      return true;
   if( year > date2.year )
      return false;

   if( month < date2.month )
      return true;
   if( month > date2.month )
      return false;

   if( day < date2.day )
      return true;

   return false;
}

// if the year is a leap year, return true; otherwise, return false
bool Date::leapYear( int testYear ) const
{
   if( testYear % 400 == 0 ||
      ( testYear % 100 != 0 && testYear % 4 == 0 ) )
      return true; // a leap year
   else
      return false; // not a leap year
} // end function leapYear

// return *this - date2 provided that *this > date2
int Date::operator-( const Date &date2 )
{
	int totalDays=0,lessMonth=date2.month;

	for (; lessMonth < month; lessMonth++)
	{
		if (lessMonth == 2)
		{
			if (leapYear(date2.year))
				totalDays += 29;
			else
				totalDays += days[lessMonth];
		}
		else
			totalDays+= days[lessMonth];
	}
	totalDays += day;//�[�W�Q��ƪ���lex.7/1�N�[1

	return totalDays - date2.day;
	/*if (lessMonth == 4 || lessMonth == 6 || lessMonth == 9 || lessMonth == 11)
		totalDays += 30;
	else if (lessMonth == 2)
	{
		if (leapYear(date2.year))
			totalDays += 29;
		else
			totalDays += 28;
	}
	else
		totalDays += 31;*/
}

Date Date::operator+( int numDays )
{
	/*cout << "test start:" << month << "/" << day << endl;
	cout << "numDays" << numDays << endl;*/
	Date temp = *this;
	int monthDays;
	while (numDays != 0)
	{
		if (temp.month == 2)
		{
			if (leapYear(temp.year))
				monthDays = 29;
			else
				monthDays = temp.days[month];
		}
		else
			monthDays = temp.days[month];


		if ((temp.day + numDays) > monthDays)
		{
			numDays-=(monthDays - temp.day);
			temp.month++;
			temp.day = 0;
			if (temp.month > 12)
			{
				temp.year++;
				temp.month = 1;
			}
		}
		else
		{
			temp.day += numDays;
			numDays = 0;
		}
			
	}
	return temp;
}