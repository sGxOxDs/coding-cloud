#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	loadAvailSeats();
	Date dateTemp;
	computeCurrentDate(dateTemp);
	//test
	/*cout <<"test"<< dateTemp.getMonth() << "/" << dateTemp.getDay() << endl;*/
	if (availSeats.size() == 0)//�p�G�S��Ū���ƴN�ؤ@�ӷs��
	{

		//cout << "size zero" << endl;//test
		AvailSeats availTemp;
		for (int i = 1; i <= 30; i++)
		{
			computeCurrentDate(dateTemp);
			availTemp.setDate(dateTemp + i);
			for (int k = 1; k < 5; k++)
			{
				availTemp.setNumAvailSeats(k, 20);
			}

			availSeats.push_back(availTemp);
			//test
			//cout << "test:" << availSeats[i - 1].getDate().getDay() << endl;
		}
		
		
	}
	else if((dateTemp+1)-availSeats[0].getDate()!=0)
	{
		int gap = dateTemp - availSeats[0].getDate();

		vector<AvailSeats> New;
		for (int i = gap; i < availSeats.size(); i++)
		{
			New.push_back(availSeats[i]);
		}

		availSeats.clear();
		int NewOldSize = New.size();
		for (int k = 0; k < 30; k++)
		{
			if (k >= NewOldSize)
			{
				AvailSeats availTemp;
				for (int k = 1; k < 5; k++)
				{
					availTemp.setNumAvailSeats(k, 20);
				}
				availSeats.push_back(availTemp);
			}
			else
			{
				availSeats.push_back(New[k]);
			}

		}
		
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	Date dateTemp;
	computeCurrentDate(dateTemp);
	dateTemp = dateTemp + 1;
	int num = date - dateTemp;

	int originSeat = availSeats[num].getNumAvailSeats(timeCode);
	availSeats[num].setNumAvailSeats(timeCode, originSeat - requiredSeats);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	Date dateTemp;
	computeCurrentDate(dateTemp);
	dateTemp = dateTemp + 1;
	int num = date - dateTemp;

	for (int i = 1; i < 5; i++)
	{
		//test
		//cout << "test:" << availSeats[num].getNumAvailSeats(i) << endl;
		if (availSeats[num].getNumAvailSeats(i) >= requiredSeats)
			return true;
	}
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	Date dateTemp;
	computeCurrentDate(dateTemp);
	int num = date - dateTemp;

	
	if (availSeats[num].getNumAvailSeats(timeCode) >= requiredSeats)
		return true;
	else
		return false;
	
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	Date dateTemp;
	computeCurrentDate(dateTemp);
	int num = date - dateTemp;
	
	vector< AvailSeats >::iterator ptr ;
	return ptr;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream in("AvailSeats.dat", ios::in | ios::binary);
	if (!in)
	{
		cout << "The file can't be opened." << endl;
		system("pause");
		exit(1);
	}

	AvailSeats temp;
	while (in.read(reinterpret_cast<char*>(&temp), sizeof(temp)))
	{
		availSeats.push_back(temp);
	}
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream out("AvailSeats.dat", ios::in | ios::binary);
	if (!out)
	{
		cout << "The file can't be opened." << endl;
		system("pause");
		exit(1);
	}

	for (int i = 0; i < availSeats.size(); i++)
	{
		out.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(AvailSeats));
	}
}