#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	extern void computeCurrentDate(Date & currentDate);
	loadAvailSeats();
	Date currentDate;
	computeCurrentDate(currentDate);
	if (availSeats.size() != 0) {
		while ((availSeats[0].getDate() < currentDate) || (availSeats[0].getDate() == currentDate))
			availSeats.erase(availSeats.begin());
	}
	AvailSeats newAvailSeats;
	for (int i = 1; i < 5; i++)
		newAvailSeats.setNumAvailSeats(i, 20);
	for (int i = availSeats.size()+1; i < 31; i++) {
		newAvailSeats.setDate(currentDate + i);
		availSeats.push_back(newAvailSeats);
	}

}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	if (availableTimes(date, timeCode, requiredSeats))
		it->setNumAvailSeats(timeCode, it->getNumAvailSeats(timeCode) - requiredSeats);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	int availbleSeats = 0;
	for (int i = 1; i < 5; i++) {
		if (it->getNumAvailSeats(i) >= requiredSeats)
			return true;
	}
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	return (it->getNumAvailSeats(timeCode) >= requiredSeats);
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator it = availSeats.begin();
	for (; it != availSeats.end(); ++it)
		if (it->getDate() == date)
			return it;
	return availSeats.end();
}

void AvailSeatsDatabase::loadAvailSeats()
{
	fstream inFile("AvailSeats.dat", ios::in | ios::binary);
	inFile.seekg(0,ios::end);
	int numLine = inFile.tellg() / sizeof(AvailSeats);
	inFile.seekg(0,ios::beg);
	availSeats.resize(numLine);
	for (int i = 0; i < numLine; i++)
		inFile.read(reinterpret_cast<char*>(&availSeats[i]), sizeof(AvailSeats));
	inFile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	fstream outFile("AvailSeats.dat", ios::out | ios::binary);
	for (int i = 0; i < availSeats.size(); i++)
		outFile.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(AvailSeats));
}