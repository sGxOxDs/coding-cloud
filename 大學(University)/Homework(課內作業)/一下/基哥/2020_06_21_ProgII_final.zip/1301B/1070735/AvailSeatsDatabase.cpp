#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	Date currentDate;
	int theNumAvailSeats[5] = {0,20,20,20,20};
	int i = 1;

	loadAvailSeats();
	vector< AvailSeats >::iterator it = availSeats.begin();
	computeCurrentDate(currentDate);

	while (it->getDate() < (currentDate+1))
	{
		availSeats.erase(it);
		if (availSeats.size() == 0)
			break;
		it = availSeats.begin()+i;
		i++;
	}
	if (availSeats.size() == 0) {
		AvailSeats seat(currentDate + 1, theNumAvailSeats);
		availSeats.push_back(seat);
		it = availSeats.begin();
	}
	i = 1;
	while (it->getDate() < (currentDate + 31))
	{
		AvailSeats seat(it->getDate() + 1, theNumAvailSeats);
		availSeats.push_back(seat);
		it = availSeats.begin() + i;
		i++;
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
	storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats(Date date, int timeCode, int requiredSeats)
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	it->setNumAvailSeats(timeCode, it->getNumAvailSeats(timeCode) - requiredSeats);
}

bool AvailSeatsDatabase::availableTimes(Date date, int requiredSeats)
{
	int NumAvailSeats = 0;
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	for (int i = 1; i < 5; i++)
	{
		if (it->getNumAvailSeats(i) < requiredSeats)
		{
			return false;
		}
	}
	return true;
}

bool AvailSeatsDatabase::availableTimes(Date date, int timeCode, int requiredSeats)
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);

	if (it->getNumAvailSeats(timeCode) < requiredSeats)
		return false;
	else
		return true;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats(Date date)
{
	vector< AvailSeats >::iterator it = availSeats.begin();
	
	for (int i = 1; i < availSeats.size(); i++)
	{
		if (it->getDate() == date)
			return it;
		it = availSeats.begin() + i;
	}

}

void AvailSeatsDatabase::loadAvailSeats()
{
	fstream ifile("AvailSeats.dat", ios::in | ios::binary);
	AvailSeats seat;
	while (!ifile.fail())
	{
		ifile.read(reinterpret_cast<char*>(&seat), sizeof(AvailSeats));
		if (ifile.fail())
			break;
		availSeats.push_back(seat);
	}
	ifile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	fstream ofile("AvailSeats.dat", ios::out | ios::binary);
	for (int i = 0; i < availSeats.size(); i++)
	{
		ofile.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(AvailSeats));
	}
	ofile.close();
}