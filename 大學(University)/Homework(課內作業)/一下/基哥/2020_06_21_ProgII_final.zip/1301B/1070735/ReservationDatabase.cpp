#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
	loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
	storeReservations();
}

bool ReservationDatabase::empty()
{
	return (reservations.size() == 0);
}

bool ReservationDatabase::exist(string phoneNumber)
{
	vector< Reservation >::iterator it = reservations.begin();
	
	for (int i = 1; it != reservations.end(); i++)
	{
		if (it->getPhoneNumber() == phoneNumber)
			return true;
		it = reservations.begin() + i;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo(string phoneNumber)
{
	string availableTime[5] = { "","11:30","13:30","17:45","19:45" };
	vector< Reservation >::iterator it = reservations.begin();
	int i = 1,j=1;

	for (; it != reservations.end(); j++)
	{
		if (it->getPhoneNumber() == phoneNumber)
		{
			cout << setw(2) << i << ". " << it->getPartySize() << " guests  " 
				 << it->getDate().getYear() << it->getDate().getMonth() << it->getDate().getDay() 
				 << "  " << availableTime[it->getTime()] << endl;
			i++;
		}
		it = reservations.begin() + j;
	}


}

void ReservationDatabase::pushBack(Reservation newReservation)
{
	reservations.push_back(newReservation);
}

void ReservationDatabase::loadReservations()
{
	fstream ifile("Reservations.dat", ios::in | ios::binary);
	Reservation reservation;
	while (!ifile.fail())
	{
		ifile.read(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
		if (ifile.fail())
			break;
		reservations.push_back(reservation);
	}
	ifile.close();
}

void ReservationDatabase::storeReservations()
{
	fstream ofile("Reservations.dat", ios::out | ios::binary);
	for (int i = 0; i < reservations.size(); i++)
	{
		ofile.write(reinterpret_cast<char*>(&reservations[i]), sizeof(Reservation));
	}
	ofile.close();
}