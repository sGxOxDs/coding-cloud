#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++) 
		if (reservations[i].getPhoneNumber() == phoneNumber)
			return true;

	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	cout << endl;
	int item = 0;
	for (int i = 0; i < reservations.size(); i++)
		if (reservations[i].getPhoneNumber() == phoneNumber) {
			cout << setw(2) << item + 1 << ". ";
			reservations[i].displayReservationInfo();
			item++;
		}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	Reservation zero;
	fstream inFile("Reservations.dat", ios::in | ios::out | ios::binary);
	inFile.seekg(0, ios::end);
	int numLine = inFile.tellg() / sizeof(Reservation);
	inFile.seekg(0, ios::beg);
	reservations.resize(numLine);
	for (int i = 0; i < numLine; i++) {
		inFile.read(reinterpret_cast<char*>(&reservations[i]), sizeof(reservations[i]));
	}
	for (int i = 0; i < numLine; i++) {
		inFile.write(reinterpret_cast<char*>(&zero), sizeof(Reservation));
	}
}

void ReservationDatabase::storeReservations()
{
	fstream file("Reservations.dat", ios::in | ios::out | ios::binary);

	for (int i = 0; i < reservations.size(); i++)
		file.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(reservations[i]));
}