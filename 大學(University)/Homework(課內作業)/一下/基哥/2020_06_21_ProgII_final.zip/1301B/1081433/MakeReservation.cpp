// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );
}

void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{
	cout << "\nChoose a date\n";
	Date today;
	today = currentDate + 1;
	int line = 0;
	int num[30] = { 0 };
	vector< Date > iWant;
	iWant.resize(30);
	for (int i = 0; i < 30; i++) {
		if (availSeatsDatabase.availableTimes(today, partySize)) {
			cout << setw(2) << i + 1 << ". "
				<< today.getYear() << "/"
				<< setw(2) << today.getMonth() << "/"
				<< setw(2) << today.getDay() << "  ";
			line++;
			num[i] = 1;
			iWant[i] = today;
		}
		if (line % 4 == 0)
			cout << endl;
		today = today + 1;
	}
	cout << endl;

	int choice;
	do {
		do {
			cout << "?";
		} while ((choice = inputAnInteger(1, 30)) == -1);
	} while (!num[choice - 1]);
	date = iWant[choice - 1];
}

void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{
	string times[5] = { "","11:30","13:30","17:45","19:45" };
	int num[5] = { 0 };
	cout << "\nChoose a time:\n";
	for (int i = 1; i <= 4; i++) {
		if (availSeatsDatabase.availableTimes(date, i, partySize)) {
			cout << i << ". " << times[i] << endl;
			num[i] = 1;
		}
	}
	cout << endl;

	int choice;
	do {
		do {
			cout << "?";
		} while ((choice = inputAnInteger(1, 4)) == -1);
	} while (!num[choice]);
	timeCode = choice;
}