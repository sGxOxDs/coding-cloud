#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	extern void computeCurrentDate(Date & currentDate);

	Date currentDate;
	computeCurrentDate(currentDate);
	loadAvailSeats();
	int seats[5] = { 0,20,20,20,20 };
	if (availSeats.size() == 0) {
		for (int i = 1; i <= 30; i++) {
			AvailSeats newAvailSeats(currentDate + i, seats);
			availSeats.push_back(newAvailSeats);
		}
	}
	else if (availSeats[0].getDate() < currentDate || availSeats[0].getDate() == currentDate) {
			int differenceDay;
			differenceDay = currentDate - availSeats[0].getDate() + 1;
			for (int i = 1; i <= differenceDay; i++) {
				AvailSeats newAvailSeats(currentDate + 30 + i, seats);
				availSeats.push_back(newAvailSeats);
				availSeats.erase(availSeats.begin() - i);
			}
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	it._Ptr->setNumAvailSeats(timeCode, it._Ptr->getNumAvailSeats(timeCode) - requiredSeats);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	for (int i = 1; i <= 4; i++) {
		if (it._Ptr->getNumAvailSeats(i) >= requiredSeats)
			return true;
	}
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	if (it._Ptr->getNumAvailSeats(timeCode) >= requiredSeats)
		return true;
	else
		return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator it = availSeats.begin();
	for (; it != availSeats.end(); it++) {
		if (it._Ptr->getDate() == date)
			return it;
	}
}

void AvailSeatsDatabase::loadAvailSeats()
{
	AvailSeats zero;
	fstream inFile("Reservations.dat", ios::in | ios::out | ios::binary);
	inFile.seekg(0, ios::end);
	int numLine = inFile.tellg() / sizeof(AvailSeats);
	inFile.seekg(0, ios::beg);
	availSeats.resize(numLine);
	for (int i = 0; i < numLine; i++) {
		inFile.read(reinterpret_cast<char*>(&availSeats[i]), sizeof(availSeats[i]));
	}
	for (int i = 0; i < numLine; i++) {
		inFile.write(reinterpret_cast<char*>(&zero), sizeof(AvailSeats));
	}
}

void AvailSeatsDatabase::storeAvailSeats()
{
	fstream file("AvailSeats.dat", ios::in | ios::out | ios::binary);

	for (int i = 0; i < availSeats.size(); i++)
		file.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(availSeats[i]));
}