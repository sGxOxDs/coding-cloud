#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
	{
		if (reservations[i].getPhoneNumber() == phoneNumber)
			return true;
	}
	
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	cout << endl;
	for (int i = 0,j=1; i < reservations.size(); i++)
	{
		if (reservations[i].getPhoneNumber() == phoneNumber)
		{
			cout << " " << j << " ." << reservations[i].getPartySize()
				<< " guests  " << reservations[i].getDate().getYear()
				<< "/0" << reservations[i].getDate().getMonth() << "/" << reservations[i].getDate().getDay() << "  ";
			if (reservations[i].getTime() == 1)
				cout << "11:30";
			else if (reservations[i].getTime() == 2)
				cout << "13:30";
			else if (reservations[i].getTime() == 3)
				cout << "17:45";
			else if (reservations[i].getTime() == 4)
				cout << "19:45";
			cout << endl;
			j++;
		}
	}

}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream inFile("Reservations.dat", ios::in | ios::binary);
	if (!inFile)
	{
		ofstream outFile("Reservations.dat", ios::out | ios::binary);
		outFile.close();
	}
	inFile.seekg(0, ios::end);
	int end = inFile.tellg();

	int times = end / sizeof(Reservation);
	Reservation a;

	inFile.seekg(0, ios::beg);
	for (int i = 0; i < times; i++)
	{
		inFile.read(reinterpret_cast<char*>(&a),sizeof(a));
		reservations.push_back(a);
	}
	inFile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outFile("Reservations.dat", ios::out | ios::binary);

	for (int i = 0; i < reservations.size(); i++)
	{
		outFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(reservations[i]));
	}

	outFile.close();
}