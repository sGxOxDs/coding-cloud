#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{

}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it1 = searchAvailSeats(date);
	it1->setNumAvailSeats(timeCode, requiredSeats);

	availSeats.push_back(*it1);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector< AvailSeats >::iterator it1 = searchAvailSeats(date);
	int total = 0;

	for (int i = 1; i <= 4; i++)
	{
		total += it1->getNumAvailSeats(i);
	}
	if ((80 - total) >= requiredSeats)
		return true;
	else
		return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it1 = searchAvailSeats(date);
	
	if ((20 - it1->getNumAvailSeats(timeCode)) >= requiredSeats)
	  return true;
	else 
	  return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator it1 = availSeats.begin();

	for (;it1< availSeats.end();)
	{
		if (it1->getDate() == date)
			return it1;
		else
			++it1;
	}

}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream inFile("AvailSeats.dat", ios::in | ios::binary);
	if (!inFile)
	{
		ofstream outFile("AvailSeats.dat", ios::out | ios::binary);
		outFile.close();
	}
	inFile.seekg(0, ios::end);
	int end = inFile.tellg();

	int times = end / sizeof(AvailSeats);
	AvailSeats a;

	inFile.seekg(0, ios::beg);
	for (int i = 0; i < times; i++)
	{
		inFile.read(reinterpret_cast<char*>(&a), sizeof(a));
		availSeats.push_back(a);
	}
	inFile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outFile("AvailSeats.dat", ios::out | ios::binary);

	for(int i = 0; i < availSeats.size(); i++)
	 outFile.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(availSeats[i]));

	outFile.close();

}