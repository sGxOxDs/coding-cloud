#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	loadAvailSeats();
	Date current;
	computeCurrentDate(current);
	// clear old information
	while (
			availSeats.size() > 0 && (
				availSeats.begin()->getDate() < current ||
				availSeats.begin()->getDate() == current
			)
		  ) {
		availSeats.erase(availSeats.begin());
	}

	int availSeatsNum[5] = { 0,20,20,20,20 };

	// first record
	if (availSeats.size() == 0) {
		availSeats.push_back(AvailSeats((current + 1), availSeatsNum));
	}

	// fill to 30 days
	while (availSeats.size() <= 30) {
		availSeats.push_back(AvailSeats((availSeats.end() - 1)->getDate() + 1, availSeatsNum));
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator itr = searchAvailSeats(date);
	itr->setNumAvailSeats(timeCode, itr->getNumAvailSeats(timeCode) - requiredSeats);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector<AvailSeats>::iterator itr = searchAvailSeats(date);
	return itr->getNumAvailSeats(1) >= requiredSeats ||
		   itr->getNumAvailSeats(2) >= requiredSeats ||
		   itr->getNumAvailSeats(3) >= requiredSeats ||
		   itr->getNumAvailSeats(4) >= requiredSeats;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator itr = searchAvailSeats(date);
	return itr->getNumAvailSeats(timeCode) >= requiredSeats;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator itr = availSeats.begin();
	for (; itr != availSeats.end(); itr++) {
		if (itr->getDate() == date) {
			return itr;
		}
	}
	return itr;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream inFile("AvailSeats.dat", ios::binary | ios::in);
	if (!inFile) {
		return;
	}
	AvailSeats tmp;
	while (true) {
		inFile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
		if (inFile.eof()) {
			break;
		}
		availSeats.push_back(tmp);
	}
	inFile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outFile("AvailSeats.dat", ios::binary | ios::out);
	if (!outFile) {
		cout << "File could not be open!" << endl;
		exit(1);
	}
	for (AvailSeats& i : availSeats) {
		outFile.write(reinterpret_cast<char*>(&i), sizeof(i));
	}
	outFile.close();
}