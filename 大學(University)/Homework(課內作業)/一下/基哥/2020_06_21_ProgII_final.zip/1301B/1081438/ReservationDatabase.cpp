#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (Reservation& i : reservations) {
		if (phoneNumber == i.getPhoneNumber()) {
			return true;
		}
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	cout << endl;
	int cnt = 1;
	Date current;
	computeCurrentDate(current);
	for (Reservation& i : reservations) {
		if (phoneNumber == i.getPhoneNumber() && (current < i.getDate() || current == i.getDate()) ){
			cout << setw(2) << setfill(' ') << cnt++ << ". ";
			i.displayReservationInfo();
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream inFile("Reservations.dat", ios::binary | ios::in);

	if (!inFile) {
		return;
	}
	Reservation tmp;
	while (true) {
		inFile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
		if (inFile.eof()) {
			break;
		}
		reservations.push_back(tmp);
	}
	inFile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outFile("Reservations.dat", ios::binary | ios::out);
	if (!outFile) {
		cout << "couldn't open file!" << endl;
		exit(1);
	}
	for (Reservation& i : reservations) {
		outFile.write(reinterpret_cast<char*>(&i), sizeof(i));
	}
	outFile.close();
}