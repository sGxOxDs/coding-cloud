#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	loadAvailSeats();

	if (availSeats.empty()) {
		//cout << "No data." << endl;
		AvailSeats newthirty;
		Date now;
		computeCurrentDate(now);
		Date temp = now + 1;
		//cout << now.getYear() << now.getMonth() << now.getDay() << endl;
		for (int i = 0; i < 30; i++) {
			newthirty.setDate(temp);
			for (int j = 0; j < 5; j++)
				newthirty.setNumAvailSeats(j,20);
			availSeats.push_back(newthirty);
			//cout << availSeats[i].getDate().getYear()<<"/"<<availSeats[i].getDate().getMonth()<<"/"<<availSeats[i].getDate().getDay()<<endl;
			//cout << availSeats[i].getNumAvailSeats(1) << " " << availSeats[i].getNumAvailSeats(2) << " " << availSeats[i].getNumAvailSeats(3) << " " << availSeats[i].getNumAvailSeats(4) << endl;;
			temp = temp + 1;
		}

	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);

	int availableseats = it->getNumAvailSeats(timeCode);
	if (availableseats >= requiredSeats) {
		it->setNumAvailSeats(timeCode,availableseats-requiredSeats);
	}

}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats ) //�Ψ���ܥ���30�Ѫ�
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);

	int availseats1 = it->getNumAvailSeats(1);
	int availseats2 = it->getNumAvailSeats(2);
	int availseats3 = it->getNumAvailSeats(3);
	int availseats4 = it->getNumAvailSeats(4);

	if (requiredSeats > availseats1 && requiredSeats > availseats2 && requiredSeats > availseats3 && requiredSeats > availseats4)
		return false;

	else
		return true;

	
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats ) //�Ψ���ܮɬq��
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);

	int availableseats = it->getNumAvailSeats(timeCode);

	if (availableseats >= requiredSeats)
		return true;

	else
		return false;

}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector<AvailSeats>::iterator it = availSeats.begin();
	for (; it != availSeats.end(); it++) {
		if (it->getDate() == date)
			return it;
	}
	return it;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream inFile("AvailSeats.dat", ios::in | ios::binary);

	if (!inFile.is_open())
		cout << "\nFile not be opened!\n";
	else {
		inFile.clear();
		AvailSeats read;
		while (inFile.peek() != EOF) {
			inFile.read(reinterpret_cast<char*>(&read),sizeof(AvailSeats));
			availSeats.push_back(read);
		}
		inFile.close();
	}

}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outFile("AvailSeats.dat", ios::out | ios::binary);

	if (!outFile.is_open())
		cout << "\nFile not be opened!\n";
	else {
		for (int i = 0; i < availSeats.size(); i++) {
			outFile.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(AvailSeats));
		}
		outFile.close();
	}

}