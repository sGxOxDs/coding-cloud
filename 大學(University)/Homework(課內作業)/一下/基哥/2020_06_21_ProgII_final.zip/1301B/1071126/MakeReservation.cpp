// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );

   

  // ReservationDatabase storereservation;
  // AvailSeatsDatabase storeseat;

  
}

void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{
	cout << "\nChoose a date\n";

	//AvailSeatsDatabase data;
	Date temp=currentDate;
	vector<Date> store;
	store.push_back(Date());
	vector<int> storeUnavail;

	for (int i = 1; i <= 30;) {
		for (int j = 0; j < 4; j++) {
			if (i == 31)
				break;
			temp = temp+ 1;
			if (availSeatsDatabase.availableTimes(temp, partySize)) {
				store.push_back(temp);
				cout << setw(2) << i << ". " << temp.getYear() << "/";
				if (temp.getMonth() < 10) {
					cout << "0" << temp.getMonth() << "/";
				}
				else {
					cout << temp.getMonth() << "/";
				}
				if (temp.getDay() < 10) {
					cout << "0" << temp.getDay() << "   ";
				}
				else {
					cout << temp.getDay() << "   ";
				}
			}
			else {
				storeUnavail.push_back(i);
				j--;
			}
			i++;
		}
		cout << endl;
	}

	int choice;
	do cout << "\n?";
	while ((choice = inputAnInteger(1, 30)) == -1);

	for (int i = 0; i < storeUnavail.size(); i++) {
		while (choice == storeUnavail[i] || choice < 1 || choice>30) {
			cout << "?";
			cin >> choice;
		}
	}
	date = store[choice];
	//cout << date.getYear() << " " << date.getMonth() << " " << date.getDay() << endl;
	

}

void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{

	string timelist[5] = { " ","11:30","13:30","17:45","19:45" };
	//AvailSeatsDatabase data;
	vector<int> storeUnavail;


	cout << "\nChoose a time: \n";
	for (int i = 1; i <= 4; i++) {
		if (availSeatsDatabase.availableTimes(date, i, partySize))
			cout << i << ". " << timelist[i] << endl;
		else
			storeUnavail.push_back(i);
	}
	
	do cout << "?";
	while ((timeCode = inputAnInteger(1, 4)) == -1 );

	for (int i = 0; i < storeUnavail.size(); i++) {
		while (timeCode==storeUnavail[i] || timeCode<1 || timeCode>4) {
			cout << "?";
			cin >> timeCode;
		}
	}




}