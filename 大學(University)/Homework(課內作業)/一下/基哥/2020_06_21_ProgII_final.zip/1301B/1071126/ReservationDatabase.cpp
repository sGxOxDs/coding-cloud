#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++) {
		if (phoneNumber == reservations[i].getPhoneNumber())
			return true;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	string timelist[5] = { " ","11:30","13:30","17:45","19:45" };
	vector<Reservation>store;
	for (int i = 0; i < reservations.size(); i++) {
		if (phoneNumber == reservations[i].getPhoneNumber())
			store.push_back(reservations[i]);
	}

	for (int j = 0; j < store.size(); j++) {
		cout << j + 1 << ". " << store[j].getPartySize();
		if (store[j].getPartySize() == 1)
			cout << " guest   ";
		else {
			cout << " guests  ";
		}
		cout << store[j].getDate().getYear() << "/";
		if (store[j].getDate().getMonth() < 10) {
			cout << "0" << store[j].getDate().getMonth() << "/";
		}
		else {
			cout << store[j].getDate().getMonth() << "/";
		}
		if (store[j].getDate().getDay() < 10) {
			cout << "0" << store[j].getDate().getDay() << "  ";
		}
		else {
			cout << store[j].getDate().getDay() << "  ";
		}
		cout << timelist[store[j].getTime()]<<endl;
	}


}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream inFile("Reservations.dat", ios::in | ios::binary);

	if (!inFile.is_open())
		cout << "File not be opened\n";
	else {
		inFile.clear();
		Reservation read;
		while (inFile.peek() != EOF) {
			inFile.read(reinterpret_cast<char*>(&read), sizeof(Reservation));
			reservations.push_back(read);
		}
		inFile.close();
	}
}

void ReservationDatabase::storeReservations()
{
	ofstream outFile("Reservations.dat", ios::out | ios::binary );

	if (!outFile.is_open())
		cout << "\nFile not be opened!\n";
	else {
		for (int i = 0; i < reservations.size(); i++) {
			outFile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(Reservation));
		}
		outFile.close();
	}


}