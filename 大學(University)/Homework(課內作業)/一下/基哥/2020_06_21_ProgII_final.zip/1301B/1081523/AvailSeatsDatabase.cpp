#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	Date date;
	computeCurrentDate(date);
	AvailSeats buf;
	buf.setDate(date);
	for(int i = 1;i<=4;i++)
		buf.setNumAvailSeats(1, 20);
	loadAvailSeats();
	availSeats.push_back(buf);
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats(Date date, int timeCode, int requiredSeats)
{
	vector< AvailSeats >::iterator buf = searchAvailSeats(date);
	int seat = buf->getNumAvailSeats(timeCode);//��y���
	buf->setNumAvailSeats(timeCode, seat - requiredSeats);//�s�y���
}

bool AvailSeatsDatabase::availableTimes(Date date, int requiredSeats)
{
	for (int i = 1; i <= 4; i++)
		if (availSeats[i - 1].getNumAvailSeats(i) > requiredSeats)//���ѬY�ɬq����l
			return true;

	return false;//����������l
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator buf = searchAvailSeats(date);
	if (buf->getNumAvailSeats(timeCode) < requiredSeats)//��l����
		return false;
	else
		return true;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	loadAvailSeats();
	vector< AvailSeats >::iterator it = availSeats.begin();
	for (; it != availSeats.end(); ++it)
		if (it->getDate() == date)
			return it;
	return  availSeats.begin();
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream file("AvailSeats.dat", ios::in | ios::binary);
	AvailSeats buf;
	while (!file.eof())
	{
		file.read(reinterpret_cast<char*>(&buf), sizeof(AvailSeats));
		if (file.eof())
			break;
		availSeats.push_back(buf);
	}
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outFile("AvailSeats.dat", ios::app | ios::binary);
	for (int i = 0; i < availSeats.size(); i++)
		outFile.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(AvailSeats));
}