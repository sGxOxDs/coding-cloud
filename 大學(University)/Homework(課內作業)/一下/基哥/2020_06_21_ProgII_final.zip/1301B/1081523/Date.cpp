// Date.cpp
// AvailSeats-function definitions for class Date.
#include <iostream>
#include <iomanip>
#include <ctime>
using namespace std;
#include "Date.h"

extern bool leapYear(int year);

Date::Date()
{
	year = 2000;
	month = 0;
	day = 0;
}

// const return avoids: ( a1 = a2 ) = a3
const Date& Date::operator=(const Date& right)
{
	if (&right != this) // avoid self-assignment
	{
		month = right.month;
		day = right.day;
		year = right.year;
	} // end if

	return *this; // enables x = y = z, for example
} // end function operator=

void Date::setDate(int y, int m, int d)
{
	year = (y >= 2000) ? y : 2000; // sets year
	month = (m >= 1 && m <= 12) ? m : 1; // sets month

	if (month == 2 && leapYear(year))
		day = (d >= 1 && d <= 29) ? d : 1;
	else
		day = (d >= 1 && d <= days[month]) ? d : 1;
}

void Date::setYear(int y)
{
	year = (y >= 2000) ? y : 2000; // sets year
} // end function setYear

void Date::setMonth(int m)
{
	month = (m >= 1 && m <= 12) ? m : 1; // sets month
} // end function setMonth

void Date::setDay(int d)
{
	if (month == 2 && leapYear(year))
		day = (d >= 1 && d <= 29) ? d : 1;
	else
		day = (d >= 1 && d <= days[month]) ? d : 1;
} // end function setDay

int Date::getYear() const
{
	return year;
}

int Date::getMonth() const
{
	return month;
}

int Date::getDay() const
{
	return day;
}

bool Date::operator==(const Date& date2)
{
	return (year == date2.year && month == date2.month && day == date2.day);
}

bool Date::operator<(const Date& date2)
{
	if (year < date2.year)
		return true;
	if (year > date2.year)
		return false;

	if (month < date2.month)
		return true;
	if (month > date2.month)
		return false;

	if (day < date2.day)
		return true;

	return false;
}

// if the year is a leap year, return true; otherwise, return false
bool Date::leapYear(int testYear) const
{
	if (testYear % 400 == 0 ||
		(testYear % 100 != 0 && testYear % 4 == 0))
		return true; // a leap year
	else
		return false; // not a leap year
} // end function leapYear

// return *this - date2 provided that *this > date2
int Date::operator-(const Date& date2)
{
	Date buf(*this), buf2(date2);

	for (unsigned int i = 1; i <= buf.month; i++)
		buf.day += buf.days[i];//�Ѽ�
	if (leapYear(buf.year) && buf.month > 2)
		buf.day++;//�G��29��

	for (unsigned int i = 1; i <= buf2.month; i++)
		buf2.day += buf2.days[i];//�Ѽ�
	if (buf2.leapYear(date2.year) && buf2.month > 2)
		buf2.day++;//�G��29��

	int moreYear = buf.year - buf2.year;//�h�X�~
	for (int i = moreYear; i > 0; i -= 4)
		buf.day++;//�ۮt�X���|�~

	int num = moreYear * 365 + buf.day - buf2.day;

	return num;
}

Date Date::operator+(int numDays)
{
	Date buf(*this);
	buf.day += numDays;
	while (buf.day > buf.days[month])//�ѼƤj��Ӥ�
	{
		if (buf.month == 2 && leapYear(buf.year))//�G��B�|�~
		{
			if (buf.day > 29)
				buf.day -= 29;
		}
		else
			buf.day -= buf.days[month];
		buf.month++;
		if (buf.month > 12)
		{
			buf.year++;
			buf.month -= 12;
		}
	}
	return buf;
}