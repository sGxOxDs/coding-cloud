// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );
}

void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{
	Date buf(currentDate);
	buf.operator+(1);//�q�j�Ѷ}�l�q

	cout << "\nChoose a date\n";

	for (int i = 1; i <= 30; i++)
	{
		if (availSeatsDatabase.availableTimes(buf, partySize)) 
		{
			cout << i << ". " << buf.getYear() << "/" << buf.getMonth() << "/"
				<< buf.getDay() << "   ";

			buf = buf+1;
			if (i % 4 == 0)
				cout << endl;//�|����ƴ��@����
		}
		else
			continue;
	}
	cout << endl;
	int chooseDay = -1;

	do cout << "?";
	while ((chooseDay = inputAnInteger(1, 30)) == -1);//����l

	buf = currentDate;
	
	date = buf.operator+(chooseDay);
}

void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{
	cout << "\nChoose a time:\n";
	int noSeat[5] = {};
	for (int i = 1; i <= 4; i++)
	{
		if (availSeatsDatabase.availableTimes(date, partySize, partySize))
		{
			cout << i << ". ";
			if (i == 1)
				cout << "11:30\n";
			if (i == 2)
				cout << "13:30\n";
			if (i == 3)
				cout << "17:45\n";
			if (i == 4)
				cout << "19:45\n";
		}
		else
		{
			noSeat[i] = 1;
			continue;
		}
	}
	do cout << "?";
	while ((timeCode = inputAnInteger(1, 4)) == -1 && noSeat[timeCode]);
}