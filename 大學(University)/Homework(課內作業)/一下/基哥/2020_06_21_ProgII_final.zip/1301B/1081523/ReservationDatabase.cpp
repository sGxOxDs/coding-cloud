#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
		if (reservations[i].getPhoneNumber() == phoneNumber)
			return true;
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	int k = 0;
	for (int i = 0; i < reservations.size(); i++)
		if (reservations[i].getPhoneNumber() == phoneNumber)
		{
			k = i;
			break;
		}
	reservations[k].displayReservationInfo();
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	Reservation buf;
	ifstream inFile("Reservations.dat", ios::in | ios::binary);
	while (!inFile.eof())
	{
		inFile.read(reinterpret_cast<char*>(&buf), sizeof(Reservation));
		if (inFile.eof())
			break;
		reservations.push_back(buf);
	}
}

void ReservationDatabase::storeReservations()
{
	ofstream outFile("Reservations.dat", ios::app | ios::binary);
	for (int i = 0; i < reservations.size(); i++)
		outFile.write(reinterpret_cast<char*>(&reservations[i]), sizeof(Reservation));
}