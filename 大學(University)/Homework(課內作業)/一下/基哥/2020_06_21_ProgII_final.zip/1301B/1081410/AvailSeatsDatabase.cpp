#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	Date a;
	computeCurrentDate(a);
	AvailSeats b;
	for (int i = 0; i < 30; i++)
	{
		a=a+1;
		b.setDate(a);
		for (int i = 1; i < 5; i++)
		{
			b.setNumAvailSeats(i, 20);
		}
		availSeats.push_back(b);
	}
	loadAvailSeats();
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = availSeats.begin();
	for (; it != availSeats.end(); it++)
	{
		if (it->getDate() == date)
		{
			it->setNumAvailSeats(timeCode, it->getNumAvailSeats(timeCode) - requiredSeats);
		}
	}
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	//vector<AvailSeats>::iterator it = availSeats.begin();
	//for (;it!=availSeats.end();it++)
	//{
	//	if (it->getDate() == date)
	//	{
	//		for (int i = 0; i < 5; i++)
	//		{
	//			if (it->getNumAvailSeats(i) >= requiredSeats)
	//				return true;
	//		}
	//		return false;
	//	}
	//	
	//}
	//vector<AvailSeats>::iterator it = searchAvailSeats(date);
	//for (int i = 1; i < 5; i++)
	//{
	//	if (it->getNumAvailSeats(i) >= requiredSeats)
	//		return true;
	//}
	//return false;
	for (int i = 0; i < availSeats.size(); i++)
	{
		if (availSeats[i].getDate() == date)
		{
			for (int j = 1; j < 5; j++)
				if (availSeats[i].getNumAvailSeats(j) >= requiredSeats)
					return true;
		}
	}
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	for (int i = 0; i < availSeats.size(); i++)
	{
		if (availSeats[i].getDate() == date)
		{
			if (availSeats[i].getNumAvailSeats(timeCode) >= requiredSeats)
				return true;
		}
	}
	return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector<AvailSeats>::iterator it = availSeats.begin();
	for (; it != availSeats.end(); it++)
	{
		if (it->getDate() == date)
		{
			return it;
		}
	}
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream file;
	file.open("AvailSeats.dat", ios::binary);
	AvailSeats a;
	int count = 0;
	if (!file.is_open())
		cout << "can't open" << endl;
	while (!file.eof())
	{
		file.read(reinterpret_cast<char*>(&a), sizeof(a));
		if (a.getDate().getDay() != 0)//�P�_�O���O�Ū�
		{
			for (int i = 0; i < 30; i++)
			{
				//�P�_���e������S���b����30��
				if (a.getDate().getYear() == availSeats[i].getDate().getYear())
				{
					if (a.getDate().getMonth() == availSeats[i].getDate().getMonth())
					{
						if (a.getDate().getDay() == availSeats[i].getDate().getDay())
						{
							//���N�쥻���Ŧ�m
							for (int j = 1; j < 5; j++)
							{
								availSeats[i].setNumAvailSeats(j, a.getNumAvailSeats(j));
							}
						}
					}
				}			
			}
		}
	}
	
	file.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream file;
	file.open("AvailSeats.dat", ios::binary|ios::_Nocreate);
	for (int i = 0; i < availSeats.size(); i++)
	{
		file.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(availSeats[i]));
	}
	file.close();
}