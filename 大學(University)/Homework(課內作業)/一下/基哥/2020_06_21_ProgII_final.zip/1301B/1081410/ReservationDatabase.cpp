#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	vector<Reservation>::iterator it = reservations.begin();
	for (; it != reservations.end(); it++)
	{
		if (it->getPhoneNumber() == phoneNumber)
			return true;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	vector<Reservation>::iterator it = reservations.begin();
	for (; it != reservations.end(); it++)
	{
		if (it->getPhoneNumber() == phoneNumber)
		{
			cout << it->getPartySize() << " guests   " << it->getDate().getYear() << "/";
			cout << it->getDate().getMonth() << "/" << it->getDate().getDay() << "   ";
			if (it->getTime() == 1)
				cout << "11:30" << endl;
			else if (it->getTime() == 2)
				cout << "13:30" << endl;
			else if (it->getTime() == 3)
				cout << "17:45" << endl;
			else if (it->getTime() == 4)
				cout << "19:45" << endl;
		}
	}
	
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream file;
	file.open("Reservations.dat", ios::binary);
	Reservation a;
	while (!file.eof())
	{
		file.read(reinterpret_cast<char*>(&a), sizeof(a));
		reservations.push_back(a);
	}
	file.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream file;
	file.open("Reservations.dat", ios::binary);
	for (int i = 0; i < reservations.size(); i++)
	{
		file.write(reinterpret_cast<char*>(&reservations[i]), sizeof(reservations[i]));
	}
	file.close();
}