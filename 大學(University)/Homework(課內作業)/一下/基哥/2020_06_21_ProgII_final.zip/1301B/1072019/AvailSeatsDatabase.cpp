#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	//
	loadAvailSeats();

	Date currentDate;
	computeCurrentDate(currentDate);
	vector<AvailSeats>::iterator it = availSeats.begin();
	for (int i = 0; i < availSeats.size(); i++,it++) {
		if (availSeats[i].getDate().getMonth() < currentDate.getMonth()) {
			availSeats.erase(it);
		}
		else if (availSeats[i].getDate().getMonth() == currentDate.getMonth()) {
			if (availSeats[i].getDate().getDay() <= currentDate.getDay()) {
				availSeats.erase(it);
			}
		}
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	cout << endl;
	if (it._Ptr == nullptr) {
		AvailSeats temp;
		temp.setDate(date);
		for (int i = 1; i <= 4; i++) {
			if (i == timeCode) 
				temp.setNumAvailSeats(timeCode, 20 - requiredSeats);
			else 
				temp.setNumAvailSeats(i, 20);
		}
		availSeats.push_back(temp);
	}
	else {
		it->setNumAvailSeats(timeCode, it->getNumAvailSeats(timeCode) - requiredSeats);
	}
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	//
	for (int i = 0; i < availSeats.size(); i++) {
		if (availSeats[i].getDate() == date) {
			for (int j = 1; j <= 4; j++) {
				if (availableTimes(date, j, requiredSeats) == true)
					return true;
			}
			return false;
		}
	}
	return true;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	for (int i = 0; i < availSeats.size(); i++) {
		if (availSeats[i].getDate() == date) {
			if (availSeats[i].getNumAvailSeats(timeCode) < requiredSeats)
				return false;
			else
				return true;
		}
	}
	return true;

}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector<AvailSeats>::iterator it = availSeats.begin();
	for (; it < availSeats.end(); it++) {
		if (it->getDate() == date) {
			return it;
		}
	};
	return availSeats.begin();
}

void AvailSeatsDatabase::loadAvailSeats()
{
	fstream file;
	file.open("AvailSeats.dat", ios::in);
	AvailSeats temp;
	while (file.read(reinterpret_cast<char*>(&temp), sizeof(temp))) {
		availSeats.push_back(temp);
	}
	file.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	fstream file;
	file.open("AvailSeats.dat", ios::out);
	for (int i = 0; i < availSeats.size(); i++)
		file.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(availSeats[i]));
	file.close();
}