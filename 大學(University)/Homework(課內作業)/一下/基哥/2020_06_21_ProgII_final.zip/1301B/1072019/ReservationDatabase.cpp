#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	//
	for (int i = 0; i < reservations.size(); i++) {
		if (reservations[i].getPhoneNumber() == phoneNumber) {
			return true;
		}
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	cout << endl;
	int num = 0;
	string time[5] = { "","11:30","13:30","17:45","19:45" };
	for (int i = 0; i < reservations.size(); i++) {
		if (reservations[i].getPhoneNumber() == phoneNumber) {
			num++;
			cout << num << ": ";
			cout << reservations[i].getPartySize() << " guests  "
				<< reservations[i].getDate().getYear() << "/"
				<< reservations[i].getDate().getMonth() << "/"
				<< reservations[i].getDate().getDay() << " "
				<< time[reservations[i].getTime()] << endl;
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	fstream file;
	file.open("Reservations.dat", ios::in);
	Reservation temp;
	while (file.read(reinterpret_cast<char*>(&temp), sizeof(temp))) {
		reservations.push_back(temp);
	}
	file.close();
}

void ReservationDatabase::storeReservations()
{
	fstream file;
	file.open("Reservations.dat", ios::out);
	for (int i = 0; i < reservations.size(); i++)
		file.write(reinterpret_cast<char*>(&reservations[i]), sizeof(reservations[i]));
}