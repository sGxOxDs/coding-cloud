// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   //�H��
   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );
   //�ثe���
   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );
}

void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{
	cout << "\nChoose a date" << endl;
	//cin.ignore();
	int line = 0;
	bool Seat[31];

	for (int i = 0; i < 31; i++)
		Seat[i] = false;
	//�L�X���
	for (int i = 1; i < 31; i++) {
		Date temp = currentDate + i;
		if (availSeatsDatabase.availableTimes(temp, partySize) == true) {
			line++;
			cout << setw(3) << i << ". " << temp.getYear() << "/" << temp.getMonth() << "/";
			if (temp.getDay() < 10) {
				cout << "0";
			}
			cout << temp.getDay();
		}
		else
			Seat[i] = true;

		if (line % 3 == 0) 
			cout << endl;
		else 
			cout << setw(5);
	}
	if (line % 3!=0) {
		cout << endl;
	}
	int DateNum;
	while (true) {
		cout << "? ";
		cin >> DateNum;
		if (Seat[DateNum] == false && DateNum > 0 && DateNum < 31)
			break;
	}
	date = currentDate + DateNum;
}

void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{
	cout << "\nChoose a time:" << endl;
	bool seat[5];
	string time[5] = { "","11:30","13:30","17:45","19:45" };
	for (int i = 0; i < 5; i++)
		seat[i] = false;
	//�L�X�ɬq
	for (int i = 1; i <= 4; i++) {
		if (availSeatsDatabase.availableTimes(date, i, partySize) == true) {
			cout << i << ". " << time[i] << endl;
			seat[i] = true;
		}
	}
	while (true) {
		cout << "? ";
		cin >> timeCode;
		if (timeCode <= 4 && timeCode >= 1 && seat[timeCode] == true)
			break;
	}
}