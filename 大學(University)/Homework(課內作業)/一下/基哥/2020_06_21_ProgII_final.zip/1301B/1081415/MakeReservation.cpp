// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );
}

void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{
	date = currentDate;

	Date tmp = currentDate + 1;
	std::cout << "\nChoose a date" << std::endl;
	for (int i = 1; i <= 30; i++) {  // print
		if (availSeatsDatabase.availableTimes(tmp, partySize)) {
			if (i % 4 == 1 && i != 1) {
				std::cout << std::endl;
			}
			std::cout << std::setw(4) << i << ". ";

			std::cout << tmp.getYear() << "/" << tmp.getMonth() << "/";
			if (tmp.getDay() < 10)  std::cout << "0";
			std::cout << tmp.getDay() << "   ";
		}
		else {
			i--;
		}

		tmp = (tmp + 1);
	}
	std::cout << std::endl;

	int dateNum;  // input
	do cout << "? ";
	while ((dateNum = inputAnInteger(1, 30)) == -1);

	date = tmp = currentDate + 1;
	for (int i = 1; i < dateNum; i++) {
		if (!availSeatsDatabase.availableTimes(tmp, partySize)) {
			i--;
		}

		date = (date + 1);
	}

	//std::cout << "-----------------------------> " << date.getDay() << std::endl;
}

void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{
	vector<int> tmp;

	std::cout << "\nChoose a time:" << std::endl;
	if (availSeatsDatabase.availableTimes(date, 1, partySize))
		std::cout << "1. 11:30" << std::endl;
	else
		tmp.push_back(1);
	if (availSeatsDatabase.availableTimes(date, 2, partySize))
		std::cout << "2. 13:30" << std::endl;
	else
		tmp.push_back(2);
	if (availSeatsDatabase.availableTimes(date, 3, partySize))
		std::cout << "3. 17:45" << std::endl;
	else
		tmp.push_back(3);
	if (availSeatsDatabase.availableTimes(date, 4, partySize))
		std::cout << "4. 19:45" << std::endl;
	else
		tmp.push_back(4);

	vector<int>::iterator it;
	bool wrong;
	do {
		cout << "? ";

		wrong = false;
		if ((timeCode = inputAnInteger(1, 4)) == -1) {
			wrong = true;
		}
		else {
			it = tmp.begin();
			for (; it != tmp.end(); it++) {
				if (timeCode == *it) {
					wrong = true;
				}
			}
		}
	} while (wrong);
}
