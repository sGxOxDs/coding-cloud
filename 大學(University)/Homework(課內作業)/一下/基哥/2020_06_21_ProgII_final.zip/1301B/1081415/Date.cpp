// Date.cpp
// AvailSeats-function definitions for class Date.
#include <iostream>
#include <iomanip>
#include <ctime>
using namespace std;
#include "Date.h"

extern bool leapYear( int year );

Date::Date()
{
   year = 2000;
   month = 0;
   day = 0;
}

// const return avoids: ( a1 = a2 ) = a3
const Date &Date::operator=( const Date &right )
{
   if( &right != this ) // avoid self-assignment
   {
      month = right.month;
      day = right.day;
      year = right.year;
   } // end if

   return *this; // enables x = y = z, for example
} // end function operator=

void Date::setDate( int y, int m, int d )
{
   year = ( y >= 2000 ) ? y : 2000; // sets year
   month = ( m >= 1 && m <= 12 ) ? m : 1; // sets month

   if( month == 2 && leapYear( year ) )
      day = ( d >= 1 && d <= 29 ) ? d : 1;
   else
      day = ( d >= 1 && d <= days[ month ] ) ? d : 1;
}

void Date::setYear( int y )
{
   year = ( y >= 2000 ) ? y : 2000; // sets year
} // end function setYear

void Date::setMonth( int m )
{
   month = ( m >= 1 && m <= 12 ) ? m : 1; // sets month
} // end function setMonth

void Date::setDay( int d )
{
   if( month == 2 && leapYear( year ) )
      day = ( d >= 1 && d <= 29 ) ? d : 1;
   else
      day = ( d >= 1 && d <= days[ month ] ) ? d : 1;
} // end function setDay

int Date::getYear() const
{
   return year;
}

int Date::getMonth() const
{
   return month;
}

int Date::getDay() const
{
   return day;
}

bool Date::operator==( const Date &date2 )
{
   return ( year == date2.year && month == date2.month && day == date2.day );
}

bool Date::operator<( const Date &date2 )
{
   if( year < date2.year )
      return true;
   if( year > date2.year )
      return false;

   if( month < date2.month )
      return true;
   if( month > date2.month )
      return false;

   if( day < date2.day )
      return true;

   return false;
}

// if the year is a leap year, return true; otherwise, return false
bool Date::leapYear( int testYear ) const
{
   if( testYear % 400 == 0 ||
      ( testYear % 100 != 0 && testYear % 4 == 0 ) )
      return true; // a leap year
   else
      return false; // not a leap year
} // end function leapYear

// return *this - date2 provided that *this > date2
int Date::operator-( const Date &date2 )
{
	int sum = 0, d = 0;

	// �H�U��if, else���e�ܥi�ȦӥB�]���ӽ����F�[�W�{����ڶ]�X�ӥΤ���o��function�ҥH�����O�̾a��ı�Q�X�Ӫ�, ���T�פ��i�H
	if (year >= date2.getYear()) {
		if (month >= date2.getMonth()) {
			if (day >= date2.getDay()) {  // Y: 1>2, M: 1>2, D: 1>2
				d = year - date2.getYear();
				while (d != 0) {
					if (leapYear(date2.getYear()))
						sum += 366;
					else
						sum += 365;
					d--;
				}
				
				d = month - date2.getMonth();
				for (int i = 0; i < d; i++) {
					sum += days[date2.getMonth() + i];
				}
				
				sum += (day - date2.getDay());
			}
			else {  // Y: 1>2, M: 1>2, D: 1<2
				d = year - date2.getYear();
				while (d != 0) {
					if (leapYear(date2.getYear()))
						sum += 366;
					else
						sum += 365;
					d--;
				}

				d = month - date2.getMonth();
				for (int i = 0; i < d - 1; i++) {
					sum += days[date2.getMonth() + i];
				}

				sum += (date2.getDay() - day);
			}
		}
		else { 
			if (day >= date2.getDay()) { // Y: 1>2, M: 1<2, D: 1>2
				while (d != 1) {
					if (leapYear(date2.getYear()))
						sum += 366;
					else
						sum += 365;
					d--;
				}

				d = date2.getMonth() - month;
				for (int i = 0; i < d; i++) {
					sum += days[date2.getMonth() + i];
				}

				sum += (day - date2.getDay());
			}
			else {  // Y: 1>2, M: 1<2, D: 1<2
				while (d != 1) {
					if (leapYear(date2.getYear()))
						sum += 366;
					else
						sum += 365;
					d--;
				}

				d = date2.getMonth() - month;
				for (int i = 0; i < d - 1; i++) {
					sum += days[date2.getMonth() + i];
				}

				sum += (date2.getDay() - day);
			}
		}
	}
	else {
		if (month >= date2.getMonth()) {
			if (day >= date2.getDay()) {  // Y: 1<2, M: 1>2, D: 1>2
				d = date2.getYear() - year;
				while (d != 0) {
					if (leapYear(date2.getYear()))
						sum += 366;
					else
						sum += 365;
					d--;
				}

				d = month - date2.getMonth();
				for (int i = 0; i < d; i++) {
					sum += days[date2.getMonth() + i];
				}

				sum += (day - date2.getDay());
			}
			else {  // Y: 1<2, M: 1>2, D: 1<2
				d = date2.getYear() - year;
				while (d != 1) {
					if (leapYear(date2.getYear()))
						sum += 366;
					else
						sum += 365;
					d--;
				}

				d = month - date2.getMonth();
				for (int i = 0; i < d - 1; i++) {
					sum += days[date2.getMonth() + i];
				}

				sum += (date2.getDay() - day);
			}
		}
		else {
			if (day >= date2.getDay()) {  // Y: 1<2, M: 1<2, D: 1>2
				d = date2.getYear() - year;
				while (d != 0) {
					if (leapYear(date2.getYear()))
						sum += 366;
					else
						sum += 365;
					d--;
				}

				d = date2.getMonth() - month;
				for (int i = 0; i < d - 1; i++) {
					sum += days[date2.getMonth() + i];
				}

				sum += (day - date2.getDay());
			}
			else {  // Y: 1<2, M: 1<2, D: 1<2
				d = date2.getYear() - year;
				while (d != 0) {
					if (leapYear(date2.getYear()))
						sum += 366;
					else
						sum += 365;
					d--;
				}

				d = date2.getMonth() - month;
				for (int i = 0; i < d; i++) {
					sum += days[date2.getMonth() + i];
				}

				sum += (date2.getDay() - day);
			}
		}
	}

	return sum;
}

Date Date::operator+( int numDays )
{
	Date tmp = *this;
	int sumDay = day + numDays;
	tmp.setDay(sumDay);

	while (sumDay > 28) {  // maybe need month + 1
		int buffer = tmp.getDay();
		if (tmp.getMonth() == 2) {
			if (leapYear(tmp.getYear())) {
				if (sumDay > 29) {
					if (tmp.getMonth() + 1 > 12) {  // next year
						tmp.setMonth(1);
						tmp.setYear(tmp.getYear() + 1);
					}
					else {
						tmp.setMonth(tmp.getMonth() + 1);
					}
					sumDay -= 29;
				}
			}
			else {
				if (sumDay > 28) {
					if (tmp.getMonth() + 1 > 12) {  // next year
						tmp.setMonth(1);
						tmp.setYear(tmp.getYear() + 1);
					}
					else {
						tmp.setMonth(tmp.getMonth() + 1);
					}
					sumDay -= 28;
				}
			}
		}
		else if (tmp.getMonth() == 1 || tmp.getMonth() == 3 || tmp.getMonth() == 5 || tmp.getMonth() == 7 || tmp.getMonth() == 8 || tmp.getMonth() == 10 || tmp.getMonth() == 12) {
			if (sumDay > 31) {
				if (tmp.getMonth() + 1 > 12) {  // next year
					tmp.setMonth(1);
					tmp.setYear(tmp.getYear() + 1);
				}
				else {
					tmp.setMonth(tmp.getMonth() + 1);
				}
				sumDay -= 31;
			}
		}
		else {
			if (sumDay > 30) {
				if (tmp.getMonth() + 1 > 12) {  // next year
					tmp.setMonth(1);
					tmp.setYear(tmp.getYear() + 1);
				}
				else {
					tmp.setMonth(tmp.getMonth() + 1);
				}
				sumDay -= 30;
			}
		}

		if (buffer == tmp.getDay()) {
			tmp.setDay(sumDay);
			break;
		}
	}
	return tmp;
}