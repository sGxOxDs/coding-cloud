#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	vector< Reservation >::iterator it = reservations.begin();
	for (; it != reservations.end(); it++) {
		if (it->getPhoneNumber() == phoneNumber) {
			return true;
		}
	}

	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	vector< Reservation >::iterator it = reservations.begin();
	for (int i = 1; it != reservations.end(); it++) {
		if (it->getPhoneNumber() == phoneNumber) {
			std::cout << i << ". ";
			it->displayReservationInfo();
			i++;
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream iFile("Reservations.dat", ios::in);
	if (!iFile) {
		std::cout << "File can not open." << std::endl;
	}

	Reservation tmp;
	while (!iFile.eof()) {
		iFile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
		if (iFile.eof()) {
			break;
		}

		reservations.push_back(tmp);
	}

	iFile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream oFile("Reservations.dat", ios::out | ios::trunc);
	if (!oFile) {
		std::cout << "File can not open." << std::endl;
	}

	Reservation tmp;
	for (int i = 0; i < reservations.size(); i++) {
		tmp = reservations[i];
		oFile.write(reinterpret_cast<const char*>(&tmp), sizeof(tmp));
	}

	oFile.close();
}