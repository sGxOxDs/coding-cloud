#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	loadAvailSeats();

	if (!availSeats.empty()) {
		Date currentDate;
		computeCurrentDate(currentDate);
		vector< AvailSeats >::iterator it = availSeats.begin();
		for (; it != availSeats.end(); it++) {
			if (it->getDate() < currentDate) {
				availSeats.erase(it);
			}
		}
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	it->setNumAvailSeats(timeCode, it->getNumAvailSeats(timeCode) - requiredSeats);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);

	int counter = 0;
	for (int i = 1; i <= 4; i++ ) {
		if (it->getNumAvailSeats(i) < requiredSeats) {
			counter++;
		}
	}

	if (counter == 4) {
		return false;
	}
	else {
		return true;
	}
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);

	if (it->getNumAvailSeats(timeCode) >= requiredSeats) {
		return true;
	}

	return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	if (!availSeats.empty()) {
		vector< AvailSeats >::iterator it = availSeats.begin();
		for (; it != availSeats.end(); it++) {
			if (it->getDate() == date) {
				return it;
			}
		}
	}

	int tmp[5] = { 0, 20, 20, 20, 20 };
	AvailSeats buffer(date, tmp);
	availSeats.push_back(buffer);
	return availSeats.end() - 1;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream iFile("AvailSeats.dat", ios::in);
	if (!iFile) {
		std::cout << "File can not open." << std::endl;
	}

	AvailSeats tmp;
	while (!iFile.eof()) {
		iFile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
		if (iFile.eof()) {
			break;
		}

		availSeats.push_back(tmp);
	}

	iFile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream oFile("AvailSeats.dat", ios::out | ios::trunc);
	if (!oFile) {
		std::cout << "File can not open." << std::endl;
	}

	AvailSeats tmp;
	for (int i = 0; i < availSeats.size(); i++) {
		tmp = availSeats[i];
		oFile.write(reinterpret_cast<const char*>(&tmp), sizeof(tmp));
	}

	oFile.close();
}