#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
		if (reservations[i].getPhoneNumber() == phoneNumber)
			return true;
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	for (int i = 0, j = 0; i < reservations.size(); i++) {
		if (reservations[i].getPhoneNumber() == phoneNumber)
		{
			cout << ++j << ". ";
			reservations[i].displayReservationInfo();
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream infile("Reservations.dat", ios::in | ios::binary);
	if (!infile) {
		cout << "could not opened the file" << endl;
		exit(1);
	}
	Reservation temp;
	infile.read(reinterpret_cast<char*>(&temp), sizeof(Reservation));
	while (!infile.eof()) {
		reservations.push_back(temp);
		infile.read(reinterpret_cast<char*>(&temp), sizeof(Reservation));	
	}
	infile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outfile("Reservations.dat", ios::out | ios::binary);
	if (!outfile) {
		cout << "outfile could not be opened" << endl;
		exit(1);
	}

	outfile.seekp(0, ios::beg);
	for (int i = 0; i < reservations.size(); i++)
		outfile.write(reinterpret_cast<char*>(&reservations[i]), sizeof(Reservation));

	outfile.close();
}