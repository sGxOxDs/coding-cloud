// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );
}

void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{	
	Date temp = currentDate;
	cout << "\nChoose a date" << endl;
	for (int i = 1, p = 1; i <= 30; i++) {
		Date temp;
		currentDate + 1;
		temp = currentDate;
		if (!availSeatsDatabase.availableTimes(temp, partySize))
			continue;
		cout << setw(2) << i << ". ";
		cout << temp.getYear() << "/" << (temp.getMonth() < 10 ? "0" : "")
			<< temp.getMonth() << "/" << (temp.getDay() < 10 ? "0" : "") << temp.getDay() << "  ";
		if (p % 4 == 0)
			cout << endl;
		p++;
	}
	cout << endl;
	int choice;
	Date check;
	do {
		cout << "?";
		cin >> choice;
		Date save = temp;
		check = temp + choice;
		temp = save;
		cin.ignore();
	} while (!availSeatsDatabase.availableTimes(check, partySize));
	date = check;
}

void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{
	cout << "\nChoose a time:" << endl;
	string times[5] = {"", "11:30", "13:30", "17:45", "19:45" };
	for (int i = 1; i <= 4; i++) {
		if (!availSeatsDatabase.availableTimes(date, i, partySize))
			continue;
		cout << i << ". " << times[i] << endl;
	}
	int choice;
	do {
		cout << "?";
		cin >> choice;
		cin.ignore();
	} while (!availSeatsDatabase.availableTimes(date, choice, partySize));
	timeCode = choice;
}