#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	loadAvailSeats();
	Date current;// 2020/06/21
	computeCurrentDate(current);
	if (availSeats.size() > 0) {//renew the date
		int currentpos = 0;
		current + 1;
		//compute where to copy
		for (int i = 0; i < availSeats.size(); i++) {//the first time wouldn't come in, cause is empty
			if (current - availSeats[i].getDate() > 0)//2020/06/21 - 2020/06/16
				currentpos++;
			else if (current - availSeats[i].getDate() == 0)
			{
				//currentpos++;
				break;
			}
		}
		if (!currentpos)
			return;
		//move the current date + 1 day to 0
		for (int i = currentpos; i < availSeats.size(); i++) {
			availSeats[i - currentpos] = availSeats[i];
		}
		//set the new 30 - currentpos date after the vector
		int numAvailSeats[5] = { 0, 20, 20, 20, 20 };
		for (int i = 30 - currentpos, j = 1; i < 30; i++, j++) {
			
			AvailSeats temp(availSeats[i - 1].getDate() + j, numAvailSeats);
			availSeats[i] = temp;
			/*AvailSeats temp(current + 1, numAvailSeats);
			availSeats[i] = temp;*/
		}
	}
	else {// Is Empty. So push 30 date into the vector start from current date + 1
		int numAvailSeats[5] = { 0, 20, 20, 20, 20 };
		for (int i = 0, j = 1; i < 30; i++, j++) {
			current + 1;
			AvailSeats temp(current, numAvailSeats);
			availSeats.push_back(temp);
		}
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	it->setNumAvailSeats(timeCode, it->getNumAvailSeats(timeCode) - requiredSeats);
	/*for (int i = 0; i < availSeats.size(); i++) {
		if (availSeats[i].getDate() == date)
		{
			availSeats[i].setNumAvailSeats(timeCode, requiredSeats);//requiredSeats had already been minus
			return;
		}
	}*/
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	if (it == availSeats.end()) return false;
	for (int i = 1; i <= 4; i++) {
		if (it->getNumAvailSeats(i) > requiredSeats)
			return true;
	}
	return false;
	/*for (int i = 0; i < availSeats.size(); i++) {
		if (availSeats[i].getDate() == date) 
		{
			for (int j = 1; j <= 4; j++) {
				if (availSeats[i].getNumAvailSeats(j) > 0)
					return true;
			}
			return false;
		}
	}*/
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	if (timeCode < 0 || timeCode > 4)
		return false;
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	return it->getNumAvailSeats(timeCode) >= requiredSeats;
	/*for (int i = 0; i < availSeats.size(); i++) {
		if (availSeats[i].getDate() == date) {
			if (availSeats[i].getNumAvailSeats(requiredSeats) > 0)
				return true;
			return false;
		}
	}
	return false;//didn't find a date that fit */
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator it = availSeats.begin();
	for (; it != availSeats.end(); it++) {
		if(it->getDate() == date)
			for (int i = 1; i <= 4; i++) {
				if (it->getNumAvailSeats(i) > 0)
					return it;
			}
	}
	it = availSeats.end();
	return it;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream infile("AvailSeats.dat", ios::in | ios::binary);
	if (!infile) {
		cout << "could not opened the file" << endl;
		exit(1);
	}
	AvailSeats temp;
	infile.read(reinterpret_cast<char*>(&temp), sizeof(AvailSeats));
	while (!infile.eof()) {
		availSeats.push_back(temp);
		infile.read(reinterpret_cast<char*>(&temp), sizeof(AvailSeats));
	}
	infile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outfile("AvailSeats.dat", ios::out | ios::binary);
	if (!outfile) {
		cout << "outfile could not be opened" << endl;
		exit(1);
	}

	outfile.seekp(0, ios::beg);
	for (int i = 0; i < availSeats.size(); i++)
		outfile.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(AvailSeats));

	outfile.close();
}