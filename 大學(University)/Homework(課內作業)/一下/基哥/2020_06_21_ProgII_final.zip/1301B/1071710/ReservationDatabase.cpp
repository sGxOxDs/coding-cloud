#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
	{
		if (reservations[i].getPhoneNumber() == phoneNumber)
			return true;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	int count = 1;
	cout << endl;
	for (int i = 0; i < reservations.size(); i++)
	{
		if (reservations[i].getPhoneNumber() == phoneNumber)
		{
			cout << count << '.'; 
			reservations[i].displayReservationInfo();
			count++;
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
   storeReservations();
}

void ReservationDatabase::loadReservations()
{

	ifstream infile("Reservations.dat", ios::in | ios::binary);
	Reservation temp;
	while (infile.read(reinterpret_cast<char*>(&temp), sizeof(Reservation)))
	{
		reservations.push_back(temp);
	}
	infile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outfile("Reservations.dat", ios::out | ios::binary);
	for (int i = 0; i < reservations.size(); i++)
		outfile.write(reinterpret_cast<char*>(&reservations[i]), sizeof(Reservation));
	outfile.close();
}