#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	//��Ū�� �ê�l�ƨC��Availseats
	int newTime[5] = { 0,18,18,18,18};
	loadAvailSeats();
	Date date;
	computeCurrentDate(date);
	date = date + 1;//�w�����ѥH�᪺�ɶ�
	AvailSeats newAvail(date, newTime);
	int Num = 0;
	bool first = false;
	vector< AvailSeats >::const_iterator it=availSeats.begin();
	vector< AvailSeats >::const_iterator temp;
	if (it._Ptr == nullptr)
	{
		Num = 30;
		first = true;
	}
	else
		Num=(date - it._Ptr->getDate());
	if (Num != 0 && Num < 30)
	{
		vector<AvailSeats> temp;
		for (int i = availSeats.size() - 1; i >= 0; i--)
		{
			temp.push_back(availSeats[i]);
		}
		for (int i = 0; i < Num; i++)
		{
			temp.pop_back();
		}
		availSeats.clear();
		for (int i = temp.size() - 1; i >= 0; i--)
		{
			availSeats.push_back(temp[i]);
		}
		temp.clear();
	}
	else if (Num > 30)
	{
		availSeats.clear();

		for (int i = 0; i < 30; i++)
		{
			newAvail.setDate(date);
			availSeats.push_back(newAvail);
			date = date + 1;
		}

	}
	else if (Num == 30&& first == true)
	{
		for (int i = 0; i < 30; i++)
		{
			newAvail.setDate(date);
			availSeats.push_back(newAvail);
			date = date + 1;
		}
	}
	else
	{
		date = date + (30 - Num);
		for (int i = 0; i < Num; i++)
		{
			newAvail.setDate(date = date + 1);
			availSeats.push_back(newAvail);
		}
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	int p1 = 0;
	int p2 = 0;
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	p1=it._Ptr->getNumAvailSeats(timeCode); //���ѳѦh�֤H
	p2 = requiredSeats;
	if (p1 >= p2)
	{
		p1 -= p2;
	}
	it._Ptr->setNumAvailSeats(timeCode, p1);
	storeAvailSeats();
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	//�ݭn�h�֤H��
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	for (int i = 1; i <= 4; i++)
	{
		if (it._Ptr->getNumAvailSeats(i) >= requiredSeats)
			return true;
	}
		return false;
	
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	if (it._Ptr->getNumAvailSeats(timeCode) >= requiredSeats)
	{
		return true;
	}
	else
		return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator it = availSeats.begin();
	for (;it!=availSeats.end();it++)
	{
		if (it._Ptr->getDate() == date)
			return it;
	}
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream infile("AvailSeats.dat", ios::in | ios::binary);
	AvailSeats temp;
	while (infile.read(reinterpret_cast<char*>(&temp), sizeof(AvailSeats)))
	{
		availSeats.push_back(temp);
	}
	infile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outfile("AvailSeats.dat", ios::out | ios::binary);
	for (int i = 0; i < availSeats.size(); i++)
		outfile.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(AvailSeats));
	outfile.close();
}