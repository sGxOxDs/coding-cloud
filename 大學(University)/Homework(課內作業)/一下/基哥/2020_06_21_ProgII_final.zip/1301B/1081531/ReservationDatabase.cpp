#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
	loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
	storeReservations();
}

bool ReservationDatabase::empty()
{
	return (reservations.size() == 0);
}

bool ReservationDatabase::exist(string phoneNumber)
{
	for (vector<Reservation>::iterator it = reservations.begin(); it != reservations.end(); it++)
		if (it->getPhoneNumber() == phoneNumber)
			return true;
	return false;
}

void ReservationDatabase::displayReservationInfo(string phoneNumber)
{
	cout << endl;
	vector<Reservation>::iterator it = reservations.begin();
	int i = 1;
	while (it != reservations.end()) {
		if (it->getPhoneNumber() == phoneNumber) {
			cout << setw(2) << right << i << ". ";
			it->displayReservationInfo();
			i++; 		
		}
		it++;
	}
}

void ReservationDatabase::pushBack(Reservation newReservation)
{
	reservations.push_back(newReservation);
}

void ReservationDatabase::loadReservations()
{
	ifstream infile("Reservations.dat", ios::in | ios::binary);
	if (!infile) {
		cerr << "File could not be open." << endl;
		exit(1);
	}
	infile.seekg(0, ios::end);
	int num = infile.tellg() / sizeof(Reservation);
	infile.seekg(0, ios::beg);
	reservations.resize(num);
	for (int i = 0; i < num; i++)
		infile.read(reinterpret_cast<char*>(&reservations[i]), sizeof(Reservation));
	infile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream ofile("Reservations.dat", ios::out | ios::binary);
	if (!ofile) {
		cerr << "File could not be open." << endl;
		exit(1);
	}
	for (int i = 0; i < reservations.size(); i++)
		ofile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(Reservation));
	ofile.close();
}