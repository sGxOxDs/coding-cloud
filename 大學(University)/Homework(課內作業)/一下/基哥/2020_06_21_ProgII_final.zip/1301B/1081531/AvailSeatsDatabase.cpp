#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	Date currentDate, date;
	int seats[5] = { 0,20,20,20,20 };
	computeCurrentDate(currentDate);
	loadAvailSeats();
	for (vector<AvailSeats>::iterator it = availSeats.begin(); it != availSeats.end(); it++)
	{
		if (it->getDate() < currentDate)
			availSeats.erase(it);
	}
	if (availSeats.size() < 30)
		for (int i = availSeats.size(); i < 30; i++) {
			date = currentDate + i + 1;
			AvailSeats add(date, seats);
			availSeats.push_back(add);
		}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
	storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats(Date date, int timeCode, int requiredSeats)
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	int num;
	num = it->getNumAvailSeats(timeCode) - requiredSeats;
	it->setNumAvailSeats(timeCode, num);
}

bool AvailSeatsDatabase::availableTimes(Date date, int requiredSeats)
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	for (int i = 1; i < 5; i++) {
		if (it->getNumAvailSeats(i) >= requiredSeats)
			return true;
	}
	return false;
}

bool AvailSeatsDatabase::availableTimes(Date date, int timeCode, int requiredSeats)
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	if (it->getNumAvailSeats(timeCode) >= requiredSeats)
		return true;
	return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats(Date date)
{
	for (vector<AvailSeats>::iterator it = availSeats.begin(); it != availSeats.end(); it++)
		if (it->getDate() == date)
			return it;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream infile("AvailSeats.dat", ios::in | ios::binary);
	if (!infile) {
		cerr << "File could not be open." << endl;
		exit(1);
	}
	infile.seekg(0, ios::end);
	int num = infile.tellg() / sizeof(AvailSeats);
	infile.seekg(0, ios::beg);
	availSeats.resize(num);
	for (int i = 0; i < num; i++)
		infile.read(reinterpret_cast<char*>(&availSeats[i]), sizeof(AvailSeats));
	infile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream ofile("AvailSeats.dat", ios::out | ios::binary);
	if (!ofile) {
		cerr << "File could not be open." << endl;
		exit(1);
	}
	for (int i = 0; i < availSeats.size(); i++)
		ofile.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(AvailSeats));
	ofile.close();
}