#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
		if (reservations[i].getPhoneNumber() == phoneNumber)
			return true;
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	int count = 1;
	for (int i = 0; i < reservations.size(); i++) {
		if (reservations[i].getPhoneNumber() == phoneNumber) {
			cout << count<<". ";
			reservations[i].displayReservationInfo();
			count++;
		}
	}
			
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream infile("Reservations.dat", ios::binary);
	if (!infile) {
		cout << "infile reservations failed!\n";
		exit(1);
	}
	Reservation tmp;
	for (; infile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));) {
		reservations.push_back(tmp);
	}
	infile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outfile("Reservations.dat", ios::binary);
	for (int i = 0; i < reservations.size(); i++)
		outfile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(Reservation));
	outfile.close();
}