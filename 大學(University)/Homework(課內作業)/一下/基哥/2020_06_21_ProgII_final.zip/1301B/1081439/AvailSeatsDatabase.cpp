#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	Date today;
	computeCurrentDate(today);
	loadAvailSeats();
	vector<AvailSeats>newavailseats;
	for (int i = 1; i <= 30; i++) {
		if (searchAvailSeats(today + i) != availSeats.end()) {
			newavailseats.push_back(*searchAvailSeats(today + i));
		}
		else {
			int numavail[5] = { 0,20,20,20,20 };
			AvailSeats add(today+i, numavail);
			newavailseats.push_back(add);
		}
	}
	availSeats = newavailseats;
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	auto it = searchAvailSeats(date);
	it._Ptr->setNumAvailSeats(timeCode, it._Ptr->getNumAvailSeats(timeCode) - requiredSeats);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	for (int i = 0; i <= 4; i++) {
		if (availableTimes(date, i, requiredSeats))
			return true;
	}
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	auto it = searchAvailSeats(date);
	return (it._Ptr->getNumAvailSeats(timeCode) >= requiredSeats);
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	auto it = availSeats.begin();
	for (; it != availSeats.end(); it++) {
		if (it._Ptr->getDate() == date)
			return it;
	}
	return it;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream infile("AvailSeats.dat", ios::binary);
	if (!infile) {
		cout << "infile availseats failed!\n";
		exit(1);
	}
	AvailSeats tmp;
	for (; infile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));) {
		availSeats.push_back(tmp);
	}
	infile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outfile("AvailSeats.dat", ios::binary);
	for (int i = 0; i < availSeats.size(); i++)
		outfile.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(AvailSeats));
	outfile.close();
}