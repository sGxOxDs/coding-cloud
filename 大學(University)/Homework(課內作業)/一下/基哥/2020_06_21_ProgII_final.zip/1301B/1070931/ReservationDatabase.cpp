#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
	return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber ) 
{
	vector < Reservation >::iterator it = reservations.begin();
	while (it != reservations.end()) {
		if (it->getPhoneNumber() == phoneNumber)
			return true;
		it++;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	vector < Reservation >::iterator it = reservations.begin();
	while (it != reservations.end())
	{
		if (it->getPhoneNumber() == phoneNumber)
			it->displayReservationInfo();
		it++;
	}
			
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream inFile;
	inFile.open("Reservations.dat", ios::binary);
	char buffer[20];
	int count = 0,countMax=0;
	if (!inFile.eof())
	{
		inFile >> buffer;
		countMax = atoi(buffer);
	}

	while (count < countMax)
	{
		Reservation newReservation;
		Date newDate;
		inFile >> buffer;
		newReservation.setPartySize(atoi(buffer));

		inFile >> buffer;
		newDate.setYear(atoi(buffer));
		inFile >> buffer;
		newDate.setMonth(atoi(buffer));
		inFile >> buffer;
		newDate.setDay(atoi(buffer));
		newReservation.setDate(newDate);

		inFile >> buffer;
		newReservation.setTime(atoi(buffer));

		inFile >> buffer;
		newReservation.setName(buffer);

		inFile >> buffer;
		newReservation.setPhoneNumber(buffer);
		pushBack(newReservation);
		count++;
	}

	inFile.close();
}

void ReservationDatabase::storeReservations()
{
	vector < Reservation >::iterator it = reservations.begin();
	ofstream outFile;
	outFile.open("Reservations.dat", ios::binary);

	outFile << reservations.size() << ' ';
	while (it != reservations.end())
	{
		outFile << it->getPartySize() << ' ';
		outFile << it->getDate().getYear() << ' ';
		outFile << it->getDate().getMonth() << ' ';
		outFile << it->getDate().getDay() << ' ';
	    outFile << it->getTime() << ' ';
		outFile << it->getName() << ' ';
		outFile << it->getPhoneNumber() << ' ' << '\n';;
		it++;
	}

	outFile.close();
}