#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	loadAvailSeats();
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	it->setNumAvailSeats(timeCode, it->getNumAvailSeats(timeCode)-requiredSeats);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	if (it->getNumAvailSeats(1) < requiredSeats &&
		it->getNumAvailSeats(2) < requiredSeats &&
		it->getNumAvailSeats(3) < requiredSeats &&
		it->getNumAvailSeats(4) < requiredSeats )
		return false;
	return true;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	if (it->getNumAvailSeats(timeCode) < requiredSeats)
		return false;
	return true;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{///////////////////////////////x
	vector<AvailSeats>::iterator it = availSeats.begin();
	while (it != availSeats.end())
	{
		if (it->getDate() == date)
			return it;
		it++;
	}
	int* availSeat=new int[5]{ 0,20,20,20,20 };
	availSeats.push_back(AvailSeats(date, availSeat));
	return availSeats.begin();
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream inFile;
	inFile.open("AvailSeats.dat", ios::binary);
	char buffer[20];
	int count = 0, countMax = 0;

	if (!inFile.eof())
	{
		inFile >>buffer;
		countMax = atoi(buffer);
	}

	while (count < countMax)
	{
		AvailSeats newAvailSeats;
		Date newDate;
		inFile >> buffer;
		newDate.setYear(atoi(buffer));
		inFile >> buffer;
		newDate.setMonth(atoi(buffer));
		inFile >> buffer;
		newDate.setDay(atoi(buffer));
		newAvailSeats.setDate(newDate);

		inFile >> buffer;
		newAvailSeats.setNumAvailSeats(1, atoi(buffer));
		inFile >> buffer;
		newAvailSeats.setNumAvailSeats(2, atoi(buffer));
		inFile >> buffer;
		newAvailSeats.setNumAvailSeats(3, atoi(buffer));
		inFile >> buffer;
		newAvailSeats.setNumAvailSeats(4, atoi(buffer));
		availSeats.push_back(newAvailSeats);
		count++;
	}

	inFile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	vector < AvailSeats >::iterator it = availSeats.begin();
	ofstream outFile;
	outFile.open("AvailSeats.dat", ios::binary);
	while (it != availSeats.end())
	{
		outFile << availSeats.size() << ' ';
		outFile << it->getDate().getYear() << ' ';
		outFile << it->getDate().getMonth() << ' ';
		outFile << it->getDate().getDay() << ' ';
		outFile << it->getNumAvailSeats(1) << ' ';
		outFile << it->getNumAvailSeats(2) << ' ';
		outFile << it->getNumAvailSeats(3) << ' ';
		outFile << it->getNumAvailSeats(4) << ' ' << '\n';
		
		it++;
	}

	outFile.close();
}