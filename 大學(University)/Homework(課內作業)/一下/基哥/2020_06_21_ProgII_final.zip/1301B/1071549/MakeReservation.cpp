// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );
}

void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{
	Date zero;
	vector<Date> tmp;
	cout << "\nChoose a date\n";
	for (int i = 1,b=0; i < 31; i++) {
		if (availSeatsDatabase.availableTimes((currentDate + i), partySize)) {
			tmp.push_back((currentDate + i));
			cout << setw(2) << i << ". " << setw(4) << (currentDate + i).getYear() << "/";
			if ((currentDate + i).getMonth() < 10)
				cout << "0" << (currentDate + i).getMonth();
			else
				cout << (currentDate + i).getMonth();
			cout << "/";
			if ((currentDate + i).getDay() < 10)
				cout << "0" << (currentDate + i).getDay();
			else
				cout << (currentDate + i).getDay();
			if (b == 3) {
				cout << endl;
				b = 0;
			}
			else {
				b++;
				cout << "  ";
			}
		}
		else tmp.push_back(zero);
	}
	cout << endl;
	int choose;
	bool judge;
	do {
		judge = false;
		cout << "? ";
		choose = inputAnInteger(1, 30);
		if (choose == -1) {
			judge = true;
		}
		else {
			if (tmp[choose - 1] == zero)
				judge = true;
		}
	} while (judge);
	date = tmp[choose - 1];
}

void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{
	int zero = 0;
	vector<int>tmp;
	string time_table[5] = { "" ,"11:30","13:30","17:45","19:45" };
	cout << "\n\nChoose a time:\n";
	for (int i = 1; i < 5; i++) {
		if (availSeatsDatabase.availableTimes(date, i, partySize)) {
			cout << i << ". " << time_table[i] << endl;
			tmp.push_back(i);
		}
		else tmp.push_back(zero);
	}
	int choose;
	bool judge = false;
	do {
		judge = false;
		cout << "? ";
		choose = inputAnInteger(1, 4);
		if (choose == -1)
			judge = true;
		else {
			if (tmp[choose - 1] == zero) {
				judge = true;
			}
		}
	} while (judge);
	timeCode = choose;
}