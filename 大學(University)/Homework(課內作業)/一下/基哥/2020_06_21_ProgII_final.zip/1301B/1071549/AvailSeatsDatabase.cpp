#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	loadAvailSeats();
	Date current_date;
	int nnumAvailSeats[5] = { 0,20,20,20,20 };
	computeCurrentDate(current_date);
	if (availSeats.size() > 0) {
		while (availSeats.begin()->getDate() < current_date || availSeats.begin()->getDate() == current_date) {
			availSeats.erase(availSeats.begin());
		}	
	}
	while (availSeats.size() != 30) {
		AvailSeats tmp(current_date + availSeats.size()+1, nnumAvailSeats);
		availSeats.push_back(tmp);
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator t1 = searchAvailSeats(date);
	int def = t1->getNumAvailSeats(timeCode) - requiredSeats;
	t1->setNumAvailSeats(timeCode, def);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector< AvailSeats >::iterator t1 = searchAvailSeats(date);
	for (int i = 1; i < 5; i++) {
		if (t1->getNumAvailSeats(i) >= requiredSeats)
			return true;
	}
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator t1 = searchAvailSeats(date);
	if (t1->getNumAvailSeats(timeCode) >= requiredSeats)
		return true;
	return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator t1 = availSeats.begin();
	for (; !(t1->getDate() == date); t1++);
	if (t1->getDate() == date)
		return t1;
	else return availSeats.end();
}

void AvailSeatsDatabase::loadAvailSeats()
{
	fstream input("AvailSeats.dat", ios::in | ios::binary);
	AvailSeats tmp;
	while (input.read(reinterpret_cast<char*>(&tmp), sizeof(tmp))) {
		availSeats.push_back(tmp);
	}
	input.close();
	//20�y��
}

void AvailSeatsDatabase::storeAvailSeats()
{
	fstream output("AvailSeats.dat", ios::out | ios::binary);
	for (int i = 0; i < availSeats.size(); i++) {
		output.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(availSeats[i]));
	}
	output.close();
}