#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++) {
		if (reservations[i].getPhoneNumber() == phoneNumber)
			return true;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	int num = 0;
	string time_table[5] = { "" ,"11:30","13:30","17:45","19:45" };
	cout << endl;
	for (int i = 0; i < reservations.size(); i++) {
		if (reservations[i].getPhoneNumber() == phoneNumber) {
			cout << ++num << ". " << reservations[i].getPartySize() << " " << reservations[i].getName();
			cout << "  " << reservations[i].getDate().getYear() << "/" << reservations[i].getDate().getMonth() << "/" << reservations[i].getDate().getDay();
			cout << "  " << time_table[reservations[i].getTime()]<<endl;
		}
	}

}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	fstream input("Reservations.dat", ios::in | ios::binary);
	while (!input.fail()) {
		Reservation tmp;
		input.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
		reservations.push_back(tmp);
	}
	input.close();
}

void ReservationDatabase::storeReservations()
{
	fstream output("Reservations.dat", ios::out | ios::binary);
	for (int i = 0; i < reservations.size(); i++) {
		output.write(reinterpret_cast<char*>(&reservations[i]), sizeof(reservations[i]));
	}
	output.close();
}