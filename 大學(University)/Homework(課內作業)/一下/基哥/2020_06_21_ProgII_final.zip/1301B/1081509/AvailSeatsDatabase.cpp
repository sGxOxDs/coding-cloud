#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	vector< AvailSeats > availSeats;  // Vector of available seats
	loadAvailSeats();
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
	storeAvailSeats();
}

//void AvailSeats::setNumAvailSeats( int timeCode, int theNumAvailSeats )
//numAvailSeats[ timeCode ] = ( theNumAvailSeats >= 0 ? theNumAvailSeats : 0 );
void AvailSeatsDatabase::decreaseAvailSeats(Date date, int timeCode, int requiredSeats)
{
	vector<AvailSeats>::iterator it;
	it = searchAvailSeats(date);
	it->setNumAvailSeats(timeCode, it->getNumAvailSeats(timeCode) - requiredSeats);
}

//we want to know this date whether have (time of four) seats?
//only one is ok;
bool AvailSeatsDatabase::availableTimes(Date date, int requiredSeats)
{
	bool isAvailable = false;
	for (int i = 1; i <= 4; i++)
	{
		if (availableTimes(date, i, requiredSeats))
		{
			isAvailable = true;
			break;
		}
	}
	return isAvailable;
}

//to check this day in this time is available with requiredSeats?
bool AvailSeatsDatabase::availableTimes(Date date, int timeCode, int requiredSeats)
{
	vector<AvailSeats>::iterator it;
	it = searchAvailSeats(date);
	return it->getNumAvailSeats(timeCode) >= requiredSeats;
}

// return a iterator  , to look for input date in vector
vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats(Date date)
{
	for (int i = 0; i < availSeats.size(); i++)
	{

		if (availSeats[i].getDate() == date)
		{
			vector<AvailSeats>::iterator itr = availSeats.begin() + i;
			return itr;
			//return &availSeats[i].getDate;
		}
	}
	//if no ?
}

//if not have data => create data
//if have data => this day  => ok no need to update
//             => but is another day => load data and add new data
void AvailSeatsDatabase::loadAvailSeats()
{
	fstream infile("AvailSeats.dat", fstream::in | fstream::out | fstream::binary);
	AvailSeats tmp;
	while (infile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp)))
		availSeats.push_back(tmp);
	infile.close();

   Date currentDate;
   computeCurrentDate( currentDate );

   AvailSeats as;
	if (availSeats.size() == 0)//first into system
	{
		for (int i = 0; i < 30; i++)
			availSeats.push_back(as);
		cout << "size = 0 ?" << availSeats.size();
		for (int i = 0; i < 30; i++)
		{
			availSeats[i].setDate(currentDate + i + 1);
			for (int j = 1; j <= 4; j++)
				availSeats[i].setNumAvailSeats(j, 20);
		}
	}
	else//DB have something
	{
		int cost = (currentDate + 1 - availSeats[0].getDate());
		if ( cost > 0)//omg  not this day
		{
			if (cost >= 30)//cost >= 30 => new  
			{
				for (int i = 0; i < 30; i++)
				{
					availSeats[i].setDate(currentDate + i + 1 );
					for (int j = 1; j <= 4; j++)
						availSeats[i].setNumAvailSeats(j, 20);
				}
			}
			else //cose < 30 need copy from old DB and add new data
			{
				for (int i = 0; i < 30; i++)
					availSeats[i].setDate( availSeats[i + cost].getDate() );
				for (int i = 0; i < cost; i++)
					availSeats.pop_back();
				for (int i = 0; i < cost; i++)
				{
					AvailSeats tt;
					int num = 1 + 30 - cost + i;
					tt.setDate(currentDate + num);
					for (int j = 1; j <= 4; j++)
						tt.setNumAvailSeats(j, 20);
					//availSeats.push_back()
				}
			}
		}
	}
}

void AvailSeatsDatabase::storeAvailSeats()
{
	fstream outfile("AvailSeats.dat", fstream::in | fstream::out | fstream::binary | fstream::trunc);
	for (int i = 0; i < availSeats.size(); i++)
		while (outfile.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(availSeats[i])));
}