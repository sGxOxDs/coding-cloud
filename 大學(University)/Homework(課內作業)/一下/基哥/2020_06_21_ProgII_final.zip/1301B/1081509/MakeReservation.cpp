// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include<vector>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );
}

//bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
//void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{
	bool ck[35]{};
	cout << "Choose a date\n";
	int countDate = 1;
	for (int i = 1; i <= 30; i++)//show
	{
		if (availSeatsDatabase.availableTimes(currentDate + i, partySize))
			cout << i << ". "
			<< (currentDate + i).getYear() << "/"
			<< (currentDate + i).getMonth() << "/"
			<< (currentDate + i).getDay()<< endl;
		else
			ck[i] = 1;
	}
   int chooseDate;
   cout << "? ";
   while (1)//avoid stupid
   {
	   cin >> chooseDate;
	   if (chooseDate > 30 || chooseDate < 1 || ck[chooseDate] == 1)
	   {
		   cout << "? ";
			   continue;
	   }
	   else
		   break;
   }
   //do cout << "? ";
   //while( ( chooseDate = inputAnInteger( 1, 30 ) ) == -1 );

   date.setYear((currentDate+chooseDate).getYear());
   date.setMonth((currentDate+chooseDate).getMonth());
   date.setDay((currentDate+chooseDate).getDay());
}

//bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{
	vector<string>s(6);
	s[1] = "11:30";
	s[2] = "13:30";
	s[3] = "17:45";
	s[4] = "19:45";
	bool ck[7]{};
	cout << "Choose a time\n";
	for (int i = 1; i <= 4; i++)
	{
		if (availSeatsDatabase.availableTimes(date, i, partySize))
			cout << i << " . " << s[i]<<endl;
		else
			ck[i] = 1;
	}
   int chooseTime;
   cout << "? ";
   while (1)//avoid stupid
   {
	   cin >> chooseTime;
	   if (chooseTime > 4 || chooseTime < 1 || ck[chooseTime] == 1)
	   {
		   cout << "? ";
			   continue;
	   }
	   else
		   break;
   }
   //do cout << "? ";
   //while( ( chooseTime = inputAnInteger( 1, 4 ) ) == -1 );
   timeCode = chooseTime;
}