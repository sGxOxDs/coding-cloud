#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
	{
		if (reservations[i].getPhoneNumber == phoneNumber)
			return true;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
	{
		if (reservations[i].getPhoneNumber == phoneNumber)
		{
			cout << i << ". "
				<< reservations[i].getPartySize << " " << "guests"
				<< reservations[i].getDate.getYear()<<"/"
				<< reservations[i].getDate.getMonth()<<"/"
				<< reservations[i].getDate.getDay()<<" "
				<< reservations[i].getTime
				<< endl;
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()// read reservation DB 
{
   vector< Reservation > reservations; // vector of all reservations
   Reservation tmp;
   fstream infile("Reservations.dat", fstream::in | fstream::out | fstream::binary);
	while (infile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp)))
		reservations.push_back(tmp); 
	infile.close();
}

void ReservationDatabase::storeReservations() // write reservation DB
{
   fstream outfile("Reservations.dat",fstream::in|fstream::out|fstream::binary|fstream::trunc);
   for (int i = 0; i < reservations.size(); i++)
	   while (outfile.write(reinterpret_cast<const char*>(&reservations[i]), sizeof(reservations[i])));
}