#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (auto data : reservations)
	{
		if (data.getPhoneNumber() == phoneNumber)
			return true;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	for (auto data : reservations)
	{
		int i = 1;
		if (data.getPhoneNumber() == phoneNumber)
		{
			cout << i << ". ";
			data.displayReservationInfo();
			i++;
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream inFile("Reservations.dat", ios::binary);
	if (!inFile)
	{
		cout << "File could not opened." << endl;
		exit(1);
	}
	Reservation reservation;
	inFile.read(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
	while (!inFile.eof())
	{
		pushBack(reservation);
		inFile.read(reinterpret_cast<char*>(&reservation), sizeof(Reservation));
	}
}

void ReservationDatabase::storeReservations()
{
	ofstream outFile("Reservations.dat", ios::binary);
	if (!outFile)
	{
		cout << "File could not opened." << endl;
		exit(1);
	}
	for (auto data : reservations)
	{
		outFile.write(reinterpret_cast<char*>(&data), sizeof(Reservation));
	}
}