#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	Date currentDate;
	computeCurrentDate(currentDate);
	int numAvailSeats[5] = { 0, 18, 18, 18, 18 };
	for (int i = 0; i < 30; i++)
	{
		AvailSeats availSeat(currentDate + 1, numAvailSeats);
		availSeats.push_back(availSeat);
	}
	loadAvailSeats();
	for (auto data : availSeats)
	{
		if (data.getDate() < currentDate)
		{
			data.setDate(currentDate);
			currentDate = currentDate + 1;
		}
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	int numAvailSeats = it->getNumAvailSeats(timeCode);
	numAvailSeats -= requiredSeats;
	it->setNumAvailSeats(timeCode, numAvailSeats);
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	int totalSeats = 0;
	for (int i = 1; i <= 4; i++)
	{
		totalSeats += it->getNumAvailSeats(i);
	}
	if (totalSeats > requiredSeats)
		return true;
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator it = searchAvailSeats(date);
	if (it->getNumAvailSeats(timeCode) < requiredSeats)
		return false;
	return true;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector<AvailSeats>::iterator it = availSeats.begin();
	for (; it != availSeats.end(); ++it)
	{
		if (it->getDate() == date)
			break;
	}
	return it;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream inFile("AvailSeats.dat", ios::binary);
	if (!inFile)
	{
		cout << "File could not opened." << endl;
		exit(1);
	}
	AvailSeats seats;
	inFile.read(reinterpret_cast<char*>(&seats), sizeof(AvailSeats));
	while (!inFile.eof())
	{
		availSeats.push_back(seats);
		inFile.read(reinterpret_cast<char*>(&seats), sizeof(AvailSeats));
	}
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outFile("AvailSeats.dat", ios::binary);
	if (!outFile)
	{
		cout << "File could not opened." << endl;
		exit(1);
	}
	for (auto data : availSeats)
	{
		outFile.write(reinterpret_cast<char*>(&data), sizeof(AvailSeats));
	}
}