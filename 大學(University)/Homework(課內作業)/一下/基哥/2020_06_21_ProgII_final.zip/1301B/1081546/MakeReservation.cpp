// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );
}

void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{
	cout << "Choose a date\n";
	for (int i = 1; i < 31; i++)
	{
		currentDate.operator+(i);
		if (i % 4 == 0)
		{
			if (i < 10)
			{
				if (currentDate.operator+(i).getMonth() < 10)
				{
					if (currentDate.operator+(i).getDay() < 10)
					{
						cout << " " << i << ". " << currentDate.operator+(i).getYear() << "/0" << currentDate.getMonth() << "/0" << currentDate.operator+(i).getDay() << endl;
					}
					else
					{
						cout << " " << i << ". " << currentDate.operator+(i).getYear() << "/0" << currentDate.getMonth() << "/" << currentDate.operator+(i).getDay() << endl;
					}
				}
				else
				{
					if (currentDate.operator+(i).getDay() < 10)
					{
						cout << " " << i << ". " << currentDate.operator+(i).getYear() << "/" << currentDate.operator+(i).getMonth() << "/0" << currentDate.operator+(i).getDay() << endl;
					}
					else
					{
						cout << " " << i << ". " << currentDate.operator+(i).getYear() << "/" << currentDate.operator+(i).getMonth() << "/" << currentDate.operator+(i).getDay() << endl;
					}					
				}
			}
			else
			{
				if (currentDate.operator+(i).getMonth() < 10)
				{
					if (currentDate.operator+(i).getDay() < 10)
					{
						cout << i << ". " << currentDate.operator+(i).getYear() << "/0" << currentDate.operator+(i).getMonth() << "/0" << currentDate.operator+(i).getDay() << endl;
					}
					else
					{
						cout << i << ". " << currentDate.operator+(i).getYear() << "/0" << currentDate.operator+(i).getMonth() << "/" << currentDate.operator+(i).getDay() << endl;
					}					
				}
				else
				{
					if (currentDate.operator+(i).getDay() < 10)
					{
						cout << i << ". " << currentDate.operator+(i).getYear() << "/" << currentDate.operator+(i).getMonth() << "/0" << currentDate.operator+(i).getDay() << endl;
					}
					else
					{
						cout << i << ". " << currentDate.operator+(i).getYear() << "/" << currentDate.operator+(i).getMonth() << "/" << currentDate.operator+(i).getDay() << endl;
					}
				}
			}
		}
		else
		{
			if (i < 10)
			{
				if (currentDate.operator+(i).getMonth() < 10)
				{
					if (currentDate.operator+(i).getDay() < 10)
					{
						cout << " " << i << ". " << currentDate.operator+(i).getYear() << "/0" << currentDate.operator+(i).getMonth() << "/0" << currentDate.operator+(i).getDay() << "  ";
					}
					else
					{
						cout << " " << i << ". " << currentDate.operator+(i).getYear() << "/0" << currentDate.operator+(i).getMonth() << "/" << currentDate.operator+(i).getDay() << "  ";
					}	
				}
				else
				{
					if (currentDate.operator+(i).getDay() < 10)
					{
						cout << " " << i << ". " << currentDate.operator+(i).getYear() << "/" << currentDate.operator+(i).getMonth() << "/0" << currentDate.operator+(i).getDay() << "  ";
					}
					else
					{
						cout << " " << i << ". " << currentDate.operator+(i).getYear() << "/" << currentDate.operator+(i).getMonth() << "/" << currentDate.operator+(i).getDay() << "  ";
					}				
				}
			}
			else
			{
				if (currentDate.operator+(i).getMonth() < 10)
				{
					if (currentDate.operator+(i).getDay() < 10)
					{
						cout << i << ". " << currentDate.operator+(i).getYear() << "/0" << currentDate.operator+(i).getMonth() << "/0" << currentDate.operator+(i).getDay() << "  ";
					}
					else
					{
						cout << i << ". " << currentDate.operator+(i).getYear() << "/0" << currentDate.operator+(i).getMonth() << "/" << currentDate.operator+(i).getDay() << "  ";
					}				
				}
				else
				{
					if (currentDate.operator+(i).getDay() < 10)
					{
						cout << i << ". " << currentDate.operator+(i).getYear() << "/" << currentDate.operator+(i).getMonth() << "/0" << currentDate.operator+(i).getDay() << "  ";
					}
					else
					{
						cout << i << ". " << currentDate.operator+(i).getYear() << "/" << currentDate.operator+(i).getMonth() << "/" << currentDate.operator+(i).getDay() << "  ";
					}
				}
			}
		}
	}
	int choosedate;
	do {
		cout << "\n?";
		/*if (availSeatsDatabase.availableTimes(date, partySize))
		{
			break;
		}*/
	} while ((choosedate = inputAnInteger(1, 30)) == -1);
	/*cout << "\n?";
	while ((choosedate = inputAnInteger(1, 30)) == -1)
	{

		if (availSeatsDatabase.availableTimes(date, partySize))
		{
			break;
		}
		else
			cout << "\n?";
	}*/
}

void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{
	int timecode;
	string timecode1 = "1. 11:30\n";
	string timecode2 = "2. 13:30\n";
	string timecode3 = "3. 17:45\n";
	string timecode4 = "4. 19:45\n";
	cout << "\nChoose a time:" << endl;
	for (int i = 1; i < 5; i++)
	{
		if (availSeatsDatabase.availableTimes(date, partySize))
		{
			if (i == 1)
				cout << timecode1;
			if (i == 2)
				cout << timecode2;
			if (i == 3)
				cout << timecode3;
			if (i == 4)
				cout << timecode4;
		}
	}
	
	//cout << "1. 11:30\n" << "2. 13:30\n" << "3. 17:45\n" << "4. 19:45\n";
	do {
		cout << "?";
	} while ((timecode = inputAnInteger(1, 4)) == -1);
	/*cout << "?";
	while ((timecode = inputAnInteger(1, 4)) == 1) 
	{
		
		if (availSeatsDatabase.availableTimes(date, timecode, partySize))
		{
			break;
		}
		else
			cout << "?";
	}*/
}