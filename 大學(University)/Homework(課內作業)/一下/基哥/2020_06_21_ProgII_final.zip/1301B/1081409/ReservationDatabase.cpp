#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
	{
		if (reservations[i].getPhoneNumber() == phoneNumber)
			return true;
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	string timereference[5] = { "","11:30","13:30","17:45", "19:45" };
	int k = 1;
	for (int i = 0; i < reservations.size(); i++)
	{
		if (reservations[i].getPhoneNumber() == phoneNumber)
		{
			if (reservations[i].getPartySize() == 1)
			{
				cout << k << ". " << reservations[i].getPartySize() << " guest  " << reservations[i].getDate().getYear()
					<< " / " << reservations[i].getDate().getMonth() << " / " << reservations[i].getDate().getDay()
					<< "  " << timereference[reservations[i].getTime()] << endl;
			}
			else
			{
				cout << k << ". " << reservations[i].getPartySize() << " guests  " << reservations[i].getDate().getYear()
					<< " / " << reservations[i].getDate().getMonth() << " / " << reservations[i].getDate().getDay()
					<< "  " << timereference[reservations[i].getTime()] << endl;
			}
		}
		k++;
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	Reservation buffer;
	ifstream infile("Reservations.dat", ios::in, ios::binary);
	if (!infile)
	{
		cout << "File could not open!";
		exit(1);
	}

	while (!infile.eof())
	{
		infile.read(reinterpret_cast<char*>(&buffer), sizeof(buffer));
		reservations.push_back(buffer);
	}

	infile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outfile("Reservations.dat", ios::out, ios::binary);
	if (!outfile)
	{
		cout << "File could not open!";
		exit(1);
	}

	for (int i = 0; i < reservations.size(); i++)
	{
		outfile.write(reinterpret_cast<char*>(&reservations[i]), sizeof(reservations[i]));
	}

	outfile.close();
}