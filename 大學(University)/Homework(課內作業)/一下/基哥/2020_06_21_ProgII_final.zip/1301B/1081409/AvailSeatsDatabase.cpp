#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	Date current;
	AvailSeats buffer;
	computeCurrentDate(current);
	for (int i = 0; i < 30; i++)
	{
		buffer.setDate(current);
		current + 1;
		for (int j = 1; j < 5; j++)
			buffer.setNumAvailSeats(j, 20);
		availSeats.push_back(buffer);
	}
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	for (int i = 0; i < availSeats.size(); i++)
	{
		if (availSeats[i].getDate() == date)
		{
			//cout << availSeats[i].getNumAvailSeats(timeCode);
			availSeats[i].setNumAvailSeats(timeCode, availSeats[i].getNumAvailSeats(timeCode) - requiredSeats);
			//cout << availSeats[i].getNumAvailSeats(timeCode);
		}
	}
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	int buffer;
	for (int i = 0; i < availSeats.size(); i++)
	{
		if (availSeats[i].getDate() == date)
		{
			for (int k = 0; k < 5; k++)
			{
				buffer = availSeats[i].getNumAvailSeats(k);
				if (buffer >= requiredSeats)
				{
					return true;
				}
			}
		}
	}
	return false;

}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	for (int i = 0; i < availSeats.size(); i++)
	{
		if (availSeats[i].getDate() == date && availSeats[i].getNumAvailSeats(timeCode) >= requiredSeats)
		{
			return true;
		}
	}
	return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator it;
	for (int i = 0; i < availSeats.size(); i++)
	{
		if (availSeats[i].getDate() == date)
		{
			*it = availSeats[i];
			return it;
		}
	}
	return it;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	AvailSeats buffer;
	ifstream infile("AvailSeats.dat", ios::in, ios::binary);
	if (!infile)
	{
		cout << "File could not open!";
		exit(1);
	}

	while (!infile.eof())
	{
		infile.read(reinterpret_cast<char*>(&buffer), sizeof(buffer));
		availSeats.push_back(buffer);
	}

	infile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outfile("AvailSeats.dat", ios::out, ios::binary);
	if (!outfile)
	{
		cout << "File could not open!";
		exit(1);
	}

	for (int i = 0; i < availSeats.size(); i++)
	{
		outfile.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(availSeats[i]));
	}
	outfile.close();
}