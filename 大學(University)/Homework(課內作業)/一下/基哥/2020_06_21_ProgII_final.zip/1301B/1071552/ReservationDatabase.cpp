#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
		if (phoneNumber == reservations[i].getPhoneNumber())
			return true;
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	cout << endl;
	for (int i = 0,j = 1; i < reservations.size(); i++) {
		if (phoneNumber == reservations[i].getPhoneNumber()) {
			cout << std::right<<setw(2)<<j++ << ". ";
			reservations[i].displayReservationInfo();
		}
	}
	storeReservations();
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	fstream input;
	input.open("Reservations.dat",ios::in|ios::binary);

	Reservation tmp;
	while (input.read(reinterpret_cast<char*>(&tmp), sizeof(tmp)))
	{
		reservations.push_back(tmp);
	}
	input.close();
}

void ReservationDatabase::storeReservations()
{
	fstream output;
	output.open("Reservations.dat", ios::out | ios::binary);
	
	for (int i = 0; i < reservations.size(); i++)
		output.write(reinterpret_cast< char*>(&reservations[i]), sizeof(reservations[i]));

	output.close();
}