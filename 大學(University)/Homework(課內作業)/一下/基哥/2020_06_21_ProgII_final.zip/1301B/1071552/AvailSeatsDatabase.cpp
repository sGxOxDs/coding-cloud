#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{

	availSeats.resize(31);
	Date currentDay;
	computeCurrentDate(currentDay);
	int move = 0;

	
	for (int i = 1; i <= 30; i++) {
		availSeats[i].setDate(currentDay + i);
		for (int j = 1; j <= 4; j++)
			availSeats[i].setNumAvailSeats(j, 20);
	}

	loadAvailSeats();
	
	/*
	for (int i = 0; i < availSeats.size(); i++)
		if (availSeats[i].getDate() < currentDay)
			move++;

	for (int i = 1; i <= move ; i++) {
		AvailSeats tmp;
		tmp.setDate(currentDay +( 30 - move +i));
		//availSeats[i].setDate(currentDay + i);
		for (int j = 1; j <= 4; j++)
			tmp.setNumAvailSeats(j, 20);
		availSeats.push_back(tmp);
	}*/

}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	int tmp;
	tmp = searchAvailSeats(date)->getNumAvailSeats(timeCode) - requiredSeats;
	searchAvailSeats(date)->setNumAvailSeats(timeCode,tmp);
	storeAvailSeats();
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	if (availableTimes(date, 1, requiredSeats)||
		availableTimes(date, 2, requiredSeats)||
		availableTimes(date, 3, requiredSeats)||
		availableTimes(date, 4, requiredSeats))
		return true;
	else
		return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector<AvailSeats>::iterator it = availSeats.begin();
	if (searchAvailSeats(date)->getNumAvailSeats(timeCode) >= requiredSeats)
		return true;
	else
		return false;

}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	for (vector<AvailSeats>::iterator it = availSeats.begin(); it != availSeats.end(); it++) {
		if (it->getDate() == date)
			return it;
	}
	return availSeats.end();
}

void AvailSeatsDatabase::loadAvailSeats()
{
	fstream input;
	input.open("AvailSeats.dat", ios::in | ios::binary);

	AvailSeats tmp;
	while (input.read(reinterpret_cast<char*>(&tmp), sizeof(tmp)))
	{
		availSeats.push_back(tmp);
	}
	input.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	fstream output;
	output.open("AvailSeats.dat", ios::out | ios::binary);

	for (int i = 0; i < availSeats.size(); i++)
		output.write(reinterpret_cast<const char*>(&availSeats[i]), sizeof(availSeats[i]));

	output.close();
}