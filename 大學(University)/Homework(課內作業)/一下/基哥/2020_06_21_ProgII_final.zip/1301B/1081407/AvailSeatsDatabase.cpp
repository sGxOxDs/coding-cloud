#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	Date currentDate;
	computeCurrentDate(currentDate);
	loadAvailSeats();
	Date buffer = currentDate;
	buffer + 1;
	vector< AvailSeats >::iterator it = availSeats.begin();
	for (; it !=availSeats.end() ; it++)
	{
		if (it->getDate()<buffer)
		{
			availSeats.erase(it);
			it = availSeats.begin();
			break;
		}
	}
	
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	if (it==availSeats.end())
	{
		AvailSeats buffer;
		buffer.setDate(date);
		buffer.setNumAvailSeats(timeCode, buffer.getNumAvailSeats(timeCode) + requiredSeats);
		availSeats.push_back(buffer);
	}
	else
	{

		it->setNumAvailSeats(timeCode, it->getNumAvailSeats(timeCode) + requiredSeats);
	}
	
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	if (it == availSeats.end())
	{
		return true;
	}
	for (size_t i = 1; i < 5; i++)
	{
		if (availableTimes(date, i, requiredSeats))
		{
			return true;
		}
	}
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	vector< AvailSeats >::iterator it = searchAvailSeats(date);
	if (it == availSeats.end())
	{
		return true;
	}
	if ((20 - it->getNumAvailSeats(timeCode)) < requiredSeats)
	{
		return false;
	}
	else
		return true;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator it = availSeats.begin();
	for  (; it!=availSeats.end(); it++)
	{
		if (it->getDate() == date)
			return it;
	}
	it = availSeats.end();
	return it;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream inFile("AvailSeats.dat", ios::in | ios::binary);
	if (!inFile)
	{
		ofstream inFile("AvailSeats.dat", ios::out | ios::binary);
		inFile.close();
		return;
	}

	AvailSeats buffer;
	while (!inFile.eof())
	{
		inFile.read(reinterpret_cast<char*>(&buffer), sizeof(buffer));
		if (inFile.eof())
		{
			break;
		}
		availSeats.push_back(buffer);
	}
	inFile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outFile("AvailSeats.dat", ios::out | ios::binary);
	vector<AvailSeats>::iterator it = availSeats.begin();
	for (;it != availSeats.end();it++)
	{
		outFile.write(reinterpret_cast<const char*>(&*it), sizeof(*it));
	}
	outFile.close();
}