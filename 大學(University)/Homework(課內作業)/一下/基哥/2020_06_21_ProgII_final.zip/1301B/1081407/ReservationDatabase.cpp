#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	vector<Reservation>::iterator it = reservations.begin();
	for (; it !=reservations.end(); it++)
	{
		if (it->getPhoneNumber()==phoneNumber)
		{
			return true;
		}
	}
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	cout << endl;
	vector<Reservation>::iterator it = reservations.begin();
	int i = 1;
	for (; it != reservations.end(); it++)
	{
		if (it->getPhoneNumber() == phoneNumber)
		{
			cout <<setw(2)<< i << ". ";
			 it->displayReservationInfo();
			 i++;
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream inFile("Reservations.dat", ios::in | ios::binary);
	if (!inFile)
	{
		ofstream inFile("Reservations.dat", ios::out | ios::binary);
		inFile.close();
		return;
	}
	Reservation buffer;
	while (!inFile.eof())
	{
		inFile.read(reinterpret_cast<char*>(&buffer), sizeof(buffer));
		if (inFile.eof())
		{
			break;
		}
		reservations.push_back(buffer);
	}
	inFile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outFile("Reservations.dat", ios::out | ios::binary);
	vector<Reservation>::iterator it = reservations.begin();
	for (;it!=reservations.end();it++)
	{
		outFile.write(reinterpret_cast<const char*>(&*it), sizeof(*it));
	}
	outFile.close();
}