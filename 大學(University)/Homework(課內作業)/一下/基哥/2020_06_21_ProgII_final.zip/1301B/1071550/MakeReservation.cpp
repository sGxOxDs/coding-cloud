// MakeReservation.cpp
// AvailSeats-function definitions for class MakeReservation.
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "MakeReservation.h"

extern int inputAnInteger( int begin, int end );

MakeReservation::MakeReservation( ReservationDatabase &theReservationDatabase,
   AvailSeatsDatabase &theSeatsDatabase )
   : reservationDatabase( theReservationDatabase ),
     availSeatsDatabase( theSeatsDatabase )
{
}

void MakeReservation::execute()
{
   cout << "\nEnter the party size (1~6): ";

   int partySize;
   do cout << "? ";
   while( ( partySize = inputAnInteger( 1, 6 ) ) == -1 );

   Date currentDate;
   computeCurrentDate( currentDate );

   Date date;
   inputDate( date, currentDate, partySize );

   int timeCode;
   inputTimeCode( timeCode, date, partySize );

   string name;
   cout << "\nEnter name: ";
   cin >> name;

   string phoneNumber;
   cout << "\nEnter phone Number: ";
   cin >> phoneNumber;
   cin.ignore();

   cout << "\nChoose a menu:\n";
   cout << "1. NT$ 1080\n";
   cout << "2. NT$ 1680\n";
   cout << "3. NT$ 2280\n";

   int menuCode;
   do cout << "? ";
   while( ( menuCode = inputAnInteger( 1, 3 ) ) == -1 );

   Reservation newReservation( phoneNumber, name, date, timeCode, partySize, menuCode );

   cout << endl;
   newReservation.displayReservationInfo();

   cout << "\nReservation Completed\n";

   reservationDatabase.pushBack( newReservation );

   availSeatsDatabase.decreaseAvailSeats( date, timeCode, partySize );
}

void MakeReservation::inputDate( Date &date, Date currentDate, int partySize )
{
	int count = 0;
	Date tmp;
	cout << "\nChoose a date" << endl;
	for (int i = 1; i <= 30; i++) {
		tmp = currentDate + i;
		if (availSeatsDatabase.availableTimes(tmp, partySize)) {
			cout << setw(2) << i << ". " << tmp.getYear() << "/";
			if (tmp.getMonth() < 10)cout << "0" << tmp.getMonth() << "/";
			else cout << tmp.getMonth() << "/";
			if (tmp.getDay() < 10)cout << "0" <<tmp.getDay();
			else cout << tmp.getDay();
			cout << "  ";
			count++;
		}
		if (count % 4 == 0)cout << endl;
	}
	int choice = 0;
	while (true) {
		if (count % 4 != 0)cout << endl;
		cout << " ?";
		choice = inputAnInteger(1, 30);
		if (choice == -1)continue;
		if (availSeatsDatabase.availableTimes(currentDate + choice, partySize))break;
	}
	date = currentDate + choice;
}

void MakeReservation::inputTimeCode( int &timeCode, Date date, int partySize )
{
	char time[5][6] = { " ", "11:30", "13:30", "17:45", "19:45" };
	bool available[5] = { false };
	cout << "\nChoose a time" << endl;
	for (int i = 1; i <= 4; i++) {
		if (availSeatsDatabase.availableTimes(date, i, partySize)) {
			cout << i << ". " << time[i] << endl;
			available[i] = true;
		}
	}
	int choice = 0;
	while (!available[choice]) {
		cout << " ?";
		choice = inputAnInteger(1, 4);
		if (choice == -1)choice = 0;
	}
	timeCode = choice;
	//availSeatsDatabase.decreaseAvailSeats(date, timeCode, partySize);
}