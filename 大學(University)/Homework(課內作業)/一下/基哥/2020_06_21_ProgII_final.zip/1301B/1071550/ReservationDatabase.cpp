#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace::std;

#include "ReservationDatabase.h"

ReservationDatabase::ReservationDatabase()
{
   loadReservations();
}

ReservationDatabase::~ReservationDatabase()
{
   storeReservations();
}

bool ReservationDatabase::empty()
{
   return ( reservations.size() == 0 );
}

bool ReservationDatabase::exist( string phoneNumber )
{
	for (int i = 0; i < reservations.size(); i++)
		if (reservations[i].getPhoneNumber() == phoneNumber)return true;
	return false;
}

void ReservationDatabase::displayReservationInfo( string phoneNumber )
{
	int count = 1;
	for (int i = 0; i < reservations.size(); i++ ) {
		if (reservations[i].getPhoneNumber() == phoneNumber) {
			cout << setw(2) << count << ". ";
			reservations[i].displayReservationInfo();
			count++;
		}
	}
}

void ReservationDatabase::pushBack( Reservation newReservation )
{
   reservations.push_back( newReservation );
}

void ReservationDatabase::loadReservations()
{
	ifstream inFile("Reservations.dat", ios::binary);
	if (!inFile) {
		cerr << "File not found" << endl;
		exit(0);
	}
	Reservation tmp;
	//reservations.resize(31);
	inFile.seekg(0, ios::beg);
	while (!inFile.eof()) {
		inFile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
		reservations.push_back(tmp);
	}
	inFile.close();
}

void ReservationDatabase::storeReservations()
{
	ofstream outFile("Reservations.dat", ios::binary);
	if (!outFile) {
		cerr << "File could not be opened" << endl;
		exit(0);
	}
	
	outFile.seekp(0, ios::beg);
	for (int i = 0; i < reservations.size(); i++) {
		outFile.write(reinterpret_cast<char*>(&reservations[i]), sizeof(Reservation));
	}
	outFile.close();
}