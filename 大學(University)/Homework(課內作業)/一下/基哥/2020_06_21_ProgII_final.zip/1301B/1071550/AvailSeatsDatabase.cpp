#include <iostream>
#include <fstream>
using namespace::std;

#include "AvailSeatsDatabase.h"

AvailSeatsDatabase::AvailSeatsDatabase()
{
	loadAvailSeats();

	Date today;
	computeCurrentDate(today);

	vector< AvailSeats > newDatabase;
	newDatabase.resize(31);
	
	AvailSeats empty;
	empty.setDate(Date());
	empty.setNumAvailSeats(0, 0);
	newDatabase.push_back(empty);
	if (availSeats.size() == 1) {
		availSeats.resize(31);
		for (int i = 0; i <= 30; i++) {
			availSeats[i].setDate(today + i);
			for (int j = 0; j <= 4; j++)
				availSeats[i].setNumAvailSeats(j, 20);
		}
		return;
	}
	vector< AvailSeats >::iterator it = availSeats.begin() + 1;
	//= searchAvailSeats(today);
	for (int j = 1; j < availSeats.size(), it != availSeats.end();j++, it++) {
		if (availSeats[j].getDate() == today)break;
	}
		
	if (it->getDate() == (availSeats.begin() + 1)->getDate())return;
	else {
		AvailSeats tmp;
		for (; it != availSeats.end(); it++) {
			tmp = *it;
			newDatabase.push_back(tmp);
		}
		while (newDatabase.size() != 31) {
			tmp.setDate(today + newDatabase.size());
			for (int j = 0; j <= 4; j++)
				tmp.setNumAvailSeats(j, 20);
			newDatabase.push_back(tmp);
		}
	}
	availSeats = newDatabase;
	//availSeats.resize(31);
	/*for (int i = 0; i <= 30; i++) 
		for (int j = 0; j <= 4; j++)
			availSeats[i].setNumAvailSeats(j, 20);
	*/
}

AvailSeatsDatabase::~AvailSeatsDatabase()
{
   storeAvailSeats();
}

void AvailSeatsDatabase::decreaseAvailSeats( Date date, int timeCode, int requiredSeats )
{
	//vector< AvailSeats >::iterator it = searchAvailSeats(date);
	for (int i = 1; i < availSeats.size(); i++) {
		if (date == availSeats[i].getDate()) {
			int originalSeats = availSeats[i].getNumAvailSeats(timeCode);
			availSeats[i].setNumAvailSeats(timeCode, originalSeats - requiredSeats);
			return;
		}
	}
}

bool AvailSeatsDatabase::availableTimes( Date date, int requiredSeats )
{
	for (int i = 1; i <= 4; i++) 
		if (availableTimes(date, i, requiredSeats))return true;
	
	return false;
}

bool AvailSeatsDatabase::availableTimes( Date date, int timeCode, int requiredSeats )
{
	//vector< AvailSeats >::iterator it;
	//it = searchAvailSeats(date);
	for (int i = 1; i < availSeats.size(); i++) 
		if (date == availSeats[i].getDate()) {
			if (availSeats[i].getNumAvailSeats(timeCode) >= requiredSeats)return true;
			else return false;
		}
	//if (it->getNumAvailSeats(timeCode) >= requiredSeats)return true;
	return false;
}

vector< AvailSeats >::iterator AvailSeatsDatabase::searchAvailSeats( Date date )
{
	vector< AvailSeats >::iterator it = availSeats.begin() + 1;
	for (; it != availSeats.end(); it++)
		if (it->getDate() == date)return it;
}

void AvailSeatsDatabase::loadAvailSeats()
{
	ifstream inFile("AvailSeats.dat", ios::binary);
	if (!inFile) {
		cerr << "File not found" << endl;
		exit(0);
	}
	AvailSeats tmp;
	//availSeats.resize(1);
	inFile.seekg(0, ios::beg);
	while (!inFile.eof()) {
		inFile.read(reinterpret_cast<char*>(&tmp), sizeof(tmp));
		availSeats.push_back(tmp);
		cout << "1";
	}
	inFile.close();
}

void AvailSeatsDatabase::storeAvailSeats()
{
	ofstream outFile("AvailSeats.dat", ios::binary);
	if (!outFile) {
		cerr << "File could not be opened" << endl;
		exit(0);
	}
	outFile.seekp(0, ios::beg);
	for (int i = 0; i < availSeats.size(); i++) {
		outFile.write(reinterpret_cast<char*>(&availSeats[i]), sizeof(AvailSeats));
	}
	/*
	vector< AvailSeats >::iterator it = availSeats.begin();
	outFile.seekp(0, ios::beg);
	for (; it != availSeats.end(); it++) {
		outFile.write(reinterpret_cast<char*>(&(*it)), sizeof(AvailSeats));
	}*/
	outFile.close();
}