#pragma once#pragma once
// vector standard header

#ifndef VECTOR_H
#define VECTOR_H

#include <cstddef>

// CLASS TEMPLATE VectorVal
template< typename ValueType >
class VectorVal
{
public:
	using value_type = ValueType;
	using size_type = size_t;
	using difference_type = ptrdiff_t;
	using pointer = value_type*;
	using const_pointer = const value_type*;
	using reference = value_type&;
	using const_reference = const value_type&;

	VectorVal()
		: myFirst(),
		myLast(),
		myEnd()
	{
	}

	pointer myFirst; // pointer to beginning of array
	pointer myLast;  // pointer to current end of sequence
	pointer myEnd;   // pointer to end of array
};


// CLASS TEMPLATE vector
template< typename Ty >
class vector // varying size array of values
{
public:
	using value_type = Ty;
	using pointer = value_type*;
	using const_pointer = const value_type*;
	using reference = Ty&;
	using const_reference = const Ty&;
	using size_type = size_t;
	using difference_type = ptrdiff_t;

private:
	using ScaryVal = VectorVal< Ty >;

public:
	using iterator = value_type*;
	using const_iterator = const value_type*;

	// empty container constructor (default constructor)
	// Constructs an empty container, with no elements.
	vector()
		: myData()
	{
	}

	// fill constructor
	// Constructs a container with "count" elements.
	// Each element is initialized as 0.
	vector(const size_type count)
		: myData()
	{
		if (count != 0)
		{
			Ty* Array = new Ty[count]();
			myData.myFirst = Array;
			myData.myLast = myData.myEnd = Array + count;
		}
	}

	// copy constructor
	// Constructs a container with a copy of each of the elements in "right",
	// in the same order.
	vector(const vector& right)
		: myData()
	{
		pointer Array = new Ty[right.size()]();
		for (int i = 0; i < right.size(); i++) {
			Array[i] = right.begin()[i];
		}
		myData.myFirst = Array;
		myData.myLast = myData.myEnd = Array + right.size();
	}

	// Vector destructor
	// Destroys the container object.
	// Deallocates all the storage capacity allocated by the vector.
	~vector()
	{
		if (myData.myFirst != nullptr)
			delete[] myData.myFirst;
	}

	// The vector is extended by inserting a new element before the element
	// at the specified position, effectively increasing the container size by one.
	// This causes an automatic reallocation of the allocated storage space
	// if and only if the new vector size surpasses the current vector capacity.
	// Relocates all the elements that were after "where" to their new positions.
	iterator insert(const_iterator where, const value_type& val)
	{
		if (where >= myData.myFirst && where <= myData.myLast)
		{
			/*int newsize = this->size() + 1;
			Ty* newArray = nullptr;

			if (newsize < this->capacity() * 3 / 2) {
				newArray = new Ty[this->capacity()*3/2]();
			}
			else {
				newArray = new Ty[newsize]();
			}
			int fromwhere = where - myData.myFirst;
			//insert from begin
			if (fromwhere == 0) {
				newArray[0] = val;
				for (int i = 1; i < newsize; i++) {
					newArray[i] = this->begin()[i - 1];
				}
				delete[]myData.myFirst;
				myData.myFirst = newArray;
				myData.myLast = newArray + newsize;
				if (newsize < this->capacity() * 3 / 2) {
					myData.myEnd = newArray + this->capacity() * 3 / 2;
				}
				else {
					myData.myEnd = newArray + newsize;
				}
			}

			else {
				for (int i = 0; i < fromwhere; i++) {
					newArray[i] = this->begin()[i];
				}
				newArray[fromwhere] = val;
				for (int i = fromwhere + 1; i < this->size(); i++) {
					newArray[i] = this->begin()[i - 1];
				}
				//delete[]myData.myFirst;
				myData.myFirst = newArray;
				myData.myLast = newArray + newsize;
				if (newsize < this->capacity() * 3 / 2) {
					myData.myEnd = newArray + this->capacity() * 3 / 2;
				}
				else {
					myData.myEnd = newArray + newsize;
				}*/
				/*int elements = this->size();
					int newsize = elements + 1;
					Ty* newArray = nullptr;
					int fromwhere = where - myData.myFirst;
					if (newsize < this->capacity() * 3 / 2) {
						newArray = new int[this->capacity() * 3 / 2]();
						//from first
						if (where = myData.myFirst) {
							newArray[0] = val;
							for (int i = 0; i < elements; i++) {
								newArray[i + 1] = this->begin()[i];
							}
						}
						//from else
						else {
							for (int i = 0; i < fromwhere; i++) {
								newArray[i + 1] = this->begin()[i];
							}
							newArray[fromwhere] = val;
							for (int i = fromwhere; i < elements; i++) {
								newArray[i + 1] = this->begin()[i];
							}
						}
						delete[]myData.myFirst;
						myData.myFirst = newArray;
						myData.myLast = newArray + elements;
						myData.myEnd = newArray + this->capacity() * 3 / 2;
					}
					else {
						newArray = new int[newsize];
						if (where = myData.myFirst) {
							newArray[0] = val;
							for (int i = 0; i < elements; i++) {
								newArray[i + 1] = this->begin()[i];
							}
						}
						//from else
						else {
							for (int i = 0; i < fromwhere; i++) {
								newArray[i + 1] = this->begin()[i];
							}
							newArray[fromwhere] = val;
							for (int i = fromwhere; i < elements; i++) {
								newArray[i + 1] = this->begin()[i];
							}
						}
						delete[]myData.myFirst;
						myData.myFirst = newArray;
						myData.myLast = myData.myEnd = newArray + elements;
					}*/

					/*int newsize = this->size() + 1;
						int int_capacity = this->capacity();
						int newcapacity = int_capacity + int_capacity / 2;
						pointer newArray = nullptr;
						if (myData.myFirst == nullptr) {
							newArray = new int[newsize];
							newArray[0] = val;
							for (int i = 1; i < newsize; i++) {
								newArray[i] = this->begin()[i - 1];
							}
							myData.myFirst = newArray;
							myData.myLast = myData.myEnd = newArray + newsize;
						}
						//resize
						else {
							if (newsize > int_capacity) {
								if (newsize <= 4) {
									newArray = new int[newsize]();
								}
								else {
									newArray = new int[newcapacity]();
								}
								//copy
								for (int i = 0; i < this->size(); i++) {
									newArray[i] = this->begin()[i];
								}
								//shift
								for (int i = this->size(); i >= where - myData.myFirst; i--) {
									newArray[i] = this->begin()[i - 1];
								}
								newArray[where - myData.myFirst] = val;
								for (int i = where - myData.myFirst - 1; i >= 0; i--) {
									newArray[i] = this->begin()[i];
								}
								//delete[]myData.myFirst;
								myData.myFirst = newArray;
								myData.myLast = newArray + newsize;
								myData.myEnd = newArray + newcapacity;
							}
							else {
								int temp = this->begin()[where - myData.myFirst];
								this->begin()[where - myData.myFirst] = val;
								for (int i = where - myData.myFirst; i < newsize - 1; i++) {
									int temp2 = this->begin()[i + 1];
									this->begin()[i + 1] = this->begin()[i];
									this->begin()[i] = temp;
									temp = temp2;
								}
								myData.myLast += 1;
							}


						}*/

			int newsize = this->size() + 1;
			int newcapacity = this->capacity() * 3 / 2;
			Ty* newArray = nullptr;
			if (newsize > this->capacity()) {
				if (newsize > newcapacity) {
					newArray = new Ty[newsize];
				}
				else {
					newArray = new Ty[newcapacity];
				}
			}
			newArray = new Ty[newsize];
			int fromwhere = where - myData.myFirst;
			//insert from begin
			if (fromwhere == 0) {
				newArray[0] = val;
				for (int i = 1; i < newsize; i++) {
					newArray[i] = this->begin()[i - 1];
				}
				delete[]myData.myFirst;
				myData.myFirst = newArray;
				myData.myLast = myData.myEnd = newArray + newsize;
			}
			else {
				for (int i = 0; i < fromwhere; i++) {
					newArray[i] = this->begin()[i];
				}
				newArray[fromwhere] = val;
				for (int i = fromwhere + 1; i < newsize; i++) {
					newArray[i] = this->begin()[i - 1];
				}
				delete[]myData.myFirst;
				myData.myFirst = newArray;
				myData.myLast = myData.myEnd = newArray + newsize;
			}
		}
		else {
			return nullptr;
		}
	}
	// Removes from the vector either a single element (where).
	// This effectively reduces the container size by one, which is destroyed.
	// Relocates all the elements after the element erased to their new positions.
	iterator erase(const_iterator where)
	{
		if (where >= myData.myFirst && where < myData.myLast)
		{
			/*int newsize = this->size() - 1;
			int* newArray = new int[newsize];
			int fromwhere = where - myData.myFirst;
			if (fromwhere == 0) {
				for (int i = 0; i < newsize; i++) {
					newArray[i] = this->begin()[i + 1];
				}
				delete[]myData.myFirst;
				myData.myFirst = newArray;
				myData.myLast = myData.myLast = newArray + newsize;
			}
			else {
				for (int i = 0; i < fromwhere; i++) {
					newArray[i] = this->begin()[i];
				}
				for (int i = fromwhere; i < newsize; i++) {
					newArray[i] = this->begin()[i + 1];
				}
			}*/
			/*if (where - myData.myFirst == 0) {
				myData.myFirst += 1;
			}
			else {
				for (int i = where - myData.myFirst; i < this->size() - 1; i++) {
					this->begin()[i] = this->begin()[i + 1];
				}
				myData.myLast -= 1;
			}*/
			int Where = where - myData.myFirst;
			vector::iterator it = this->begin() + Where;
			for (; it != this->end() ; ++it) {

				*it = *(it + 1);

			}
			myData.myLast -= 1;
		}
		else
			return nullptr;
	}

	// Removes all elements from the vector (which are destroyed),
	// leaving the container with a size of 0.
	// A reallocation is not guaranteed to happen,
	// and the vector capacity is not guaranteed to change due to calling this function.
	void clear() // erase all
	{
		myData.myLast = myData.myFirst;
	}

	// Returns an iterator pointing to the first element in the vector.
	// If the container is empty, the returned iterator value shall not be dereferenced.
	iterator begin()
	{
		return myData.myFirst;
	}

	// Returns an iterator pointing to the first element in the vector.
	// If the container is empty, the returned iterator value shall not be dereferenced.
	const_iterator begin() const
	{
		return const_iterator(myData.myFirst);
	}

	// Returns an iterator referring to the past-the-end element in the vector container.
	// The past-the-end element is the theoretical element
	// that would follow the last element in the vector.
	// It does not point to any element, and thus shall not be dereferenced.
	// If the container is empty, this function returns the same as vector::begin.
	iterator end()
	{
		return myData.myLast;
	}

	// Returns an iterator referring to the past-the-end element in the vector container.
	// The past-the-end element is the theoretical element
	// that would follow the last element in the vector.
	// It does not point to any element, and thus shall not be dereferenced.
	// If the container is empty, this function returns the same as vector::begin.
	const_iterator end() const
	{
		return const_iterator(myData.myLast);
	}

	// Returns whether the vector is empty (i.e. whether its size is 0).
	bool empty() const
	{
		return myData.myFirst == myData.myLast;
	}

	// Returns the number of elements in the vector.
	// This is the number of actual objects held in the vector,
	// which is not necessarily equal to its storage capacity.
	size_type size() const
	{
		return static_cast<size_type>(myData.myLast - myData.myFirst);
	}

	// Returns the size of the storage space currently allocated for the vector,
	// expressed in terms of elements.
	// This capacity is not necessarily equal to the vector size.
	// It can be equal or greater, with the extra space allowing to accommodate
	// for growth without the need to reallocate on each insertion.
	size_type capacity() const
	{
		return static_cast<size_type>(myData.myEnd - myData.myFirst);
	}

	// Returns a reference to the element at position "pos" in the vector container.
	value_type& operator[](const size_type pos)
	{
		if (pos >= static_cast<size_type>(myData.myLast - myData.myFirst))
		{
			cout << "vector subscript out of range\n";
			exit(1);
		}

		return myData.myFirst[pos];
	}

	// Returns a reference to the element at position "pos" in the vector container.
	const value_type& operator[](const size_type pos) const
	{
		if (pos >= static_cast<size_type>(myData.myLast - myData.myFirst))
		{
			cout << "vector subscript out of range\n";
			exit(1);
		}

		return myData.myFirst[pos];
	}

private:
	ScaryVal myData;
};

// determine if two Arrays are equal and return true, otherwise return false
template< typename Ty >
bool operator==(const vector< Ty >& left, const vector< Ty >& right)
{
	if (left.size() != right.size()) {
		return false;
	}
	for (int i = 0; i < right.size(); i++) {
		if (left.begin()[i] != right.begin()[i]) {
			return false;
		}
	}
	return true;
}

#endif // VECTOR_H
